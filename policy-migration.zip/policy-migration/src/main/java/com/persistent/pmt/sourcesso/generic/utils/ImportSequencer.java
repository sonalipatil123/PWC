package com.persistent.pmt.sourcesso.generic.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.PropertyConstants;
import com.persistent.pmt.dao.EnvironmentDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.service.AuditRecordService;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.model.Agent;
import com.persistent.pmt.sourcesso.casm.model.AgentConfig;
import com.persistent.pmt.sourcesso.casm.model.AgentGroups;
import com.persistent.pmt.sourcesso.casm.model.AuthScheme;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.model.Domain;
import com.persistent.pmt.sourcesso.casm.reader.impl.DomainReader;
import com.persistent.pmt.sourcesso.casm.reader.impl.UserDirectoryReader;
import com.persistent.pmt.sourcesso.casm.reader.impl.UtilityReader;
import com.persistent.pmt.sourcesso.casm.writer.impl.AgentGroupWriter;
import com.persistent.pmt.sourcesso.casm.writer.impl.AgentWriter;
import com.persistent.pmt.sourcesso.casm.writer.impl.AuthSchemeWriter;
import com.persistent.pmt.sourcesso.casm.writer.impl.DomainWriter;
import com.persistent.pmt.sourcesso.casm.writer.impl.FederationWriter;
import com.persistent.pmt.sourcesso.casm.writer.impl.UserDirectoryWriter;
import com.persistent.pmt.sourcesso.generic.reader.GenericReader;
import com.persistent.pmt.utils.AuditWriter;
@Component
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class ImportSequencer {

	public static final String endpointFile = "CA_FED_Endpoint.xml";
	public static final String attributeAuthorityConfigFile = "CA_FED_AttributeAuthorityConfig.xml";
	public static final String attributeMappingFile = "CA_FED_AttributeMapping.xml";
	public static final String attributeSourceFile = "CA_FED_AttributeSource.xml";
	public static final String statusRedirectsFile = "CA_FED_StatusRedirects.xml";
	public static final String openCookieConfigFile = "CA_FED_OpenCookieConfig.xml";
	public static final String certificateFile = "CA_FED_Certificate.xml";
	public static final String backchannelConfigFile = "CA_FED_BackchannelConfig.xml";
	public static final String userMappingFile = "CA_FED_UserMapping.xml";
	public static final String saml2AttributeFile = "CA_FED_SAML2Attribute.xml";
	public static final String nameIdMgtConfigFile = "CA_FED_NameIDMgtConfig.xml";
	public static final String encryptionConfigFile = "CA_FED_EncryptionConfig.xml";
	public static final String attributeRequesterConfigFile = "CA_FED_AttributeRequesterConfig.xml";

	@Autowired
	@Qualifier("domainReader")
	DomainReader domainReader;

	@Autowired
	@Qualifier("federationReader")
	GenericReader federationReader;

	@Autowired
	@Qualifier("referenceReader")
	GenericReader referenceReader;

	@Autowired
	UtilityReader utilityReader;

	@Autowired
	UtilityReader utilityReaderAttributeAuthorityConfig;

	@Autowired
	UtilityReader utilityReaderAttributeMapping;

	@Autowired
	UtilityReader utilityReaderAttributeSource;

	@Autowired
	UtilityReader utilityReaderStatusRedirects;

	@Autowired
	UtilityReader utilityReaderOpenCookieConfigLink;

	@Autowired
	UtilityReader utilityReaderCertificate;

	@Autowired
	UtilityReader utilityReaderBackchannelConfig;

	@Autowired
	UtilityReader utilityReaderUserMapping;

	@Autowired
	UtilityReader utilityReaderSAML2Attribute;

	@Autowired
	UtilityReader utilityReaderNameIDMgtConfig;

	@Autowired
	UtilityReader utilityReaderEncryptionConfig;

	@Autowired
	UtilityReader utilityReaderRequesterConfig;

	@Autowired
	@Qualifier("agentReader")
	GenericReader agentReader;

	@Autowired
	@Qualifier("agentConfigReader")
	GenericReader agentConfigReader;

	@Autowired
	@Qualifier("authSchemeReader")
	GenericReader authSchemeReader;

	@Autowired
	@Qualifier("agentGroupReader")
	GenericReader agentGroupReader;

	@Autowired
	@Qualifier("userDirectoryReader")
	UserDirectoryReader userDirectoryReader;

	@Autowired
	Environment environment;

	@Autowired
	UserDirectoryWriter userDirectoryWriter;

	@Autowired
	AuthSchemeWriter authSchemeWriter;

	@Autowired
	FederationWriter federationWriter;

	@Autowired
	AgentWriter agentWriter;

	@Autowired
	AgentGroupWriter agentGroupWriter;

	@Autowired
	DomainWriter domainWriter;

	Map<String, GenericReader> readerMap = new HashMap<>();
	
	@Autowired
	ThreadLocal<PMTContext> pmtContextThreadLocal;
	
	@Autowired
	AuditRecordService auditRecordService;
	
	@Autowired
	EnvironmentDao environmentDao;

  @Autowired
  AuditWriter auditWriter;

	private void initialize() {

		LookupUtil.clearContents();
		prepareFixedValues();

	}

	@SuppressWarnings("unchecked")
	public GenericResponse<?> startSequence(Map<String, String> params) throws GenericException {
		
		initialize();
		
		PMTContext pmtContext = pmtContextThreadLocal.get();
		String envName = pmtContext.getEnvironmentValue();
		com.persistent.pmt.model.Environment env = environmentDao.getEnvironmentByName(envName);
		
		int processId = auditRecordService.getMaxProcessIdForImportAll(env.getId());
		pmtContext.setProcessId(Integer.toString(processId));

		Object[] auditArray = new Object[] {};
		referenceReader.readAndSaveData();
		readerMap.put("referenceReader", referenceReader);

		prepareReaderMapForUtilityReaders();

		List<CasmGenericObject> userDirectoriList = (List<CasmGenericObject>) userDirectoryReader.readAndSaveData();
		readerMap.put("userDirectoryReader", userDirectoryReader);

		List<CasmGenericObject> federationPartners = (List<CasmGenericObject>) federationReader.readAndSaveData();
		readerMap.put("federationReader", federationReader);

		List<Domain> domains = (List<Domain>) domainReader.readAndSaveData();
		readerMap.put("domainReader", domainReader);

		federationPartners.addAll(domainReader.getWsFedSP());

		AgentGroups agentGroups = (AgentGroups) agentGroupReader.readAndSaveData();
		readerMap.put("agentGroupReader", agentGroupReader);

		Map<String, Agent> agentMap = (Map<String, Agent>) agentReader.readAndSaveData();
		readerMap.put("agentReader", agentReader);

		Map<String, AgentConfig> agentConfigMap = (Map<String, AgentConfig>) agentConfigReader.readAndSaveData();
		readerMap.put("agentConfigReader", agentConfigReader);

		List<AuthScheme> authSchemes = (List<AuthScheme>) authSchemeReader.readAndSaveData();
		readerMap.put("authSchemeReader", authSchemeReader);

		LookupUtil.setReaders(readerMap);
		LookupUtil.setAgentConfigMap(agentConfigMap);
		LookupUtil.setAgentGroups(agentGroups);
		LookupUtil.setAgentsMap(agentMap);
		LookupUtil.setAuthSchemesData(authSchemes);
		LookupUtil.setUserDirectories(userDirectoriList);

		// Entity Writers
		if (!CasmConstants.STRING_FALSE.equals(params.get("userDirectory"))) {
    	userDirectoryWriter.write(userDirectoriList);
      // Audit record, user directory data populated successful with
      // environment details
      auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS,
          environment.getProperty(AuditPropertyConstants.SOURCE_WRITER_USER_DIRECTORIES), 
          prepareAuditContextString(userDirectoriList.size()),
          auditArray);
    }
					 
    if (!CasmConstants.STRING_FALSE.equals(params.get("authScheme"))) {
    	authSchemeWriter.write(authSchemes);
      // Audit record,auth scheme data populated successful with
      // environment details
      auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS,
          environment.getProperty(AuditPropertyConstants.SOURCE_WRITER_AUTHSCHEME), 
          prepareAuditContextString(authSchemes.size()),
          auditArray);

    }
    if (!CasmConstants.STRING_FALSE.equals(params.get("federation"))) {
       federationWriter.write(federationPartners);
      // Audit record, provider data populated successful with
      // environment details
      auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS,
          environment.getProperty(AuditPropertyConstants.SOURCE_WRITER_FEDERATION), 
          prepareAuditContextString(federationPartners.size()),
          auditArray);

    }
		// Picking agents from LookupUtil
    if (!CasmConstants.STRING_FALSE.equals(params.get("agent"))) {
       agentWriter.write(null);
      // Audit record, agent data populated successful with
      // environment details
      auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS,
          environment.getProperty(AuditPropertyConstants.SOURCE_WRITER_AGENT), 
          prepareAuditContextString(LookupUtil.getAgentsMap().entrySet().size()), 
          auditArray);

    }
			  
		// Picking agentGroups from LookupUtil
    if (!CasmConstants.STRING_FALSE.equals(params.get("agentGroup"))) {
       agentGroupWriter.write(null);
      // Audit record, agent group data populated successful with
      // environment details
      auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS,
          environment.getProperty(AuditPropertyConstants.SOURCE_WRITER_AGENT_GROUP), 
          prepareAuditContextString(LookupUtil.getAgentGroups().getAgentGroups().entrySet().size()),
          auditArray);
    }
		
    if (!CasmConstants.STRING_FALSE.equals(params.get("domain"))) {
       domainWriter.write(domains);
      // Audit record, domain/applications data populated successful
      // with environment details
      auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS_COUNT,
          environment.getProperty(AuditPropertyConstants.SOURCE_WRITER_DOMAIN), 
          prepareAuditContextString(pmtContext.getTotalAppCount()), 
          auditArray);

		}

		GenericResponse<String> wrapperResponse = new GenericResponse<>();
		wrapperResponse.setContent("Application import successful");
		wrapperResponse.setStatusCode(200);
		wrapperResponse.setMessage(GenericResponse.SUCCESS);
		wrapperResponse.setStatus(GenericResponse.SUCCESS);

		return wrapperResponse;
	}

	private void prepareReaderMapForUtilityReaders() throws GenericException {

		utilityReader.readAndSaveData(endpointFile);
		readerMap.put("CA.FED::Endpoint", utilityReader);

		utilityReaderAttributeAuthorityConfig.readAndSaveData(attributeAuthorityConfigFile);
		readerMap.put("CA.FED::AttributeAuthorityConfig", utilityReaderAttributeAuthorityConfig);

		utilityReaderAttributeMapping.readAndSaveData(attributeMappingFile);
		readerMap.put("CA.FED::AttributeMapping", utilityReaderAttributeMapping);

		utilityReaderAttributeSource.readAndSaveData(attributeSourceFile);
		readerMap.put("CA.FED::AttributeSource", utilityReaderAttributeSource);

		utilityReaderStatusRedirects.readAndSaveData(statusRedirectsFile);
		readerMap.put("CA.FED::StatusRedirects", utilityReaderStatusRedirects);

		utilityReaderOpenCookieConfigLink.readAndSaveData(openCookieConfigFile);
		readerMap.put("CA.FED::OpenCookieConfig", utilityReaderOpenCookieConfigLink);

		utilityReaderCertificate.readAndSaveData(certificateFile);
		readerMap.put("CA.FED::Certificate", utilityReaderCertificate);

		utilityReaderBackchannelConfig.readAndSaveData(backchannelConfigFile);
		readerMap.put("CA.FED::BackchannelConfig", utilityReaderBackchannelConfig);

		utilityReaderUserMapping.readAndSaveData(userMappingFile);
		readerMap.put("CA.FED::UserMapping", utilityReaderUserMapping);

		utilityReaderSAML2Attribute.readAndSaveData(saml2AttributeFile);
		readerMap.put("CA.FED::SAML2Attribute", utilityReaderSAML2Attribute);

		utilityReaderNameIDMgtConfig.readAndSaveData(nameIdMgtConfigFile);
		readerMap.put("CA.FED::NameIDMgtConfig", utilityReaderNameIDMgtConfig);

		utilityReaderEncryptionConfig.readAndSaveData(encryptionConfigFile);
		readerMap.put("CA.FED::EncryptionConfig", utilityReaderEncryptionConfig);

		utilityReaderRequesterConfig.readAndSaveData(attributeRequesterConfigFile);
		readerMap.put("CA.FED::AttributeRequesterConfig", utilityReaderRequesterConfig);
	}

	private void prepareFixedValues() {
		LookupUtil.prepareAgentTypes(environment.getProperty(CasmConstants.PROPERTY_AGENT_TYPE));
		LookupUtil.prepareResponseAttrTypes(environment.getProperty(CasmConstants.PROPERTY_AGENT_TYPE_ATTR));

	}
	
	private String prepareAuditContextString(int recordCount) {
		
		StringBuilder contextBuilder = new StringBuilder();
		contextBuilder.append(PMTConstants.IMPORT_Import_Status);
		contextBuilder.append("=");
		contextBuilder.append(PMTConstants.IMPORT_SUCCESSFUL);
		contextBuilder.append("=");
		contextBuilder.append(recordCount);
		contextBuilder.append(PropertyConstants.COMMA);
/*		contextBuilder.append(PMTConstants.IMPORT_FAILED);
		contextBuilder.append("=");
		contextBuilder.append("0");
		contextBuilder.append(PropertyConstants.COMMA); */
		contextBuilder.append(PMTConstants.IMPORT_TOTAL);
		contextBuilder.append("=");
		contextBuilder.append(recordCount);
		
		return contextBuilder.toString();		
	}	
	
}
