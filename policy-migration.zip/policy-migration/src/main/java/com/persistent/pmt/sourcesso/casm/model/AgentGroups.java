package com.persistent.pmt.sourcesso.casm.model;

import java.util.Map;
import java.util.Set;

public class AgentGroups {

	// Map of agent Group Xid as key and comma separated agents in that group as value
  private Map<String, String> groupAgents;
  private Map<String, String> parentToChildGroupsHierarchy;
  private Map<String, String> childToParentGroupsHierarchy;
  private Map<String, String> agentToGroups;
  private Set<String> agentsIds;
  private Map<String, CasmGenericObject> agentGroups;

  public Map<String, String> getGroupAgents() {
    return groupAgents;
  }

  public void setGroupAgents(Map<String, String> groupAgents) {
    this.groupAgents = groupAgents;
  }

  public Map<String, String> getParentToChildGroupsHierarchy() {
    return parentToChildGroupsHierarchy;
  }

  public Map<String, String> getChildToParentGroupsHierarchy() {
    return childToParentGroupsHierarchy;
  }

  public void setChildToParentGroupsHierarchy(
      Map<String, String> childToParentGroupsHierarchy) {
    this.childToParentGroupsHierarchy = childToParentGroupsHierarchy;
  }

  public void setParentToChildGroupsHierarchy(Map<String, String> parentToChildGroupsHierarchy) {
    this.parentToChildGroupsHierarchy = parentToChildGroupsHierarchy;
  }

  public Map<String, String> getAgentToGroups() {
    return agentToGroups;
  }

  public void setAgentToGroups(Map<String, String> agentToGroups) {
    this.agentToGroups = agentToGroups;
  }

  public Set<String> getAgentsIds() {
    return agentsIds;
  }

  public void setAgentsIds(Set<String> agentsIds) {
    this.agentsIds = agentsIds;
  }

  public Map<String, CasmGenericObject> getAgentGroups() {
    return agentGroups;
  }

  public void setAgentGroups(Map<String, CasmGenericObject> agentGroups) {
    this.agentGroups = agentGroups;
  }

  @Override
  public String toString() {
    return "AgentGroup [groupAgents=" + groupAgents + ", groupHierarchy=" + parentToChildGroupsHierarchy
        + ", agentsIds=" + agentsIds + ", agentGroups=" + agentGroups + "]";
  }
}
