package com.persistent.pmt.sourcesso.generic.utils;

import java.util.HashMap;
import java.util.Map;

public class ReferenceUtil {

  private static Map<String, String> references = new HashMap<>();

  public static Map<String, String> getReferences() {
    return references;
  }

  public static void setReferences(Map<String, String> references) {
    ReferenceUtil.references = references;
  }

  public static String getReferenceById(String referenceId) {
    return references.get(referenceId);
  }
}
