package com.persistent.pmt.sourcesso.casm.reader.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
// import com.google.common.base.CaseFormat;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.PropertyConstants;
import com.persistent.pmt.constant.casm.BitMappingEnum;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.model.Domain;
import com.persistent.pmt.sourcesso.casm.model.Policy;
import com.persistent.pmt.sourcesso.casm.model.PolicyLink;
import com.persistent.pmt.sourcesso.casm.model.Realm;
import com.persistent.pmt.sourcesso.casm.model.ResourcePartnerUsers;
import com.persistent.pmt.sourcesso.casm.model.Response;
import com.persistent.pmt.sourcesso.casm.model.ResponseAttr;
import com.persistent.pmt.sourcesso.casm.model.ResponseGroup;
import com.persistent.pmt.sourcesso.casm.model.Rule;
import com.persistent.pmt.sourcesso.casm.model.RuleGroup;
import com.persistent.pmt.sourcesso.casm.model.Samlv2Sp;
import com.persistent.pmt.sourcesso.casm.model.UserPolicy;
import com.persistent.pmt.sourcesso.casm.model.Variable;
import com.persistent.pmt.sourcesso.casm.model.WsFedSP;
import com.persistent.pmt.sourcesso.casm.model.derived.AuthorizationPolicy;
import com.persistent.pmt.sourcesso.casm.model.derived.PolicyResponse;
import com.persistent.pmt.sourcesso.casm.model.derived.ResourceDefinition;
import com.persistent.pmt.sourcesso.casm.reader.AbstractXmlReader;
import com.persistent.pmt.sourcesso.casm.reader.EventReaderContext;
import com.persistent.pmt.sourcesso.generic.response.BaseResponse;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;
import com.persistent.pmt.sourcesso.generic.utils.ReferenceUtil;
import com.persistent.pmt.utils.AuditWriter;

/**
 * @author shishir_kumar XML Reader for reading CA SiteMinder Domain
 *         objects
 */
@PropertySource(value = { "classpath:application.properties", "classpath:auditMessages.properties" })
@Component("domainReader")
public class DomainReader extends AbstractXmlReader {

  @Autowired
  org.springframework.core.env.Environment systemEnvironment;

  @Autowired
  AuditWriter auditWriter;

  private static Logger logger = Logger.getLogger(DomainReader.class);
  public static final String DOMAIN_FILE_NAME = "CA_SM_Domain.xml";
  private final String classname = DomainReader.class.getName();
  private Set<String> authSchemes;
  private Domain globalDomain;
  private Set<String> agents;
  private Set<String> agentGroupIds;
  private List<CasmGenericObject> wsfedSP = new ArrayList<>();
  private List<String> validFileExtensions = new ArrayList<>();

  // Initialization that does not depend on any external factors
  public DomainReader() {
    super();
  }

  @Override
  public BaseResponse readData() {
    return null;
  }

  @Override
  public Object readAndSaveData() throws GenericException {

    final String methodName = "readAndSaveData";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName);

    String fileExtensions =
        systemEnvironment.getProperty(PropertyConstants.VALID_RESOURCE_FILE_EXTENSIONS);
    if (null != fileExtensions) {
      String[] fileExtensionArrays = fileExtensions.split("\\|");
      for (String extension : fileExtensionArrays) {
        validFileExtensions.add(extension);
      }
    }
    authSchemes = new HashSet<>();
    agents = new HashSet<>();
    agentGroupIds = new HashSet<>();

    List<Domain> domainList = getDomainList(authSchemes);

    LookupUtil.setAuthSchemes(authSchemes);
    LookupUtil.setAgentIds(agents);
    LookupUtil.setAgentGroupsIds(agentGroupIds);

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);
    return domainList;
  }

  @Override
  public Object readAndSaveData(String fileName) throws GenericException {
    return null;
  }

  public List<Domain> getDomainList(Set<String> authSchemes) throws GenericException {

    XMLEventReader eventReader = null;
    List<Domain> domainList = new ArrayList<>();
    Domain domainObject;
    EventReaderContext domainReaderContext = getEventReaderContext(DOMAIN_FILE_NAME);

    try {
      eventReader = domainReaderContext.getEventReader();
      while (eventReader.hasNext()) {

        XMLEvent event = eventReader.nextEvent();
        if (event.isStartElement()) {
          StartElement startElement = event.asStartElement();
          String tagName = startElement.getName().getLocalPart();

          if (tagName.equals(XmlTagConstants.OBJECT)) {
            domainObject = (Domain) parseObject(eventReader, event, CasmConstants.DOMAIN, authSchemes);
            String domainMode = domainObject.getProperties().get(XmlTagConstants.MODE);

            if (CasmConstants.GLOBAL.equals(domainMode)) {
              globalDomain = domainObject;

              // Audit details of global domain
              Object[] auditArray = new Object[] { globalDomain.getName() };
              auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS, systemEnvironment
                  .getProperty(AuditPropertyConstants.READER_GLOBAL_DOMAIN_FOUND), "", auditArray);
            } 
            else {
              setExtraDomainProperties(domainObject);
              domainList.add(domainObject);
            }
          }
        }
        if (event.isEndElement()) {
          EndElement endElement = event.asEndElement();
          String tagName = endElement.getName().getLocalPart();

          if (tagName.equals(XmlTagConstants.OBJECT)) {
            continue;
          }
        }
      }
    }
    catch (XMLStreamException e) {
      throw new GenericException("Error while reading domain input stream ", e);
    }
    finally {
      domainReaderContext.closeResources();
    }
    return domainList;
  }

  // Domain has values but not in appropriate placeholder. This
  // function sets
  // values for those
  // placeholders. For example, UserDirectoryLinks
  protected void setExtraDomainProperties(Domain domainObject) {
    try {
      /* START - Store UserDirectory name instead of links */
      List<String> userStores = new ArrayList<String>();
      String[] userStoreLinks =
          StringUtils.delimitedListToStringArray(
              domainObject.getProperties().get("UserDirectoriesLink"), ",");
      if (userStoreLinks != null) {
        for (String link : userStoreLinks) {
          userStores.add(LookupUtil.getName(link));
        }
        domainObject.setUserDirectoryLinks(userStores);
      }
      /* END -Store UserDirectory name instead of links */
    }
    catch (Exception e) {
      // Ignore silently as same information is anyway available in
      // domainObject.
    }
    return;
  }

  protected String getBitMappedValue(String propertyKeyName, String keyNumericValueString) {

    if (XmlTagConstants.MODE.equals(propertyKeyName)) {
      String mode =
          BitMappingEnum.DOMAIN_MODE.getBitMapValue(Integer.parseInt(keyNumericValueString));
      if (null != mode)
        return mode;
    }
    return keyNumericValueString;
  }

  protected void processStringValue(XMLEvent event, String propertyKey,
      Map<String, String> objectPropertyMap, CasmGenericObject genObject) {

    String value = null;
    if (!event.isEndElement()) {
      value = event.asCharacters().getData();
    }
    if (null != objectPropertyMap.get(propertyKey) && null != value) {
      value = objectPropertyMap.get(propertyKey) + CasmConstants.COMMA + value;
    }
    objectPropertyMap.put(propertyKey, value);
    if (XmlTagConstants.NAME.equals(propertyKey))
      genObject.setName(value);
  }

  protected CasmGenericObject getObjectInstance(String objectName) {

    CasmGenericObject genObject = null;

    switch (objectName) {

      case CasmConstants.DOMAIN:
        genObject = new Domain();
        break;

      case CasmConstants.REALM:
        genObject = new Realm();
        break;

      case CasmConstants.RESPONSE:
        genObject = new Response();
        break;

      case CasmConstants.POLICY:
        genObject = new Policy();
        break;

      case CasmConstants.RESPONSE_ATTR:
        genObject = new ResponseAttr();
        break;

      case CasmConstants.RULE:
        genObject = new Rule();
        break;

      case CasmConstants.VARIABLE:
        genObject = new Variable();
        break;

      case CasmConstants.RULE_GROUP:
        genObject = new RuleGroup();
        break;

      case CasmConstants.RESPONSE_GROUP:
        genObject = new ResponseGroup();
        break;

      case CasmConstants.USER_POLICY:
        genObject = new UserPolicy();
        break;

      case CasmConstants.POLICY_LINK:
        genObject = new PolicyLink();
        break;

      case CasmConstants.SAMLV2SP:
        genObject = new Samlv2Sp();
        break;
      case CasmConstants.WSFEDSP:
        genObject = new WsFedSP();
        break;

      case CasmConstants.RESOURCE_PART_USERS:
        genObject = new ResourcePartnerUsers();
        break;
    }
    return genObject;
  }

  protected void processSubObject(XMLEvent event, XMLEventReader eventReader,
      CasmGenericObject genObject, Set<String> authSchemes) throws XMLStreamException,
      GenericException {

    StartElement subObjectStartElement = event.asStartElement();
    String subObjectName =
        removeObjectNameSuffix(subObjectStartElement.getAttributeByName(
            new QName(XmlTagConstants.CLASS)).getValue());

    if (CasmConstants.REALM.equals(subObjectName)) {
      Realm realm = (Realm) parseObject(eventReader, event, subObjectName, authSchemes);
      Domain domain = (Domain) genObject;
      domain.getRealms().add(realm);
      LookupUtil.addXidToNamePair(realm.getxId(), realm.getName());
      deriveRealmHierarchy(realm, domain);
      deriveRealmAttributes(realm, domain);

    }
    else if (CasmConstants.RULE.equals(subObjectName)) {
      Rule rule = (Rule) parseObject(eventReader, event, subObjectName, authSchemes);
      Realm realm = (Realm) genObject;
      LookupUtil.addXidToNamePair(rule.getxId(), rule.getName());
      realm.getRules().add(rule);
      realm.getCommaSeparatedRuleXid().append(rule.getxId() + CasmConstants.COMMA);

    }
    else if (CasmConstants.RESPONSE.equals(subObjectName)) {
      Response response =
          (Response) parseObject(eventReader, event, subObjectName, authSchemes);
      Domain domain = (Domain) genObject;
      LookupUtil.addXidToNamePair(response.getxId(), response.getName());
      String agentType =
          LookupUtil.getResponseAttrType(response.getProperties().get("AgentTypeLink"));
      if (agentType != null) {
        response.getProperties().put("agentType", agentType);
      }
      else {
        response.getProperties().put("agentType", "NOT SUPPORTED");
      }
      domain.getResponses().add(response);

    }
    else if (CasmConstants.POLICY.equals(subObjectName)) {
      Policy policy = (Policy) parseObject(eventReader, event, subObjectName, authSchemes);
      Domain domain = (Domain) genObject;
      domain.getPolicies().add(policy);
      derivePolicyAttributes(policy, domain);

    }
    else if (CasmConstants.POLICY_LINK.equals(subObjectName)) {
      PolicyLink policyLink =
          (PolicyLink) parseObject(eventReader, event, subObjectName, authSchemes);
      Policy policy = (Policy) genObject;
      policy.getPolicyLinks().add(policyLink);

    }
    else if (CasmConstants.RESPONSE_ATTR.equals(subObjectName)) {
      ResponseAttr responseAttr =
          (ResponseAttr) parseObject(eventReader, event, subObjectName, authSchemes);
      String responseType =
          LookupUtil.getResponseAttrType(responseAttr.getProperties().get("AgentTypeAttrLink"));
      if (responseType != null) {
        responseAttr.getProperties().put("type", responseType);
      }
      else {
        responseAttr.getProperties().put("type", "");
      }
      Response response = (Response) genObject;
      response.getResponseAttributes().add(responseAttr);

    }
    else if (CasmConstants.VARIABLE.equals(subObjectName)) {
      Variable variable =
          (Variable) parseObject(eventReader, event, subObjectName, authSchemes);
      Domain domain = (Domain) genObject;
      domain.getVariables().add(variable);

    }
    else if (CasmConstants.RULE_GROUP.equals(subObjectName)) {
      RuleGroup ruleGroup =
          (RuleGroup) parseObject(eventReader, event, subObjectName, authSchemes);
      Domain domain = (Domain) genObject;
      domain.getRuleGroups().add(ruleGroup);

    }
    else if (CasmConstants.RESPONSE_GROUP.equals(subObjectName)) {
      ResponseGroup responseGroup =
          (ResponseGroup) parseObject(eventReader, event, subObjectName, authSchemes);
      Domain domain = (Domain) genObject;
      domain.getResponseGroups().add(responseGroup);

    }
    else if (CasmConstants.USER_POLICY.equals(subObjectName)) {
      UserPolicy userPolicy =
          (UserPolicy) parseObject(eventReader, event, subObjectName, authSchemes);
      userPolicy.getProperties().put("UserDirectory",
          LookupUtil.getName(userPolicy.getProperties().get("UserDirectoryLink")));
      Policy policy = (Policy) genObject;
      policy.getUserPolicies().add(userPolicy);

    }
    else if (CasmConstants.SAMLV2SP.equals(subObjectName)) {
      Samlv2Sp samlv2Sp =
          (Samlv2Sp) parseObject(eventReader, event, subObjectName, authSchemes);
      Domain domain = (Domain) genObject;
      domain.getProperties().put(PMTConstants.PROVIDER_NAME,
          samlv2Sp.getProperties().get(XmlTagConstants.KEY_SPID));
      domain.getProperties().put(CasmConstants.AUTH_TYPE, PMTConstants.PROVIDER_SAML2);

    }
    else if (CasmConstants.WSFEDSP.equals(subObjectName)) {
      WsFedSP wsFedSP = (WsFedSP) parseObject(eventReader, event, subObjectName, authSchemes);
      wsfedSP.add(wsFedSP);
      Domain domain = (Domain) genObject;
      domain.getProperties().put(PMTConstants.PROVIDER_NAME,
          wsFedSP.getProperties().get(XmlTagConstants.KEY_RPID));
      domain.getProperties().put(CasmConstants.AUTH_TYPE, PMTConstants.PROVIDER_WSFEDSP);

    }
    else if (CasmConstants.RESOURCE_PART_USERS.equals(subObjectName)) {
      ResourcePartnerUsers resourcePartnerUsers =
          (ResourcePartnerUsers) parseObject(eventReader, event, subObjectName, authSchemes);
      WsFedSP wsfedSP = (WsFedSP) genObject;
      wsfedSP.setResourcePartnerUsers(resourcePartnerUsers);

    }
    else if (CasmConstants.SERVICE_PROV_USERS.equals(subObjectName)
        || CasmConstants.SAMLV2SP.equals(subObjectName)
        || CasmConstants.EPM_ROLE.equals(subObjectName)) {
      overLookObject(eventReader);
    }
  }

  private CasmGenericObject parseObject(XMLEventReader eventReader, XMLEvent currectEvent,
      String objectName, Set<String> authSchemes) throws XMLStreamException, GenericException {

    CasmGenericObject genObject = getObjectInstance(objectName);
    Map<String, String> objectPropertyMap = genObject.getProperties();
    String propertyKey = null;
    StartElement firstElement = currectEvent.asStartElement();
    genObject
        .setxId(firstElement.getAttributeByName(new QName(XmlTagConstants.Xid)).getValue());

    while (eventReader.hasNext()) {

      XMLEvent event = eventReader.nextEvent();
      if (event.isStartElement()) {
        StartElement startElement = event.asStartElement();
        String tagName = startElement.getName().getLocalPart();

        switch (tagName) {

          case XmlTagConstants.PROPERTY:
            propertyKey =
                removePropertyNameSuffix(startElement.getAttributeByName(
                    new QName(XmlTagConstants.NAME)).getValue());
            break;

          case XmlTagConstants.NUMBER_VALUE:
            event = eventReader.nextEvent();
            objectPropertyMap.put(propertyKey,
                getBitMappedValue(propertyKey, event.asCharacters().getData()));
            break;

          case XmlTagConstants.BOOLEAN_VALUE:
            event = eventReader.nextEvent();
            objectPropertyMap.put(propertyKey, event.asCharacters().getData());
            break;

          case XmlTagConstants.STRING_VALUE:
            event = eventReader.nextEvent();
            processStringValue(event, propertyKey, objectPropertyMap, genObject);
            break;

          case XmlTagConstants.XREF:
            event = eventReader.nextEvent();
            processXref(event, propertyKey, objectPropertyMap);
            break;

          case XmlTagConstants.XID:
            event = eventReader.nextEvent();
            processXid(event, propertyKey, objectPropertyMap, authSchemes);
            break;

          case XmlTagConstants.OBJECT:
            processSubObject(event, eventReader, genObject, authSchemes);
            break;

          default:
            continue;
        }
      }
      else if (event.isEndElement()) {

        EndElement endElement = event.asEndElement();
        String tagName = endElement.getName().getLocalPart();

        if (tagName.equals(XmlTagConstants.OBJECT)) {
          break;
        }
      }
    }
    return genObject;
  }

  private void processXid(XMLEvent event, String propertyKey,
      Map<String, String> objectPropertyMap, Set<String> authSchemes) {

    String xid = event.asCharacters().getData();
    if (null != objectPropertyMap.get(propertyKey)) {
      xid = objectPropertyMap.get(propertyKey) + CasmConstants.COMMA + xid;
    }
    objectPropertyMap.put(propertyKey, xid);
    if (XmlTagConstants.AUTH_SCHEME_LINK.equals(propertyKey))
      authSchemes.add(xid);
  }

  private void processXref(XMLEvent event, String propertyKey,
      Map<String, String> objectPropertyMap) {

    String xref = event.asCharacters().getData();
    String xrefValue = ReferenceUtil.getReferenceById(xref);
    if (null != objectPropertyMap.get(propertyKey)) {
      xrefValue = objectPropertyMap.get(propertyKey) + CasmConstants.COMMA + xrefValue;
    }
    objectPropertyMap.put(propertyKey, xrefValue);
  }

  // This method skips object that we don't intend to process
  // As we are using stream, we still need to read it but ignore.
  private void overLookObject(XMLEventReader eventReader) throws XMLStreamException {

    while (eventReader.hasNext()) {

      XMLEvent event = eventReader.nextEvent();
      if (event.isStartElement()) {
        StartElement startElement = event.asStartElement();
        String tagName = startElement.getName().getLocalPart();

        switch (tagName) {
          case XmlTagConstants.OBJECT:
            overLookObject(eventReader);
            break;

          default:
            continue;
        }
      }
      else if (event.isEndElement()) {

        EndElement endElement = event.asEndElement();
        String tagName = endElement.getName().getLocalPart();

        if (tagName.equals(XmlTagConstants.OBJECT)) {
          break;
        }
      }
    }

  }

  private void derivePolicyAttributes(Policy policy, Domain domain) {
		
/*	  if(domain.getxId().equals("CA.SM::Domain@03-00074455-615b-1213-a31c-835f8ea1fdbf-UK-DEV" )) {
		  System.out.println("got it"); 
	  }	*/
		 
    // get xId of realm in which ruleXid is present
    // check parent realm for above realm
    // If found deduce the filterPath and append it to StringBuilder
    // then append fetchFilter path for original realm
    // append resource attribute of realm
    boolean policyEnabledState =
        Boolean.parseBoolean(policy.getProperties().get(XmlTagConstants.IS_ENABLED));
    if (!policyEnabledState) {
      if (!domain.getProperties().containsKey(CasmConstants.DISABLED_POLICY)) {
    	  domain.getProperties().put(CasmConstants.DISABLED_POLICY, CasmConstants.STRING_TRUE);
      }
    	 
    }

    AuthorizationPolicy authPolicy;
    // Made it set so that we do not get duplicate Authorization
    // policies for single resourceDef
    Set<AuthorizationPolicy> authPolicyList = new LinkedHashSet<>();
    for (UserPolicy userPplocy : policy.getUserPolicies()) {
      authPolicy = new AuthorizationPolicy();
      authPolicy.setUserPolicyLink(userPplocy.getxId());
      Map<String, String> propMap = userPplocy.getProperties();
      authPolicy.setType(propMap.get(XmlTagConstants.FILTER_CLASS));
      authPolicy.setValue(propMap.get(XmlTagConstants.FILTER_PATH));
      String policyFlag = propMap.get(XmlTagConstants.POLICY_FLAGS);
      if (CasmConstants.EXCLUDE.equals(policyFlag) || "1".equals(policyFlag)) {
        authPolicy.setNegateFlag(true);
      }
      authPolicy.setPolicyFlag(policyFlag);
      authPolicy.setUserDirectoryLink(propMap.get(XmlTagConstants.USER_DIRECTORY_LINK));
      authPolicy.setResolutionType(propMap.get(XmlTagConstants.POLICY_RESOLUTION));
      authPolicyList.add(authPolicy);
    }

    for (PolicyLink pLink : policy.getPolicyLinks()) {

      String ruleXid = pLink.getProperties().get(XmlTagConstants.RULE_LINK);
      String ruleGroupLink = pLink.getProperties().get(XmlTagConstants.RULE_GROUP_LINK);

      if (null != ruleXid) {

        processRule(domain, ruleXid, policy, pLink, authPolicyList);

      }
      else if (null != ruleGroupLink) {

        RuleGroup ruleGroup = domain.getRuleGroupByXid(ruleGroupLink);
        if (ruleGroup.getProperties().containsKey(XmlTagConstants.RULES_LINK)) {
          String[] rulesArray =
              ruleGroup.getProperties().get(XmlTagConstants.RULES_LINK).split(CasmConstants.COMMA);
          for (String ruleLink : rulesArray) {
            processRule(domain, ruleLink, policy, pLink, authPolicyList);
          }
        }
      }
    }

  }

  private void processRule(Domain domain, String ruleXid, Policy policy, PolicyLink pLink,
      Set<AuthorizationPolicy> authPolicyList) {

    String agentLink = null;
    Realm realm = new Realm();
    Rule rule = null;
    StringBuilder resourcePath = new StringBuilder();

    for (Realm r : domain.getRealms()) {
      if (r.getCommaSeparatedRuleXid().toString().contains(ruleXid)) {
    	  
/*    	  if(r.getxId().equals("CA.SM::Realm@06-0004d167-af42-1696-a1b8-8360caa70cb3-UK-DEV")) {
    		  System.out.println("2.1");
    	  }*/

        // Only one level of nested realm assumed -- nested realms handled in mapper
/*        if (null != r.getProperties().get(XmlTagConstants.PARENT_REALM_LINK)) {
          Realm parentRealm =
              domain.getRealmByXid(r.getProperties().get(XmlTagConstants.PARENT_REALM_LINK));
          resourcePath.append(parentRealm.getProperties().get(XmlTagConstants.RESOURCE_FILTER));

        }*/
        resourcePath.append(r.getProperties().get(XmlTagConstants.RESOURCE_FILTER));

        rule = r.getRuleByXid(ruleXid);
        if (!checkForLeafNode(resourcePath)) {
          resourcePath.append(CasmConstants.FORWARD_SLASH);
          resourcePath.append(rule.getProperties().get(XmlTagConstants.RESOURCE));
        }
        realm = r;
        agentLink = r.getProperties().get(XmlTagConstants.AGENT_LINK);
        if (null == agentLink)
          agentLink = r.getProperties().get(XmlTagConstants.AGENT_GROUP_LINK);

        break;
      }
    }
    // Create resource definition object and add it to domain
    // agentResourceDef map
    createResourseDefForRule(resourcePath, domain, ruleXid, policy, realm, pLink, agentLink,
        authPolicyList, rule);

  }

  private void createResourseDefForRule(StringBuilder resourcePath, Domain domain,
      String ruleXid, Policy policy, Realm realm, PolicyLink pLink, String agentLink,
      Set<AuthorizationPolicy> authPolicyList, Rule rule) {

    ResourceDefinition resourceDef = new ResourceDefinition();
    if (StringUtils.hasText(resourcePath.toString())) {

      ResourceDefinition resourceDefByRule = domain.getResourceDefinitionByRuleXid(ruleXid);
      ResourceDefinition resourceDefByResourceUri = domain
              .getResourceDefinitionByResourceuri(agentLink + cleanseResourcePath(resourcePath.toString()));

      // Creating only one resourceDefinition object for rules having
      // same link or identical resourceUri
      if (null != resourceDefByResourceUri) {
        domain.getProperties().put(CasmConstants.RULES_CONSOLIDATED, "true");
        resourceDef = resourceDefByResourceUri;
        if (!resourceDef.getRuleLink().contains(ruleXid))
          resourceDef.setRuleLink(resourceDef.getRuleLink() + CasmConstants.COMMA + ruleXid);
        if (!resourceDef.getPolicyLink().contains(policy.getxId()))
          resourceDef.setPolicyLink(resourceDef.getPolicyLink() + CasmConstants.COMMA
              + policy.getxId());

        String actionString =
            getActionString(rule.getProperties().get(XmlTagConstants.ACTIONS), rule
                .getProperties().get(XmlTagConstants.ALLOW_ACCESS));
        if (!resourceDef.getAction().contains(actionString)) {
          resourceDef.setAction(resourceDef.getAction() + CasmConstants.COMMA + actionString);
        }
      }
      else if (null != resourceDefByRule) {
        domain.getProperties().put(CasmConstants.RULES_CONSOLIDATED, "true");
        resourceDef = resourceDefByRule;
        if (!resourceDef.getPolicyLink().contains(policy.getxId()))
          resourceDef.setPolicyLink(resourceDef.getPolicyLink() + CasmConstants.COMMA
              + policy.getxId());

      }
      else {
        resourceDef = createNewResourceDef(ruleXid, policy, realm, resourcePath, rule);
      }
    }
    String responseXid = pLink.getProperties().get(XmlTagConstants.RESPONSE_LINK);
    String responseGroupXid = pLink.getProperties().get(XmlTagConstants.RESPONSE_GROUP_LINK);
    if (null != responseXid) {
      Response res = domain.getResponseByXid(responseXid);
      if (null != res) {
        PolicyResponse policyResponse = getPolicyResponseFromResponseObject(res, rule);
        resourceDef.getResponses().add(policyResponse);
      }
    }
    else if (null != responseGroupXid) {
      ResponseGroup resGroup = domain.getResponseGroupByXid(responseGroupXid);
      if (resGroup.getProperties().containsKey(XmlTagConstants.RESPONSES_LINK)) {
        String[] responseArray =
            resGroup.getProperties().get(XmlTagConstants.RESPONSES_LINK)
                .split(CasmConstants.COMMA);
        for (String responseLink : responseArray) {
          Response res = domain.getResponseByXid(responseLink);
          if (null != res) {
            PolicyResponse policyResponse = getPolicyResponseFromResponseObject(res, rule);
            resourceDef.getResponses().add(policyResponse);
          }
        }
      }
    }
    // fetch responses from global domain
    String domainMode = domain.getProperties().get(XmlTagConstants.MODE);
    if (null != agentLink && null != domainMode
        && CasmConstants.GLOBAL_POLICIES_APPLY.equals(domainMode)) {
      Response globalResponse = getGlobalResponse(agentLink, rule, ruleXid);
      if (null != globalResponse) {
        PolicyResponse pResponse = getPolicyResponseFromResponseObject(globalResponse, rule);
        pResponse.setGlobalResponse(true);
        resourceDef.getResponses().add(pResponse);
        domain.getProperties().put(CasmConstants.HAS_GLOBAL_RESPONSE, "true");
      }
    }

    // Add user Authorization Policy
    resourceDef.getAuthorizationPolicyList().addAll(authPolicyList);

    Map<String, Set<ResourceDefinition>> agentResourceMap = domain.getAgentResourceDefMap();
    Set<ResourceDefinition> resourceDefList;
    if (null != agentLink) { // remove this null check, we should
                             // always get agent or agent group link
      // for a policy of domain
      if (null == agentResourceMap.get(agentLink)) {
        resourceDefList = new HashSet<>();
        resourceDefList.add(resourceDef);
        domain.addToRuleResourceDefMap(resourceDef.getRuleLink(), resourceDef);
        domain.addToResourceUriResourceDefMap(agentLink + resourceDef.getResourceUri(), resourceDef);
        agentResourceMap.put(agentLink, resourceDefList);
      }
      else {
        resourceDefList = agentResourceMap.get(agentLink);
        resourceDefList.add(resourceDef);
        domain.addToRuleResourceDefMap(resourceDef.getRuleLink(), resourceDef);
        domain.addToResourceUriResourceDefMap(agentLink + resourceDef.getResourceUri(), resourceDef);
      }
    }

  }

  /*
   * Map<Agent/AgentGroup, Parent-Child Realm String> Agent/AgentGroup
   * ->Realm1 | Realm1.1 | Realm1.2 ->Real2 | Realm2.1 ->Realm3 In
   * this example, Realm1 and Realm3 are at the same level Realm1.1
   * and Realm1.2 are sub-realms of Realm1 Realm2.1 is subrealm of
   * Realm2 There could be another Agent/AgentGroup in same Domain,
   * the list will continue in that case.
   */
  private void deriveRealmAttributes(Realm realm, Domain domain) {

    String agentXid = realm.getProperties().get(XmlTagConstants.AGENT_LINK);
    if (null == agentXid) {
      agentXid = realm.getProperties().get(XmlTagConstants.AGENT_GROUP_LINK);
      agentGroupIds.add(agentXid);
    }
    else {
      agents.add(agentXid);
    }
    List<String> realmXidList = domain.getAgentRealmMap().get(agentXid);
    if (null == realmXidList) {
      realmXidList = new ArrayList<>();
      realmXidList.add(realm.getxId());
    }
    else {
      String realmParentLink = realm.getProperties().get(XmlTagConstants.PARENT_REALM_LINK);
      if (null == realmParentLink) {
        realmXidList.add(realm.getxId());
      }
      else {
        ListIterator<String> xidIterator = realmXidList.listIterator();
        while (xidIterator.hasNext()) {
          String xid = xidIterator.next();
          if (realmParentLink.equals(xid)) {
            xidIterator.remove();
          }
        }
        realmXidList.add(realmParentLink + CasmConstants.PIPE + realm.getxId());
      }
    }
    domain.getAgentRealmMap().put(agentXid, realmXidList);

    String obsoleteKeywords =
        systemEnvironment.getProperty(PropertyConstants.OBSOLETE_KEYWORDS);

    if (null != obsoleteKeywords) {
      String[] keywordArray = obsoleteKeywords.split(CasmConstants.COMMA);
      for (String keyword : keywordArray) {
        if (null != realm.getName()
            && realm.getName().toUpperCase().contains(keyword.toUpperCase()))
        		domain.getProperties().put(CasmConstants.IS_OBSOLETE, CasmConstants.STRING_TRUE);
      }
    }

  }

  private void deriveRealmHierarchy(Realm realm, Domain domain) {

    String parentRealmLink = realm.getProperties().get(XmlTagConstants.PARENT_REALM_LINK);
    if (null == parentRealmLink) {
      domain.getRealmHierarchy().put(realm.getxId(), null);
    }
    else {
      String value = domain.getRealmHierarchy().get(parentRealmLink);
      if (null == value) {
        domain.getRealmHierarchy().put(parentRealmLink, realm.getxId());
      }
      else {
        value = value + CasmConstants.COMMA + realm.getxId();
        domain.getRealmHierarchy().put(parentRealmLink, value);
      }
    }
  }

  /*
   * private boolean checkForLeafNode(StringBuilder resourcePath) {
   * 
   * //TOOD: change logic of leaf node to determine it from enum //if
   * string after last slash and before ?(if present) is in the list
   * of string then leaf node other wise not boolean isLeafNodeReached
   * = false; String[] resourceSplit =
   * resourcePath.toString().split("/"); if(resourceSplit.length>1) {
   * String leaf = resourceSplit[resourceSplit.length-1];
   * 
   * 
   * if(leaf.contains(".") || leaf.contains("*")) isLeafNodeReached =
   * true; } return isLeafNodeReached; }
   */

  private boolean checkForLeafNode(StringBuilder resourcePath) {

    // TOOD: change logic of leaf node to determine it from enum
    // if string after last slash and before ?(if present) is in the
    // list of string then leaf node other wise not
    boolean isLeafNodeReached = false;
    String[] resourceSplit = resourcePath.toString().split("/");
    if (resourceSplit.length > 1) {
      String leaf = resourceSplit[resourceSplit.length - 1];
      String[] actualLeafArray = leaf.split("\\?");
      String actualLeaf = actualLeafArray[0];

      if (validateFileExtension(actualLeaf) || actualLeaf.contains("*"))
        isLeafNodeReached = true;
    }
    return isLeafNodeReached;
  }

  private boolean validateFileExtension(String actualLeaf) {

    boolean isFileExtensionPresent = false;
    if (actualLeaf.contains(".")) {
      String[] splitArray = actualLeaf.split("\\.");
      if (splitArray.length > 1) {
        String fileExtension = splitArray[1];
        if (validFileExtensions.contains(fileExtension))
          isFileExtensionPresent = true;
      }
    }
    return isFileExtensionPresent;
  }

  private ResourceDefinition createNewResourceDef(String ruleXid, Policy policy, Realm realm,
      StringBuilder resourcePath, Rule rule) {

    ResourceDefinition resourceDef = new ResourceDefinition();
    resourceDef.setRuleLink(ruleXid);
    resourceDef.setPolicyLink(policy.getxId());
    resourceDef.setRealmLink(realm.getxId());
    resourceDef.setResourceUri(cleanseResourcePath(resourcePath.toString()));
    resourceDef.setProtectedStatus(rule.getProperties().get(XmlTagConstants.ALLOW_ACCESS)); // setting
                                                                                            // rule
                                                                                            // specific
                                                                                            // protected
                                                                                            // status,
                                                                                            // 19-Mar
    resourceDef.setAction(getActionString(rule.getProperties().get(XmlTagConstants.ACTIONS),
        rule.getProperties().get(XmlTagConstants.ALLOW_ACCESS)));
    resourceDef.setAuthSchemeLink(realm.getProperties().get(XmlTagConstants.AUTH_SCHEME_LINK));
    return resourceDef;
  }

  private String getActionString(String action, String accessType) {

    StringBuilder formattedActionString = new StringBuilder();
    String[] actionArray = action.split(",");

    int i = 0;
    for (String actionIterator : actionArray) {

      if (i > 0)
        formattedActionString.append(CasmConstants.COMMA);

      formattedActionString.append(actionIterator);
      formattedActionString.append(CasmConstants.PIPE);
      if (CasmConstants.STRING_TRUE.equals(accessType)) {
        formattedActionString.append(CasmConstants.ALLOW);
      }
      else {
        formattedActionString.append(CasmConstants.DENY);
      }
      i++;
    }
    return formattedActionString.toString();
  }

  private Response getGlobalResponse(String agentLink, Rule rule, String ruleXid) {
    Response response = null;
    boolean pLinkFound = false;
    for (Rule globalRule : globalDomain.getRealms().get(0).getRules()) {
      if (agentLink.equals(globalRule.getProperties().get(XmlTagConstants.AGENT_GROUP_LINK))
          || agentLink.equals(globalRule.getProperties().get(XmlTagConstants.AGENT_LINK))) {
        for (Policy policy : globalDomain.getPolicies()) {
          for (PolicyLink pLink : policy.getPolicyLinks()) {
            if (globalRule.getxId()
                .equals(pLink.getProperties().get(XmlTagConstants.RULE_LINK))) {

              String grobalResourceUri =
                  globalRule.getProperties().get(XmlTagConstants.RESOURCE);
              if (null != grobalResourceUri
                  && (grobalResourceUri.equals("*") || grobalResourceUri.equals("/*") || grobalResourceUri
                      .equals(rule.getProperties().get(XmlTagConstants.RESOURCE)))) {

                String responseLink = pLink.getProperties().get(XmlTagConstants.RESPONSE_LINK);
                response = globalDomain.getResponseByXid(responseLink);
                pLinkFound = true;
                break;

              }
            }
          }
          if (pLinkFound)
            break;
        }
        if (pLinkFound)
          break;
      }
    }
    return response;
  }

  private PolicyResponse getPolicyResponseFromResponseObject(Response res, Rule rule) {
    PolicyResponse policyResponse = new PolicyResponse();
    String actions = rule.getProperties().get(XmlTagConstants.ACTIONS);
    if (null != actions) {
      String[] actionsArray = actions.split(CasmConstants.COMMA);
      for (String action : actionsArray) {
        if (StringUtils.startsWithIgnoreCase(action, CasmConstants.ACTION_PREFIX_ON_AUTH)) {
          policyResponse.setAuthenticationType(true);
        }
        else
          policyResponse.setAuthorizationType(true);
      }
    }
    policyResponse.setRuleAction(actions);
    policyResponse.setName(res.getProperties().get(XmlTagConstants.NAME));
    policyResponse.setDesc(res.getProperties().get(XmlTagConstants.DESC));
    policyResponse.setAgentTypeLink(res.getProperties().get(XmlTagConstants.AGENT_TYPE_LINK));
    policyResponse.getResponseAttrList().addAll(res.getResponseAttributes());
    return policyResponse;
  }

  public Set<String> getAuthSchemes() {
    return authSchemes;
  }

  public Domain getGlobalDomain() {
    return globalDomain;
  }

  public Set<String> getAgents() {
    return agents;
  }

  public List<CasmGenericObject> getWsFedSP() {
    return wsfedSP;
  }
}
