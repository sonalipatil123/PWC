package com.persistent.pmt.sourcesso.casm.model.epm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Role extends CasmGenericObject {

}
