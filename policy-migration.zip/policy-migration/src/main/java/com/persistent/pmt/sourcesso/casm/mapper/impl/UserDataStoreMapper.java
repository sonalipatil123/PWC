package com.persistent.pmt.sourcesso.casm.mapper.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.persistent.pmt.model.UserDataStore;
import com.persistent.pmt.model.UserDataStoreAttributes;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.generic.mapper.GenericMapper;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;

@Component("userDataStoreMapper")
public class UserDataStoreMapper implements GenericMapper {
	
	private static Logger logger = Logger.getLogger(UserDataStoreMapper.class);
	private final String classname = UserDataStoreMapper.class.getName();
	
	@Override
	public Object getMappedObject(Object object) {
		final String methodName = "getMappedObject";	
	    CasmGenericObject userDirectory = (CasmGenericObject) object;
	    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName+"and passed parameter is CasmGenericObject "+userDirectory.toString());
	    UserDataStore userDataStore = new UserDataStore();
	    userDataStore.setId(userDirectory.getxId());
	    userDataStore.setName(userDirectory.getProperties().get("CA.SM::UserDirectory.Name"));
	    userDataStore.setDescription(userDirectory.getProperties().get("CA.SM::UserDirectory.Dec"));
	    userDataStore.setNamespace(userDirectory.getProperties().get(
	        "CA.SM::UserDirectory.Namespace"));
	    userDataStore.setServer(userDirectory.getProperties().get("Server"));
	    userDataStore.setSearchRoot(userDirectory.getProperties().get(
	        "CA.SM::UserDirectory.SearchRoot"));
	    userDataStore.setSearchscope(userDirectory.getProperties().get(
	        "CA.SM::UserDirectory.SearchScope"));
	    userDataStore.setUsername(userDirectory.getProperties()
	        .get("CA.SM::UserDirectory.Username"));
	    userDataStore.setPassword(userDirectory.getProperties()
	        .get("CA.SM::UserDirectory.Password"));
	 
	    UserDataStoreAttributes userDataStoreAttributes;
	    List<UserDataStoreAttributes> attributeList = new ArrayList<UserDataStoreAttributes>();
	    for (Entry<String, String> entry : userDirectory.getProperties().entrySet()) {
	
	      userDataStoreAttributes = new UserDataStoreAttributes();
	      userDataStoreAttributes.setSourceAttrName(entry.getKey().substring(
	          entry.getKey().lastIndexOf(".") + 1));
	      userDataStoreAttributes.setSourceAttrValue(entry.getValue());
	      attributeList.add(userDataStoreAttributes);
	    }
	    userDataStore.setAttributes(attributeList);
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName+" and returned value is UserDataStore Object with ID "+userDataStore.getId());
	    return userDataStore;
  }
}
