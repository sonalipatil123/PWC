package com.persistent.pmt.sourcesso.casm.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.sourcesso.casm.model.derived.ResourceDefinition;
import com.persistent.pmt.sourcesso.casm.model.epm.Role;

/**
 * @author shishir_kumar
 * Domain object holds raw and derived attributes
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Domain extends CasmGenericObject {

	private String mode;
	private List<String> userDirectoryLinks = new ArrayList<>();
	private List<Response> responses = new ArrayList<>();
	private List<Realm> realms = new ArrayList<>();
	private List<Policy> policies = new ArrayList<>();
	private List<RuleGroup> ruleGroups = new ArrayList<>();
	private List<ResponseGroup> responseGroups = new ArrayList<>();
	private List<Variable> variables = new ArrayList<>();
	private List<Role> epmRoles = new ArrayList<>();
	//Derived data
	private Map<String, Set<ResourceDefinition>> agentResourceDefMap = new HashMap<>();
	private Map<String, List<String>> agentRealmMap = new HashMap<>();
	private Map<String, String> realmHierarchy = new HashMap<>();
	private Map<String, ResourceDefinition> ruleResourceDefMap = new HashMap<>();
	private Map<String, ResourceDefinition> resourceUriResourceDefMap = new HashMap<>();
	

	  public void addToRuleResourceDefMap(String ruleXid, ResourceDefinition resourceDef) {
	    ruleResourceDefMap.put(ruleXid, resourceDef);
	  }

	  public ResourceDefinition getResourceDefinitionByRuleXid(String ruleXid) {
	    return ruleResourceDefMap.get(ruleXid);
	  }

	  public void addToResourceUriResourceDefMap(String resourceUri,
	      ResourceDefinition resourceDef) {
	    resourceUriResourceDefMap.put(resourceUri, resourceDef);
	  }

	  public ResourceDefinition getResourceDefinitionByResourceuri(String resourceUri) {
	    return resourceUriResourceDefMap.get(resourceUri);
	  }
	  
	public Map<String, String> getRealmHierarchy() {
		return realmHierarchy;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public List<String> getUserDirectoryLinks() {
		return userDirectoryLinks;
	}
	public void setUserDirectoryLinks(List<String> userDirectoryLinks) {
		this.userDirectoryLinks = userDirectoryLinks;
	}
	public List<Response> getResponses() {
		return responses;
	}
	public void setResponses(List<Response> responses) {
		this.responses = responses;
	}
	public List<Realm> getRealms() {
		return realms;
	}
	public void setRealms(List<Realm> realms) {
		this.realms = realms;
	}
	public List<Policy> getPolicies() {
		return policies;
	}
	public void setPolicies(List<Policy> policies) {
		this.policies = policies;
	}
	public List<RuleGroup> getRuleGroups() {
		return ruleGroups;
	}
	public void setRuleGroups(List<RuleGroup> ruleGroups) {
		this.ruleGroups = ruleGroups;
	}
	public List<ResponseGroup> getResponseGroups() {
		return responseGroups;
	}
	public void setResponseGroups(List<ResponseGroup> responseGroups) {
		this.responseGroups = responseGroups;
	}
	public List<Variable> getVariables() {
		return variables;
	}
	public void setVariables(List<Variable> variables) {
		this.variables = variables;
	}
	public List<Role> getEpmRoles() {
		return epmRoles;
	}	
	public Map<String, Set<ResourceDefinition>> getAgentResourceDefMap() {
		return agentResourceDefMap;
	}	
	public Map<String, List<String>> getAgentRealmMap() {
		return agentRealmMap;
	}
	
	public Realm getRealmByXid(String xId) {
		
		Realm realm = null;
		for(Realm r : realms) {
			if(xId.equals(r.getxId())) {
				realm = r;
				break;
			}
		}
		return realm;
	}
	
	public Response getResponseByXid(String xId) {
		
		Response response = null;
		if(null != xId) {
			for(Response r : responses) {
				if(xId.equals(r.getxId())) {
					response = r;
					break;
				}
			}
		}		
		return response;
	}
	
	public ResponseGroup getResponseGroupByXid(String xId) {
		
		ResponseGroup responseGroup = null;
		if(null != xId) {
			for(ResponseGroup rg : responseGroups) {
				if(xId.equals(rg.getxId())) {
					responseGroup = rg;
					break;
				}
			}
		}		
		return responseGroup;
	}

	public RuleGroup getRuleGroupByXid(String xId) {
		
		RuleGroup ruleGroup = null;
		if(null != xId) {
			for(RuleGroup rg : ruleGroups) {
				if(xId.equals(rg.getxId())) {
					ruleGroup = rg;
					break;
				}
			}
		}		
		return ruleGroup;
	}
	
	public Policy getPolicyByXid(String xId) {
		
		Policy policy = null;
		if(null != xId) {
			for(Policy pl : policies) {
				if(xId.equals(pl.getxId())) {
					policy = pl;
					break;
				}
			}
		}		
		return policy;
	}
	
}
