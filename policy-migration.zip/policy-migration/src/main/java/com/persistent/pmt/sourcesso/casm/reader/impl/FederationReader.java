package com.persistent.pmt.sourcesso.casm.reader.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.model.Partner;
import com.persistent.pmt.sourcesso.casm.model.PartnershipBase;
import com.persistent.pmt.sourcesso.casm.reader.AbstractXmlReader;
import com.persistent.pmt.sourcesso.casm.reader.EventReaderContext;
import com.persistent.pmt.sourcesso.generic.response.BaseResponse;
import com.persistent.pmt.sourcesso.generic.utils.ReferenceUtil;

@PropertySource(value = { "classpath:application.properties" })
@Component("federationReader")
public class FederationReader extends AbstractXmlReader {

	private static Logger logger = Logger.getLogger(FederationReader.class);
	public static final String fedIdpBaseFile = "CA_FED_IdPBase.xml";
	public static final String fedSpBaseFile = "CA_FED_SPBase.xml";
	public static final String fedPartnershipBaseFile = "CA_FED_PartnershipBase.xml";
	private final String classname = FederationReader.class.getName();

	@Override
	public Object readAndSaveData() throws GenericException {

		final String methodName = "readAndSaveData";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and no parameter Passed ");

		List<Partner> partners = new ArrayList<Partner>();

		// Create Partner objects for IdPs
		partners.addAll(getIdentityProviders());

		// Create Partner objects for SPs
		partners.addAll(getServiceProviders());

		HashMap<String, Map<String, String>> partnershipBases = getPartnershipBases();

		// Add the partnership base attributes to corresponding Partner
		// objects
		partners = addPartnershipBaseAttributesToPartners(partners,
				partnershipBases);

		logger.log(Level.DEBUG, "Number of Partners: " + partners.size());
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns partners");
		return partners;
	}

	/**
	 * Read IdPBase XML file in to Partner beans.
	 * 
	 * @return
	 * @throws GenericException
	 */
	private List<Partner> getIdentityProviders() throws GenericException {

		final String methodName = "getIdentityProviders";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and no parameters passed");

		XMLEventReader eventReader = null;
		List<Partner> partners = new ArrayList<>();
		EventReaderContext idpReaderContext = getEventReaderContext(fedIdpBaseFile);

		try {

			eventReader = idpReaderContext.getEventReader();
			while (eventReader.hasNext()) {

				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					String tagName = startElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						Partner partner = (Partner) parseObject(eventReader,
								event, CasmConstants.IDPBASE);
						partner.setType(CasmConstants.PARTNER_TYPE_IDP);

						if (partner.getProperties() != null) {
							if (partner.getProperties().containsKey(
									CasmConstants.IS_IDP_REMOTE)) {
								partner.setIsRemote(true);
							} else {
								partner.setIsRemote(false);
							}
						}

						partners.add(partner);
					}
				}
				// If we reach the end of an item element, we add it to the
				// list
				if (event.isEndElement()) {
					EndElement endElement = event.asEndElement();
					String tagName = endElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						continue;
					}
				}
			}
		} catch (XMLStreamException e) {
			throw new GenericException("Error while reading IdP input stream ",
					e);
		} finally {
			idpReaderContext.closeResources();
		}

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns List of Parrtners");
		return partners;
	}

	/**
	 * Read SPBase XML file in to Partner beans.
	 * 
	 * @return
	 * @throws GenericException
	 */
	private List<Partner> getServiceProviders() throws GenericException {

		final String methodName = "getServiceProviders";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and no parameter passed");

		XMLEventReader eventReader = null;
		List<Partner> partners = new ArrayList<>();
		EventReaderContext idpReaderContext = getEventReaderContext(fedSpBaseFile);

		try {

			eventReader = idpReaderContext.getEventReader();
			while (eventReader.hasNext()) {

				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					String tagName = startElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						Partner partner = (Partner) parseObject(eventReader,
								event, CasmConstants.SPBASE);
						partner.setType(CasmConstants.PARTNER_TYPE_SP);

						if (partner.getProperties() != null) {
							if (partner.getProperties().containsKey(
									CasmConstants.IS_SP_REMOTE)) {
								partner.setIsRemote(true);
							} else {
								partner.setIsRemote(false);
							}
						}

						partners.add(partner);
					}
				}
				// If we reach the end of an item element, we add it to the
				// list
				if (event.isEndElement()) {
					EndElement endElement = event.asEndElement();
					String tagName = endElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						continue;
					}
				}
			}
		} catch (XMLStreamException e) {
			throw new GenericException("Error while reading SP input stream ",
					e);
		} finally {
			idpReaderContext.closeResources();
		}

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns List of Partner");
		return partners;
	}

	/**
	 * Read PartnershipBase XML file in to PartnershipBase beans. Then retrive
	 * the data from beans to return a HashMap of complete data. HashMap is
	 * created to easily retrieve the data using IdP/SP XID.
	 * 
	 * @return
	 * @throws GenericException
	 */
	private HashMap<String, Map<String, String>> getPartnershipBases()
			throws GenericException {

		final String methodName = "getPartnershipBases";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and no parameter passed");

		XMLEventReader eventReader = null;
		HashMap<String, Map<String, String>> partnershipBases = new HashMap<String, Map<String, String>>();
		EventReaderContext pbReaderContext = getEventReaderContext(fedPartnershipBaseFile);

		try {

			eventReader = pbReaderContext.getEventReader();
			while (eventReader.hasNext()) {

				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					String tagName = startElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						PartnershipBase partnershipBase = (PartnershipBase) parseObject(
								eventReader, event,
								CasmConstants.PARTNERSHIPBASE);
						if (partnershipBase.getProperties() != null) {
							String remoteLink = partnershipBase.getProperties()
									.get(XmlTagConstants.SPREMOTELINK);
							if (remoteLink == null || remoteLink.isEmpty()) {
								remoteLink = partnershipBase.getProperties()
										.get(XmlTagConstants.IDPREMOTELINK);
							}
							partnershipBase.setPartnerId(remoteLink);
						}

						// Ignoring objects with null remotelink
						if (partnershipBase.getPartnerId() != null
								&& !partnershipBase.getPartnerId().isEmpty()) {
							// Add the partnership base to hashmap
							if (partnershipBases.containsKey(partnershipBase
									.getPartnerId())) {
								partnershipBase
										.setPartnerId(CasmConstants.DUPLICATE_PARTNER_IDENTIFIER_PREFIX
												+ partnershipBase
														.getPartnerId());
							}
							partnershipBases.put(
									partnershipBase.getPartnerId(),
									partnershipBase.getProperties());
						}
					}
				}
				// If we reach the end of an item element, we add it to the
				// list
				if (event.isEndElement()) {
					EndElement endElement = event.asEndElement();
					String tagName = endElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						continue;
					}
				}
			}
		} catch (XMLStreamException e) {
			throw new GenericException(
					"Error while reading PartnershipBase input stream ", e);
		} finally {
			pbReaderContext.closeResources();
		}

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns HashMap of Idp/Sp based Xid");
		return partnershipBases;
	}

	/**
	 * Update Partner beans with data from corresponding PartnershipBase beans
	 * 
	 * @param partners
	 * @param partnershipBases
	 * @return List of updated Partner objects
	 */
	private List<Partner> addPartnershipBaseAttributesToPartners(
			List<Partner> partners,
			HashMap<String, Map<String, String>> partnershipBases) {

		final String methodName = "addPartnershipBaseAttributesToPartners";
		logger.log(
				Level.DEBUG,
				"Entering :: "
						+ classname
						+ ":"
						+ methodName
						+ " and passed parameters are partner List and Map of partnershipBases");

		for (Partner partner : partners) {
			Map<String, String> attributes = partnershipBases.get(partner
					.getxId());

			if (attributes != null && attributes.size() > 0) {
				Map<String, String> existingAttributes = partner
						.getProperties();
				existingAttributes.putAll(attributes);
				partner.setProperties(existingAttributes);
			}
		}

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and List of Partner");
		return partners;
	}

	/**
	 * Parse an Object node to retrieve all the properties in CasmGenericObject
	 * 
	 * @param eventReader
	 *            XMLEventReader handle
	 * @param currectEvent
	 *            XMLEvent object for Object tag
	 * @param objectName
	 *            Type of object
	 * @return CasmGenericObject Object with all the properties of Object node
	 * @throws XMLStreamException
	 * @throws GenericException
	 */
	protected CasmGenericObject parseObject(XMLEventReader eventReader,
			XMLEvent currectEvent, String objectName)
			throws XMLStreamException, GenericException {

		final String methodName = "parseObject";
		logger.log(
				Level.DEBUG,
				"Entering :: "
						+ classname
						+ ":"
						+ methodName
						+ " and passed parameter is eventReader, currectEvent and  objectName :"
						+ objectName);

		CasmGenericObject genObject = getObjectInstance(objectName);
		Map<String, String> objectPropertyMap = new HashMap<>();
		String propertyKey = null;

		StartElement firstElement = currectEvent.asStartElement();
		genObject.setxId((firstElement.getAttributeByName(new QName(
				XmlTagConstants.Xid)).getValue()));

		while (eventReader.hasNext()) {

			XMLEvent event = eventReader.nextEvent();
			if (event.isStartElement()) {
				StartElement startElement = event.asStartElement();
				String tagName = startElement.getName().getLocalPart();

				switch (tagName) {

				case XmlTagConstants.PROPERTY:
					propertyKey = removePropertyNameSuffix(startElement
							.getAttributeByName(new QName(XmlTagConstants.NAME))
							.getValue());
					break;

				case XmlTagConstants.BOOLEAN_VALUE:
					event = eventReader.nextEvent();
					objectPropertyMap.put(propertyKey, event.asCharacters()
							.getData());
					break;

				case XmlTagConstants.NUMBER_VALUE:
					event = eventReader.nextEvent();
					objectPropertyMap.put(
							propertyKey,
							getBitMappedValue(propertyKey, event.asCharacters()
									.getData()));
					break;

				case XmlTagConstants.STRING_VALUE:
					event = eventReader.nextEvent();
					processStringValue(event, propertyKey, objectPropertyMap,
							genObject);
					break;

				case XmlTagConstants.XREF:
					event = eventReader.nextEvent();
					String referenceId = event.asCharacters().getData();
					String referenceValue = ReferenceUtil
							.getReferenceById(referenceId);
					objectPropertyMap.put(propertyKey, referenceValue);
					break;

				case XmlTagConstants.XID:
					event = eventReader.nextEvent();
					processXid(event, propertyKey, objectPropertyMap);
					break;

				default:
					continue;
				}
			} else if (event.isEndElement()) {

				EndElement endElement = event.asEndElement();
				String tagName = endElement.getName().getLocalPart();

				if (tagName.equals(XmlTagConstants.OBJECT)) {
					genObject.setProperties(objectPropertyMap);
					break;
				}
			}
		}

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns CasmGenericObject " + genObject.toString());
		return genObject;
	}

	protected CasmGenericObject getObjectInstance(String objectName) {

		final String methodName = "getObjectInstance";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and passed parameter is objectName " + objectName);

		CasmGenericObject genObject = null;

		switch (objectName) {

		case CasmConstants.IDPBASE:
			genObject = new Partner();
			break;

		case CasmConstants.SPBASE:
			genObject = new Partner();
			break;

		case CasmConstants.PARTNERSHIPBASE:
			genObject = new PartnershipBase();
			break;
		}

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ "and returns CasmGenericObject " + genObject.toString());
		return genObject;
	}

	@Override
	public BaseResponse readData() throws GenericException {
		// Skipped for FederationReader
		return null;
	}

	@Override
	public Object readAndSaveData(String fileName) throws GenericException {
		// Unused for federation reader
		return null;
	}

}
