package com.persistent.pmt.sourcesso.casm.response;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PolicyRulesTo {

	private String realm="";
	private String ruleLink="";
	private String ruleGroupLink="";
	private String responseLink=" ";
	private String responseGroupLink="";

	public String getRealm() {
		return realm;
	}

	public void setRealm(String realm) {
		this.realm = realm;
	}

	public String getRuleLink() {
		return ruleLink;
	}

	public void setRuleLink(String ruleLink) {
		this.ruleLink = ruleLink;
	}

	public String getRuleGroupLink() {
		return ruleGroupLink;
	}

	public void setRuleGroupLink(String ruleGroupLink) {
		this.ruleGroupLink = ruleGroupLink;
	}

	public String getResponseLink() {
		return responseLink;
	}

	public void setResponseLink(String responseLink) {
		this.responseLink = responseLink;
	}

	public String getResponseGroupLink() {
		return responseGroupLink;
	}

	public void setResponseGroupLink(String responseGroupLink) {
		this.responseGroupLink = responseGroupLink;
	}

}
