package com.persistent.pmt.sourcesso.casm.model.derived;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResourceDefinition {

  private String ruleLink;
  private String policyLink;
  private String realmLink;
  private String resourceUri;
  private String protectedStatus;
  private String authSchemeLink;
  private String action;
  private String allowAccess;	
  private Set<AuthorizationPolicy> authorizationPolicyList = new LinkedHashSet<>();
  private Set<PolicyResponse> responses = new HashSet<>();

  private String rootResource;
  
  @Override
  public boolean equals(Object o) {

      if (o == this) 
    	  return true;

      ResourceDefinition resourceDef = (ResourceDefinition) o;   
      if(null==resourceDef)
    	  return false;
  
      return  this.ruleLink.equals(resourceDef.getRuleLink()) &&
    		  this.policyLink.equals(resourceDef.getPolicyLink()) &&
    		  this.resourceUri.equals(resourceDef.getResourceUri()) &&
    		  this.authSchemeLink.equals(resourceDef.getAuthSchemeLink());
  }

  
  @Override
  public int hashCode() {
	  
	  int hash = ruleLink.hashCode() + policyLink.hashCode() + resourceUri.hashCode() + 
			  authSchemeLink.hashCode();
      return hash/47;
  }
  
  public String getRootResource() {
	return rootResource;
  }

  public void setRootResource(String rootResource) {
		this.rootResource = rootResource;
  }

  public String getRuleLink() {
    return ruleLink;
  }

  public void setRuleLink(String ruleLink) {
    this.ruleLink = ruleLink;
  }

  public String getPolicyLink() {
    return policyLink;
  }

  public void setPolicyLink(String policyLink) {
    this.policyLink = policyLink;
  }

  public String getRealmLink() {
    return realmLink;
  }

  public void setRealmLink(String realmLink) {
    this.realmLink = realmLink;
  }

  public String getResourceUri() {
    return resourceUri;
  }

  public void setResourceUri(String resourceUri) {
    this.resourceUri = resourceUri;
  }

  public String getProtectedStatus() {
    return protectedStatus;
  }

  public void setProtectedStatus(String protectedStatus) {
    this.protectedStatus = protectedStatus;
  }

  public String getAuthSchemeLink() {
    return authSchemeLink;
  }

  public void setAuthSchemeLink(String authSchemeLink) {
    this.authSchemeLink = authSchemeLink;
  }

  public String getAction() {
    return action;
  }

  public void setAction(String action) {
    this.action = action;
  }

  public Set<AuthorizationPolicy> getAuthorizationPolicyList() {
    return authorizationPolicyList;
  }

  public Set<PolicyResponse> getResponses() {
    return responses;
  }

  public String getAllowAccess() {
    return allowAccess;
  }

  public void setAllowAccess(String allowAccess) {
    this.allowAccess = allowAccess;
  }

  @Override
  public String toString() {
    return "ResourceDefinition [resourceUri=" + resourceUri + ", protectedStatus="
        + protectedStatus + ", authSchemeLink=" + authSchemeLink + ", action=" + action
        + ", allowAccess=" + allowAccess + ", authorizationPolicyList="
        + authorizationPolicyList + ", responses=" + responses + "]";
  }
	
		
}
