package com.persistent.pmt.sourcesso.casm.reader.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.AgentGroups;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.reader.AbstractXmlReader;
import com.persistent.pmt.sourcesso.casm.reader.EventReaderContext;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;
import com.persistent.pmt.sourcesso.generic.utils.ReferenceUtil;

@Component("agentGroupReader")
@PropertySource(value = { "classpath:application.properties" })
public class AgentGroupReader extends AbstractXmlReader {

	private static Logger logger = Logger.getLogger(AgentGroupReader.class);
	public static final String agentGroupFile = "CA_SM_AgentGroup.xml";
	private final String classname = AgentGroupReader.class.getName();

	private Set<String> agentIds = new HashSet<>();
	private Map<String, String> groupAgents;
	private Map<String, String> parentToChildGroupsHierarchy;
	private Map<String, String> agentToGroup;

	@Override
	public AgentGroups readAndSaveData() throws GenericException {

		final String methodName = "readAndSaveData";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName + " and there is no parameter passed");

		groupAgents = new HashMap<>();
		parentToChildGroupsHierarchy = new HashMap<>();
		agentToGroup = new HashMap<>();

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName + " and returns getAgentGroups");

		return getAgentGroups(LookupUtil.getAgentGroupsIds());
	}

	private AgentGroups getAgentGroups(Set<String> agentGroupsIds) throws GenericException {

		final String methodName = "getAgentGroups";
		logger.log(Level.DEBUG,
				"Entering :: " + classname + ":" + methodName + " and parameter passed is Set of agentGroupsIds");

		AgentGroups agentGroups = new AgentGroups();

		XMLEventReader eventReader = null;
		EventReaderContext readerContext = getEventReaderContext(agentGroupFile);

		HashMap<String, CasmGenericObject> agentGroupsData = new HashMap<>();
		// Clear all
		// groupAgents.clear();
		// agentIds.clear();
		// parentToChildGroupsHierarchy.clear();
		// agentToGroup.clear();

		try {

			eventReader = readerContext.getEventReader();
			while (eventReader.hasNext()) {

				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					String tagName = startElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						CasmGenericObject object = parseObject(eventReader, event);


						if (object != null) {

							LookupUtil.addXidToNamePair(object.getxId(), object.getName());

							if (agentGroupsIds.contains(object.getxId())) {
								agentGroupsData.put(object.getxId(), object);

							}

						}
					}
				}
				// If we reach the end of an item element, we add it to the
				// list
				if (event.isEndElement()) {
					EndElement endElement = event.asEndElement();
					String tagName = endElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						continue;
					}
				}
			}
		} catch (XMLStreamException e) {
			throw new GenericException("Error while reading AgentGroup input stream ", e);
		} finally {
			readerContext.closeResources();
		}

		// Adding agentIds to LookupUtil set
		LookupUtil.getAgentIds().addAll(agentIds);

		Map<String, String> childToParentGroupsHierarchy = getChildToParentGroupsHierarchy();

		// Add the data to AgentGroups bean
		agentGroups.setAgentsIds(agentIds);
		agentGroups.setParentToChildGroupsHierarchy(parentToChildGroupsHierarchy);
		agentGroups.setChildToParentGroupsHierarchy(childToParentGroupsHierarchy);
		agentGroups.setGroupAgents(groupAgents);
		agentGroups.setAgentToGroups(agentToGroup);
		agentGroups.setAgentGroups(agentGroupsData);

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName + " and returns AgentGroups ");

		return agentGroups;
	}

	/**
	 * Parse an Object node to retrieve all the properties in CasmGenericObject
	 * 
	 * @param eventReader
	 *            XMLEventReader handle
	 * @param currectEvent
	 *            XMLEvent object for Object tag
	 * @return CasmGenericObject Object with all the properties of Object node
	 * @throws XMLStreamException
	 * @throws GenericException
	 */
	protected CasmGenericObject parseObject(XMLEventReader eventReader, XMLEvent currectEvent)
			throws XMLStreamException, GenericException {

		final String methodName = "parseObject";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and parameter passed is eventreader and currectEvent");

		CasmGenericObject genObject = new CasmGenericObject();
		Map<String, String> objectPropertyMap = new HashMap<>();
		String propertyKey = null;

		StartElement firstElement = currectEvent.asStartElement();
		genObject.setxId((firstElement.getAttributeByName(new QName(XmlTagConstants.Xid)).getValue()));

		while (eventReader.hasNext()) {

			XMLEvent event = eventReader.nextEvent();
			if (event.isStartElement()) {
				StartElement startElement = event.asStartElement();
				String tagName = startElement.getName().getLocalPart();

				switch (tagName) {

				case XmlTagConstants.PROPERTY:
					propertyKey = removePropertyNameSuffix(
							startElement.getAttributeByName(new QName(XmlTagConstants.NAME)).getValue());
					break;

				case XmlTagConstants.BOOLEAN_VALUE:
					event = eventReader.nextEvent();
					objectPropertyMap.put(propertyKey, event.asCharacters().getData());
					break;

				case XmlTagConstants.NUMBER_VALUE:
					event = eventReader.nextEvent();
					objectPropertyMap.put(propertyKey, getBitMappedValue(propertyKey, event.asCharacters().getData()));
					break;

				case XmlTagConstants.STRING_VALUE:
					event = eventReader.nextEvent();
					processStringValue(event, propertyKey, objectPropertyMap, genObject);
					break;

				case XmlTagConstants.XREF:
					event = eventReader.nextEvent();
					String referenceId = event.asCharacters().getData();
					String referenceValue = ReferenceUtil.getReferenceById(referenceId);
					objectPropertyMap.put(propertyKey, referenceValue);
					break;

				case XmlTagConstants.XID:
					event = eventReader.nextEvent();
					processXid(event, propertyKey, objectPropertyMap, genObject);
					break;

				default:
					continue;
				}
			} else if (event.isEndElement()) {

				EndElement endElement = event.asEndElement();
				String tagName = endElement.getName().getLocalPart();

				if (tagName.equals(XmlTagConstants.OBJECT)) {
					genObject.setProperties(objectPropertyMap);
					break;
				}
			}
		}

		String groupHierarchyValue = (genObject.getProperties() != null)
				? genObject.getProperties().get(XmlTagConstants.AGENTGROUPSLINK)
				: null;

		// Add group hierarchy i.e. agent group id, comma
		// separated list of all the immediate child groups ids
		parentToChildGroupsHierarchy.put(genObject.getxId(), groupHierarchyValue);

		// If any Child AgentGroup is read before current AgentGroup, then
		// add the child groups agents to current group
		// processCurrentGroupWithChildGroupsAgents(genObject.getxId());

		// Add the current group agents to current and parent groups.
		// Current group will be updated with Child AgentGroups agents and
		// self agents. Then, the complete set of agents will be
		// propagated to parent AgentGroups in hierarchy
		processCurrentAndParentGroupsWithAgents(genObject.getxId(), objectPropertyMap.get(XmlTagConstants.AGENTSLINK));

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName + " and returns CasmGenericObject "
				+ genObject.toString());
		return genObject;
	}

	/**
	 * Process XID property to get the value
	 * 
	 * @param event
	 * @param propertyKey
	 * @param objectPropertyMap
	 */
	protected void processXid(XMLEvent event, String propertyKey, Map<String, String> objectPropertyMap,
			CasmGenericObject object) {

		final String methodName = "processXid";
		logger.log(Level.DEBUG,
				"Entering :: " + classname + ":" + methodName + " and passed parameter is propertyKey " + propertyKey);

		String xid = event.asCharacters().getData();

		if (XmlTagConstants.AGENTSLINK.equalsIgnoreCase(propertyKey)) {
			agentIds.add(xid);

			// Add the AgentGroup to agentToGroups map. The key would the
			// AgentXid identified as "xid"
			processAgentToGroups(xid, object.getxId());
		}

		if (null != objectPropertyMap.get(propertyKey)) {
			xid = objectPropertyMap.get(propertyKey) + CasmConstants.COMMA + xid;
		}
		objectPropertyMap.put(propertyKey, xid);

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName + " and doesn't return anything");
	}

	/**
	 * Populates the "agentToGroups" map which contains AgentXid as key and comma
	 * separated list of all AgentGroups which contains the Agent
	 * 
	 * @param agentXid
	 * @param agentGroupXid
	 */
	private void processAgentToGroups(String agentXid, String agentGroupXid) {

		final String methodName = "processAgentToGroups";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName + " and passed parameters are agentXid "
				+ agentXid + " and agentGroupXid " + agentGroupXid);

		if (agentToGroup.get(agentXid) != null) {
			agentGroupXid = agentToGroup.get(agentXid) + CasmConstants.COMMA + agentGroupXid;
		}

		agentToGroup.put(agentXid, agentGroupXid);

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName + " and doesn't return anything");
	}

	/**
	 * Adds agents to groupAgents map. Recursively adds the agents to all the parent
	 * groups
	 * 
	 * @param groupXid
	 * @param agents
	 */
	@SuppressWarnings("rawtypes")
	private void processCurrentAndParentGroupsWithAgents(String groupXid, String agents) {

		final String methodName = "processCurrentAndParentGroupsWithAgents";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName + "and passed parameters are groupXid "
				+ groupXid + " and agents " + agents);

		agents = updateGroupWithAgents(groupXid, agents);

		// If current group has any parent, then add the agents to
		// parent's groupAgents value
		Collection<String> collectionValues = parentToChildGroupsHierarchy.values();
		collectionValues.remove(null);
		String groupHierarchyValues = collectionValues.toString();
		if (groupHierarchyValues != null && groupHierarchyValues.contains(groupXid)) {

			// List of all parent groupxid which has current groupxid as
			// child
			List<String> parentGroupXids = new ArrayList<>();

			for (Map.Entry entry : parentToChildGroupsHierarchy.entrySet()) {
				if (entry.getValue() != null) {
					String entryValue = (String) entry.getValue();
					if (entryValue.contains(groupXid)) {
						// If Map value contains current groupXid, then add it
						// to
						// the parents list
						parentGroupXids.add((String) entry.getKey());
					}
				}
			}

			// Recursively add the agents to parent agents
			for (String parentGroupXid : parentGroupXids) {
				processCurrentAndParentGroupsWithAgents(parentGroupXid, agents);
			}
		}

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName + " and doesn't return anything");
	}

	/**
	 * Update current AgentGroup with agents present in immediate child AgentGroups
	 * 
	 * @param groupXid
	 *            Current AgentGroup XID
	 */
	private void processCurrentGroupWithChildGroupsAgents(String groupXid) {

		final String methodName = "processCurrentGroupWithChildGroupsAgents";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName + " and passed parameter is " + groupXid);

		// If current AgentGroup has any child AgentGroups which were read
		// before current group. Add all the agents of all immediate child
		// AgentGroups to the current AgentGroup
		if (parentToChildGroupsHierarchy.get(groupXid) != null
				&& !parentToChildGroupsHierarchy.get(groupXid).isEmpty()) {
			// Get the comma separated list of child groups xids
			String childGroupsString = parentToChildGroupsHierarchy.get(groupXid);
			String[] childGroupsXids = childGroupsString.split(CasmConstants.COMMA);

			for (String childGroupXid : childGroupsXids) {
				if (groupAgents.get(childGroupXid) != null && !groupAgents.get(childGroupXid).isEmpty()) {
					updateGroupWithAgents(groupXid, groupAgents.get(childGroupXid));
				}
			}
		}
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName + " and doesn't return anything");
	}

	/**
	 * Update the group agents map for given groupXid with provided comma separated
	 * list of agents
	 * 
	 * @param groupXid
	 * @param agents
	 * @return
	 */
	private String updateGroupWithAgents(String groupXid, String agents) {

		final String methodName = "processCurrentGroupWithChildGroupsAgents";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName + " and passed parameter is groupXid "
				+ groupXid + " and agents " + agents);

		String existingAgents = groupAgents.get(groupXid);
		if (existingAgents != null) {
			agents = existingAgents + CasmConstants.COMMA + agents;
		}

		// Only put unique agents
		if (agents != null && !agents.isEmpty()) {
			Set<String> uniqueAgents = new HashSet<>(Arrays.asList(agents.split(CasmConstants.COMMA)));
			agents = uniqueAgents.toString().replace("[", "").replace("]", "").replace(" ", "");
		}
		groupAgents.put(groupXid, agents);
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName + " and returns agents :" + agents);

		return agents;
	}

	/**
	 * Creates map of child group to all the parent groups in upper hierarchy
	 * 
	 * @return
	 */
	private Map<String, String> getChildToParentGroupsHierarchy() {

		final String methodName = "getChildToParentGroupsHierarchy";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName + " and there is no parameter");

		Map<String, String> childToParentGroupsHierarchy = new HashMap<>();

		// Get all the unique values from the ParentToChildGroups map
		Collection<String> childGroups = parentToChildGroupsHierarchy.values();
		Iterator<String> childGroupsIterator = childGroups.iterator();
		Set<String> uniqueChildGroups = new HashSet<>();

		while (childGroupsIterator.hasNext()) {
			String value = childGroupsIterator.next();
			uniqueChildGroups.addAll(Arrays.asList(value.split(CasmConstants.COMMA)));
		}

		for (String childGroup : uniqueChildGroups) {
			String parentGroups = getParentAgentGroups(childGroup);
			childToParentGroupsHierarchy.put(childGroup, parentGroups);
		}

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ "and returns map of child group to all the parent groups in upper hierarchy");
		return childToParentGroupsHierarchy;
	}

	/**
	 * Recursively find all the parent groups for a given AgentGroup
	 * 
	 * @param currentAgentGroup
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	private String getParentAgentGroups(String currentAgentGroup) {

		final String methodName = "getParentAgentGroups";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and passed parameter is currentAgentGroup " + currentAgentGroup);

		String parentAgentGroups = "";
		// Find all the ParentGroups which have current child group
		for (Map.Entry entry : parentToChildGroupsHierarchy.entrySet()) {

			if (entry.getValue() != null) {
				String entryValue = (String) entry.getValue();
				if (entryValue.contains(currentAgentGroup)) {

					String parentGroup = (String) entry.getKey();
					if (parentAgentGroups != null && !parentAgentGroups.isEmpty()) {
						parentAgentGroups = parentAgentGroups + CasmConstants.COMMA + parentGroup;
					} else {
						parentAgentGroups = parentGroup;
					}
					if (parentGroup != null && !parentGroup.isEmpty()) {
						parentAgentGroups = parentAgentGroups + getParentAgentGroups(parentGroup);
					}
				}
			}
		}

		logger.log(Level.DEBUG,
				"Exiting :: " + classname + ":" + methodName + " and returns parentAgentGroups " + parentAgentGroups);
		return parentAgentGroups;
	}

	@Override
	public Object readData() throws GenericException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object readAndSaveData(String fileName) throws GenericException {
		// TODO Auto-generated method stub
		return null;
	}

}
