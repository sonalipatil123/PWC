package com.persistent.pmt.sourcesso.casm.model.derived;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuthorizationPolicy {

  private String userPolicyLink;
  private String type;
  private String value;
  private boolean negateFlag;
  private String policyFlag;
  private String userDirectoryLink;
  private String resolutionType;
  
  @Override
  public boolean equals(Object o) {

      if (o == this) 
    	  return true;
      if (!(o instanceof AuthorizationPolicy)) {
          return false;
      }
      AuthorizationPolicy authPolicy = (AuthorizationPolicy) o;      
      return  Objects.equals(userPolicyLink, authPolicy.getUserPolicyLink());
  }

  
  @Override
  public int hashCode() {
      return userPolicyLink.hashCode();
  }

  
  public String getPolicyFlag() {
	return policyFlag;
}


public void setPolicyFlag(String policyFlag) {
	this.policyFlag = policyFlag;
}


public String getUserPolicyLink() {
    return userPolicyLink;
  }

  public void setUserPolicyLink(String userPolicyLink) {
    this.userPolicyLink = userPolicyLink;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public boolean isNegateFlag() {
    return negateFlag;
  }

  public void setNegateFlag(boolean negateFlag) {
    this.negateFlag = negateFlag;
  }

  public String getUserDirectoryLink() {
    return userDirectoryLink;
  }

  public void setUserDirectoryLink(String userDirectoryLink) {
    this.userDirectoryLink = userDirectoryLink;
  }

  public String getResolutionType() {
    return resolutionType;
  }

  public void setResolutionType(String resolutionType) {
    this.resolutionType = resolutionType;
  }

  @Override
  public String toString() {
    return "AuthorizationPolicy [userPolicyLink=" + userPolicyLink + ", type=" + type
        + ", value=" + value + ", negateFlag=" + negateFlag + ", userDirectoryLink="
        + userDirectoryLink + ", resolutionType=" + resolutionType + "]";
  }
  
  


}
