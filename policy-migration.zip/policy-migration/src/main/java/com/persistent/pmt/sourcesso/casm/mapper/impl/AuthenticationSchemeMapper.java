package com.persistent.pmt.sourcesso.casm.mapper.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.persistent.pmt.model.AuthenticationScheme;
import com.persistent.pmt.model.AuthenticationSchemeAttributes;
import com.persistent.pmt.sourcesso.casm.model.AuthScheme;
import com.persistent.pmt.sourcesso.casm.model.SAMLv2IdP;
import com.persistent.pmt.sourcesso.casm.model.WSFEDIdP;
import com.persistent.pmt.sourcesso.generic.mapper.GenericMapper;

@Component("authenticationSchemeMapper")
public class AuthenticationSchemeMapper implements GenericMapper {

	private static Logger logger = Logger.getLogger(AuthenticationSchemeMapper.class);
	private final String classname = AuthenticationSchemeMapper.class.getName();

	@Override
	public Object getMappedObject(Object source) {
		final String methodName = "getMappedObject";

		AuthScheme authScheme = (AuthScheme) source;
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ "and passed parameter is AuthScheme with ID " + authScheme.getxId());

		Map<String, String> propertymap = authScheme.getProperties();
		String authSchemeId = authScheme.getxId();
		String authSchemeName = authScheme.getName();
		String authSchemeNameLevel = propertymap.get("Level");
		String authSchemeType = propertymap.get("Type");
		String description = propertymap.get("Desc");
		try {
			if (authSchemeType.equals("SAML2")) {
				SAMLv2IdP samlv2IdP = authScheme.getSamlv2IdP();
				if (samlv2IdP != null) {
					propertymap.putAll(samlv2IdP.getProperties());
				}
			} else if (authSchemeType.equals("WSFED")) {
				WSFEDIdP wsfedIdP = authScheme.getWsFedIdP();
				if (wsfedIdP != null) {
					propertymap.putAll(wsfedIdP.getProperties());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		AuthenticationScheme authenticationscheme = new AuthenticationScheme();
		authenticationscheme.setId(authSchemeId);
		authenticationscheme.setName(authSchemeName);
		authenticationscheme.setLevel(authSchemeNameLevel);
		authenticationscheme.setType(authSchemeType);
		authenticationscheme.setDescription(description);
		List<AuthenticationSchemeAttributes> authenticationSchemeAttributesList = new ArrayList<>();
		if (propertymap.containsKey("Desc")) {
			propertymap.remove("Desc");

			for (Map.Entry<String, String> attr : propertymap.entrySet()) {
				AuthenticationSchemeAttributes authenticationSchemeAttributes = new AuthenticationSchemeAttributes();
				authenticationSchemeAttributes.setSourceAttrName(attr.getKey());
				authenticationSchemeAttributes.setSourceAttrValue(attr.getValue()); // resolve partnership source name
																					// from saml2Idp reader
				authenticationSchemeAttributesList.add(authenticationSchemeAttributes);
			}
			authenticationscheme.setAttributes(authenticationSchemeAttributesList);
		}
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName + "and return value is AuthScheme : "
				+ authenticationscheme.toString());

		return authenticationscheme;
	}

}
