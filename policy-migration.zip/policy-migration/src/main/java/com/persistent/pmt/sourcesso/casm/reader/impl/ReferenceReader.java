package com.persistent.pmt.sourcesso.casm.reader.impl;

import java.util.HashMap;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.reader.AbstractXmlReader;
import com.persistent.pmt.sourcesso.casm.reader.EventReaderContext;
import com.persistent.pmt.sourcesso.generic.response.BaseResponse;
import com.persistent.pmt.sourcesso.generic.utils.ReferenceUtil;

@Component("referenceReader")
@PropertySource(value = { "classpath:application.properties" })
public class ReferenceReader extends AbstractXmlReader {

	private static Logger logger = Logger.getLogger(ReferenceReader.class);
	public static final String referenceFile = "CA_SM_References.xml";
	private final String classname = ReferenceReader.class.getName();

	@Override
	public Map<String, String> readAndSaveData() throws GenericException {

		final String methodName = "readAndSaveData";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and No parameters passed");

		EventReaderContext referenceReaderContext = getEventReaderContext(referenceFile);
		Map<String, String> references = new HashMap<>();

		try {
			XMLEventReader eventReader = referenceReaderContext
					.getEventReader();

			while (eventReader.hasNext()) {

				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					String tagName = startElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.REFERENCES)) {
						CasmGenericObject object = parseObject(eventReader,
								event);
						references.putAll(object.getProperties());
					}
				}
				// If we reach the end of an item element, we add it to the
				// list
				if (event.isEndElement()) {
					EndElement endElement = event.asEndElement();
					String tagName = endElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.REFERENCES)) {
						continue;
					}
				}
			}
		} catch (XMLStreamException e) {
			throw new GenericException(
					"Error while reading reference input stream ", e);
		} finally {
			referenceReaderContext.closeResources();
		}

		// Setting references in ReferenceUtil to be consumed by other
		// readers
		ReferenceUtil.setReferences(references);

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns References");
		return references;
	}

	/**
	 * Parse a References node to retrieve all the properties in
	 * CasmGenericObject
	 * 
	 * @param eventReader
	 *            XMLEventReader handle
	 * @param currectEvent
	 *            XMLEvent object for Object tag
	 * @return CasmGenericObject Object with all the properties of Object node
	 * @throws XMLStreamException
	 */
	protected CasmGenericObject parseObject(XMLEventReader eventReader,
			XMLEvent currectEvent) throws XMLStreamException {

		final String methodName = "parseObject";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and passed parameters are  eventReader and currectEvent");

		CasmGenericObject genObject = new CasmGenericObject();
		Map<String, String> objectPropertyMap = new HashMap<>();
		String propertyKey = null;

		StartElement firstElement = currectEvent.asStartElement();
		Attribute firstElementAttribute = firstElement
				.getAttributeByName(new QName(XmlTagConstants.Xid));
		if (firstElementAttribute != null) {
			genObject.setxId(firstElementAttribute.getValue());
		}

		while (eventReader.hasNext()) {

			XMLEvent event = eventReader.nextEvent();
			if (event.isStartElement()) {
				StartElement startElement = event.asStartElement();
				String tagName = startElement.getName().getLocalPart();

				switch (tagName) {

				case XmlTagConstants.STRING_VALUE:
					event = eventReader.nextEvent();
					processStringValue(event, propertyKey, objectPropertyMap,
							genObject);
					break;

				case XmlTagConstants.REFERENCE_VALUE:
					propertyKey = startElement.getAttributeByName(
							new QName(XmlTagConstants.REFERENCEID)).getValue();
					break;

				default:
					continue;
				}
			} else if (event.isEndElement()) {

				EndElement endElement = event.asEndElement();
				String tagName = endElement.getName().getLocalPart();

				if (tagName.equals(XmlTagConstants.REFERENCES)) {
					genObject.setProperties(objectPropertyMap);
					break;
				}
			}
		}

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns CasmGenericObject " + genObject.toString());
		return genObject;
	}

	@Override
	public BaseResponse readData() throws GenericException {

		return null;
	}

	@Override
	protected String getBitMappedValue(String propertyKeyName,
			String keyNumericValueString) {

		return null;
	}

	@Override
	public Object readAndSaveData(String fileName) throws GenericException {
		// TODO Auto-generated method stub
		return null;
	}

}
