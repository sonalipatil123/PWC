package com.persistent.pmt.sourcesso.generic.service;

import java.util.Map;

import org.springframework.data.domain.PageImpl;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.response.GenericResponse;


/**
 * @author shishir_kumar
 *
 */
public interface DataImportService {

  public GenericResponse<?> importPrecheck() throws com.persistent.pmt.exception.GenericException;
	/**
	 * Get details of application in NEW state by id
	 * 
	 * @param id
	 * @return
	 * @throws GenericException
	 */
	public GenericResponse<?> importNewApplication(int id)
			throws GenericException;

	/**
	 * Get summary of all applications in NEW state
	 * 
	 * @return
	 * @throws GenericException
	 * @throws com.persistent.pmt.exception.GenericException
	 */
  public PageImpl<Map<String, String>> importApplicationsSummary(Map<String, String> params)
			throws GenericException;

	public GenericResponse<?> importApplicationDataFromSource(Map<String, String> params)
			throws GenericException;

	public GenericResponse<?> importAgent(int id) throws GenericException;

	public GenericResponse<?> importAllAgents() throws GenericException;

	public GenericResponse<?> importAuthenticationScheme(int id)
			throws GenericException;

	public GenericResponse<?> importAllAuthenticationSchemes()
			throws GenericException;

	public GenericResponse<?> importUserDirectory(int id)
			throws GenericException;

	public GenericResponse<?> importAllUserDirectories()
			throws GenericException;

	public GenericResponse<?> importPartner(int id) throws GenericException;

	public GenericResponse<?> importAllPartners() throws GenericException;

}
