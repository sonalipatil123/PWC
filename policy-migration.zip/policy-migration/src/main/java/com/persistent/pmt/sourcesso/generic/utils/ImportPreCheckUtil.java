package com.persistent.pmt.sourcesso.generic.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.persistent.pmt.exception.GenericException;

public class ImportPreCheckUtil {

  private static final Logger logger = Logger.getLogger(ImportPreCheckUtil.class);

  /**
   * This method checks if basepath is exists or not
   * 
   * @param basePath
   * @return
   */
  public static boolean basePathExists(String basePath) {
    if (CommonUtils.isDirectoryExists(basePath)) {
      return true;
    }
    else {
      return false;
    }

  }

  /**
   * This method checks if environment folder exists or not
   * 
   * @param basePath
   * @param environmentNamelowerCase
   * @return
   */
  public static boolean environmentFolderExists(String basePath, String environmentName) {

    if (CommonUtils.isDirectoryExists(basePath + "/" + environmentName)) {
      return true;
    }
    else {
      return false;
    }
  }

  /**
   * This method checks if SiteMinderObjectTypes file present in
   * basepath
   * 
   * @param basepath
   * @param completeFileName
   * @return
   * @throws IOException
   */
  public static boolean completeFileExists(String basepath, String completeFileName)
      throws IOException {

    if (CommonUtils.checkIfFileExists(basepath, completeFileName)) {
      return true;
    }

    return false;
  }

  /**
   * This method checks if siteminder objects files are present in
   * environment folder or not
   * 
   * @param basePath
   * @param environmentName
   * @param files
   * @return
   */
  public static boolean isSMFileSplitComplete(String basePath, String environmentName,
      List<String> files) {

    boolean status = false;
    for (String file : files) {
      if (CommonUtils.checkIfFileExists(basePath + "/" + environmentName, file)) {
        status = true;
      }
      else {
        status = false;
        break;
      }
    }
    return status;
  }

  /**
   * This method reads the SiteMinderObjectTypesFile line by line and
   * replace dot(.) & double colon(::) in each filename with
   * underscore("_") and returns list of updated filenames
   * 
   * @param basePath
   * @param fileName
   * @return
   * @throws GenericException
   * @throws IOException
   */
  public static List<String> readSiteMinderObjectTypesFile(String basePath, String fileName)
      throws GenericException {

    List<String> files = new ArrayList<>();
    if (CommonUtils.checkIfFileExists(basePath, fileName)) {
      BufferedReader reader = null;
      try {
        reader = new BufferedReader(new FileReader(basePath + "/" + fileName));

        String fileNameInFile = reader.readLine();
        String newFileName;
        while (fileNameInFile != null) {
          newFileName = fileNameInFile.replace(".", "_");
          newFileName = newFileName.replace("::", "_").concat(".xml");
          files.add(newFileName);
          fileNameInFile = reader.readLine();
        }
        // References object does not follow same convention
        // Hence, file name is fixed here.
        files.add("CA_SM_References.xml");

      }
      catch (IOException ie) {
        logger
            .error("Error while closing bufferred reeaer objet inside readSiteMinderObjectTypesFile "
                + fileName);
        throw new GenericException("Error while reading file '" + fileName + "'.", ie);
      }
      finally {
        if (null != reader) {
          try {
            reader.close();
          }
          catch (IOException e) {
            logger
                .error("Error while closing bufferred reeaer objet inside readSiteMinderObjectTypesFile "
                    + fileName);
          }
        }
      }
    }
    return files;
  }

}
