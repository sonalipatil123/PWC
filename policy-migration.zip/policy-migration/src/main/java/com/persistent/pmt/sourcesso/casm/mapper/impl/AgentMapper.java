package com.persistent.pmt.sourcesso.casm.mapper.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.AgentAttributes;
import com.persistent.pmt.sourcesso.casm.model.Agent;
import com.persistent.pmt.sourcesso.casm.model.AgentConfig;
import com.persistent.pmt.sourcesso.casm.model.AgentGroups;
import com.persistent.pmt.sourcesso.generic.mapper.GenericMapper;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;

@Component("agentMapper")
public class AgentMapper implements GenericMapper {

  private static Logger logger = Logger.getLogger(AgentMapper.class);
  private final String classname = AgentMapper.class.getName();

  private AgentGroups agentGroups;

  @Override
  public Object getMappedObject(Object source) throws GenericException {
    final String methodName = "getMappedObject";
    Agent agent = (Agent) source;
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameter is Agent with ID " + agent.getxId());
    
    Map<String, Object> map = new HashMap<>();
    String agentId = agent.getxId();
    String agentName = agent.getName();
    String description = agent.getProperties().get("Desc");
    com.persistent.pmt.model.Agent pmtAgent = new com.persistent.pmt.model.Agent();
    pmtAgent.setId(agentId);
    pmtAgent.setName(agentName);
    pmtAgent.setDescription(description);
    pmtAgent.setType("Agent");
    Map<String, String> properties = agent.getProperties();
    if (properties.containsKey("Name") || properties.containsKey("Desc")) {
      properties.remove("Name");
      properties.remove("Desc");
    }
    List<AgentAttributes> agentAttributesList = new ArrayList<>();
    for (Map.Entry<String, String> property : properties.entrySet()) {
      AgentAttributes agentAttributes = new AgentAttributes();
      agentAttributes.setSourceAttrName(property.getKey());
      agentAttributes.setSourceAttrValue(property.getValue());
      agentAttributesList.add(agentAttributes);

    }
    AgentConfig agentConfig = agent.getAgentConfig();
    if (agentConfig != null) {
      Map<String, String> attrpair = processAttributePairMap(agentConfig.getAttributePair());
      Map<String, Set<String>> agentToFQDN = agentConfig.getAgentToFQDN();
      AgentAttributes fqdnAttribute = new AgentAttributes();
      fqdnAttribute.setSourceAttrName("fqdn");
      fqdnAttribute.setSourceAttrValue(StringUtils.join(agentToFQDN.get(agent.getName()), ','));
      agentAttributesList.add(fqdnAttribute);
      for (Map.Entry<String, String> attribute : attrpair.entrySet()) {
        AgentAttributes agentAttributes = new AgentAttributes();
        agentAttributes.setSourceAttrName(attribute.getKey());
        agentAttributes.setSourceAttrValue(attribute.getValue());
        agentAttributesList.add(agentAttributes);

      }
    }
    else {      
      map.put("configFlag", "false");
    }

    AgentAttributes agentAttributes = new AgentAttributes();
    agentAttributes.setSourceAttrName("Agent_Parent");
    String sourceAttributeValue =
        LookupUtil.resolveXidToName(LookupUtil.getAgentGroups().getAgentToGroups()
            .get(agent.getxId()));
    agentAttributes.setSourceAttrValue(sourceAttributeValue);
    agentAttributesList.add(agentAttributes);
    pmtAgent.setAttributes(agentAttributesList);

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and returned value is " + pmtAgent.getId());
    
    map.put("agent", pmtAgent);
    return map;

  }

  /**
   * This method process the attrpair map and returns a map with only
   * required attributes
   * 
   * @param attrpair
   * @return
   */

  private Map<String, String> processAttributePairMap(Map<String, String> attrpair) {
    final String methodName = "processAttributePairMap";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameter size is " + attrpair.size());
    Map<String, String> agentConfigAttrPair = new HashMap<>();
    // TODO: set first value of FQDN as agent's attribute
    if (attrpair != null) {

      for (Map.Entry<String, String> attr : attrpair.entrySet()) {
        if (attr.getValue() != null) {
          if (attr.getKey().startsWith("#")) {
            continue;
          }
          else {
            try {
              String value = URLDecoder.decode(attr.getValue(), "UTF-8");
              agentConfigAttrPair.put(attr.getKey(), value);
            }
            catch (UnsupportedEncodingException e) {

              e.printStackTrace();
            }
          }

        }

      }
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "and return value map size is " + agentConfigAttrPair.size());

    return agentConfigAttrPair;
  }

  public AgentGroups getAgentGroups() {
    return agentGroups;
  }

  public void setAgentGroups(AgentGroups agentGroups) {
    this.agentGroups = agentGroups;
  }

}
