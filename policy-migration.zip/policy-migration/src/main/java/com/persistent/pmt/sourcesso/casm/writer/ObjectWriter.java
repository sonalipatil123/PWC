package com.persistent.pmt.sourcesso.casm.writer;

import java.util.List;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;

public interface ObjectWriter {

	public void write(List<? extends CasmGenericObject> objects) throws GenericException;
}
