package com.persistent.pmt.sourcesso.casm.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author umesh_waghode Domain response for REST API
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DomainTo {

	private String name;
	private String domainName;
	private String isAffiliate;
	private String userDirectoryLink;
	private String mode;
	private String description;
	private String agentGroupLink;// ignore for now
	private String type; // if domain.getProperties(IsAffiliateDomain) is "1". set type="Federated" else
							// set it to "Agent"
	private String agent; // Ignore
	private List<String> userDirectoryLinks = new ArrayList<>();
	private List<ResponseTo> responses = new ArrayList<>();
	private List<ResponseGroupTo> responseGroups = new ArrayList<>();// not needed now
	private List<RealmTo> realms = new ArrayList<>();
	private List<PolicyTo> policies = new ArrayList<>();
	private List<RuleGroupTo> ruleGroups = new ArrayList<>();// not needed now

	private boolean isObsolete;
	private boolean hasGlobalResponse;
	private boolean disabledPolicy;
	private boolean rulesConsolidated;
	private boolean agentHierResConsolidated;
	private String providerName;

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsAffiliate() {
		return isAffiliate;
	}

	public void setIsAffiliate(String isAffiliate) {
		this.isAffiliate = isAffiliate;
	}

	public String getUserDirectoryLink() {
		return userDirectoryLink;
	}

	public void setUserDirectoryLink(String userDirectoryLink) {
		this.userDirectoryLink = userDirectoryLink;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAgentGroupLink() {
		return agentGroupLink;
	}

	public void setAgentGroupLink(String agentGroupLink) {
		this.agentGroupLink = agentGroupLink;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<String> getUserDirectoryLinks() {
		return userDirectoryLinks;
	}

	public void setUserDirectoryLinks(List<String> userDirectoryLinks) {
		this.userDirectoryLinks = userDirectoryLinks;
	}

	public List<ResponseTo> getResponses() {
		return responses;
	}

	public void setResponses(List<ResponseTo> responses) {
		this.responses = responses;
	}

	public List<ResponseGroupTo> getResponseGroups() {
		return responseGroups;
	}

	public void setResponseGroups(List<ResponseGroupTo> responseGroups) {
		this.responseGroups = responseGroups;
	}

	public List<RealmTo> getRealms() {
		return realms;
	}

	public void setRealms(List<RealmTo> realms) {
		this.realms = realms;
	}

	public List<PolicyTo> getPolicies() {
		return policies;
	}

	public void setPolicies(List<PolicyTo> policies) {
		this.policies = policies;
	}

	public List<RuleGroupTo> getRuleGroups() {
		return ruleGroups;
	}

	public void setRuleGroups(List<RuleGroupTo> ruleGroups) {
		this.ruleGroups = ruleGroups;
	}

	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}

	public boolean isObsolete() {
		return isObsolete;
	}

	public void setObsolete(boolean isObsolete) {
		this.isObsolete = isObsolete;
	}

	public boolean isHasGlobalResponse() {
		return hasGlobalResponse;
	}

	public void setHasGlobalResponse(boolean hasGlobalResponse) {
		this.hasGlobalResponse = hasGlobalResponse;
	}

	public boolean isDisabledPolicy() {
		return disabledPolicy;
	}

	public void setDisabledPolicy(boolean disabledPolicy) {
		this.disabledPolicy = disabledPolicy;
	}

	public boolean isRulesConsolidated() {
		return rulesConsolidated;
	}

	public void setRulesConsolidated(boolean rulesConsolidated) {
		this.rulesConsolidated = rulesConsolidated;
	}

	public boolean isAgentHierResConsolidated() {
		return agentHierResConsolidated;
	}

	public void setAgentHierResConsolidated(boolean agentHierResConsolidated) {
		this.agentHierResConsolidated = agentHierResConsolidated;
	}

	public String isProviderName() {
		return providerName;
	}

	public void setProviderName(String string) {
		this.providerName = string;
	}

}
