package com.persistent.pmt.sourcesso.casm.writer.impl;

import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.dao.UserDataStoreDao;
import com.persistent.pmt.model.UserDataStore;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.writer.ObjectWriter;
import com.persistent.pmt.sourcesso.generic.mapper.GenericMapper;

@Component("userDirectoryWriter")
@PropertySource(value = { "classpath:application.properties" })
public class UserDirectoryWriter implements ObjectWriter {

  private static Logger logger = Logger.getLogger(UserDirectoryWriter.class);
  private final String classname = UserDirectoryWriter.class.getName();	
	
  @Autowired
  @Qualifier("userDataStoreDao")
  UserDataStoreDao userDataStoreDao;
  
  @Autowired
  @Qualifier("userDataStoreMapper")
  GenericMapper userDataStoreMapper;

  public void write(List<? extends CasmGenericObject> userDirectories) throws com.persistent.pmt.exception.GenericException {
	  
    final String methodName = "write";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName+" and the passed parameter is List of userDirectories that extends CasmGenericObject");  
	  
    for (CasmGenericObject userDirectory : userDirectories) {
    	  UserDataStore userDataStore = (UserDataStore) userDataStoreMapper.getMappedObject(userDirectory);
      	  userDataStoreDao.createUserDataStore(userDataStore);
    }
    
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);  

  }
  
}
