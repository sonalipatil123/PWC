package com.persistent.pmt.sourcesso.casm.model;

import java.util.Map;

public class References {

	private Map<String, String> referenceMap;

	public Map<String, String> getReferenceMap() {
		return referenceMap;
	}

	public void setReferenceMap(Map<String, String> referenceMap) {
		this.referenceMap = referenceMap;
	}
	
}
