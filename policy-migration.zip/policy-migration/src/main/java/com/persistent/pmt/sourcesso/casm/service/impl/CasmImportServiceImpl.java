package com.persistent.pmt.sourcesso.casm.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.constant.ApplicationFilter;
import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.PropertyConstants;
import com.persistent.pmt.dao.ApplicationDao;
import com.persistent.pmt.dao.EnvironmentDao;
import com.persistent.pmt.dao.ServerConfigurationDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.ApplicationSummary;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.model.PropertyStore;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.service.ServerConfigurationService;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.mapper.impl.DomainResponseMapper;
import com.persistent.pmt.sourcesso.casm.model.Domain;
import com.persistent.pmt.sourcesso.casm.response.DomainTo;
import com.persistent.pmt.sourcesso.casm.response.ImportPrecheckResponse;
import com.persistent.pmt.sourcesso.generic.spi.ImportService;
import com.persistent.pmt.sourcesso.generic.utils.ImportPreCheckUtil;
import com.persistent.pmt.sourcesso.generic.utils.ImportSequencer;
import com.persistent.pmt.utils.AuditWriter;
import com.persistent.pmt.utils.MapperUtils;

/**
 * Implementation class for application import functionality
 */
@Service("casmImportService")
public class CasmImportServiceImpl implements ImportService {

  private static final Logger logger = Logger.getLogger(CasmImportServiceImpl.class);

  @Autowired
  ApplicationDao applicationDao;

  @Autowired
  EnvironmentDao environmentDao;

  @Autowired
  ImportSequencer importSequencer;

  @Autowired
  ServerConfigurationService serverConfigurationService;

  @Autowired
  ServerConfigurationDao serverConfigurationDao;

  @Autowired
  Environment environment;

  @Autowired
  DomainResponseMapper domainResponseMapper;

  @Autowired
  ThreadLocal<PMTContext> pmtContextThreadLocal;

  @Autowired
  AuditWriter auditWriter;

  @Override
  public PageImpl<Map<String, String>> getNewApplicationsSummary(Map<String, String> params)
      throws GenericException {

    PageRequest pageable = null;
    long totalCount = 0;
    List<Map<String, String>> applications = null;

    PMTContext pmtContext = pmtContextThreadLocal.get();
    if (validateRequestFilter(pmtContext)) {

      com.persistent.pmt.model.Environment lifecycle = getEnvironment();
      if (lifecycle != null) {

        checkDataImportStatus(lifecycle.getId());
        // getting total number of application counts in drafted state
        totalCount =
            (applicationDao.getApplicationCount(lifecycle.getId(),
                com.persistent.pmt.constant.ApplicationState.getImportSummaryStates()))
                .longValue();

        List<ApplicationSummary> applicationSummaryEntities =
            applicationDao.getApplicationsSummary(lifecycle.getId(),
                com.persistent.pmt.constant.ApplicationState.getImportSummaryStates(),
                pmtContext.getPagingDetails());
        if (applicationSummaryEntities != null && !applicationSummaryEntities.isEmpty()) {
          applications = new ArrayList<Map<String, String>>();
          for (ApplicationSummary applicationSummaryEntity : applicationSummaryEntities) {
            applications.add(MapperUtils.getApplicationSummaryTO(applicationSummaryEntity));
          }
          // paging
          pageable =
              new PageRequest(pmtContext.getPagingDetails().get("page"), pmtContext
                  .getPagingDetails().get("numberPerPage"));
        }
        else {
          throw new GenericException(
              "The server successfully processed the request but applications data not found.",
              HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
        }
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
    return new PageImpl<>(applications, pageable, totalCount);

  }

  @Override
  public GenericResponse<?> getNewApplicationById(int id) throws GenericException {

    Application applications = applicationDao.getApplicationById(id);
    GenericResponse<DomainTo> response = new GenericResponse<>();
    Domain domain = null;
    if (applications != null) {
      try {
        String sourceRawData = applications.getSourceRawData();
        if (sourceRawData != null) {
          domain =
              new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
                  false).readValue(sourceRawData, Domain.class);
        }
      }
      catch (IOException e) {
        throw new GenericException("Error while reading application source data.",
            HttpStatus.INTERNAL_SERVER_ERROR.value(), GenericResponse.FAILURE);
      }
      DomainTo domainTo = null;
      if (domain != null) {
        domainTo = domainResponseMapper.processfields(domain);
        // reverting name: from application name to domain name
        // because of diff api
        domainTo.setName(domainTo.getDomainName());

        response.setContent(domainTo);
        response.setStatusCode(HttpStatus.OK.value());
        response.setMessage("Application found.");
        response.setStatus(GenericResponse.SUCCESS);
      }
      else {
        throw new GenericException(
            "The server successfully processed the request but application source data not found.",
            HttpStatus.NOT_FOUND.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException(
          "The server successfully processed the request but application data not found.",
          HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
    }
    return response;
  }

  @Override
  public GenericResponse<?> importApplicationData(Map<String, String> params)
      throws GenericException {

    return importSequencer.startSequence(params);

  }

  @Override
  public GenericResponse<?> importAndSaveApplicationData() throws GenericException {
    // Unused
    return null;
  }

  public GenericResponse<?> importPrecheck() throws GenericException {

    ImportPrecheckResponse importPreCheckResponse = new ImportPrecheckResponse();

    PMTContext pmtContext = pmtContextThreadLocal.get();
    int environmentId;
    String lifecycle = null;
    if (validateRequestFilter(pmtContext)) {
      logger.debug("CasmImportServiceImpl | importPrecheck | Retrieved pmtcontext "
          + pmtContext);
      com.persistent.pmt.model.Environment lifecycleEntry;
      lifecycleEntry = getEnvironment();
      if (lifecycleEntry != null) {
        environmentId = lifecycleEntry.getId();
        lifecycle = lifecycleEntry.getName();

        String basepath = environment.getProperty(CasmConstants.PROPERTY_CASM_XML_BASE_PATH);
        String importPropertyKey = environment.getProperty(PropertyConstants.IMPORT_STATUS);
        String propertyResponse =
            serverConfigurationService.getPropertyValue(importPropertyKey);
        List<PropertyStore> propStoreList =
            serverConfigurationDao.checkOtherImportInProgress(importPropertyKey);

        boolean status = false;
        logger.debug("CasmImportServiceImpl | importPrecheck |" + importPropertyKey + "="
            + propertyResponse);

        if ((CasmConstants.IMPORT_STATUS_IMPORTED).equalsIgnoreCase(propertyResponse)) {
          status = true;
          importPreCheckResponse.setImportStatusCode(HttpStatus.OK.value());
          importPreCheckResponse.setImportStatus(propertyResponse);
          importPreCheckResponse.setMessage(lifecycle + " environment's import status is "
              + propertyResponse);

        }
        else if (CasmConstants.IMPORT_STATUS_IMPORTING.equalsIgnoreCase(propertyResponse)) {
          status = true;
          importPreCheckResponse.setImportStatusCode(HttpStatus.OK.value());
          importPreCheckResponse.setImportStatus(CasmConstants.IMPORT_STATUS_IMPORTING);
          importPreCheckResponse.setMessage("Import is in progress for this environment.");

        }
        else if (propStoreList.size() > 0) {
          status = true;
          importPreCheckResponse.setImportStatusCode(HttpStatus.OK.value());
          importPreCheckResponse.setImportStatus(CasmConstants.IMPORT_STATUS_IMPORTINGOTHER);
          importPreCheckResponse
              .setMessage("Import is in progress for some other environment.");

        }
        else if (CasmConstants.IMPORT_STATUS_FAILED.equalsIgnoreCase(propertyResponse)) {
          status = true;
          importPreCheckResponse.setImportStatusCode(HttpStatus.OK.value());
          importPreCheckResponse.setImportStatus(CasmConstants.IMPORT_STATUS_FAILED);
          importPreCheckResponse
              .setMessage("Import is in progress for some other environment.");

        }
        else if (ImportPreCheckUtil.basePathExists(basepath)) {
          String completeFileName =
              environment.getProperty(CasmConstants.PROPERTY_CASM_OBJECT_TYPES);
          if (ImportPreCheckUtil.environmentFolderExists(basepath, lifecycle)) {
            logger
                .debug("CasmImportServiceImpl | importPrecheck | Environment folder exists at base path ");
            try {
              if (ImportPreCheckUtil.completeFileExists(basepath, completeFileName)) {
                logger
                    .debug("CasmImportServiceImpl | importPrecheck | SiteMinderObjectTypes text file  exists at base path ");
                if (ImportPreCheckUtil.isSMFileSplitComplete(basepath, lifecycle,
                    ImportPreCheckUtil
                        .readSiteMinderObjectTypesFile(basepath, completeFileName))) {
                  logger
                      .debug("CasmImportServiceImpl | importPrecheck | Detected that PolicyData xml file has been already split. ");
                  status = true;
                  importPreCheckResponse.setImportStatusCode(HttpStatus.OK.value());
                  importPreCheckResponse
                      .setImportStatus(CasmConstants.IMPORT_STATUS_READYTOIMPORT);
                  importPreCheckResponse.setMessage(lifecycle + "_PolicyData.xml");
                  PropertyStore propStore =
                      serverConfigurationDao.getPropertyValue(importPropertyKey, environmentId);
                  if (propStore == null) {
                    propStore = new PropertyStore();
                    propStore.setKey(importPropertyKey);
                  }
                  propStore.setValue(CasmConstants.IMPORT_STATUS_READYTOIMPORT);
                  serverConfigurationDao.updateProperty(propStore);
                }
              }
            }
            catch (Exception e) {

              logger.error("Error occurred while performing import pre-requisite check.", e);
              throw new GenericException(
                  "Error occurred while performing import pre-requisite check."
                      + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value(),
                  GenericResponse.FAILURE);

            }

          }
        }
        if (!status) {
          importPreCheckResponse.setImportStatusCode(HttpStatus.OK.value());
          importPreCheckResponse.setImportStatus(CasmConstants.IMPORT_STATUS_NOTCONFIGURED);
          importPreCheckResponse.setMessage(lifecycle
              + " environment is not configured for import operation");
          PropertyStore propStore =
              serverConfigurationDao.getPropertyValue(importPropertyKey, environmentId);
          if (propStore == null) {
            propStore = new PropertyStore();
            propStore.setKey(importPropertyKey);
          }
          propStore.setValue(CasmConstants.IMPORT_STATUS_NOTCONFIGURED);
          serverConfigurationDao.updateProperty(propStore);
        }
      }
    }

    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
    GenericResponse<ImportPrecheckResponse> response = new GenericResponse<>();
    response.setStatus(GenericResponse.SUCCESS);
    response.setStatusCode(HttpStatus.OK.value());
    response.setContent(importPreCheckResponse);
    return response;
  }

  private boolean validateRequestFilter(PMTContext pmtContext) {

    return pmtContext.getApplicationFilters() != null
        && !pmtContext.getApplicationFilters().isEmpty()
        && ((String) pmtContext.getApplicationFilters().get(
            ApplicationFilter.ENVIRONMENT.getValue()) != null);
  }

  private void checkDataImportStatus(int environmentId) throws GenericException {

    GenericResponse<?> response = importPrecheck();
    ImportPrecheckResponse importPreCheckResponse =
        (ImportPrecheckResponse) response.getContent();
    String importStatus = importPreCheckResponse.getImportStatus();

    if (CasmConstants.IMPORT_STATUS_READYTOIMPORT.equals(importStatus)) {

      String importPropertyKey = environment.getProperty(PropertyConstants.IMPORT_STATUS);
      PropertyStore propStore =
          serverConfigurationDao.getPropertyValue(importPropertyKey, environmentId);
      if (propStore == null) {
        propStore = new PropertyStore();
        propStore.setKey(importPropertyKey);
      }
      propStore.setValue(CasmConstants.IMPORT_STATUS_IMPORTING);
      serverConfigurationDao.updateProperty(propStore);
      try {
        importSequencer.startSequence(new HashMap<String, String>());
      }
      catch (Exception ge) {
        ge.printStackTrace();
        // Audit- Source import failure.
        auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.FAILURE,
            environment.getProperty(AuditPropertyConstants.SOURCE_IMPORT_FAILURE), "",
            new Object[] { PMTConstants.FAILURE });

        logger.error("Import failed " + ge.getMessage(), ge);
        propStore.setValue(CasmConstants.IMPORT_STATUS_FAILED);
        serverConfigurationDao.updateProperty(propStore);
        throw new GenericException("Data import failed. Reason: " + ge.getMessage(),
            HttpStatus.INTERNAL_SERVER_ERROR.value(), GenericResponse.FAILURE);
      }
      propStore.setValue(CasmConstants.IMPORT_STATUS_IMPORTED);
      serverConfigurationDao.updateProperty(propStore);
    }
    else if (CasmConstants.IMPORT_STATUS_NOTCONFIGURED.equals(importStatus)) {
      throw new GenericException(
          "Selected environment is not configured for source data import.",
          HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
    }

  }

  private com.persistent.pmt.model.Environment getEnvironment() {

    PMTContext pmtContext = pmtContextThreadLocal.get();
    return environmentDao.getEnvironmentByName((String) pmtContext.getApplicationFilters().get(
        ApplicationFilter.ENVIRONMENT.getValue()));
  }

}
