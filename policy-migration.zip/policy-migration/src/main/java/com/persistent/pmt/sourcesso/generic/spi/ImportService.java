package com.persistent.pmt.sourcesso.generic.spi;

import java.util.Map;

import org.springframework.data.domain.PageImpl;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.response.GenericResponse;

public interface ImportService {

	/**
	 * Get the summary of all applications in NEW state in PMT database
	 * 
	 * @return
	 * @throws GenericException
	 * @throws com.persistent.pmt.exception.GenericException
	 */
  public PageImpl<Map<String, String>> getNewApplicationsSummary(Map<String, String> params)
			throws GenericException;

	/**
	 * Get the details of an application identified by id
	 * 
	 * @param id
	 * @return
	 * @throws GenericException
	 */
	public GenericResponse<?> getNewApplicationById(int id)
			throws GenericException;

	public GenericResponse<?> importApplicationData(Map<String, String> params) throws GenericException;

	public GenericResponse<?> importAndSaveApplicationData()
			throws GenericException;

  public GenericResponse<?> importPrecheck() throws GenericException;
}
