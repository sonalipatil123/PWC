package com.persistent.pmt.sourcesso.casm.writer.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.constant.ApplicationFilter;
import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.dao.ApplicationDao;
import com.persistent.pmt.dao.ApplicationStateDao;
import com.persistent.pmt.dao.EnvironmentDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.ApplicationAttributes;
import com.persistent.pmt.model.ApplicationState;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.service.ApplicationService;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.writer.ObjectWriter;
import com.persistent.pmt.sourcesso.generic.mapper.GenericMapper;
import com.persistent.pmt.sourcesso.generic.utils.CommonUtils;
import com.persistent.pmt.utils.AuditWriter;

@Component("domainWriter")
@PropertySource(value = { "classpath:application.properties", "classpath:auditMessages.properties" })
public class DomainWriter implements ObjectWriter {

  private static Logger logger = Logger.getLogger(DomainWriter.class);
  private final String classname = DomainWriter.class.getName();
	
  @Autowired
  ApplicationDao applicationDao;
  
  @Autowired
  EnvironmentDao environmentDao;
  
  @Autowired
  ApplicationStateDao applicationStateDao;
  
  @Autowired
  AuditWriter auditWriter;
  
  @Autowired
  org.springframework.core.env.Environment systemEnvironment;

  @Autowired
  @Qualifier("domainEntityMapper")
  GenericMapper domainEntityMapper;

  @Autowired
  ApplicationService applicationService;
  
  @Autowired
  ThreadLocal<PMTContext> pmtContextThreadLocal;
  
  Map<String, String> propertyMap = new HashMap<>();

	@Override
	public void write(List<? extends CasmGenericObject> domains) throws GenericException {

		final String methodName = "write";
		logger.log(Level.DEBUG, "Entering :: "
								+ classname
								+ ":"
								+ methodName
								+ " and the passed parameter is List of domains that extends CasmGenericObject ");

		String domainName = null;
		PMTContext pmtContext = pmtContextThreadLocal.get();

		if (pmtContext.getApplicationFilters() != null
				&& !pmtContext.getApplicationFilters().isEmpty()) {
			
			domainName = (String) pmtContext.getApplicationFilters().get(
					ApplicationFilter.NAME.getValue());
		}

		Environment environment = null;
		if (CommonUtils.isEnvironmentSpecified(pmtContext)) {
			environment = environmentDao.getEnvironmentByName((String) pmtContext
							.getApplicationFilters().get(ApplicationFilter.ENVIRONMENT.getValue()));
		}

		ApplicationState state = applicationStateDao.getApplicationStateByName(
				com.persistent.pmt.constant.ApplicationState.DRAFTED.name());
		
		propertyMap.put(CasmConstants.DISABLED_POLICY, AuditPropertyConstants.SOURCE_MAPPER_DOMAIN_ENTITY_DISABLED_POLICY);
		propertyMap.put(CasmConstants.HAS_GLOBAL_RESPONSE, AuditPropertyConstants.SOURCE_MAPPER_DOMAIN_ENTITY_GLOBAL_RESPONSE);
		propertyMap.put(CasmConstants.IS_OBSOLETE, AuditPropertyConstants.SOURCE_MAPPER_DOMAIN_ENTITY_OBSOLETE_REALM);
		propertyMap.put(CasmConstants.RULES_CONSOLIDATED, AuditPropertyConstants.SOURCE_MAPPER_DOMAIN_ENTITY_RULES_CONSOLIDATED);		
		propertyMap.put(CasmConstants.AGENT_HIER_RES_CONSOLIDATED, AuditPropertyConstants.SOURCE_MAPPER_DOMAIN_ENTITY_RESOURCE_CONSOLIDATED);

		if (domainName != null && !domainName.isEmpty()) {
			for (CasmGenericObject domain : domains) {
				if (domainName.equalsIgnoreCase(domain.getxId())) {
					parseDomain(domain, environment, state);
				}
			}
		} else {
			int totalApplicationCount = 0;
			for (CasmGenericObject domain : domains) {
				int appCount = parseDomain(domain, environment, state);
				totalApplicationCount += appCount;
			}
			pmtContext.setTotalAppCount(totalApplicationCount);
		}
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);

	}

	@SuppressWarnings("unchecked")
	private int parseDomain(CasmGenericObject domain, Environment env, ApplicationState state) throws GenericException {

		final String methodName = "parseDomain";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and the passed parameter is CasmGenericObject");
		
		List<Application> applications = (List<Application>) domainEntityMapper.getMappedObject(domain);
		
		if (!applications.isEmpty()) {			
			//One time audit for domain level attributes for belonging applications
			auditDomainLevelAttributes(applications, domain.getName());
			
			for (Application application : applications) {
				
				application.setEnvironment(env);
				application.setApplicationState(state);
				applicationService.createApplication(application);
			}
		}
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);
		return applications.size();
	}

	private void auditDomainLevelAttributes(List<Application> applications, String domainName) throws GenericException {
		
		for(ApplicationAttributes appAttr : applications.get(0).getAttributes()) {
			
			String propertyName = appAttr.getSourceAttrName();
			if(!(CasmConstants.DOMAIN_NAME.equals(propertyName) 
					|| CasmConstants.PROVIDER_NAME.equals(propertyName))) {
				
				  auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.NEED_REVIEW, systemEnvironment
				          .getProperty(propertyMap.get(propertyName)), "", new Object[] { domainName });
			}
		}		
	}
	
}
