package com.persistent.pmt.sourcesso.generic.reader;

import com.persistent.pmt.exception.GenericException;


/**
 * @author shishir_kumar
 *
 */
public interface GenericReader {
	
	/**
   * @return structured object after reading and converting it into
   *         generic format
   * @throws GenericException
   */	
  public Object readData() throws com.persistent.pmt.exception.GenericException;
	
	/**
   * @return structured object after reading, converting and saving it
   *         into generic format
   * @throws GenericException
   */
  public Object readAndSaveData() throws GenericException;

  /**
   * @return structured object after reading, converting and saving it
   *         into generic format
   * @throws GenericException
   */
  public Object readAndSaveData(String fileName) throws GenericException;
	
}
