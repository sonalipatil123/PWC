package com.persistent.pmt.sourcesso.casm.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RealmTo {

	private String name;
	private String resourceFilter;
	private String protectAll;
	private String parentRealmLink;
	private String authSchemeLink;
	private String agent; //set value of real.getProperties("AgentLink" or realm.getProperties("AgentGroupLink")
	private List<RuleTo> rules = new ArrayList<>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getResourceFilter() {
		return resourceFilter;
	}

	public void setResourceFilter(String resourceFilter) {
		this.resourceFilter = resourceFilter;
	}

	public String getProtectAll() {
		return protectAll;
	}

	public void setProtectAll(String protectAll) {
		this.protectAll = protectAll;
	}

	public String getParentRealmLink() {
		return parentRealmLink;
	}

	public void setParentRealmLink(String parentRealmLink) {
		this.parentRealmLink = parentRealmLink;
	}

	public String getAuthSchemeLink() {
		return authSchemeLink;
	}

	public void setAuthSchemeLink(String authSchemeLink) {
		this.authSchemeLink = authSchemeLink;
	}

	public List<RuleTo> getRules() {
		return rules;
	}

	public void setRules(List<RuleTo> rules) {
		this.rules = rules;
	}

	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}
}