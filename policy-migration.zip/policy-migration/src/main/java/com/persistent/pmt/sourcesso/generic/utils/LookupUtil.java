package com.persistent.pmt.sourcesso.generic.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.MapperConstants;
import com.persistent.pmt.sourcesso.casm.model.Agent;
import com.persistent.pmt.sourcesso.casm.model.AgentConfig;
import com.persistent.pmt.sourcesso.casm.model.AgentGroups;
import com.persistent.pmt.sourcesso.casm.model.AuthScheme;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.generic.reader.GenericReader;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class LookupUtil {

  private static Set<String> authSchemes = new HashSet<>();
  private static Set<String> agentIds = new HashSet<>();
  private static Map<String, Agent> agentsMap = new HashMap<>();
  private static Map<String, String> responseAttrType = new HashMap<String, String>();
  private static Map<String, String> agentTypes = new HashMap<String, String>();
  private static Map<String, String> xidToName = new HashMap<String, String>();
  private static Map<String, AgentConfig> agentConfigMap;
  private static Map<String, GenericReader> readers;
  private static AgentGroups agentGroups;
  private static Set<String> agentGroupIds = new HashSet<>();
  private static List<AuthScheme> authSchemesData = new ArrayList<>();
  private static Map<String, String> userDirectories = new HashMap<>();
  
  public static void clearContents() {
	  
	  authSchemes = new HashSet<>();
	  agentIds = new HashSet<>();
	  agentsMap = new HashMap<>();
	  responseAttrType = new HashMap<>();
	  agentTypes = new HashMap<>();
	  xidToName = new HashMap<>();
	  agentConfigMap = null;
	  readers = null;
	  agentGroups = null;
	  agentGroupIds = new HashSet<>();
	  authSchemesData = new ArrayList<>();
	  userDirectories = new HashMap<>();
  }
  
  public static Map<String, String> getUserDirectories() {
    return userDirectories;
  }

  public static String getUserDirectoryXidByName(String name) {
    return userDirectories.get(name);
  }

  public static void setUserDirectories(List<CasmGenericObject> userDirectories) {

    if(userDirectories != null && !userDirectories.isEmpty()) {
      Map<String, String> directories = new HashMap<>();
      for (CasmGenericObject userDirectory : userDirectories) {
        if (userDirectory.getProperties() != null) {
          directories.put(userDirectory.getProperties().get(MapperConstants.USERDIRECTORY_NAME),
              userDirectory.getxId());
        }
      }

      LookupUtil.userDirectories = directories;
    }
  }

  public static List<AuthScheme> getAuthSchemesData() {
    return authSchemesData;
  }

  public static void setAuthSchemesData(List<AuthScheme> authSchemesData) {
    LookupUtil.authSchemesData = authSchemesData;
  }

  public static Set<String> getAgentGroupsIds() {
	return agentGroupIds;
  }

  public static void setAgentGroupsIds(Set<String> agentGroupIds) {
	LookupUtil.agentGroupIds = agentGroupIds;
  }

  public static Map<String, AgentConfig> getAgentConfigMap() {
    return agentConfigMap;
  }

  public static void setAgentConfigMap(Map<String, AgentConfig> agentConfigMap) {
    LookupUtil.agentConfigMap = agentConfigMap;
  }

  public static AgentGroups getAgentGroups() {
    return agentGroups;
  }

  public static void setAgentGroups(AgentGroups agentGroups) {
    LookupUtil.agentGroups = agentGroups;
  }

  public static Map<String, GenericReader> getReadersMap() {
    return readers;
  }

  public static GenericReader getReader(String readerName) {
    return readers.get(readerName);
  }

  public static void setReaders(Map<String, GenericReader> casmreaders) {
    readers = casmreaders;
  }

  public static Map<String, Agent> getAgentsMap() {
    return agentsMap;
  }

  public static Map<String, String> getResponseAttrType() {
    return responseAttrType;
  }

  // type xid of the agentattrtype referred in domain
  public static String getResponseAttrType(String type) {
    return responseAttrType.get(type);
  }

  public static void setAgentsMap(Map<String, Agent> agentsMap) {
    LookupUtil.agentsMap = agentsMap;
  }

  public static String getName(String xid) {
    return xidToName.get(xid);
  }

  public static void addXidToNamePair(String xid, String name) {
    xidToName.put(xid, name);
  }

  public static Map<String, String> prepareResponseAttrTypes(String agentTypeAttr) {
    responseAttrType = new HashMap<String, String>();
    if (agentTypeAttr != null) {
      String[] agentTypeAttribue = agentTypeAttr.split(CasmConstants.COMMA);
      if (agentTypeAttribue != null) {
        for (String agentTypeAttribueValue : agentTypeAttribue) {

          String[] agentTypeAttrValue = agentTypeAttribueValue.split(CasmConstants.EQUAL_TO);
          if (agentTypeAttrValue != null) {
            responseAttrType.put(agentTypeAttrValue[0], agentTypeAttrValue[1]);
          }

        }
      }

    }

   
    return responseAttrType;
  }

  // type xid of the agenttype referred in domain
  public static String getAgentType(String type) {
    return agentTypes.get(type);
  }

  public static Map<String, String> prepareAgentTypes(String agentType) {
    agentTypes = new HashMap<String, String>();

    if (agentType != null) {
      String[] agentTypeArray = agentType.split(CasmConstants.COMMA);
      if (agentTypeArray != null) {
        for (String agentTypeValue : agentTypeArray) {
          String[] agentTypeValueArray = agentTypeValue.split(CasmConstants.EQUAL_TO);
          if (agentTypeValueArray != null) {
            agentTypes.put(agentTypeValueArray[0], agentTypeValueArray[1]);
          }

        }
      }

    }
   

    return agentTypes;
  }

  public static Set<String> getAuthSchemes() {
    return authSchemes;
  }

  public static boolean checkIfAuthSchemeExist(String authSchemeId) {
    return authSchemes.contains(authSchemeId);
  }

  public static void setAuthSchemes(Set<String> authSchemes) {
    LookupUtil.authSchemes.addAll(authSchemes);
  }

  public static Set<String> getAgentIds() {
    return agentIds;
  }

  public static void setAgentIds(Set<String> agentIds) {
    LookupUtil.agentIds.addAll(agentIds);
  }

  public static String resolveXidToName(String stringOfXids) {
    if (stringOfXids != null) {
      String[] xids = stringOfXids.split(",");
      StringBuilder names = new StringBuilder();
      int count = 0;
      for (String xid : xids) {
        String name = getName(xid);
        if (count != 0) {
          names.append(",");
        }
        names.append(name);
        count++;
      }
      return names.toString();
    }
    return stringOfXids;
  }
  
}
