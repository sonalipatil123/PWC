package com.persistent.pmt.sourcesso.casm.reader.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.AuthScheme;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.model.SAMLv2IdP;
import com.persistent.pmt.sourcesso.casm.model.WSFEDIdP;
import com.persistent.pmt.sourcesso.casm.reader.AbstractXmlReader;
import com.persistent.pmt.sourcesso.casm.reader.EventReaderContext;
import com.persistent.pmt.sourcesso.generic.response.BaseResponse;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;
import com.persistent.pmt.sourcesso.generic.utils.ReferenceUtil;

@Component("authSchemeReader")
@PropertySource(value = { "classpath:application.properties" })
public class AuthSchemeReader extends AbstractXmlReader {

	public static final String authSchemeFile = "CA_SM_AuthScheme.xml";
	private static Logger logger = Logger.getLogger(AuthSchemeReader.class);
	private final String classname = AuthSchemeReader.class.getName();

	@Override
	public Object readAndSaveData(String fileName) throws GenericException {
		// Unused for AuthSchemeReader
		return null;
	}

	@Override
	public BaseResponse readData() throws GenericException {
		// Unused for AuthSchemeReader
		return null;
	}

	@Override
	public Object readAndSaveData() throws GenericException {

		final String methodName = "readAndSaveData";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and there is no parameter passed");

		List<AuthScheme> authSchemeList = getAuthSchemeList(LookupUtil.getAuthSchemes());

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns AuthSceheme List");

		return authSchemeList;

	}

	/**
	 * 
	 * This method parses the CA.SM.AuthScheme.xml and returns the AuthScheme
	 * type of List
	 * 
	 * @param usedAuthSchemes
	 * @return
	 * @throws GenericException
	 */
	private List<AuthScheme> getAuthSchemeList(Set<String> usedAuthSchemes)
			throws GenericException {

		final String methodName = "getAuthSchemeList";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and the parameter passed is Set of usedAuthSchemes");

		XMLEventReader eventReader = null;
		List<AuthScheme> authSchemeList = new ArrayList<AuthScheme>();

		EventReaderContext authSchemeReaderContext = getEventReaderContext(authSchemeFile);

		AuthScheme authSchemeObject = null;

		try {

			eventReader = authSchemeReaderContext.getEventReader();
			while (eventReader.hasNext()) {

				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					String tagName = startElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {

						authSchemeObject = (AuthScheme) parseObject(
								eventReader, event, CasmConstants.AUTHSCHEME);
						if (usedAuthSchemes != null
								&& usedAuthSchemes.contains(authSchemeObject
										.getxId())) {
							authSchemeList.add(authSchemeObject);
							LookupUtil.addXidToNamePair(
									authSchemeObject.getxId(),
									authSchemeObject.getName());
						}
					}
				}
				// If we reach the end of an item element, we add it to the
				// list
				if (event.isEndElement()) {
					EndElement endElement = event.asEndElement();
					String tagName = endElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						continue;
					}
				}
			}
		} catch (XMLStreamException e) {
			throw new GenericException("File Input Stream Error ", e);
		} finally {
			authSchemeReaderContext.closeResources();
		}
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns AuthSceheme List");

		return authSchemeList;
	}

	/**
	 * Parse an Object node to retrieve all the properties in CasmGenericObject
	 * 
	 * @param eventReader
	 * @param currectEvent
	 * @param objectName
	 * @param authSchemes
	 * @return
	 * @throws XMLStreamException
	 * @throws GenericException
	 */
	protected CasmGenericObject parseObject(XMLEventReader eventReader,
			XMLEvent currectEvent, String objectName)
			throws XMLStreamException, GenericException {

		final String methodName = "parseObject";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and the parameter passed is Set of usedAuthSchemes");

		CasmGenericObject genObject = getObjectInstance(objectName);
		Map<String, String> objectPropertyMap = new HashMap<String, String>();
		String propertyKey = null;

		StartElement firstElement = currectEvent.asStartElement();
		genObject.setxId(firstElement.getAttributeByName(
				new QName(XmlTagConstants.Xid)).getValue());

		while (eventReader.hasNext()) {

			XMLEvent event = eventReader.nextEvent();
			if (event.isStartElement()) {
				StartElement startElement = event.asStartElement();
				String tagName = startElement.getName().getLocalPart();

				switch (tagName) {

				case XmlTagConstants.PROPERTY:
					propertyKey = removePropertyNameSuffix(startElement
							.getAttributeByName(new QName(XmlTagConstants.NAME))
							.getValue());
					break;

				case XmlTagConstants.NUMBER_VALUE:
					event = eventReader.nextEvent();
					objectPropertyMap.put(
							propertyKey,
							getBitMappedValue(propertyKey, event.asCharacters()
									.getData()));
					break;

				case XmlTagConstants.BOOLEAN_VALUE:
					event = eventReader.nextEvent();
					objectPropertyMap.put(propertyKey, event.asCharacters()
							.getData());
					break;

				case XmlTagConstants.STRING_VALUE:
					event = eventReader.nextEvent();
					processStringValue(event, propertyKey, objectPropertyMap,
							genObject);
					break;

				case XmlTagConstants.XREF:
					event = eventReader.nextEvent();
					String referenceId = event.asCharacters().getData();
					String referenceValue = ReferenceUtil
							.getReferenceById(referenceId);
					objectPropertyMap.put(propertyKey, referenceValue);
					break;

				case XmlTagConstants.XID:
					event = eventReader.nextEvent();
					String xid = event.asCharacters().getData();
					objectPropertyMap.put(propertyKey, xid);

					break;

				case XmlTagConstants.OBJECT:
					processSubObject(event, eventReader, genObject);
					break;

				default:
					continue;
				}
			} else if (event.isEndElement()) {

				EndElement endElement = event.asEndElement();
				String tagName = endElement.getName().getLocalPart();

				if (tagName.equals(XmlTagConstants.OBJECT)) {
					genObject.setProperties(objectPropertyMap);
					break;
				}
			}
		}
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns genObject " + genObject.toString());

		return genObject;
	}

	protected CasmGenericObject getObjectInstance(String objectName) {

		CasmGenericObject genObject = null;

		switch (objectName) {

		case CasmConstants.AUTHSCHEME:
			genObject = new AuthScheme();
			break;

		case CasmConstants.SAMLv2IDP:
			genObject = new SAMLv2IdP();
			break;

		case CasmConstants.WSFEDIDP:
			genObject = new WSFEDIdP();
			break;

		}
		return genObject;
	}

	protected void processSubObject(XMLEvent event, XMLEventReader eventReader,
			CasmGenericObject genObject) throws XMLStreamException,
			GenericException {

		final String methodName = "processSubObject";
		logger.log(
				Level.DEBUG,
				"Entering :: "
						+ classname
						+ ":"
						+ methodName
						+ " and the parameters passed are event eventReader & CasmGenericObject");

		StartElement subObjectStartElement = event.asStartElement();
		String subObjectName = removeObjectNameSuffix(subObjectStartElement
				.getAttributeByName(new QName(XmlTagConstants.CLASS))
				.getValue());

		if (CasmConstants.SAMLv2IDP.equals(subObjectName)) {
			SAMLv2IdP samlv2IdP = (SAMLv2IdP) parseObject(eventReader, event,
					subObjectName);
			AuthScheme authscheme = (AuthScheme) genObject;
			authscheme.setSamlv2IdP(samlv2IdP);

		} else if (CasmConstants.WSFEDIDP.equals(subObjectName)) {
			WSFEDIdP wsFedIdP = (WSFEDIdP) parseObject(eventReader, event,
					subObjectName);
			AuthScheme authscheme = (AuthScheme) genObject;
			authscheme.setWsFedIdP(wsFedIdP);

		}
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and doesn't return anything");

	}

}
