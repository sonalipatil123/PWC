package com.persistent.pmt.sourcesso.casm.model;

public class PartnershipBase extends CasmGenericObject {

	private String partnerId;

	public PartnershipBase() {

	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	@Override
	public String toString() {
		return "PartnershipBase [partnerId=" + partnerId + ", getProperties()=" + getProperties() + "]";
	}

}
