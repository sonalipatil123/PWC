package com.persistent.pmt.sourcesso.generic.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.constant.ApplicationFilter;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;

public class CommonUtils {

  private static Logger logger = Logger.getLogger(CommonUtils.class);
  private static Map<String, String> properties = new LinkedHashMap<>();

  private static Map<String, String> loadConfig(String fileName) {

    InputStream input = null;
    try {
      input = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
      if (input != null) {
        // load a properties file
        Properties prop = new Properties();
        prop.load(input);
        Set<String> propertyNames = new TreeSet<>(prop.stringPropertyNames());
        for (String sProperty : propertyNames) {
          properties.put(sProperty, prop.getProperty(sProperty));
        }
      }
      else {
        logger.log(Level.ERROR, "Cannot Load properties[" + fileName + "]");
      }
    }
    catch (IOException ex) {
      logger.log(Level.ERROR, "Exception occurred", ex);
    }
    finally {
      if (input != null) {
        try {
          input.close();
        }
        catch (IOException e) {
          logger.log(Level.ERROR, "Exception occurred", e);
        }
      }
    }
    return properties;
  }

  public static String getPropertyValue(String propertyName) {
    if (properties.isEmpty()) {
      loadConfig(CasmConstants.PROPERTY_FILE_NAME);
    }
    return properties.get(propertyName);
  }

  public static boolean checkIfFileExists(String folderName, String fileName) {

    boolean status = false;
    File file = new File(folderName + "/" + fileName);
    if (file.exists()) {
      if (file.length() > 0) {
        status = true;
      }
    }
    return status;
  }

  public static boolean isDirectoryExists(String directoryPath)

  {
    File directory = new File(directoryPath);
    if (directory.isDirectory()) {
      return true;
    }
    return false;

  }

  public static boolean isEnvironmentSpecified(PMTContext pmtContext) {
	  
	 return  pmtContext.getApplicationFilters() != null
		        && !pmtContext.getApplicationFilters().isEmpty() && ((String) pmtContext
		            .getApplicationFilters().get(ApplicationFilter.ENVIRONMENT.getValue()) != null);
  }
  
}
