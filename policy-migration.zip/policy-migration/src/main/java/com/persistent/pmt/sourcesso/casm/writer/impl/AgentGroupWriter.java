package com.persistent.pmt.sourcesso.casm.writer.impl;

import java.util.List;
import java.util.Map.Entry;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.dao.AgentDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Agent;
import com.persistent.pmt.sourcesso.casm.mapper.impl.AgentGroupMapper;
import com.persistent.pmt.sourcesso.casm.model.AgentGroups;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.writer.ObjectWriter;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;

@Component("agentGroupWriter")
@PropertySource(value = { "classpath:application.properties" })
public class AgentGroupWriter implements ObjectWriter {

  private static Logger logger = Logger.getLogger(AgentGroupWriter.class);
  private final String classname = AgentGroupWriter.class.getName();
  
  @Autowired
  AgentDao agentDao;

  @Autowired
  AgentGroupMapper agentGroupMapper;

  @Override
  public void write(List<? extends CasmGenericObject> objects) throws GenericException {
	 
    final String methodName = "write";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName+" and passed parameter is List that extends CasmGenericObject"); 
	  
    AgentGroups agentGroups = LookupUtil.getAgentGroups();
    agentGroupMapper.setAgentGroups(agentGroups);
    
    if (agentGroups != null && agentGroups.getAgentGroups() != null
        && !agentGroups.getAgentGroups().isEmpty()) {
    	for (Entry<String, CasmGenericObject> entry : agentGroups.getAgentGroups().entrySet()) {
	        Agent agent = (Agent) agentGroupMapper.getMappedObject(entry.getValue());
	        agentDao.createAgent(agent);
    	}
    }
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);

	}
}
