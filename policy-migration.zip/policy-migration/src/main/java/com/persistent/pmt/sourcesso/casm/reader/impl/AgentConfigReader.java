package com.persistent.pmt.sourcesso.casm.reader.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.PropertyConstants;
import com.persistent.pmt.constant.casm.PolicyGrammarConstants;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
// import com.persistent.pmt.dao.impl.AdminAPIDaoImpl;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.AgentConfig;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.reader.AbstractXmlReader;
import com.persistent.pmt.sourcesso.casm.reader.EventReaderContext;
import com.persistent.pmt.utils.AuditWriter;

@Component("agentConfigReader")
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class AgentConfigReader extends AbstractXmlReader {

  @Autowired
  AuditWriter auditWriter;

  @Autowired
  Environment sysEnvironment;

  private static final Logger logger = Logger.getLogger(AgentConfigReader.class);
  public static final String agentConfigFile = "CA_SM_AgentConfig.xml";
  private Map<String, AgentConfig> agentConfigs;
  public static final String ATTRIBUTE_VALUE_SPLITTER = "=[0-9]=";
  public static final String URL_ENCODINGREFERENCE_FOR_ETX_CHAR = "%03";
  public static final String ASCII_ENCODINGREFERENCE_FOR_SPACE_CHAR = "%20";
  public static final String SPLIT_BY_COMMA = ",";
  public static final String SPLIT_BY_SPACE = " ";
  private final String classname = AgentConfigReader.class.getName();
  private Set<String> agentConfigNamesForAuditForWithNoFQDN = new HashSet<>();
  private Set<String> agentForAuditForWithDummyFQDN = new HashSet<>();

  public AgentConfig getAgentConfigByAgentName(String agentName) {

    return agentConfigs.get(agentName);
  }

  @Override
  protected String getBitMappedValue(String propertyKeyName, String keyNumericValueString) {

    return null;
  }

  @Override
  public Object readData() throws GenericException {
    return null;
  }

  @Override
  public Object readAndSaveData(String fileName) throws GenericException {

    return null;
  }

  @Override
  public Object readAndSaveData() throws GenericException {

    final String methodName = "readAndSaveData";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and there is no parameter passed");

    agentConfigs = new HashMap<String, AgentConfig>();

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and there is return value");

    return readAgentConfig();

  }

  /**
   * This method parses the CA.SM.AgentConfig.xml file and returns the
   * Map<String,AgentConfig>
   * 
   * @return
   * @throws GenericException
   */
  public Map<String, AgentConfig> readAgentConfig() throws GenericException {

    final String methodName = "readAgentConfig";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and there is no parameter passed");

    XMLEventReader eventReader = null;
    EventReaderContext agentConfigReaderContext = getEventReaderContext(agentConfigFile);

    AgentConfig agentConfig = null;

    try {

      Set<String> agentNames = new HashSet<>();
      eventReader = agentConfigReaderContext.getEventReader();
      while (eventReader.hasNext()) {

        XMLEvent event = eventReader.nextEvent();
        if (event.isStartElement()) {
          StartElement startElement = event.asStartElement();
          String tagName = startElement.getName().getLocalPart();

          if (tagName.equals(XmlTagConstants.OBJECT)) {
            agentConfig =
                (AgentConfig) parseObject(eventReader, event, CasmConstants.AGENT_CONFIG);

            if (agentConfig != null) {
              Map<String, Set<String>> agentToFQDN = agentConfig.getAgentToFQDN();

              if (agentToFQDN != null && agentToFQDN.size() > 0) {
                // set same AgentConfig object to all its agent.
                // AgentConfig can be a shared
                // object.
                for (String key : agentToFQDN.keySet()) {

                  if (!agentConfigs.containsKey(key)) {
                    agentConfigs.put(key, agentConfig);
                  }
                  else {

                    logger
                        .warn("More than one Agent configuration found for Agent, AgentName: "
                            + key);
                    agentNames.add(key);

                  }

                }

              }

            }

          }
        }
        // If we reach the end of an item element, we add it to the
        // list
        if (event.isEndElement()) {
          EndElement endElement = event.asEndElement();
          String tagName = endElement.getName().getLocalPart();

          if (tagName.equals(XmlTagConstants.OBJECT)) {
            continue;
          }
        }
      }
      try {
        StringBuilder commaSeparatedAgentNames = new StringBuilder();
        StringBuilder commaSeparatedAgentConfigNames = new StringBuilder();
        StringBuilder agentNamesWithDummyFQDN = new StringBuilder();

        for (String agentName : agentNames) {
          commaSeparatedAgentNames.append(agentName + PropertyConstants.COMMA);
        }
        for (String agentConfigName : agentConfigNamesForAuditForWithNoFQDN) {
          commaSeparatedAgentConfigNames.append(agentConfigName + PropertyConstants.COMMA);
        }
        for (String agentName : agentForAuditForWithDummyFQDN) {
          agentNamesWithDummyFQDN.append(agentName + PropertyConstants.COMMA);
        }

        auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.NEED_REVIEW, sysEnvironment
						.getProperty(AuditPropertyConstants.READER_READAGENT_CONFIG),
						commaSeparatedAgentNames.toString().replaceAll(CasmConstants.TRAILING_COMMA, ""),
						new Object[] {});

        auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.NEED_REVIEW, sysEnvironment
						.getProperty(AuditPropertyConstants.READER_PREPAREAGENT_CONFIG),
						commaSeparatedAgentConfigNames.toString().replaceAll(CasmConstants.TRAILING_COMMA, ""),
						new Object[] {});

        auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.NEED_REVIEW, sysEnvironment
            .getProperty(AuditPropertyConstants.READER_PREPAREAGENT_CONFIG_DUMMY_FQDN),
						agentNamesWithDummyFQDN.toString().replaceAll(CasmConstants.TRAILING_COMMA, ""),
						new Object[] {});
      }
      catch (Exception ex) {
        logger.log(Level.ERROR, "Error while auditing for Agent Config objects", ex);
      }
    }
    catch (XMLStreamException e) {
      throw new GenericException("File Input Stream Error ", e);
    }
    finally {
      agentConfigReaderContext.closeResources();
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and returns agentConfigs");
    return agentConfigs;
  }

  /**
   *
   * This method parses each Object in xml file and identifies its
   * each XmlTag values
   * 
   * @throws GenericException
   */
  protected CasmGenericObject parseObject(XMLEventReader eventReader, XMLEvent currentEvent,
      String objectName) throws XMLStreamException, GenericException {

    final String methodName = "parseObject";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameter is " + objectName);

    AgentConfig agentConfigObject = new AgentConfig();

    List<String> attributeValues = new ArrayList<>();
    String propertyKey = null;

    StartElement firstElement = currentEvent.asStartElement();
    agentConfigObject.setxId(firstElement.getAttributeByName(new QName(XmlTagConstants.Xid))
        .getValue());

    while (eventReader.hasNext()) {

      XMLEvent event = eventReader.nextEvent();
      if (event.isStartElement()) {
        StartElement startElement = event.asStartElement();
        String tagName = startElement.getName().getLocalPart();

        switch (tagName) {

          case XmlTagConstants.PROPERTY:
            propertyKey =
                removePropertyNameSuffix(startElement.getAttributeByName(
                    new QName(XmlTagConstants.NAME)).getValue());
            break;

          case XmlTagConstants.STRING_VALUE:
            event = eventReader.nextEvent();
            String value = null;
            if (!event.isEndElement()) {
              value = event.asCharacters().getData();
            }
            if (value != null) {
              if (XmlTagConstants.ATTRIBUTES.equals(propertyKey)) {
                attributeValues.add(value);
              }
              else if (XmlTagConstants.NAME.equals(propertyKey)) {
                agentConfigObject.setName(value);
              }
              else if (XmlTagConstants.DESC.equals(propertyKey)) {
                agentConfigObject.setDescription(value);
              }
            }
            break;

          case XmlTagConstants.OBJECT:

            break;

          default:
            continue;
        }
      }
      else if (event.isEndElement()) {

        EndElement endElement = event.asEndElement();
        String tagName = endElement.getName().getLocalPart();

        if (tagName.equals(XmlTagConstants.OBJECT)) {
          Map<String, String> attributePair = new HashMap<>();
          Map<String, Set<String>> agentToFQDN = new HashMap<>();

          prepareAgentConfig(attributeValues, attributePair, agentToFQDN,
              agentConfigObject.getName());

          agentConfigObject.setAttributePair(attributePair);
          agentConfigObject.setAgentToFQDN(agentToFQDN);

          break;

        }
      }
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and returns agentConfigObject ");
    return agentConfigObject;

  }

  /**
   * This method prepares the Map of Agent to its set of FQDNs
   * 
   * @param agentNamestring
   * @param agentToFQDN
   * @return
   */
  private void prepareAgentNames(String agentNameString, Map<String, Set<String>> agentToFQDN) {

    final String methodName = "prepareAgentNames";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameter is  agentNameString " + agentNameString);

    String encodedtemp =
        agentNameString.replace(URL_ENCODINGREFERENCE_FOR_ETX_CHAR,
            ASCII_ENCODINGREFERENCE_FOR_SPACE_CHAR);
    String agentNamesWithFQDN = null;
    try {
      agentNamesWithFQDN = URLDecoder.decode(encodedtemp, "UTF-8");
      String[] agentNamesWithFQDNTokens = agentNamesWithFQDN.split(SPLIT_BY_SPACE);

      if (agentNamesWithFQDNTokens != null) {
        for (String agentNameFQDNPair : agentNamesWithFQDNTokens) {

          String[] agentNameFQDNPairArray = agentNameFQDNPair.split(SPLIT_BY_COMMA);

          if (agentNameFQDNPairArray != null) {
            if (agentNameFQDNPairArray.length == 2) {
              String agentName = agentNameFQDNPairArray[0];
              String agentFQDN = agentNameFQDNPairArray[1];

              if (agentToFQDN.containsKey(agentName)) {
                agentToFQDN.get(agentName).add(agentFQDN);
              }
              else {
                Set<String> agentFQDNs = new HashSet<String>();
                agentFQDNs.add(agentFQDN);
                // AgentConfig at some cases in lowecase
                String agentNameLower = agentName.toLowerCase();
                agentToFQDN.put(agentNameLower, agentFQDNs);
              }
            }
          }
        }
      }
    }
    catch (UnsupportedEncodingException e) {

      e.printStackTrace();
    }

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and doesn't return anything");

  }

  /**
   * This method accepts list of attributeValues and process it and
   * returns attributePair map and agentToFQDN map
   * 
   * @param attributeValues
   * @param attributePair
   * @param agentToFQDN
   * @param agentConfigName
   * @throws GenericException
   */
  private void prepareAgentConfig(List<String> attributeValues,
      Map<String, String> attributePair, Map<String, Set<String>> agentToFQDN,
      String agentConfigName) throws GenericException {

    final String methodName = "prepareAgentConfig";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameter is  agentConfigName " + agentConfigName);

    if (attributeValues != null) {
      for (String aatributeValue : attributeValues) {
        if (aatributeValue != null) {

          String[] aatributeValueArray = aatributeValue.split(ATTRIBUTE_VALUE_SPLITTER);
          if (aatributeValueArray.length == 2) {
            attributePair.put(aatributeValueArray[0], aatributeValueArray[1]);
          }
        }
      }
    }
    // Condition 1: If AgentNameValue is null
    // - check for DefaultAgentNameValue. if that is also null then
    // make that Agent as
    // INVALID. if DefaultAgentNameValue is not null and has only
    // AgentName then append it with dummy FQDN
    // Condition 2: if AgentName is not null then that will be the key
    // in agentToFQDN map
    String agentNameValue = attributePair.get("AgentName");
    if (agentNameValue == null) {
      agentNameValue = attributePair.get("DefaultAgentName");
      if (agentNameValue != null) {
        agentForAuditForWithDummyFQDN.add(agentNameValue);

        agentNameValue =
            new StringBuilder(agentNameValue).append("%2c")
                .append(PolicyGrammarConstants.DUMMY_FQDN_VALUE).toString();
      }
      else {

        // Condition used for reporting if neither AgentName nor
        // DefaultAgentName present in AgentConfig or both are
        // commented
        HashSet<String> dummyFQDNSet = new HashSet<String>();
        dummyFQDNSet.add(PolicyGrammarConstants.DUMMY_FQDN_VALUE);
        agentToFQDN.put(new StringBuilder("INVALID_").append(agentConfigName).toString(),
            dummyFQDNSet);

        agentConfigNamesForAuditForWithNoFQDN.add(agentConfigName);
      }
    }
    if (agentNameValue != null) {
      prepareAgentNames(agentNameValue, agentToFQDN);
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and doesn't return anything");

  }

}
