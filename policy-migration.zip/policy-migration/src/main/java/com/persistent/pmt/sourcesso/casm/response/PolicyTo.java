package com.persistent.pmt.sourcesso.casm.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PolicyTo {

	private String name;
	private String isEnabled;
	private String description;
	private List<PolicyRulesTo> rules;
	private List<UserPolicyTo> users;
	private List<ConditionsTo> conditions;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsEnabled() {
		return isEnabled;
	}

	public void setIsEnabled(String isEnabled) {
		this.isEnabled = isEnabled;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<PolicyRulesTo> getRules() {
		return rules;
	}

	public void setRules(List<PolicyRulesTo> rules) {
		this.rules = rules;
	}

	public List<UserPolicyTo> getUsers() {
		return users;
	}

	public void setUsers(List<UserPolicyTo> users) {
		this.users = users;
	}

	public List<ConditionsTo> getConditions() {
		return conditions;
	}

	public void setConditions(List<ConditionsTo> conditions) {
		this.conditions = conditions;
	}
}
