package com.persistent.pmt.sourcesso.casm.model;

import com.fasterxml.jackson.annotation.JsonInclude;

// Parallel Object
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuthScheme extends CasmGenericObject {

  private SAMLv2IdP samlv2IdP;
  private WSFEDIdP wsFedIdP;

  public SAMLv2IdP getSamlv2IdP() {
    return samlv2IdP;
  }

  public void setSamlv2IdP(SAMLv2IdP samlv2IdP) {
    this.samlv2IdP = samlv2IdP;
  }

  public WSFEDIdP getWsFedIdP() {
    return wsFedIdP;
  }

  public void setWsFedIdP(WSFEDIdP wsFedIdP) {
    this.wsFedIdP = wsFedIdP;
  }

}
