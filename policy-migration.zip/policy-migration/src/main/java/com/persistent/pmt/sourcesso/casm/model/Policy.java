package com.persistent.pmt.sourcesso.casm.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Policy extends CasmGenericObject {

	private List<PolicyLink> policyLinks = new ArrayList<>();
	private List<UserPolicy> userPolicies = new ArrayList<>();	

	public List<PolicyLink> getPolicyLinks() {
		return policyLinks;
	}
	public List<UserPolicy> getUserPolicies() {
		return userPolicies;
	}
	
}
