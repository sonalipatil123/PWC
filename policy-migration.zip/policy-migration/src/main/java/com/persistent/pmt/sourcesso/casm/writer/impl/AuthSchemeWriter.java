package com.persistent.pmt.sourcesso.casm.writer.impl;

import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.persistent.pmt.dao.AuthenticationSchemeDao;
import com.persistent.pmt.model.AuthenticationScheme;
import com.persistent.pmt.sourcesso.casm.mapper.impl.AuthenticationSchemeMapper;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.writer.ObjectWriter;

@Component("authSchemeWriter")
public class AuthSchemeWriter implements ObjectWriter {
	
  private static Logger logger = Logger.getLogger(AuthSchemeWriter.class);
  private final String classname = AuthSchemeWriter.class.getName();

  @Autowired
  @Qualifier("authenticationSchemeDao")
  AuthenticationSchemeDao authenticationSchemeDao;

  public void write(List<? extends CasmGenericObject> authSchemes) throws com.persistent.pmt.exception.GenericException {
	  
    final String methodName = "write";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName+" and the passed parameter is List of authSchemes that extends CasmGenericObject"); 
	  
    AuthenticationSchemeMapper mapper = new AuthenticationSchemeMapper();

    for (CasmGenericObject authScheme : authSchemes) {
      AuthenticationScheme authenticationScheme = (AuthenticationScheme) mapper.getMappedObject(authScheme);
      authenticationSchemeDao.createAuthenticationScheme(authenticationScheme);
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);
  }
  
}
