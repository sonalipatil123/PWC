package com.persistent.pmt.sourcesso.casm.mapper.impl;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.PropertyConstants;
import com.persistent.pmt.constant.casm.BitMappingEnum;
import com.persistent.pmt.dao.AuthenticationSchemeDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Agent;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.ApplicationAttributes;
import com.persistent.pmt.model.AuthenticationPolicy;
import com.persistent.pmt.model.AuthenticationScheme;
import com.persistent.pmt.model.AuthorizationPolicy;
import com.persistent.pmt.model.AuthorizationPolicyAttribute;
import com.persistent.pmt.model.Resource;
import com.persistent.pmt.model.Response;
import com.persistent.pmt.model.UserDataStore;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.MapperConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.AuthScheme;
import com.persistent.pmt.sourcesso.casm.model.Domain;
import com.persistent.pmt.sourcesso.casm.model.Policy;
import com.persistent.pmt.sourcesso.casm.model.Realm;
import com.persistent.pmt.sourcesso.casm.model.ResponseAttr;
import com.persistent.pmt.sourcesso.casm.model.Rule;
import com.persistent.pmt.sourcesso.casm.model.derived.PolicyResponse;
import com.persistent.pmt.sourcesso.casm.model.derived.ResourceDefinition;
import com.persistent.pmt.sourcesso.generic.mapper.GenericMapper;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;
import com.persistent.pmt.utils.AuditWriter;

@Component("domainEntityMapper")
@PropertySource(value = { "classpath:application.properties", "classpath:auditMessages.properties" })
public class DomainEntityMapper implements GenericMapper {

  @Autowired
  AuthenticationSchemeDao authenticationSchemeDao;

  @Autowired
  org.springframework.core.env.Environment systemEnvironment;

  @Autowired
  ThreadLocal<PMTContext> pmtContextThreadLocal;

  @Autowired
  AuditWriter auditWriter;

  @Autowired
  Environment environment;

  private static Logger logger = Logger.getLogger(DomainEntityMapper.class);
  private final String classname = DomainEntityMapper.class.getName();
  private List<String> validFileExtensions = new ArrayList<>();

  @Override
  @SuppressWarnings({ "unchecked", "rawtypes" })
  public List<Application> getMappedObject(Object source) throws GenericException {
    final String methodName = "getMappedObject";

    Domain domain = (Domain) source;
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName + "and passed parameter is Domain with ID " + domain.getxId());

    String fileExtensions = systemEnvironment
			.getProperty(PropertyConstants.VALID_RESOURCE_FILE_EXTENSIONS);
	if (null != fileExtensions) {
		String[] fileExtensionArrays = fileExtensions.split("\\|");
		for (String extension : fileExtensionArrays) {
			validFileExtensions.add(extension);
		}
	}	
        
    List<Application> applications = new ArrayList<>();
    resolveNamesForXid(domain);
    mergeResourceDefForAgentsOfSameHierachy(domain);

    try {
      Map<String, List<String>> agentRealms = domain.getAgentRealmMap();
      for (Entry entry : agentRealms.entrySet()) {

        String key = (String) entry.getKey();
      //  if (!mergedAndDiscardedAgentIds.contains(key)) // bug fix PMT_Defect_32
          applications.addAll(getApplications(key, (List<String>) entry.getValue(), domain));
      }
    }
    catch (JsonProcessingException e) {
      throw new GenericException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value(),
          GenericResponse.FAILURE);
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "and return value is Applications ");

    return applications;
  }

  /**
   * Process objects to get List<Application> for one agentGroup
   * 
   * @param agentGroupXid
   * @param realms
   * @param domain
   * @return
   * @throws GenericException
   * @throws JsonProcessingException
   */
  private List<Application> getApplications(String agentGroupXid, List<String> realms,
      Domain domain) throws GenericException, JsonProcessingException {

    final String methodName = "getApplications";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameters are agentGroupXid: " + agentGroupXid + " Domain with ID "
        + domain.getxId());

    Set<String> parallelRealms = new HashSet<String>();
    String[] realmsInRelation = null;

    for (String realm : realms) {
      realmsInRelation = StringUtils.delimitedListToStringArray(realm, "|");
      for (String realmXid : realmsInRelation) {

        Realm localRealm = domain.getRealmByXid(realmXid);

        if (localRealm.isParentRealm()) {
          parallelRealms.add(realmXid);
        }
      }
    }

    List<Application> applications = new ArrayList<>();
    // Process each parallel realm. Each parallel realm will result
    // into one Application entity

    // Store domain JSON
    ObjectMapper mapper = new ObjectMapper();
    String domainJSON = mapper.writeValueAsString(domain);

    for (String realmXid : parallelRealms) {

      Map<String, List<Resource>> policyResources = new HashMap<>();
      Map<String, List<com.persistent.pmt.sourcesso.casm.model.derived.AuthorizationPolicy>> policyData =
          new HashMap<>();
      Map<String, List<Resource>> realmWithGenericRulesResources = new HashMap<>();
      Map<String, List<Resource>> realmWithSpecificRulesResources = new HashMap<>();
      Map<String, List<Resource>> realmWithoutRulesResources = new HashMap<>();
      Map<String, String> resourceAuthzPolicy = new HashMap<>();
      Map<String, String> resourceAuthnPolicy = new HashMap<>();
      Map<String, List<Response>> resourceResponses = new HashMap<>();

      // Invocation to parse parent realm
      // returns whether realm had rule or not
      parseAgentRealmResourceAuthzPolicies(agentGroupXid, realmXid, domain,
              policyResources, policyData, realmWithGenericRulesResources,
              realmWithSpecificRulesResources, realmWithoutRulesResources, resourceResponses);    

      // Invocation of all the child realms of realm identified by
      // "realmXid"
      if (domain.getRealmHierarchy() != null
          && domain.getRealmHierarchy().get(realmXid) != null) {
        List<String> subRealms =
            Arrays.asList(domain.getRealmHierarchy().get(realmXid).split(MapperConstants.COMMA));
        for (String subRealmXid : subRealms) {
          parseAgentRealmResourceAuthzPolicies(agentGroupXid, subRealmXid, domain,
              policyResources, policyData, realmWithGenericRulesResources,
              realmWithSpecificRulesResources, realmWithoutRulesResources, resourceResponses);
        }
      }

      // Create Application entity
      Application application = new Application();
      application.setName(domain.getRealmByXid(realmXid).getName());
      if (domain.getProperties().containsKey(CasmConstants.IS_AFFILIATE_DOMAIN))
        application.setPepType(PMTConstants.PEP_TYPE_FEDERATION);
      else
        application.setPepType(PMTConstants.PEP_TYPE_AGENT);
      application.setEnabled(true);

      Agent agent = new Agent();
      agent.setId(agentGroupXid);
      application.setAgent(agent);

      List<UserDataStore> userDataStores = getUserDataStore(domain);
      if (userDataStores != null && !userDataStores.isEmpty()) {
        application.setUserDataStores(userDataStores);
      }

      List<AuthorizationPolicy> authzPolicies =
              getApplicationAuthorizationPolicies(policyResources, policyData,
                  realmWithGenericRulesResources, realmWithoutRulesResources,
                  resourceAuthzPolicy, domain);

      application.setAuthorizationPolicies(authzPolicies);   

      List<AuthenticationPolicy> authenPolicies =
          getApplicationAuthenticationPolices(realmWithGenericRulesResources,
              realmWithoutRulesResources, realmWithSpecificRulesResources, resourceAuthnPolicy,
              domain);

      application.setAuthenticationPolicies(authenPolicies);

      List<Resource> resources =
          getApplicationResources(realmWithGenericRulesResources,
              realmWithSpecificRulesResources, realmWithoutRulesResources, resourceAuthzPolicy,
              resourceAuthnPolicy);
      application.setResources(resources);

      // Set application attributes here
      List<ApplicationAttributes> applicationAttributes = getApplicationAttributes(domain, realmXid);
      application.setAttributes(applicationAttributes);

      List<Response> responses =
          getApplicationResponses(resourceResponses, resourceAuthzPolicy, resourceAuthnPolicy);
      application.setResponses(responses);


      application.setSourceRawData(domainJSON);

      // Update Application with one AuthenticationPolicy for all
      // resources
      updateApplicationAuthenticationPolicy(application, domain);
      applications.add(application);
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "and returns List of applications ");
    return applications;
  }

  /**
   * Create authorization policies
   * 
   * Resources from realms without rule + realms with generic
   * resources will form one authorization policy. This will protect
   * all the resources which are unprotected by specific resources
   * rules
   * 
   * Resource from realms with rules will result into multiple
   * authorization policies. Each entry in policyResource" will result
   * into one authorization policy
   * 
   * @param policyResources
   * @param policyData
   * @param realmWithGenericRuleResources
   * @param realmWithoutRulesResourceMap
   * @param realmWithSpecificRulesResources
   * @param resourceAuthzPolicies
   * @param domain
   * @return
   * @throws GenericException
   */
  private List<AuthorizationPolicy> getApplicationAuthorizationPolicies(
      Map<String, List<Resource>> policyResources,
      Map<String, List<com.persistent.pmt.sourcesso.casm.model.derived.AuthorizationPolicy>> policyData,
      Map<String, List<Resource>> realmWithGenericRuleResources,
      Map<String, List<Resource>> realmWithoutRulesResourceMap,
      Map<String, String> resourceAuthzPolicy, Domain domain) throws GenericException {

    final String methodName = "getApplicationAuthorizationPolicies";
    logger
        .log(
            Level.DEBUG,
            "Entering :: " + classname + ":" + methodName
                + "and passed parameters are List of Resources and domain with Id : "
                + domain.getxId());

    List<AuthorizationPolicy> applicationAuthorizationPolicies = new ArrayList<>();

    // Global authorization policy
    AuthorizationPolicy protectAllAuthzPolicy = new AuthorizationPolicy();
    protectAllAuthzPolicy.setName(MapperConstants.PROTECT_ALL_AUTHZ_POLICY_NAME);
    protectAllAuthzPolicy.setEnabled(true);

    Map<String, List<Resource>> protectAllResources = new HashMap<>();
    protectAllResources.putAll(realmWithGenericRuleResources);
    protectAllResources.putAll(realmWithoutRulesResourceMap);

    // Add those resources to Authz policy whose Realm's ProtectAll
    // status is True
    for (String realmXid : protectAllResources.keySet()) {
      // add only for resources for which anonymous is 1
      List<Resource> resources = protectAllAuthzPolicy.getResources();
      if (resources == null) {
        resources = new ArrayList<>();
      }
      resources.addAll(protectAllResources.get(realmXid));
      protectAllAuthzPolicy.setResources(resources);
    }

    // Attributes for protectAll authz policy
    AuthorizationPolicyAttribute protectAllAttribute = new AuthorizationPolicyAttribute();
    protectAllAttribute.setName(MapperConstants.USER_POLICY);
    protectAllAttribute.setConditionType(BitMappingEnum.USERPOLICY_RESOLUTIONTYPE
        .getBitMapValue(MapperConstants.DEFAULT_USER_POLICY_RESOLUTION_TYPE));
    protectAllAttribute.setConditionValue("*");
    protectAllAttribute.setNegate(false);
    protectAllAttribute.setPolicyFlag(BitMappingEnum.USERPOLICY_POLICYFLAGS
        .getBitMapValue(MapperConstants.DEFAULT_USER_POLICY_FLAG));
    List<AuthorizationPolicyAttribute> protectAllAttributes = new ArrayList<>();
    protectAllAttributes.add(protectAllAttribute);

    protectAllAuthzPolicy.setAttributes(protectAllAttributes);
    protectAllAuthzPolicy.setAuthorizationRule(protectAllAttribute.getName());

    applicationAuthorizationPolicies.add(protectAllAuthzPolicy);

    // Authz policy for protect all resources. One resource will have
    // only one authz policy
    if (null != protectAllAuthzPolicy.getResources()) {
      for (Resource resource : protectAllAuthzPolicy.getResources()) {
        resourceAuthzPolicy.put(resource.getUri(), protectAllAuthzPolicy.getName());
      }
    }
    protectAllAuthzPolicy.setResources(null);

    // All other authorization polices. One AuthorizationPolicy entity
    // for each entry in policyResources
    for (String policyLink : policyResources.keySet()) {

      AuthorizationPolicy authzPolicy = new AuthorizationPolicy();
      // Process policy attributes
      List<AuthorizationPolicyAttribute> attributes = new LinkedList<>();

      String[] policyXids = policyLink.split(CasmConstants.COMMA);
      String policyName = "";
      AtomicInteger counter = new AtomicInteger(0);
      boolean enabledPolicyFound = false;
      for (String pXid : policyXids) {

        Policy policy = domain.getPolicyByXid(pXid);
        // To check whether any of policy is disabled or not
        if (!enabledPolicyFound) {
          boolean isEnabled =
              Boolean.parseBoolean(policy.getProperties().get(XmlTagConstants.IS_ENABLED));
          if (isEnabled)
            enabledPolicyFound = true;
        }
        // Construct Policy name by appending names of each policy
        if (null != policy) {
          if (policyName.equals(""))
            policyName = policy.getName();
          else
            policyName = policyName + "-" + policy.getName();
        }
        extractIpAddressAttribute(policy, attributes, counter);
      }

      authzPolicy.setName(policyName);
      authzPolicy.setResources(policyResources.get(policyLink));
      authzPolicy.setEnabled(enabledPolicyFound);

      // This set will maintain UserPolicyLink already added as
      // attributes, thus skipping adding redundant data
      Set<String> addedUserPolicy = new HashSet<>();

      if (policyData.get(policyLink) != null && !policyData.get(policyLink).isEmpty()) {
        Map<String, Integer> policyNameSuffix = new HashMap<>();
        for (com.persistent.pmt.sourcesso.casm.model.derived.AuthorizationPolicy authzPolicyData : policyData
            .get(policyLink)) {
          AuthorizationPolicyAttribute attribute = new AuthorizationPolicyAttribute();
          attribute.setNegate(authzPolicyData.isNegateFlag());
          attribute.setConditionValue(authzPolicyData.getValue());

          Integer resolutionType = Integer.parseInt(authzPolicyData.getResolutionType());
          attribute.setConditionType(BitMappingEnum.USERPOLICY_RESOLUTIONTYPE
              .getBitMapValue(resolutionType));

          // Derive user policy name with a counter as suffix
          if (resolutionType != null) {
            String name = BitMappingEnum.USERPOLICY_NAME.getBitMapValue(resolutionType);
            Integer suffixCounter = policyNameSuffix.get(name);
            if (suffixCounter == null) {
              suffixCounter = 1;
            }
            else {
              suffixCounter += 1;
            }
            attribute.setName(name + suffixCounter);
            policyNameSuffix.put(name, suffixCounter);
          }

          // Policy Flag value
          String policyFlag = authzPolicyData.getPolicyFlag();
          if (policyFlag == null || policyFlag.isEmpty()) {
            policyFlag = String.valueOf(MapperConstants.DEFAULT_USER_POLICY_FLAG);
          }
          attribute.setPolicyFlag(policyFlag);

          // Add only unique user policies
          if (!addedUserPolicy.contains(attribute.getName())) {
            attributes.add(attribute);
            addedUserPolicy.add(attribute.getName());
          }
          authzPolicy.setNegate(attribute.isNegate());
        }
        authzPolicy.setAttributes(attributes);

        String authorizationRule =
            getAuthorizationRule(attributes, policyLink, domain.getPolicies());
        authzPolicy.setAuthorizationRule(authorizationRule);
      }
      else {
        // In case of no authz policy attributes, add the protectAll
        // policy attributes
        authzPolicy.setAttributes(protectAllAuthzPolicy.getAttributes());
        authzPolicy.setAuthorizationRule(protectAllAuthzPolicy.getAuthorizationRule());

        // Audited for SOURCE_MAPPER_AUTH_POLICIES
      /*  auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.NEED_REVIEW,
            environment.getProperty(AuditPropertyConstants.SOURCE_MAPPER_AUTH_POLICIES), "",
            new Object[] { policyName });*/
        logger.log(Level.INFO, "Policy link not found for SM Policy with name: " + policyName);

      }

      // Add policy to list of policies for this application
      applicationAuthorizationPolicies.add(authzPolicy);

      // One resource will have only on authz policy
      for (Resource resource : authzPolicy.getResources()) {
        resourceAuthzPolicy.put(resource.getUri(), authzPolicy.getName());
      }

      // Do not need resources in policy object
      authzPolicy.setResources(null);
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "and returns AuthorizationPolicies  : ");

    return applicationAuthorizationPolicies;
  }

  /**
   * Create authorization rule from user policy data
   * 
   * @param attributes
   * @return
   */
  private String getAuthorizationRule(List<AuthorizationPolicyAttribute> attributes,
      String policyLink, List<Policy> policies) {
    final String methodName = "getAuthorizationRule";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameters are AuthorizationPolicyAttribute policies  and policyLink: "
        + policyLink);
    String authorizationRule = null;
    if (attributes != null && !attributes.isEmpty()) {
      authorizationRule = "[";
      String operator = null;
      List<String> ipAddressList = new ArrayList<>();

      for (AuthorizationPolicyAttribute attribute : attributes) {

        String name = attribute.getName();
        if (null != name && name.contains("IPAddress")) {
          ipAddressList.add(name);
        }
        else {
          Integer policyFlagBit = Integer.parseInt(attribute.getPolicyFlag());
          String policyFlag =
              BitMappingEnum.USERPOLICY_POLICYFLAGS.getBitMapValue(policyFlagBit);

          if (policyFlag == null || policyFlag.isEmpty()) {
            policyFlag = BitMappingEnum.USERPOLICY_POLICYFLAGS.getBitMapValue(0);
          }

          switch (policyFlag) {
            case MapperConstants.DEFAULT:
              String defaultRule = "(" + name + ")";
              if (operator == null) {
                authorizationRule = authorizationRule + defaultRule;
              }
              else {
                authorizationRule = authorizationRule + operator + defaultRule;
              }
              operator = MapperConstants.OR;
              break;

            case MapperConstants.EXCLUDE:
              String excludeRule = "(" + MapperConstants.NOT + name + ")";
              if (operator == null) {
                authorizationRule = authorizationRule + excludeRule;
              }
              else {
                authorizationRule = authorizationRule + operator + excludeRule;
              }
              operator = MapperConstants.OR;
              break;

            case MapperConstants.AND:
              String andRule = "(" + name + ")";
              if (operator == null) {
                authorizationRule = authorizationRule + andRule;
              }
              else {
                authorizationRule = authorizationRule + operator + andRule;
              }
              operator = MapperConstants.AND;
              break;

            case MapperConstants.RECURSIVE:
              continue;
          }

        }

      }
      authorizationRule = authorizationRule + "]";

      if (!ipAddressList.isEmpty()) {

        boolean flag = false;
        authorizationRule = authorizationRule + MapperConstants.AND + "[";
        for (String ipAddress : ipAddressList) {

          if (flag) {
            authorizationRule = authorizationRule + MapperConstants.OR;
          }
          flag = true;
          authorizationRule = authorizationRule + "(" + ipAddress + ")";
        }
        authorizationRule = authorizationRule + "]";
      }

    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and returns  authorizationRule: " + authorizationRule);
    return authorizationRule;
  }

  /**
   * Get the list of all the resources for current application in
   * process. The 3 resources lists as params contain distinct
   * resources in them.
   * 
   * @param realmWithGenericRuleResources
   * @param realmWithSpecificRuleResources
   * @param realmWithoutRulesResourceMap
   * @param resourceAuthzPolicy
   * @param resourceAuthnPolicy
   * @return
   */
  private List<Resource> getApplicationResources(
      Map<String, List<Resource>> realmWithGenericRuleResources,
      Map<String, List<Resource>> realmWithSpecificRuleResources,
      Map<String, List<Resource>> realmWithoutRulesResourceMap,
      Map<String, String> resourceAuthzPolicy, Map<String, String> resourceAuthnPolicy) {

    final String methodName = "getApplicationResources";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameters are Map Of Realm with of Rule Resources : ");

    Set<String> uniqueRealms = new HashSet<>();
    uniqueRealms.addAll(realmWithGenericRuleResources.keySet());
    uniqueRealms.addAll(realmWithSpecificRuleResources.keySet());
    uniqueRealms.addAll(realmWithoutRulesResourceMap.keySet());

    List<Resource> resources = new ArrayList<>();
    for (String uniqueRealm : uniqueRealms) {
      List<Resource> genericResources = realmWithGenericRuleResources.get(uniqueRealm);
      if (genericResources != null) {
        resources.addAll(genericResources);
      }
      List<Resource> specificResources = realmWithSpecificRuleResources.get(uniqueRealm);
      if (specificResources != null) {
        resources.addAll(specificResources);
      }
      List<Resource> withoutRuleResources = realmWithoutRulesResourceMap.get(uniqueRealm);
      if (withoutRuleResources != null) {
        resources.addAll(withoutRuleResources);
      }
    }

    List<Resource> applicationResources = new ArrayList<>();
    // Set authz and authn policies for each resource
    for (Resource resource : resources) {

      if (resourceAuthnPolicy.get(resource.getUri()) != null
          && !resourceAuthnPolicy.get(resource.getUri()).isEmpty()) {
        AuthenticationPolicy authnPolicy = new AuthenticationPolicy();
        authnPolicy.setName(resourceAuthnPolicy.get(resource.getUri()));
        resource.setAuthenticationPolicy(authnPolicy);
      }

      if (resourceAuthzPolicy.get(resource.getUri()) != null
          && !resourceAuthzPolicy.get(resource.getUri()).isEmpty()) {
        AuthorizationPolicy authzPolicy = new AuthorizationPolicy();
        authzPolicy.setName(resourceAuthzPolicy.get(resource.getUri()));
        resource.setAuthorizationPolicy(authzPolicy);
      }

      applicationResources.add(resource);
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "and returns List of resources ");

    return applicationResources;
  }

  /**
   * Get the list of UserDataStores for the domain
   * 
   * @param domain
   * @return
   */
  private List<UserDataStore> getUserDataStore(Domain domain) {

    final String methodName = "getUserDataStore";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameter is Domain with ID : " + domain.getxId());

    List<UserDataStore> userDataStores = null;
    if (domain.getUserDirectoryLinks() != null) {
      userDataStores = new ArrayList<>();
      for (String userDirectory : domain.getUserDirectoryLinks()) {
        String xid = LookupUtil.getUserDirectoryXidByName(userDirectory);
        UserDataStore userDataStore = new UserDataStore();
        userDataStore.setId(xid);

        userDataStores.add(userDataStore);
      }
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "and returns List of UserDataStore ");

    return userDataStores;
  }

  /**
   * Get the list of all authentication policies for application
   * 
   * @param realmWithGenericRuleResources
   * @param realmWithSpecificRuleResources
   * @param realmWithoutRulesResources
   * @param domain
   * @param resourceAuthnPolicies
   * @return
   */
  private List<AuthenticationPolicy> getApplicationAuthenticationPolices(
      Map<String, List<Resource>> realmWithGenericRuleResources,
      Map<String, List<Resource>> realmWithSpecificRuleResources,
      Map<String, List<Resource>> realmWithoutRulesResources,
      Map<String, String> resourceAuthnPolicy, Domain domain) {

    final String methodName = "getApplicationAuthenticationPolices";
    logger
        .log(
            Level.DEBUG,
            "Entering :: "
                + classname
                + ":"
                + methodName
                + "and passed parameters are Map Of Realm with of Rule Resources  and Domain with Id : "
                + domain.getxId());

    Set<String> uniqueRealms = new HashSet<>();
    uniqueRealms.addAll(realmWithGenericRuleResources.keySet());
    uniqueRealms.addAll(realmWithSpecificRuleResources.keySet());
    uniqueRealms.addAll(realmWithoutRulesResources.keySet());

    List<AuthenticationPolicy> authenPolicies = new ArrayList<>();

    for (String uniqueRealm : uniqueRealms) {

      AuthenticationPolicy authenPolicy = new AuthenticationPolicy();
      authenPolicy.setName(uniqueRealm);
      authenPolicy.setEnabled(true);

      Realm realm = domain.getRealmByXid(uniqueRealm);
      if (realm.getProperties() != null) {

        String authSchemeLink = realm.getProperties().get(XmlTagConstants.AUTH_SCHEME_LINK);
        AuthenticationScheme authenScheme = new AuthenticationScheme();
        authenScheme.setId(authSchemeLink);

        authenPolicy.setAuthenticationScheme(authenScheme);
      }

      // List of all resources for this authn policy
      List<Resource> authnResources = new ArrayList<>();
      List<Resource> genericResources = realmWithGenericRuleResources.get(uniqueRealm);
      if (genericResources != null) {
        authnResources.addAll(genericResources);
      }
      List<Resource> specificResources = realmWithSpecificRuleResources.get(uniqueRealm);
      if (specificResources != null) {
        authnResources.addAll(specificResources);
      }
      List<Resource> withoutRuleResources = realmWithoutRulesResources.get(uniqueRealm);
      if (withoutRuleResources != null) {
        authnResources.addAll(withoutRuleResources);
      }
      // Add authnPolicy name for each resource
      for (Resource resource : authnResources) {
        resourceAuthnPolicy.put(resource.getUri(), authenPolicy.getName());
      }

      authenPolicies.add(authenPolicy);
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "and returns List of AuthenticationPolicy : ");

    return authenPolicies;
  }

  /**
   * Get the list of responses for application
   * 
   * @param resourceResponses
   * @param resourceAuthzPolicy
   * @param resourceAuthnPolicy
   * @return
   */
  private List<Response> getApplicationResponses(Map<String, List<Response>> resourceResponses,
      Map<String, String> resourceAuthzPolicy, Map<String, String> resourceAuthnPolicy) {

    final String methodName = "getApplicationResponses";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameters are resourceAuthzPolicies : ");

    List<Response> responses = null;
    if (!resourceResponses.isEmpty()) {
      responses = new ArrayList<>();

      Set<String> resourceURIs = resourceResponses.keySet();
      Set<String> uniqueResponseNames = new HashSet<>();
      for (String resourceURI : resourceURIs) {

        List<Response> responseList = resourceResponses.get(resourceURI);
        for (Response response : responseList) {

          if (response.isAuthenticationType()) {

            String authNname = resourceAuthnPolicy.get(resourceURI);
            if (null != authNname) {
              AuthenticationPolicy responseAuthnPolicy = new AuthenticationPolicy();
              responseAuthnPolicy.setName(authNname);
              response.setAuthenticationPolicy(responseAuthnPolicy);
            }
          }
          else if (response.isAuthorizationType()) {

            String authZname = resourceAuthzPolicy.get(resourceURI);
            if (null != authZname) {
              AuthorizationPolicy authzPolicy = new AuthorizationPolicy();
              authzPolicy.setName(authZname);
              response.setAuthorizationPolicy(authzPolicy);
            }
          }

          if (!uniqueResponseNames.contains(response.getName())) {
            responses.add(response);
            uniqueResponseNames.add(response.getName());
          }
        }
      }
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and returned value is list of Responses ");

    return responses;
  }

  /**
   * Get the application attributes
   * 
   * @param authzPolicies
   * @param domain
   * @return
   * @throws GenericException
   */
  private List<ApplicationAttributes> getApplicationAttributes(Domain domain, String realmXid)
      throws GenericException {
    final String methodName = "getApplicationAttributes";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameters are List of AuthorizationPolicy and domain with XID is : "
        + domain.getxId() + "and realm with Xid " + realmXid);

    List<ApplicationAttributes> attributes = new ArrayList<>();

    ApplicationAttributes domainName = new ApplicationAttributes();
    domainName.setSourceAttrName(MapperConstants.APP_ATTR_DOMAIN_NAME);
    domainName.setSourceAttrValue(domain.getName());
    attributes.add(domainName);

    // If any policy is disabled, then true
    if (domain.getProperties().containsKey(CasmConstants.DISABLED_POLICY)) {
      ApplicationAttributes disabledPolicy = new ApplicationAttributes();
      disabledPolicy.setSourceAttrName(CasmConstants.DISABLED_POLICY);
      disabledPolicy.setSourceAttrValue(CasmConstants.STRING_TRUE);
      attributes.add(disabledPolicy);
    }

    if (domain.getProperties().containsKey(CasmConstants.HAS_GLOBAL_RESPONSE)) {
      ApplicationAttributes globalResponse = new ApplicationAttributes();
      globalResponse.setSourceAttrName(CasmConstants.HAS_GLOBAL_RESPONSE);
      globalResponse.setSourceAttrValue(domain.getProperties().get(
          CasmConstants.HAS_GLOBAL_RESPONSE));
      attributes.add(globalResponse);
    }

    if (domain.getProperties().containsKey(CasmConstants.IS_OBSOLETE)) {

      ApplicationAttributes obsoleteAttribute = new ApplicationAttributes();
      obsoleteAttribute.setSourceAttrName(CasmConstants.IS_OBSOLETE);
      obsoleteAttribute.setSourceAttrValue(CasmConstants.STRING_TRUE);
      attributes.add(obsoleteAttribute);
    }

    if (domain.getProperties().containsKey(CasmConstants.RULES_CONSOLIDATED)) {

      ApplicationAttributes rulesConsolidated = new ApplicationAttributes();
      rulesConsolidated.setSourceAttrName(CasmConstants.RULES_CONSOLIDATED);
      rulesConsolidated.setSourceAttrValue(CasmConstants.STRING_TRUE);
      attributes.add(rulesConsolidated);
    }

    if (domain.getProperties().containsKey(CasmConstants.AGENT_HIER_RES_CONSOLIDATED)) {

      ApplicationAttributes agnetHierAttrConsolidatecd = new ApplicationAttributes();
      agnetHierAttrConsolidatecd.setSourceAttrName(CasmConstants.AGENT_HIER_RES_CONSOLIDATED);
      agnetHierAttrConsolidatecd.setSourceAttrValue(CasmConstants.STRING_TRUE);
      attributes.add(agnetHierAttrConsolidatecd);
    }

    if (domain.getProperties().containsKey(PMTConstants.PROVIDER_NAME)) {

      ApplicationAttributes samlProviderName = new ApplicationAttributes();
      samlProviderName.setSourceAttrName(PMTConstants.PROVIDER_NAME);
      samlProviderName.setSourceAttrValue(domain.getProperties()
          .get(PMTConstants.PROVIDER_NAME));
      attributes.add(samlProviderName);
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "and returns List of ApplicationAttributes with size");

    return attributes;
  }

  /**
   * Updates the Application entity bean to contain one top level
   * AuthenticationPolicy. All resources will point to this
   * AuthenticationPolicy. AuthScheme will be the one with highest
   * authentication level
   * 
   */
  private void updateApplicationAuthenticationPolicy(Application application, Domain domain) {

    final String methodName = "updateApplicationAuthenticationPolicy";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameters are Application with ID " + application.getId()
        + " and Domain with ID :" + domain.getxId());

    PMTContext pmtContext = pmtContextThreadLocal.get();
    String env = pmtContext.getEnvironmentValue();

    List<AuthScheme> authSchemes = LookupUtil.getAuthSchemesData();
    AuthenticationPolicy authenticationPolicy = null;

    List<AuthenticationPolicy> authenPolicies = application.getAuthenticationPolicies();
    if (authenPolicies != null && !authenPolicies.isEmpty()) {

      // TODO: extract this code out in LookupUtil to make it one time
      // process
      // Get AuthScheme Id, authentication level
      Map<String, String> authSchemeLevels = new HashMap<>();
      if (authSchemes != null && !authSchemes.isEmpty()) {
        for (AuthScheme authScheme : authSchemes) {
          authSchemeLevels.put(authScheme.getxId(),
              authScheme.getProperties().get(XmlTagConstants.LEVEL));
        }
      }

      String applicationAuthSchemeDefault =
          systemEnvironment
              .getProperty(MapperConstants.APPLICATION_AUTHSCHEME_DEFAULT_PROPERTY);

      // TODO: default authentication scheme....

      Integer highestAuthLevel = 0;
      String highestAuthLevelAuthSchemeId = null;

      if (StringUtils.hasText(applicationAuthSchemeDefault)) {
        highestAuthLevelAuthSchemeId = applicationAuthSchemeDefault;
        String authSchemeLevel = authSchemeLevels.get(applicationAuthSchemeDefault);
        if (StringUtils.hasText(authSchemeLevel)) {
          highestAuthLevel = Integer.parseInt(authSchemeLevel);
        }
      }
      else {
        // Find highest authentication level auth scheme
        for (AuthenticationPolicy authenPolicy : authenPolicies) {
          if (authenPolicy.getAuthenticationScheme() != null) {
            String authSchemeId = authenPolicy.getAuthenticationScheme().getId();
            String authSchemeLevel = authSchemeLevels.get(authSchemeId);

            if (authSchemeLevel != null && !authSchemeLevel.isEmpty()) {
              Integer authenticationLevel = Integer.parseInt(authSchemeLevel);
              if (highestAuthLevel <= authenticationLevel) {
                highestAuthLevel = authenticationLevel;
                highestAuthLevelAuthSchemeId = authSchemeId;
              }
            }
          }
        }
      }

      // To set default authentication scheme for SAML2 and WSFED by
      // fetching
      // any one authentication scheme from DB
      AuthenticationScheme authNScheme = null;
      String authType = domain.getProperties().get(CasmConstants.AUTH_TYPE);
      if (PMTConstants.PROVIDER_SAML2.equals(authType)) {
        List<AuthenticationScheme> authSchemelist =
            authenticationSchemeDao.getAuthNSchemesByType(PMTConstants.AUTH_SCHEME_TYPE_SAML2,
                env);
        if (!authSchemelist.isEmpty())
          authNScheme = authSchemelist.get(0);

      }
      else if (PMTConstants.PROVIDER_WSFEDSP.equals(authType)) {
        List<AuthenticationScheme> authSchemelist =
            authenticationSchemeDao.getAuthNSchemesByType(PMTConstants.AUTH_SCHEME_TYPE_WSFED,
                env);
        if (!authSchemelist.isEmpty())
          authNScheme = authSchemelist.get(0);
      }
      if (null != authNScheme) {
        highestAuthLevelAuthSchemeId = authNScheme.getId();
        highestAuthLevel = Integer.parseInt(authNScheme.getLevel());
      }

      if (highestAuthLevelAuthSchemeId != null) {
        // Create AuthenticationPolicy
        authenticationPolicy = new AuthenticationPolicy();
        authenticationPolicy.setName(application.getName());
        authenticationPolicy.setEnabled(true);
        authenticationPolicy.setAuthenticationLevel(highestAuthLevel);
        authenticationPolicy.setDefaultEntity(true);

        AuthenticationScheme authenticationScheme = new AuthenticationScheme();
        authenticationScheme.setId(highestAuthLevelAuthSchemeId);
        authenticationPolicy.setAuthenticationScheme(authenticationScheme);

        // Add the authentication policy to Application object
        authenPolicies.add(authenticationPolicy);
        application.setAuthenticationPolicies(authenPolicies);

      }

    }

    // Update all Application resources with new AuthenticationPolicy
    if (authenticationPolicy != null) {
      List<Resource> resources = application.getResources();
      List<Resource> updatedResources = new LinkedList<>();

      if (resources != null && !resources.isEmpty()) {
        for (Resource resource : resources) {
          AuthenticationPolicy resourceAuthenPolicy = new AuthenticationPolicy();
          resourceAuthenPolicy.setName(authenticationPolicy.getName());
          resource.setAuthenticationPolicy(resourceAuthenPolicy);
          updatedResources.add(resource);
        }
        application.setResources(updatedResources);
      }
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " does not return anything just updates Application Entity ");
  }

  /**
   * Process domain to extract the resources and policies for an agent
   * 
   * @param agentGroupXid
   * @param realmXid
   * @param domain
   * @param policyResources
   * @param policyData
   * @param realmWithRulesUmbrellaResourceMap
   * @param realmWithRulesAllResourceMap
   * @param realmWithoutRulesResourceMap
   * @throws GenericException
   */
  private boolean parseAgentRealmResourceAuthzPolicies(
      String agentGroupXid,
      String realmXid,
      Domain domain,
      Map<String, List<Resource>> policyResources,
      Map<String, List<com.persistent.pmt.sourcesso.casm.model.derived.AuthorizationPolicy>> policyData,
      Map<String, List<Resource>> realmWithGenericRuleResources,
      Map<String, List<Resource>> realmWithSpecificRuleResources,
      Map<String, List<Resource>> realmWithoutRulesResourceMap,
      Map<String, List<Response>> resourceResponses) throws GenericException {

    final String methodName = "parseAgentRealmResourceAuthzPolicies";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameters are agentGroupXid : " + "" + agentGroupXid + ", realmXid : "
        + realmXid + " and domain with ID :" + domain.getxId());

    Map<String, Set<ResourceDefinition>> agentResourceDefMap = domain.getAgentResourceDefMap();
    boolean isRealmWithRule = false;

    // Get the resources and authorization policies, if the realm has
    // a rule i.e. present in agentDefResourceMap
    if (agentResourceDefMap != null && agentResourceDefMap.get(agentGroupXid) != null) {

      Set<ResourceDefinition> resourceDefs = agentResourceDefMap.get(agentGroupXid);
      Set<ResourceDefinition> uniqueResourceDef = new HashSet<>(resourceDefs);

      // Loop over all the resourceDef to find the object with
      // realmLink = realmXid
      for (ResourceDefinition resourceDef : uniqueResourceDef) {

        Realm localRealm = domain.getRealmByXid(realmXid);
        List<Rule> realmRules = localRealm.getRules();

				if (!realmRules.isEmpty()) {
					// Parse agentGroup with realm
					if (realmXid.equalsIgnoreCase(resourceDef.getRealmLink())) {
						// bug fix PMT_Defect_32
						processAgentResourceDefinition(realmXid, resourceDef,
								policyResources, policyData,
								realmWithGenericRuleResources,
								realmWithSpecificRuleResources,
								resourceResponses, domain);
						
					}
					isRealmWithRule = true;
				}
      }
    }
    // The realm is without rule if either agentGroup does not have an
    // entry in agentResourceDefMap, or agentResourceDefMap object for
    // the agentGroupXid does not have an entry for realmXid
    if (!isRealmWithRule) {
      processRealmsWithoutRules(realmXid, domain, realmWithoutRulesResourceMap);
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " doesn't return anything just Process domain to extract "
        + "the resources and policies for an agent");

    return isRealmWithRule;
  }

  /**
   * Update map of realmXid to resources URI set
   * 
   * @param realmXid
   * @param domain
   * @param realmWithoutRulesResourceMap
   */
  private void processRealmsWithoutRules(String realmXid, Domain domain,
      Map<String, List<Resource>> realmWithoutRulesResourceMap) {

    final String methodName = "processRealmsWithoutRules";
    logger.log(Level.DEBUG,
        "Entering :: " + classname + ":" + methodName + "and passed parameters are realmXid : "
            + realmXid + " and Domain with Id " + domain.getxId());

    List<Resource> resources = realmWithoutRulesResourceMap.get(realmXid);
    if (resources == null) {
      resources = new ArrayList<>();
    }

    Realm realm = domain.getRealmByXid(realmXid);
    Map<String, String> properties = realm.getProperties();

    // Parent parent realm's URI
    String uri = getParentRealmURI(realmXid, domain);

    if (properties != null) {

      if (uri.lastIndexOf("/") != -1 && !checkForLeafNode(uri)) {
        uri = uri + MapperConstants.GENERIC_RESOURCE;
      }
      Resource resource = new Resource();
      resource.setUri(cleanseResourcePath(uri));

      List<String> httpMethods = new ArrayList<>();
      httpMethods.add(MapperConstants.ALL);
      resource.setHttpMethods(httpMethods);

      resource.setEnabled(true);

      if (MapperConstants.FALSE.equalsIgnoreCase(properties.get(XmlTagConstants.PROTECT_ALL))) {
        resource.setAnonymous(true);
      }
      else {
        resource.setAnonymous(false);
      }

      if (MapperConstants.ROOT_RESOURCE.equalsIgnoreCase(properties
          .get(XmlTagConstants.RESOURCE_FILTER))
          || MapperConstants.GENERIC_RESOURCE.equalsIgnoreCase(properties
              .get(XmlTagConstants.RESOURCE_FILTER))) {
        resource.setRootResource(1);
      }

      resource.setResourceType(MapperConstants.URL);
      resources.add(resource);
    }
    realmWithoutRulesResourceMap.put(realmXid, resources);
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " doesn't return anything just Update map of realmXid to resources URI set");

  }

  /**
   * Recursively get the parent resource URI and form the parent URI
   * 
   * @param realmXid
   * @param domain
   * @return
   */
  private String getParentRealmURI(String realmXid, Domain domain) {
    final String methodName = "getParentRealmURI";
    logger.log(Level.DEBUG,
        "Entering :: " + classname + ":" + methodName + "and passed parameters are realmXid : "
            + realmXid + " and Domain with Id " + domain.getxId());

    Realm realm = domain.getRealmByXid(realmXid);
    Map<String, String> properties = realm.getProperties();
    String uri = "";

    if (properties != null && properties.get(XmlTagConstants.PARENT_REALM_LINK) != null) {
      uri =
          getParentRealmURI(properties.get(XmlTagConstants.PARENT_REALM_LINK), domain)
              + MapperConstants.ROOT_RESOURCE + properties.get(XmlTagConstants.RESOURCE_FILTER);
    }
    else {
      uri = properties.get(XmlTagConstants.RESOURCE_FILTER);
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName + " and returns :"
        + uri);

    return uri;
  }

  /**
   * Process realm with rules and form the maps in method params.
   * 
   * @param realmXid
   * @param resourceDef
   * @param policyResources
   * @param policyData
   * @param realmWithGenericRuleResources
   * @param realmWithSpecificRuleResources
   * @param resourceResponses
   * @param domain
   */
  private void processAgentResourceDefinition(
      String realmXid,
      ResourceDefinition resourceDef,
      Map<String, List<Resource>> policyResources,
      Map<String, List<com.persistent.pmt.sourcesso.casm.model.derived.AuthorizationPolicy>> policyData,
      Map<String, List<Resource>> realmWithGenericRuleResources,
      Map<String, List<Resource>> realmWithSpecificRuleResources,
      Map<String, List<Response>> resourceResponses, Domain domain) {

    final String methodName = "processAgentResourceDefinition";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameters are realmXid : " + realmXid + " and ResourceDefinition "
        + resourceDef.toString());

    Resource resource = new Resource();

    if (resourceDef.getAction() != null && !resourceDef.getAction().isEmpty()) {
      resource.setHttpMethods(Arrays.asList(resourceDef.getAction()
          .split(MapperConstants.COMMA)));
    }
    resource.setResourceType(MapperConstants.URL);

    // If the rule's protectedStatus = false, then anonymous is true
    if (resourceDef.getProtectedStatus() != null) {
      boolean status =
          resourceDef.getProtectedStatus().equalsIgnoreCase(MapperConstants.TRUE) ? false
              : true; // swapped
      // true false for bug fix
      resource.setAnonymous(status);
    }

    // Process resource URI
    String resourceDefURI = cleanseResourcePath(resourceDef.getResourceUri());

    // This setter is for policyResources and
    // realmWithSpecificRuleResources
    resource.setUri(resourceDefURI);

    // RootResource
    if (MapperConstants.ROOT_RESOURCE.equalsIgnoreCase(resource.getUri())
        || MapperConstants.GENERIC_RESOURCE.equalsIgnoreCase(resource.getUri())) {
      resource.setRootResource(1);
    }

    // Add the resource in realmWithSpecificRuleResources
    List<Resource> specificResources = realmWithSpecificRuleResources.get(realmXid);
    if (specificResources == null) {
      specificResources = new ArrayList<>();
    }
    specificResources.add(resource);
    realmWithSpecificRuleResources.put(realmXid, specificResources);

    // policyResources will have PolicyLink as key
    String policyLink = resourceDef.getPolicyLink();
    List<Resource> resources = policyResources.get(policyLink);
    if (resources == null) {
      resources = new ArrayList<>();
    }
    resources.add(resource);
    policyResources.put(policyLink, resources);

    // AuthorizationPolicies will be added in policyData with
    // PolicyLink as key. It will add policy only if it is not present
    // in policyData
    for (com.persistent.pmt.sourcesso.casm.model.derived.AuthorizationPolicy sourceAuthzPolicy : resourceDef
        .getAuthorizationPolicyList()) {

      List<com.persistent.pmt.sourcesso.casm.model.derived.AuthorizationPolicy> userPolicies =
          policyData.get(policyLink);
      if (userPolicies == null) {
        userPolicies = new ArrayList<>();
      }
      Set<String> uniqueUserPolicy = new HashSet<>();
      for (com.persistent.pmt.sourcesso.casm.model.derived.AuthorizationPolicy userPolicy : userPolicies) {
        uniqueUserPolicy.add(userPolicy.getUserPolicyLink());
      }

      if (!uniqueUserPolicy.contains(sourceAuthzPolicy.getUserPolicyLink())) {
        userPolicies.add(sourceAuthzPolicy);
        uniqueUserPolicy.add(sourceAuthzPolicy.getUserPolicyLink());
      }
      policyData.put(policyLink, userPolicies);
    }

    // Process URI to set it in realmWithGenericRuleResources
    // The resource will be added only, if the resourceDefURI is not *
    // If resourceDefURI = *, then resourceURI = ResourceFilter of
    // realm + /*
    if (resourceDefURI != null
        && !(MapperConstants.ALL_RESOURCE.equalsIgnoreCase(resourceDefURI) || MapperConstants.GENERIC_RESOURCE
            .equals(resourceDefURI))) {

      Realm realm = domain.getRealmByXid(realmXid);
      if (realm != null && realm.getProperties() != null) {
        Resource genericResource = new Resource();
        genericResource.setHttpMethods(resource.getHttpMethods());

        String protectAllStatus = realm.getProperties().get(XmlTagConstants.PROTECT_ALL);
        boolean isAnonymous =
            (protectAllStatus != null && MapperConstants.TRUE
                .equalsIgnoreCase(protectAllStatus)) ? false : true;
        genericResource.setAnonymous(isAnonymous);
        genericResource.setResourceType(resource.getResourceType());
        genericResource.setRootResource(resource.getRootResource());

        String uri = realm.getProperties().get(XmlTagConstants.RESOURCE_FILTER);
        if (uri.lastIndexOf("/") != -1 && !checkForLeafNode(uri)) {
          uri = uri + MapperConstants.GENERIC_RESOURCE;
        }
        genericResource.setUri(cleanseResourcePath(uri));

        if (!resourceDefURI.equals(genericResource.getUri())) {
          // Add the resource in realmWithSpecificRuleResources
          List<Resource> genericResources = realmWithGenericRuleResources.get(realmXid);
          if (genericResources == null) {
            genericResources = new ArrayList<>();
          }

          // Add only resources which is not present in
          // genericResources
          Set<String> uniqueRenericResources = new HashSet<>();
          for (Resource genResource : genericResources) {
            uniqueRenericResources.add(genResource.getUri());
          }

          // Add only if resource is not present in genericResources
          if (!(uniqueRenericResources.contains(genericResource.getUri()) || genericResource
              .getUri().equals(resource.getUri()))) {
            genericResources.add(genericResource);
            realmWithGenericRuleResources.put(realmXid, genericResources);
          }
        }

      }
    }

    // Construct response objects
    if (resourceDef.getResponses() != null && !resourceDef.getResponses().isEmpty()) {

      Set<PolicyResponse> responses = resourceDef.getResponses();
      List<Response> responseEntityList = new ArrayList<>();
      for (PolicyResponse response : responses) {

        AtomicInteger nameCounter = new AtomicInteger(0);
        for (ResponseAttr responseAttr : response.getResponseAttrList()) {

          Response responseEntity = new Response();
          responseEntity.setName(response.getName() + nameCounter.incrementAndGet()); // extract
                                                                                      // name
                                                                                      // from
                                                                                      // response
                                                                                      // attr
          responseEntity.setDescription(response.getDesc());
          responseEntity.setAuthenticationType(response.isAuthenticationType());
          responseEntity.setAuthorizationType(response.isAuthorizationType());

          Map<String, String> properties = responseAttr.getProperties();
          responseEntity.setValue(properties.get(XmlTagConstants.VALUE));
          responseEntity.setType(properties.get(XmlTagConstants.TYPE));

          String responseType = properties.get(XmlTagConstants.TYPE);
          if (null != responseType) {
            if (responseType.contains(CasmConstants.RESPONSE_ACTION_TYPE_ACCEPT))
              responseEntity.setValueType(PMTConstants.SUCCESS);
            else if (responseType.contains(CasmConstants.RESPONSE_ACTION_TYPE_REJECT))
              responseEntity.setValueType(PMTConstants.FAILURE);
          }
          responseEntityList.add(responseEntity);
        }
      }
      resourceResponses.put(resourceDef.getResourceUri(), responseEntityList);
    }
    logger
        .log(
            Level.DEBUG,
            "Exiting :: "
                + classname
                + ":"
                + methodName
                + " doesn't return anything just Process realm with rules and form the maps in method params");

  }

  private void resolveNamesForXid(Domain domain) {

    final String methodName = "resolveNamesForXid";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameters is Domain " + domain.getxId());

    Map<String, String> propMap = domain.getProperties();
    propMap.put("UserDirectoryName",
        LookupUtil.getName(propMap.get(XmlTagConstants.USER_DIRECTORIES_LINK)));

    List<Realm> realms = domain.getRealms();
    for (Realm realm : realms) {
      Map<String, String> realmPropMap = realm.getProperties();
      realmPropMap.put("AuthSchemeName",
          LookupUtil.getName(realmPropMap.get(XmlTagConstants.AUTH_SCHEME_LINK)));
      realmPropMap.put(CasmConstants.AGENT_NAME,
          LookupUtil.getName(realmPropMap.get(XmlTagConstants.AGENT_GROUP_LINK)));
      if (null == realmPropMap.get(CasmConstants.AGENT_NAME))
        realmPropMap.put(CasmConstants.AGENT_NAME,
            LookupUtil.getName(realmPropMap.get(XmlTagConstants.AGENT_LINK)));
    }
    List<com.persistent.pmt.sourcesso.casm.model.Response> responses = domain.getResponses();
    for (com.persistent.pmt.sourcesso.casm.model.Response response : responses) {
      Map<String, String> responsePropMap = response.getProperties();
      responsePropMap.put("AgentTypeName",
          LookupUtil.getAgentType(responsePropMap.get(XmlTagConstants.AGENT_TYPE_LINK)));
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " doesn't return anything just resolves name for XID");
  }

  private Set<String> mergeResourceDefForAgentsOfSameHierachy(Domain domain) {

    final String methodName = "mergeResourceDefForAgentsOfSameHierachy";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameters is Domain " + domain.getxId());

    // extract key set of agentResourceMap
    // check for parent of agent via AgentGroups object and if parent
    // present in same domain then
    // remove that entry of agent and resourceDef from map and add
    // that resourceDef value to child agent's
    // resource Def list.
    Set<String> keySetToBeDiscarded = new HashSet<>();
    Map<String, String> agentToGroup = LookupUtil.getAgentGroups().getAgentToGroups();
    Map<String, String> childToParent =
        LookupUtil.getAgentGroups().getChildToParentGroupsHierarchy();
    Map<String, Set<ResourceDefinition>> agentRespurceDefMap = domain.getAgentResourceDefMap();

    for (String agentId : agentRespurceDefMap.keySet()) {
      if (agentId.contains(CasmConstants.AGENTGROUP)) {
        if (childToParent.containsKey(agentId)) {
          String[] parentAgentIds = childToParent.get(agentId).split(CasmConstants.COMMA);
          for (String agentGroupid : parentAgentIds) {
            if (agentRespurceDefMap.containsKey(agentGroupid)) {
              Set<ResourceDefinition> resDefList = agentRespurceDefMap.get(agentGroupid);
              keySetToBeDiscarded.add(agentGroupid);
              agentRespurceDefMap.get(agentId).addAll(resDefList);
            }
          }
        }
      }
      else {
        String agentGroupId = agentToGroup.get(agentId);
        checkForParentAgentAndMerge(agentGroupId, agentId, childToParent, agentRespurceDefMap,
            keySetToBeDiscarded);
      }
    }
    Iterator<String> agentIdIterator = agentRespurceDefMap.keySet().iterator();
    if (!keySetToBeDiscarded.isEmpty()) {
      domain.getProperties().put(CasmConstants.AGENT_HIER_RES_CONSOLIDATED,
          CasmConstants.STRING_TRUE);
      while (agentIdIterator.hasNext()) {
        String agentIdKey = agentIdIterator.next();
        if (keySetToBeDiscarded.contains(agentIdKey)) {
          agentIdIterator.remove();
        }
      }
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "doesn't return anything just resolves name for XID");
    return keySetToBeDiscarded;
  }

  private void checkForParentAgentAndMerge(String agentGroupId, String agentId,
      Map<String, String> childToParent,
      Map<String, Set<ResourceDefinition>> agentRespurceDefMap, Set<String> keySetToBeDiscarded) {

    final String methodName = "checkForParentAgentAndMerge";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameters is agentGroupId " + agentGroupId + " and agentId " + agentId);

    if (agentRespurceDefMap.containsKey(agentGroupId)) {
      Set<ResourceDefinition> resDefList = agentRespurceDefMap.get(agentGroupId);
      // agentRespurceDefMap.remove(agentGroupId);
      keySetToBeDiscarded.add(agentGroupId);
      agentRespurceDefMap.get(agentId).addAll(resDefList);
    }
    if (childToParent.containsKey(agentGroupId)) {
      String[] parentAgentIds = childToParent.get(agentGroupId).split(CasmConstants.COMMA);
      for (String agentGroupid : parentAgentIds) {
        if (agentRespurceDefMap.containsKey(agentGroupid)) {
          Set<ResourceDefinition> resDefList = agentRespurceDefMap.get(agentGroupid);
          // agentRespurceDefMap.remove(agentGroupid);
          keySetToBeDiscarded.add(agentGroupId);
          agentRespurceDefMap.get(agentId).addAll(resDefList);
        }
      }
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "doesn't return anything ");

  }

  protected String cleanseResourcePath(String resourcePathString) {

    // String repeativeSlashRemovedString =
    // resourcePathString.replaceAll("//*//*", "/*");
    String nullRemovedString =
        resourcePathString.replaceAll("null", CasmConstants.EMPTY_STRING);
    return nullRemovedString.replaceAll("/{2,}", CasmConstants.FORWARD_SLASH);

  }

  private void extractIpAddressAttribute(Policy policy,
      List<AuthorizationPolicyAttribute> attributes, AtomicInteger counter) {

    // Extract IP address information
    String hexIpAddress = policy.getProperties().get(XmlTagConstants.IPADDRESSES);

    if (null != hexIpAddress) {

      StringBuilder ipAddresses = new StringBuilder();
      String[] hexAddressArray = hexIpAddress.split(PropertyConstants.COMMA);
      InetAddress inetAddress;
      for (String hexAddress : hexAddressArray) {

        if (ipAddresses.length() > 1)
          ipAddresses.append(PropertyConstants.COMMA);

        if (hexAddress.contains(PropertyConstants.COLON)) {
          StringBuilder ipAddressRangeBuilder = new StringBuilder();
          String[] hexRangeArray = hexAddress.split(PropertyConstants.COLON);
          boolean isStartRangeValue = true;
          for (String rangeIp : hexRangeArray) {
            try {
              inetAddress = InetAddress.getByAddress(DatatypeConverter.parseHexBinary(rangeIp));
              ipAddressRangeBuilder.append(inetAddress.getHostAddress());
              if (isStartRangeValue) {
                ipAddressRangeBuilder.append(PropertyConstants.COLON);
                isStartRangeValue = false;
              }
            }
            catch (Exception e) {
              logger.error("Error parsing hex decimal rage to dotted IP4 Address range", e);
            }
          }
          ipAddresses.append(ipAddressRangeBuilder.toString());
        }
        else {
          try {
            inetAddress =
                InetAddress.getByAddress(DatatypeConverter.parseHexBinary(hexAddress));
            ipAddresses.append(inetAddress.getHostAddress());
          }
          catch (Exception e) {
            logger.error("Error parsing hex decimal to dotted IP4 Address", e);
          }
        }

      }
      AuthorizationPolicyAttribute ipAddressAttribute = new AuthorizationPolicyAttribute();
      ipAddressAttribute.setName(MapperConstants.IPADDRESS_POLICY + counter.incrementAndGet());
      ipAddressAttribute.setConditionType(BitMappingEnum.USERPOLICY_RESOLUTIONTYPE
          .getBitMapValue(MapperConstants.IP_ADDRESS_RESOLUTION_TYPE));
      ipAddressAttribute.setConditionValue(ipAddresses.toString());
      ipAddressAttribute.setNegate(false);
      ipAddressAttribute
          .setPolicyFlag(String.valueOf(MapperConstants.DEFAULT_USER_POLICY_FLAG));

      attributes.add(ipAddressAttribute);
    }
  }
  
	private boolean checkForLeafNode(String resourcePath) {

		// TOOD: change logic of leaf node to determine it from enum
		// if string after last slash and before ?(if present) is in the
		// list of string then leaf node other wise not
		boolean isLeafNodeReached = false;
		String[] resourceSplit = resourcePath.split("/");
		if (resourceSplit.length > 1) {
			String leaf = resourceSplit[resourceSplit.length - 1];
			String[] actualLeafArray = leaf.split("\\?");
			String actualLeaf = actualLeafArray[0];

			if (validateFileExtension(actualLeaf) || actualLeaf.contains("*"))
				isLeafNodeReached = true;
		}
		return isLeafNodeReached;
	}

	private boolean validateFileExtension(String actualLeaf) {

		boolean isFileExtensionPresent = false;
		if (actualLeaf.contains(".")) {
			String[] splitArray = actualLeaf.split("\\.");
			if (splitArray.length > 1) {
				String fileExtension = splitArray[1];
				if (validFileExtensions.contains(fileExtension))
					isFileExtensionPresent = true;
			}
		}
		return isFileExtensionPresent;
	}

}
