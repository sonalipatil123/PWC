package com.persistent.pmt.sourcesso.casm.mapper.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.persistent.pmt.model.Provider;
import com.persistent.pmt.model.ProviderAttributes;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.model.Partner;
import com.persistent.pmt.sourcesso.casm.model.WsFedSP;
import com.persistent.pmt.sourcesso.casm.reader.impl.UtilityReader;
import com.persistent.pmt.sourcesso.generic.mapper.GenericMapper;
import com.persistent.pmt.sourcesso.generic.reader.GenericReader;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;

@Component("samlProviderMapper")
public class SamlProviderMapper implements GenericMapper {

  private static Logger logger = Logger.getLogger(SamlProviderMapper.class);
  private final String classname = SamlProviderMapper.class.getName();

  /**
   * This method checks whether object is of type Partner or WsFedSP
   * and call appropriate method for mapping
   * 
   * @param object
   * @return
   */
  @Override
  public Provider getMappedObject(Object object) {
    final String methodName = "getMappedObject";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameter is Object can be an instance of WsFedSP or Partner");
    Provider provider;
    if (object instanceof WsFedSP) {
      provider = getWSFedMappedObject(object);
    }
    else {
      provider = getSamlMappedObject(object);
    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "and returned value is WsFedSP or Partner with Id " + provider.getId());
    return provider;
  }

  private Provider getWSFedMappedObject(Object object) {

    final String methodName = "getWSFedMappedObject";
    WsFedSP wsfedsp = (WsFedSP) object;
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameter is WsFedSP with ID " + wsfedsp.getxId());

    Provider provider = new Provider();
    provider.setName(wsfedsp.getName());
    provider.setDescription(wsfedsp.getProperties().get("Description"));
    provider.setType("WSFEDSP");
    // PWC data only contains remote WS FED SP
    provider.setRemote(true);
    ProviderAttributes providerAttributes;
    List<ProviderAttributes> attributeList = new ArrayList<ProviderAttributes>();

    // Adding provider xid in provider_attributes table
    providerAttributes = new ProviderAttributes();
    providerAttributes.setSourceAttrName("XID");
    providerAttributes.setSourceAttrValue(wsfedsp.getxId());
    attributeList.add(providerAttributes);

    for (Entry<String, String> entry : wsfedsp.getProperties().entrySet()) {
      providerAttributes = new ProviderAttributes();
      if (!entry.getKey().equals("Name") && !entry.getKey().equals("Description")) {
        providerAttributes.setSourceAttrName(entry.getKey());
        providerAttributes.setSourceAttrValue(entry.getValue());
      }
      attributeList.add(providerAttributes);

    }
    for (Entry<String, String> entry : wsfedsp.getResourcePartnerUsers().getProperties()
        .entrySet()) {
      providerAttributes = new ProviderAttributes();
      providerAttributes.setSourceAttrName(entry.getKey());
      providerAttributes.setSourceAttrValue(entry.getValue());
      attributeList.add(providerAttributes);

    }
    provider.setAttributes(attributeList);
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and returned value is Provider Object with Name " + provider.getId());
    return provider;

  }

  private Provider getSamlMappedObject(Object object) {

    final String methodName = "getWSFedMappedObject";
    Partner partner = (Partner) object;
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + "and passed parameter is Partner with ID " + partner.getxId());

    Provider provider = new Provider();
    provider.setName(partner.getName());
    provider.setDescription(partner.getDescription());
    provider.setRemote(partner.isRemote());
    provider.setType(partner.getType());

    ProviderAttributes providerAttributes;

    List<ProviderAttributes> attributeList = new ArrayList<ProviderAttributes>();

    // Adding provider xid in provider_attributes table
    providerAttributes = new ProviderAttributes();
    providerAttributes.setSourceAttrName("XID");
    providerAttributes.setSourceAttrValue(partner.getxId());
    attributeList.add(providerAttributes);

    for (Entry<String, String> entry : partner.getProperties().entrySet()) {
      providerAttributes = new ProviderAttributes();
      providerAttributes.setSourceAttrName(entry.getKey());
      providerAttributes.setSourceAttrValue(getSourceAttributeValue(entry.getValue()));
      attributeList.add(providerAttributes);
    }
    provider.setAttributes(attributeList);

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + "and returned value is Provider Object with Name " + provider.getId());

    return provider;
  }

  private String getSourceAttributeValue(String entryValuetobeResolved) {
    String attrValue = "";
    Map<String, GenericReader> readerMap = LookupUtil.getReadersMap();
    if (!(entryValuetobeResolved == null)
        && entryValuetobeResolved.trim().startsWith("CA.FED::")) {

      String keyToMap =
          entryValuetobeResolved.substring(0, entryValuetobeResolved.indexOf('@'));
      if (readerMap != null && readerMap.containsKey(keyToMap)) {

        Map<String, CasmGenericObject> utilityMap =
            ((UtilityReader) readerMap.get(keyToMap)).getMap();

        String[] entryValues = entryValuetobeResolved.split(",");
        boolean flag = false;
        for (String entryValue : entryValues) {
          if (flag) {
            attrValue = attrValue + "|";
          }
          else {
            flag = true;
          }

          CasmGenericObject casmGenericObject = utilityMap.get(entryValue);
          if (casmGenericObject != null) {

            Map<String, String> properties = casmGenericObject.getProperties();
            if (properties != null) {
              boolean flag1 = false;
              for (Entry<String, String> entryProperties : properties.entrySet()) {
                if (flag1) {
                  attrValue = attrValue + ",";
                }
                else {
                  flag1 = true;
                }
                if (!(entryProperties.getValue() == null)
                    && entryProperties.getValue().trim().startsWith("CA.FED::")) {
                  attrValue = attrValue + getSourceAttributeValue(entryProperties.getValue());
                }
                else {
                  attrValue =
                      attrValue
                          + entryProperties.getKey()
                              .substring(entryProperties.getKey().lastIndexOf(":") + 1)
                              .replace('.', '_') + "=" + entryProperties.getValue();
                }
              }
            }
          }
        }
      }
      else {
        attrValue = entryValuetobeResolved;
      }
    }
    else {
      attrValue = entryValuetobeResolved;
    }
    return attrValue;
  }

}