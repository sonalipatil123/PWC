package com.persistent.pmt.sourcesso.casm.reader;

import java.io.IOException;
import java.io.InputStream;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;

import org.apache.log4j.Logger;

import com.persistent.pmt.exception.GenericException;


/**
 * @author shishir_kumar
 * Context object for holding input stream data 
 */
public class EventReaderContext {
	
	private Logger logger = Logger.getLogger(EventReaderContext.class);
	private XMLEventReader eventReader;
	private InputStream inputStream;
	
	public EventReaderContext(XMLEventReader eventReader, InputStream inputStream) {
		this.eventReader = eventReader;
		this.inputStream = inputStream;
	}
	public XMLEventReader getEventReader() {
		return eventReader;
	}
	public InputStream getInputStream() {
		return inputStream;
	}
	
	public void closeResources() throws GenericException {
		
		try {
			if(null != eventReader)
				eventReader.close();
			if(null != inputStream) {
				inputStream.close();
			}
		} catch(XMLStreamException | IOException e) {
			logger.error("Error while closing XML stream resource");
			throw new com.persistent.pmt.exception.GenericException("Error while closing resources ", e);
		}
		
	}
		
}
