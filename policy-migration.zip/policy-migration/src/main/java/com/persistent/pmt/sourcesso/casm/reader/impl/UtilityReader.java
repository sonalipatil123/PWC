package com.persistent.pmt.sourcesso.casm.reader.impl;

import java.util.HashMap;
import java.util.Map;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.reader.AbstractXmlReader;
import com.persistent.pmt.sourcesso.casm.reader.EventReaderContext;
import com.persistent.pmt.sourcesso.generic.response.BaseResponse;

@PropertySource(value = { "classpath:application.properties" })
@Component("utilityReader")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class UtilityReader extends AbstractXmlReader {

	private static Logger logger = Logger.getLogger(UtilityReader.class);
	private final String classname = UtilityReader.class.getName();

	private Map<String, CasmGenericObject> map;

	@Override
	public Object readAndSaveData(String fileName)
			throws com.persistent.pmt.exception.GenericException {
		final String methodName = "readAndSaveData";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and the parameter passed is " + fileName);
		map = new HashMap<String, CasmGenericObject>();

		// Create objects for utilities
		XMLEventReader eventReader = null;
		EventReaderContext utilityReaderContext = getEventReaderContext(fileName);

		try {
			eventReader = utilityReaderContext.getEventReader();

			while (eventReader.hasNext()) {

				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					String tagName = startElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						CasmGenericObject object = (CasmGenericObject) parseObject(
								eventReader, event, CasmConstants.GENERIC);
						map.put(object.getxId(), object);
					}
				}
				// If we reach the end of an item element, we add it to the
				// list
				if (event.isEndElement()) {
					EndElement endElement = event.asEndElement();
					String tagName = endElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						continue;
					}
				}
			}
		} catch (XMLStreamException e) {
			throw new GenericException(
					"Error while reading utility input stream, filename = "
							+ fileName, e);
		} finally {
			utilityReaderContext.closeResources();
		}

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and return Object Map");
		return map;

	}

	protected CasmGenericObject getObjectInstance(String objectName) {
		return new CasmGenericObject();
	}

	@Override
	public BaseResponse readData() throws GenericException {
		// Unused for UtilityReader
		return null;
	}

	@Override
	public Object readAndSaveData() throws GenericException {
		// Unused for UtilityReader
		return null;
	}

	public Map<String, CasmGenericObject> getMap() {
		return map;
	}

	public void setMap(Map<String, CasmGenericObject> map) {
		this.map = map;
	}
}
