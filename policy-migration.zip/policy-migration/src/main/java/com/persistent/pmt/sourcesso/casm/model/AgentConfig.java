package com.persistent.pmt.sourcesso.casm.model;

import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AgentConfig extends CasmGenericObject {

  private Map<String, String> attributePair;
  private Map<String, Set<String>> agentToFQDN;

  public Map<String, String> getAttributePair() {
    return attributePair;
  }

  public void setAttributePair(Map<String, String> attributePair) {
    this.attributePair = attributePair;
  }

  public Map<String, Set<String>> getAgentToFQDN() {
    return agentToFQDN;
  }

  public void setAgentToFQDN(Map<String, Set<String>> agentToFQDN) {
    this.agentToFQDN = agentToFQDN;
  }

}
