package com.persistent.pmt.sourcesso.casm.constant;

/**
 * 
 * Holds constants related CA SiteMinder
 */
public class CasmConstants {

	// Object Names
	public static final String DOMAIN = "Domain";
	public static final String REALM = "Realm";
	public static final String RULE = "Rule";
	public static final String RESPONSE = "Response";
	public static final String POLICY = "Policy";
	public static final String RESPONSE_ATTR = "ResponseAttr";
	public static final String VARIABLE = "Variable";
	public static final String POLICY_LINK = "PolicyLink";
	public static final String RULE_GROUP = "RuleGroup";
	public static final String RESPONSE_GROUP = "ResponseGroup";
	public static final String USER_POLICY = "UserPolicy";
	public static final String RESOURCE_PART_USERS = "ResourcePartnerUsers";
	public static final String SERVICE_PROV_USERS = "ServiceProviderUsers";
	public static final String WSFEDSP = "WSFEDSP";
	public static final String SAMLV2SP = "SAMLv2SP";
	public static final String EPM_ROLE = "Role";
	public static final String IDPBASE = "IdPBase";
	public static final String SPBASE = "SPBase";
	public static final String PARTNERSHIPBASE = "PartnershipBase";
	public static final String AGENTGROUP = "AgentGroup";
	public static final String PARTNER = "Partner";
	public static final String GENERIC = "Generic";
	public static final String USERDIRECTORY = "UserDirectory";
	public static final String AUTHSCHEME = "AuthScheme";
	public static final String SAMLv2IDP = "SAMLv2IdP";
	public static final String WSFEDIDP = "WSFEDIdP";
	public static final String AGENT = "Agent";
	public static final String AGENT_TYPE = "AgentType";
	public static final String AGENT_TYPE_ATR = "AgentTypeAtr";
	public static final String AGENT_CONFIG = "AgentConfig";

	// General Constants
	public static final String EMPTY_STRING = "";
	public static final String COMMA = ",";
	public static final String PIPE = "|";
	public static final String FORWARD_SLASH = "/";
	public static final String EQUAL_TO = "=";
	public static final String STRING_FALSE = "false";
	public static final String STRING_TRUE = "true";
	public static final String AGENT_NAME = "AgentName";
	public static final String ALLOW = "Allow";
	public static final String DENY = "Deny";

	// Attribute Value Constants
	public static final String DEFAULT = "Default";
	public static final String GLOBAL = "Global";
	public static final String EXCLUDE = "Exclude";
	public static final String PARTNER_TYPE_IDP = "IDP";
	public static final String PARTNER_TYPE_SP = "SP";
	public static final String IS_SP_REMOTE = "IsSPRemote";
	public static final String IS_SP_LOCAL = "IsSPLocal";
	public static final String IS_IDP_LOCAL = "IsIdPLocal";
	public static final String IS_IDP_REMOTE = "IsIdPRemote";
	public static final String GLOBAL_POLICIES_APPLY = "GlobalPoliciesApply";
	public static final String HAS_GLOBAL_RESPONSE = "hasGlobalResponse";
	public static final String IS_OBSOLETE = "isObsolete";
	public static final String AGENT_HIER_RES_CONSOLIDATED = "agentHierResConsolidated";
	public static final String RULES_CONSOLIDATED = "rulesConsolidated";
	public static final String DOMAIN_NAME = "domainName";
	public static final String IS_AFFILIATE_DOMAIN = "IsAffiliateDomain";
	public static final String DISABLED_POLICY = "disabledPolicy";
	public static final String PROVIDER_NAME = "providerName";
	public static final String AUTH_TYPE = "authType";

	
	public static final String DUPLICATE_PARTNER_IDENTIFIER_PREFIX = "DUPLICATE_";

	// Data import status
	public static final String IMPORT_STATUS_IMPORTED = "IMPORTED";
	public static final String IMPORT_STATUS_IMPORTING = "IMPORTING";
	public static final String IMPORT_STATUS_FAILED = "IMPORT FAILED";
	public static final String IMPORT_STATUS_NOTCONFIGURED = "NOT_CONFIGURED";
	public static final String IMPORT_STATUS_READYTOIMPORT = "READY_TO_IMPORT";
	public static final String IMPORT_STATUS_IMPORTINGOTHER = "IMPORTING_OTHER";

	// Configuration
	public static final String PROPERTY_FILE_NAME = "migration_config.properties";

	public static final String CASM_XML_DOMAIN = "CA_SM_Domain.xml";
	public static final String CASM_XML_AUTHSCHEME = "CA_SM_AuthScheme.xml";

	public static final String PROPERTY_CASM_XML_BASE_PATH = "casm.xml.basepath";

	public static final String PROPERTY_CASM_XML_PWC_PROD_EXPORT = "casm.xml.pwcprodexport";
	public static final String PROPERTY_CASM_OBJECT_TYPES = "casm.objecttypes";

	public static final String PROPERTY_AGENT_TYPE = "AgentType";
	public static final String PROPERTY_AGENT_TYPE_ATTR = "AgentTypeAttr";
	
	// Rule action prefix
	public static final String ACTION_PREFIX_ON_AUTH = "OnAuth";
	public static final String ACTION_PREFIX_ON_ACCESS = "OnAccess";
	public static final String RESPONSE_ACTION_TYPE_REJECT = "Reject";
	public static final String RESPONSE_ACTION_TYPE_ACCEPT = "Accept";

	// REGEX For Trailing Commas
	public static final String TRAILING_COMMA = "(,)*$";
		
}
