package com.persistent.pmt.sourcesso.casm.mapper.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.persistent.pmt.model.Agent;
import com.persistent.pmt.model.AgentAttributes;
import com.persistent.pmt.sourcesso.casm.model.AgentGroups;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.generic.mapper.GenericMapper;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;

@Component("agentGroupMapper")
public class AgentGroupMapper implements GenericMapper {

  private AgentGroups agentGroups;
  
  private static Logger logger = Logger.getLogger(AgentGroupMapper.class);
  private final String classname = AgentGroupMapper.class.getName();

  @Override
  public Object getMappedObject(Object source) {
	  
	  final String methodName = "getMappedObject"; 
    CasmGenericObject casmGenericObject = (CasmGenericObject) source;
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName+" and passed parameter is "+casmGenericObject.toString());

    String agentGroupXid = casmGenericObject.getxId();
    String agentGroupName = casmGenericObject.getName();
    String agentGroupdescription = casmGenericObject.getDescription();

    Agent agent = new Agent();
    agent.setId(agentGroupXid);
    agent.setName(agentGroupName);
    agent.setDescription(agentGroupdescription);
    agent.setType("AgentGroup");
    List<AgentAttributes> agentAttributesList = new ArrayList<>();
    AgentAttributes agentAttributeGroupParent = new AgentAttributes();
    agentAttributeGroupParent.setSourceAttrName("Group_Child");
    agentAttributeGroupParent.setSourceAttrValue(LookupUtil.resolveXidToName(agentGroups
        .getParentToChildGroupsHierarchy().get(agentGroupXid)));
    AgentAttributes agentAttributeGroupChild = new AgentAttributes();
    agentAttributeGroupChild.setSourceAttrName("Group_Parent");
    agentAttributeGroupChild.setSourceAttrValue(LookupUtil.resolveXidToName(agentGroups
        .getChildToParentGroupsHierarchy().get(agentGroupXid)));
    AgentAttributes agentAttributeGroupAgents = new AgentAttributes();
    agentAttributeGroupAgents.setSourceAttrName("Group_Agents");
    agentAttributeGroupAgents.setSourceAttrValue(LookupUtil.resolveXidToName(agentGroups
        .getGroupAgents().get(agentGroupXid)));
    agentAttributesList.add(agentAttributeGroupParent);
    agentAttributesList.add(agentAttributeGroupChild);
    agentAttributesList.add(agentAttributeGroupAgents);
    agent.setAttributes(agentAttributesList);
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName+"and returned value is Agent with ID"+agent.getId());

    return agent;
  }

  public AgentGroups getAgentGroups() {
    return agentGroups;
  }

  public void setAgentGroups(AgentGroups agentGroups) {
    this.agentGroups = agentGroups;
  }
}
