package com.persistent.pmt.sourcesso.casm.constant;

public class MapperConstants {

  public static final String COMMA = ",";
  public static final String DOT = ".";
  public static final String TRUE = "true";
  public static final String FALSE = "false";
  public static final String ALL = "ALL";
  public static final String URL = "URL";

  public static final String DOMAIN = "Domain";
  public static final String AUTH_SCHEMES = "AuthSchemes";
  public static final String APPLICATION_AUTHSCHEME_DEFAULT_PROPERTY = "application.authscheme.default";

  public static final String USERDIRECTORY_NAME = "CA.SM::UserDirectory.Name";
  
  public static final String POLICY_RESOURCES = "policyResources";
  public static final String POLICY_DATA = "policyData";

  public static final String ROOT_RESOURCE = "/";
  public static final String GENERIC_RESOURCE = "/*";
  public static final String ALL_RESOURCE = "*";

  public static final String PROTECT_ALL_AUTHZ_POLICY_NAME = "ProtectAll";
  public static final String APP_ATTR_DOMAIN_NAME = "domainName";
  public static final String APP_ATTR_DISABLED_POLICY = "disabledPolicy";

  public static final String APP_STATE_DRAFTED = "DRAFTED";

  public static final Integer DEFAULT_USER_POLICY_FLAG = 0;
  public static final Integer DEFAULT_USER_POLICY_RESOLUTION_TYPE = 1;
  public static final Integer IP_ADDRESS_RESOLUTION_TYPE = 13;
  public static final String USER_POLICY = "User";
  public static final String GROUP_POLICY = "Group";
  public static final String IPADDRESS_POLICY = "IPAddress";

  public static final String DEFAULT = "Default";
  public static final String EXCLUDE = "Exclude";
  public static final String RECURSIVE = "Recursive";
  public static final String AND = "AND";
  public static final String OR = "OR";
  public static final String NOT = "!";
}
