package com.persistent.pmt.sourcesso.casm.writer.impl;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.PropertyConstants;
import com.persistent.pmt.dao.AgentDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.mapper.impl.AgentGroupMapper;
import com.persistent.pmt.sourcesso.casm.mapper.impl.AgentMapper;
import com.persistent.pmt.sourcesso.casm.model.Agent;
import com.persistent.pmt.sourcesso.casm.model.AgentConfig;
import com.persistent.pmt.sourcesso.casm.model.AgentGroups;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.writer.ObjectWriter;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;
import com.persistent.pmt.utils.AuditWriter;

@Component("agentWriter")
@PropertySource(value = { "classpath:application.properties" })
public class AgentWriter implements ObjectWriter {

  private static Logger logger = Logger.getLogger(AgentWriter.class);
  private final String classname = AgentWriter.class.getName();
	
  @Autowired
  @Qualifier("agentDao")
  AgentDao agentDao;
  
  @Autowired
  AuditWriter auditWriter;

  @Autowired
  Environment environment;
  
  @Autowired
  AgentMapper agentMapper;
  
  @Autowired
  AgentGroupMapper agentGroupMapper;

  public void write(List<? extends CasmGenericObject> agents) throws GenericException {

    final String methodName = "write";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName+" and passed parameter is List Agents that extends CasmGenericObject"); 
	  
	  	AgentGroups agentGroups = LookupUtil.getAgentGroups();
	    agentMapper.setAgentGroups(agentGroups);
	    agentGroupMapper.setAgentGroups(agentGroups);
	    
	    StringBuilder agentWithoutConfig = new StringBuilder();
    
		for (Entry<String, Agent> oneAgent : LookupUtil.getAgentsMap().entrySet()) {
			
			AgentConfig agentConfig = LookupUtil.getAgentConfigMap().get(oneAgent.getKey());
			oneAgent.getValue().setAgentConfig(agentConfig);
			Map<String, Object> map = (Map<String, Object>) agentMapper.getMappedObject(oneAgent.getValue());				
			com.persistent.pmt.model.Agent agent = (com.persistent.pmt.model.Agent) map.get("agent");
			if(map.containsKey("configFlag")) {
				agentWithoutConfig.append(agent.getName() + PropertyConstants.COMMA);
			}
			agentDao.createAgent(agent);
        }
	      // Audit- agent does not have entity config object.
	      auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.NEED_REVIEW, environment
	          .getProperty(AuditPropertyConstants.SOURCE_MAPPER_AGENT_NOT_HAVING_AGENT_CONFIG),
				agentWithoutConfig.toString().replaceAll(CasmConstants.TRAILING_COMMA, ""), 
	          new Object[] { });
	      
	    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);
   }
  
}
