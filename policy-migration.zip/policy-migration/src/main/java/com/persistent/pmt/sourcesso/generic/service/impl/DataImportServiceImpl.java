package com.persistent.pmt.sourcesso.generic.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.sourcesso.generic.service.DataImportService;
import com.persistent.pmt.sourcesso.generic.spi.ImportService;

@Service
public class DataImportServiceImpl implements DataImportService {

	@Autowired
	@Qualifier("casmImportService")
	ImportService sourceImportService;
	

	@Override
  public PageImpl<Map<String, String>> importApplicationsSummary(Map<String, String> params)
      throws GenericException {

    return sourceImportService.getNewApplicationsSummary(params);
	}

	@Override
	public GenericResponse<?> importNewApplication(int id)
			throws GenericException {
		return sourceImportService.getNewApplicationById(id);
	}

	@Override
	public GenericResponse<?> importApplicationDataFromSource(Map<String, String> params)
			throws GenericException {
		return sourceImportService.importApplicationData(params);
	}

	@Override
	public GenericResponse<?> importAgent(int id) throws GenericException {
		return null;
	}

	@Override
	public GenericResponse<?> importAllAgents() throws GenericException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GenericResponse<?> importAuthenticationScheme(int id)
			throws GenericException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GenericResponse<?> importAllAuthenticationSchemes()
			throws GenericException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GenericResponse<?> importUserDirectory(int id)
			throws GenericException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GenericResponse<?> importAllUserDirectories()
			throws GenericException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GenericResponse<?> importPartner(int id) throws GenericException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GenericResponse<?> importAllPartners() throws GenericException {
		// TODO Auto-generated method stub
		return null;
	}

  @Override
  public GenericResponse<?> importPrecheck() throws GenericException {

    return sourceImportService.importPrecheck();
  }

}
