package com.persistent.pmt.sourcesso.casm.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.sourcesso.casm.model.Agent;
import com.persistent.pmt.sourcesso.casm.model.AgentConfig;
import com.persistent.pmt.sourcesso.casm.model.AgentGroups;
import com.persistent.pmt.sourcesso.casm.model.AuthScheme;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.model.Domain;
import com.persistent.pmt.sourcesso.casm.model.Partner;
import com.persistent.pmt.sourcesso.casm.model.UserDirectory;
import com.persistent.pmt.sourcesso.generic.response.BaseResponse;

/**
 * @author shishir_kumar This response object would be returned by
 *         ApplicationImportServiceImpl
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationImportResponse extends BaseResponse {

	private List<Domain> domainList;
	private List<Partner> partners;
	private List<CasmGenericObject> objects;
	private List<Agent> agentList;
	private List<UserDirectory> userDirectoryList;
	private List<AuthScheme> authSchemeList;
	private List<AgentConfig> agentConfigList;
	private AgentGroups agentGroups;

	public List<Agent> getAgentList() {
		return agentList;
	}

	public void setAgentList(List<Agent> agentList) {
		this.agentList = agentList;
	}

	public List<UserDirectory> getUserDirectoryList() {
		return userDirectoryList;
	}

	public void setUserDirectoryList(List<UserDirectory> userDirectoryList) {
		this.userDirectoryList = userDirectoryList;
	}

	public List<AuthScheme> getAuthSchemeList() {
		return authSchemeList;
	}

	public void setAuthSchemeList(List<AuthScheme> authSchemeList) {
		this.authSchemeList = authSchemeList;
	}

	public List<AgentConfig> getAgentConfigList() {
		return agentConfigList;
	}

	public void setAgentConfigList(List<AgentConfig> agentConfigList) {
		this.agentConfigList = agentConfigList;
	}

	public List<Domain> getDomainList() {
		return domainList;
	}

	public void setDomainList(List<Domain> domainList) {
		this.domainList = domainList;
	}

	public List<Partner> getPartners() {
		return partners;
	}

	public void setPartners(List<Partner> partners) {
		this.partners = partners;
	}

	public List<CasmGenericObject> getObjects() {
		return objects;
	}

	public void setObjects(List<CasmGenericObject> objects) {
		this.objects = objects;
	}

	public AgentGroups getAgentGroups() {
		return agentGroups;
	}

	public void setAgentGroups(AgentGroups object) {
		this.agentGroups = object;
	}

}
