package com.persistent.pmt.sourcesso.casm.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WsFedSP extends CasmGenericObject{

	private ResourcePartnerUsers resourcePartnerUsers = new ResourcePartnerUsers();

	public ResourcePartnerUsers getResourcePartnerUsers() {
		return resourcePartnerUsers;
	}

	public void setResourcePartnerUsers(ResourcePartnerUsers resourcePartnerUsers) {
		this.resourcePartnerUsers = resourcePartnerUsers;
	}
	
	
}
