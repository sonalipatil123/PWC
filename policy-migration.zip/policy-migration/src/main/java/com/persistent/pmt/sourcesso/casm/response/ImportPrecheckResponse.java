package com.persistent.pmt.sourcesso.casm.response;

public class ImportPrecheckResponse {
  private int importStatusCode;
  private String importStatus;
  private String message;

  public int getImportStatusCode() {
    return importStatusCode;
  }

  public void setImportStatusCode(int importStatusCode) {
    this.importStatusCode = importStatusCode;
  }

  public String getImportStatus() {
    return importStatus;
  }

  public void setImportStatus(String importStatus) {
    this.importStatus = importStatus;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

}
