package com.persistent.pmt.sourcesso.casm.model.derived;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.sourcesso.casm.model.ResponseAttr;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PolicyResponse {

	private String name;
	private String agentTypeLink;
	private String desc;
	private boolean isAuthenticationType;
	private boolean isAuthorizationType;	
	private boolean isGlobalResponse;
	private String ruleAction;
	private List<ResponseAttr> responseAttrList = new ArrayList<>();
		
	  @Override
	  public boolean equals(Object o) {

	      if (o == this) 
	    	  return true;

	      PolicyResponse policyResponse = (PolicyResponse) o;      
	      if(null==policyResponse)
	    	  return false;
	  
	      return  name.equals(policyResponse.getName()) &&
	    		  agentTypeLink.equals(policyResponse.getAgentTypeLink());
	      
	  }
	  
	  @Override
	  public int hashCode() {
	      return Objects.hash(name, agentTypeLink);
	  }
	  
	public boolean isGlobalResponse() {
		return isGlobalResponse;
	}
	public void setGlobalResponse(boolean isGlobalResponse) {
		this.isGlobalResponse = isGlobalResponse;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAgentTypeLink() {
		return agentTypeLink;
	}
	public void setAgentTypeLink(String agentTypeLink) {
		this.agentTypeLink = agentTypeLink;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public List<ResponseAttr> getResponseAttrList() {
		return responseAttrList;
	}
	public boolean isAuthenticationType() {
		return isAuthenticationType;
	}
	public void setAuthenticationType(boolean isAuthenticationType) {
		this.isAuthenticationType = isAuthenticationType;
	}
	public boolean isAuthorizationType() {
		return isAuthorizationType;
	}
	public void setAuthorizationType(boolean isAuthorizationType) {
		this.isAuthorizationType = isAuthorizationType;
	}
	public String getRuleAction() {
		return ruleAction;
	}
	public void setRuleAction(String ruleAction) {
		this.ruleAction = ruleAction;
	}
			
}
