package com.persistent.pmt.sourcesso.casm.mapper.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.model.Domain;
import com.persistent.pmt.sourcesso.casm.model.Policy;
import com.persistent.pmt.sourcesso.casm.model.PolicyLink;
import com.persistent.pmt.sourcesso.casm.model.Realm;
import com.persistent.pmt.sourcesso.casm.model.Response;
import com.persistent.pmt.sourcesso.casm.model.ResponseAttr;
import com.persistent.pmt.sourcesso.casm.model.Rule;
import com.persistent.pmt.sourcesso.casm.model.RuleGroup;
import com.persistent.pmt.sourcesso.casm.model.UserPolicy;
import com.persistent.pmt.sourcesso.casm.response.ConditionsTo;
import com.persistent.pmt.sourcesso.casm.response.DomainTo;
import com.persistent.pmt.sourcesso.casm.response.PolicyRulesTo;
import com.persistent.pmt.sourcesso.casm.response.PolicyTo;
import com.persistent.pmt.sourcesso.casm.response.RealmTo;
import com.persistent.pmt.sourcesso.casm.response.ResponseAttrTo;
import com.persistent.pmt.sourcesso.casm.response.ResponseTo;
import com.persistent.pmt.sourcesso.casm.response.RuleTo;
import com.persistent.pmt.sourcesso.casm.response.UserPolicyTo;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;
import com.persistent.pmt.utils.AuditWriter;

@Component
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class DomainResponseMapper {

  @Autowired
  AuditWriter auditWriter;

  @Autowired
  Environment environment;

  private static Logger logger = Logger.getLogger(DomainResponseMapper.class);
  private final String classname = DomainResponseMapper.class.getName();

  public DomainTo processfields(Domain d1) throws GenericException {
    final String methodName = "processfields";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameter is Domain with ID " + d1.getxId());

    DomainTo d2 = new DomainTo();
    d2.setDomainName(d1.getName());
    d2.setIsAffiliate(d1.getProperties().get("IsAffiliate"));
    d2.setUserDirectoryLink(d1.getProperties().get("UserDirectoryName"));
    d2.setMode(d1.getProperties().get("Mode"));
    d2.setDescription(d1.getProperties().get("Desc"));
    if (d1.getProperties().containsKey(CasmConstants.IS_AFFILIATE_DOMAIN))
      d2.setType(PMTConstants.PEP_TYPE_FEDERATION);
    else
      d2.setType(PMTConstants.PEP_TYPE_AGENT);

    d2.setObsolete(Boolean.valueOf(d1.getProperties().get(CasmConstants.IS_OBSOLETE)));
    d2.setRulesConsolidated(Boolean.valueOf(d1.getProperties().get(
        CasmConstants.RULES_CONSOLIDATED)));

    d2.setDisabledPolicy(Boolean.valueOf(d1.getProperties().get(CasmConstants.DISABLED_POLICY)));
    d2.setHasGlobalResponse(Boolean.valueOf(d1.getProperties().get(
        CasmConstants.HAS_GLOBAL_RESPONSE)));

    d2.setAgentHierResConsolidated(Boolean.valueOf(d1.getProperties().get(
        CasmConstants.AGENT_HIER_RES_CONSOLIDATED)));
    d2.setProviderName(d1.getProperties().get(CasmConstants.PROVIDER_NAME));

    d2.setUserDirectoryLinks(processUserDirectoryLinks(d1.getUserDirectoryLinks()));
    d2.setResponses(processResponses(d1.getResponses()));
    d2.setRealms(processRealm(d1.getRealms()));
    d2.setPolicies(processPolicies(d1.getPolicies(), d1));

    // Domain processing completed for domain.
    auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS,
        environment.getProperty(AuditPropertyConstants.SOURCE_MAPPER_DOMAIN), "",
        new Object[] { d1.getName() });

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and returned value is DomainTo Object " + d2.getName());

    return d2;
  }

  private List<String> processUserDirectoryLinks(List<String> domainUserDirectoryLinks)
      throws GenericException {
    final String methodName = "processUserDirectoryLinks";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameter is List of Strings domainUserDirectoryLinks ");

    List<String> domainToUserDirectoryLinks = new ArrayList<String>();
    for (String str : domainUserDirectoryLinks) {
      domainToUserDirectoryLinks.add(str);
    }
    // UserDirectory processing completed.
    auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS,
        environment.getProperty(AuditPropertyConstants.SOURCE_MAPPER_USER_DIRECTORIES), "",
        new Object[] {});

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and returned value is domainToUserDirectoryLinks ");

    return domainToUserDirectoryLinks;
  }

  private List<ResponseTo> processResponses(List<Response> response) throws GenericException {

    final String methodName = "processResponses";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameter is List of Response ");

    List<ResponseTo> responseTo = new ArrayList<ResponseTo>();
    for (Response res : response) {
      ResponseTo rto = new ResponseTo();
      rto.setName(res.getName());
      rto.setAgentTypeLink(res.getProperties().get("AgentTypeName"));

      List<ResponseAttrTo> responseattrto = new ArrayList<>();
      for (ResponseAttr resattr : res.getResponseAttributes()) {

        String name = null, value = null;

        ResponseAttrTo rattrto = new ResponseAttrTo();
        rattrto.setType(LookupUtil.getResponseAttrType(resattr.getProperties().get(
            "AgentTypeAttrLink")));

        String resAtttrVal = resattr.getProperties().get("Value");
        if (resAtttrVal != null) {
          if (resAtttrVal.contains("/")) {
            rattrto.setName("url");
            rattrto.setValue(resAtttrVal);
          }

          else if (resAtttrVal.indexOf('=') > 0) {
            name = resAtttrVal.substring(0, resAtttrVal.indexOf('='));
            value = resAtttrVal.substring(resAtttrVal.indexOf('='), resAtttrVal.length());
            value = StringUtils.trimLeadingCharacter(value, '=');

            rattrto.setName(name);
            rattrto.setValue(value);

          }
          /*
           * else { rattrto.setName("responseattributename");
           * rattrto.setValue(resAtttrVal); }
           */

        }

        responseattrto.add(rattrto);
      }
      rto.setResponseAttributes(responseattrto);
      responseTo.add(rto);
    }
    // Responses processing completed
    auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS,
        environment.getProperty(AuditPropertyConstants.SOURCE_MAPPER_RESPONSES), "",
        new Object[] {});

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and returned value is List of ResponseTo ");
    return responseTo;
  }

  public List<RealmTo> processRealm(List<Realm> realms) throws GenericException {

    final String methodName = "processRealm";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameter is List of Realm ");

    List<RealmTo> realmTo = new ArrayList<RealmTo>();
    // System.out.println(realms.size());
    for (Realm r : realms) {
      RealmTo rto = new RealmTo();
      rto.setName(r.getProperties().get("Name"));
      rto.setResourceFilter(r.getProperties().get("ResourceFilter"));
      rto.setAuthSchemeLink(r.getProperties().get("AuthSchemeName"));
      rto.setProtectAll(r.getProperties().get("ProtectAll"));
      rto.setParentRealmLink(r.getProperties().get(XmlTagConstants.PARENT_REALM_LINK));
      if (r.getProperties().get("AgentLink") != null) {
        rto.setAgent(r.getProperties().get("AgentName"));
      }
      else {
        rto.setAgent(r.getProperties().get("AgentName"));
      }
      List<RuleTo> ruleto = new ArrayList<>();
      for (Rule rc : r.getRules()) {
        RuleTo rcto = new RuleTo();

        rcto.setName(rc.getName());
        rcto.setResource(rc.getProperties().get("Resource"));
        rcto.setActions(rc.getProperties().get("Actions"));
        rcto.setIsEnabled(rc.getProperties().get("IsEnabled"));
        rcto.setDescription(rc.getDescription());
        rcto.setAllowAccess(rc.getProperties().get("AllowAccess"));
        ruleto.add(rcto);
      }
      rto.setRules(ruleto);
      realmTo.add(rto);
    }

    // Realm processing completed.
    auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS,
        environment.getProperty(AuditPropertyConstants.SOURCE_MAPPER_REALMS), "",
        new Object[] {});

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and returned value is List of RealmTo ");
    return realmTo;
  }

  public List<PolicyTo> processPolicies(List<Policy> policy, Domain d) throws GenericException {

    final String methodName = "processPolicies";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameter is List of Policy and Domain with Id " + d.getxId());

    // System.out.println(policy.size());
    // int i=0;
    List<PolicyTo> policyTo = new ArrayList<PolicyTo>();
    List<ConditionsTo> conditionsTo = new ArrayList<ConditionsTo>();
    ConditionsTo conditionto = new ConditionsTo();
    for (Policy p : policy) {
      // System.out.println(i);
      PolicyTo pcto = new PolicyTo();
      pcto.setName(p.getName());
      pcto.setIsEnabled(p.getProperties().get("IsEnabled"));
      pcto.setDescription(p.getDescription());

      List<UserPolicyTo> userpolicyto = new ArrayList<>();
      // System.out.println(p.getUserPolicies().size());
      // int j=0;
      for (UserPolicy up : p.getUserPolicies()) {
        // System.out.println(j);
        UserPolicyTo upt = new UserPolicyTo();
        upt.setFilterClass(up.getProperties().get("FilterClass"));
        upt.setFilterPath(up.getProperties().get("FilterPath"));
        upt.setPolicyFlags(up.getProperties().get("PolicyFlags"));
        upt.setPolicyResolution(up.getProperties().get("PolicyResolution"));
        upt.setUserDirectoryLink(up.getProperties().get("UserDirectory"));
        userpolicyto.add(upt);
        // j++;
      }

      List<PolicyRulesTo> policyrulesto = new ArrayList<>();

      for (PolicyLink plk : p.getPolicyLinks()) {
        PolicyRulesTo prt = new PolicyRulesTo();
        prt.setResponseGroupLink(getResponseName(
            getBlankIfNull(plk.getProperties().get("ResponseGroupLink")), d));
        prt.setRuleLink(getRuleName(getBlankIfNull(plk.getProperties().get("RuleLink")), d));
        prt.setRuleGroupLink(getRuleGroupName(
            getBlankIfNull(plk.getProperties().get("RuleGroupLink")), d));
        prt.setResponseLink(getResponseName(
            getBlankIfNull(plk.getProperties().get("ResponseLink")), d));
        String ruleid = plk.getProperties().get("RuleLink");
        if (ruleid == null) {
          ruleid = processRuleGroupToRule(d, plk.getProperties().get("RuleGroupLink"));
        }
        String realmname = "";

        if (ruleid != null) {
          realmname = processRuleToRealm(ruleid, d);
        }
        prt.setRealm(realmname);
        policyrulesto.add(prt);
      }

      if (p.getProperties().get("IPAddresses") != null) {
        // Define enum for condition
        conditionto.setType("IPAddress");
        conditionto.setValue(p.getProperties().get("IPAddresses"));
        conditionsTo.add(conditionto);

      }

      pcto.setUsers(userpolicyto);
      pcto.setRules(policyrulesto);
      pcto.setConditions(conditionsTo);
      policyTo.add(pcto);
      // i++;
    }
    // Auditing for policy processing completed.
    auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS,
        environment.getProperty(AuditPropertyConstants.SOURCE_MAPPER_POLICIES), "",
        new Object[] {});

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
        + " and returned value is List of RealmTo ");
    return policyTo;
  }

  private String getBlankIfNull(Object o) {
    if (o == null)
      return "";
    else
      return (String) o;
  }

  private String processRuleGroupToRule(Domain d1, String rulegroupid) throws GenericException {
    final String methodName = "processRuleGroupToRule";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
        + " and passed parameter is rulegroupid " + rulegroupid + " and Domain " + d1.getxId());

    List<RuleGroup> lis = d1.getRuleGroups();
    if (lis != null) {
      for (RuleGroup r : lis) {
        if (r.getxId().equalsIgnoreCase(rulegroupid)) {
          String arr[] = {};
          if (r.getProperties().get("RulesLink") != null) {
            arr = r.getProperties().get("RulesLink").split(",");
            if (arr != null && arr.length > 0) {
              return arr[0];
            }
          }
          break;
        }

      }
    }
    // Processing completed for rule group to rule.
    auditWriter.write(ACTIONS.IMPORT_ALL, PMTConstants.SUCCESS,
        environment.getProperty(AuditPropertyConstants.SOURCE_MAPPER_RULE_GROUP), "",
        new Object[] {});

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName + " and returns Rule");

    return "";

  }

  private String processRuleToRealm(String id, Domain d) {
    List<Realm> lis = d.getRealms();

    if (lis != null) {
      for (Realm r : lis) {
        if (r.getRuleByXid(id) != null) {
          return r.getName();
        }
      }
    }

    return "";
  }

  private String getRuleName(String ruleId, Domain d) {
    List<Realm> lis = d.getRealms();
    Rule rule = null;
    if (lis != null) {
      for (Realm r : lis) {
        rule = r.getRuleByXid(ruleId);
        if (rule != null) {
          return rule.getName();
        }
      }
    }

    return "";
  }

  private String getRuleGroupName(String rgId, Domain d) {
    RuleGroup rg = d.getRuleGroupByXid(rgId);
    if (rg != null)
      return rg.getName();
    else
      return "";
  }

  private String getResponseName(String responseId, Domain d) {

    CasmGenericObject r = null;
    if (responseId.startsWith("CA.SM::Response@")) {
      r = d.getResponseByXid(responseId);
    }
    else {
      r = d.getResponseGroupByXid(responseId);
    }

    if (r != null)
      return r.getName();
    else
      return "";
  }

}
