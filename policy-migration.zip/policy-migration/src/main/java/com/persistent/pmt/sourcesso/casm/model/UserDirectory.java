package com.persistent.pmt.sourcesso.casm.model;

import com.fasterxml.jackson.annotation.JsonInclude;

// Parallel Object
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserDirectory extends CasmGenericObject {

}
