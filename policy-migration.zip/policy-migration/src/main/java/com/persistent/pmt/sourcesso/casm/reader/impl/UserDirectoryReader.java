package com.persistent.pmt.sourcesso.casm.reader.impl;

import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.reader.AbstractXmlReader;
import com.persistent.pmt.sourcesso.casm.reader.EventReaderContext;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;

@Component("userDirectoryReader")
@PropertySource(value = { "classpath:application.properties" })
public class UserDirectoryReader extends AbstractXmlReader {

	public static final String userDirectoryFile = "CA_SM_UserDirectory.xml";

	public final String OBJECT_NAME = "CA.SM::UserDirectory";
	public final String FILENAME = "CA_SM_UserDirectory.xml";
	private static Logger logger = Logger.getLogger(UserDirectoryReader.class);
	private final String classname = UserDirectoryReader.class.getName();

	@Override
	public Object readAndSaveData(String fileName) throws GenericException {
		// Unused for UserDirectoryReader
		return null;
	}

	@Override
	public Object readData() {

		return null;
	}

	@Override
	public Object readAndSaveData() throws GenericException {

		final String methodName = "readAndSaveData";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and No parameters passed");

		List<CasmGenericObject> userDirectoryList = getUserDirectoryList();

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns userDirectoryList List of CasmGenericObject");

		return userDirectoryList;
	}

	/**
	 * This method parses the CA.SM.UserDirectory.xml and returns the
	 * UserDirectory type of list
	 * 
	 * @return
	 * @throws GenericException
	 */
	private List<CasmGenericObject> getUserDirectoryList()
			throws GenericException {

		final String methodName = "getUserDirectoryList";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and No parameters passed");

		XMLEventReader eventReader = null;
		List<CasmGenericObject> userDirectoryList = new ArrayList<CasmGenericObject>();
		EventReaderContext userDirectoryReaderContext = getEventReaderContext(userDirectoryFile);
		CasmGenericObject userDirectoryObject = null;

		try {

			eventReader = userDirectoryReaderContext.getEventReader();
			while (eventReader.hasNext()) {

				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					String tagName = startElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {

						userDirectoryObject = parseObject(eventReader, event,
								CasmConstants.USERDIRECTORY);
						userDirectoryList.add(userDirectoryObject);
						LookupUtil.addXidToNamePair(
								userDirectoryObject.getxId(),
								userDirectoryObject.getProperties().get(
										"CA.SM::UserDirectory.Name"));
					}
				}
				// If we reach the end of an item element, we add it to the
				// list
				if (event.isEndElement()) {
					EndElement endElement = event.asEndElement();
					String tagName = endElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						continue;
					}
				}
			}
		} catch (XMLStreamException e) {
			throw new GenericException("File Input Stream Error ", e);
		} finally {
			userDirectoryReaderContext.closeResources();
		}
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns userDirectoryList List of CasmGenericObject");

		return userDirectoryList;
	}

	/*
	 * @Override protected CasmGenericObject parseObject(XMLEventReader
	 * eventReader, XMLEvent currectEvent, String objectName) throws
	 * XMLStreamException, GenericException { final String methodName =
	 * "parseObject";
	 * 
	 * CasmGenericObject genObject = new CasmGenericObject(); Map<String,
	 * String> objectPropertyMap = new HashMap<>(); String propertyKey = null;
	 * 
	 * StartElement firstElement = currectEvent.asStartElement(); Attribute
	 * firstElementAttribute = firstElement.getAttributeByName(new
	 * QName(XmlTagConstants.Xid)); if (firstElementAttribute != null) {
	 * genObject.setxId(firstElementAttribute.getValue()); }
	 * 
	 * while (eventReader.hasNext()) {
	 * 
	 * XMLEvent event = eventReader.nextEvent(); if (event.isStartElement()) {
	 * StartElement startElement = event.asStartElement(); String tagName =
	 * startElement.getName().getLocalPart();
	 * 
	 * switch (tagName) {
	 * 
	 * case XmlTagConstants.PROPERTY: propertyKey =
	 * removePropertyNameSuffix(startElement.getAttributeByName( new
	 * QName(XmlTagConstants.NAME)).getValue()); break;
	 * 
	 * case XmlTagConstants.BOOLEAN_VALUE: event = eventReader.nextEvent();
	 * objectPropertyMap.put(propertyKey, event.asCharacters().getData());
	 * break;
	 * 
	 * case XmlTagConstants.NUMBER_VALUE: event = eventReader.nextEvent();
	 * objectPropertyMap.put(propertyKey, getBitMappedValue(propertyKey,
	 * event.asCharacters().getData())); break;
	 * 
	 * case XmlTagConstants.STRING_VALUE: event = eventReader.nextEvent();
	 * processStringValue(event, propertyKey, objectPropertyMap, genObject);
	 * break;
	 * 
	 * case XmlTagConstants.XREF: event = eventReader.nextEvent(); String
	 * referenceId = event.asCharacters().getData(); String referenceValue =
	 * ReferenceUtil.getReferenceById(referenceId); if (referenceValue != null)
	 * { objectPropertyMap.put(propertyKey, referenceValue); } break;
	 * 
	 * case XmlTagConstants.XID: event = eventReader.nextEvent();
	 * processXid(event, propertyKey, objectPropertyMap); break;
	 * 
	 * default: continue; } } else if (event.isEndElement()) {
	 * 
	 * EndElement endElement = event.asEndElement(); String tagName =
	 * endElement.getName().getLocalPart();
	 * 
	 * if (tagName.equals(XmlTagConstants.OBJECT)) {
	 * genObject.setProperties(objectPropertyMap);
	 * LookupUtil.addXidToNamePair(genObject.getxId(), genObject.getName());
	 * break; } } }
	 * 
	 * return genObject; }
	 */

}
