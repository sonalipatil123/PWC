package com.persistent.pmt.sourcesso.casm.response;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserPolicyTo {

	private String policyFlags;
	private String userDirectoryLink;
	private String filterClass;
	private String filterPath;
	private String policyResolution;

	public String getPolicyFlags() {
		return policyFlags;
	}

	public void setPolicyFlags(String policyFlags) {
		this.policyFlags = policyFlags;
	}

	public String getUserDirectoryLink() {
		return userDirectoryLink;
	}

	public void setUserDirectoryLink(String userDirectoryLink) {
		this.userDirectoryLink = userDirectoryLink;
	}

	public String getFilterClass() {
		return filterClass;
	}

	public void setFilterClass(String filterClass) {
		this.filterClass = filterClass;
	}

	public String getFilterPath() {
		return filterPath;
	}

	public void setFilterPath(String filterPath) {
		this.filterPath = filterPath;
	}

	public String getPolicyResolution() {
		return policyResolution;
	}

	public void setPolicyResolution(String policyResolution) {
		this.policyResolution = policyResolution;
	}
}
