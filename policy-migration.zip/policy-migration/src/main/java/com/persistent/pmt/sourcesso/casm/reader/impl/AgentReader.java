package com.persistent.pmt.sourcesso.casm.reader.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.Agent;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.reader.AbstractXmlReader;
import com.persistent.pmt.sourcesso.casm.reader.EventReaderContext;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;

@Component("agentReader")
@PropertySource(value = { "classpath:application.properties" })
public class AgentReader extends AbstractXmlReader {

	public static final String agentFile = "CA_SM_Agent.xml";
	private static Logger logger = Logger.getLogger(AgentReader.class);
	private final String classname = AgentReader.class.getName();

	@Override
	public Object readData()
			throws com.persistent.pmt.exception.GenericException {
		return null;
	}

	@Override
	public Object readAndSaveData() throws GenericException {

		final String methodName = "readAndSaveData";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and there is no parameter passed");

		HashMap<String, Agent> agents = getAgents(LookupUtil.getAgentIds());

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns agents");

		return agents;

	}

	@Override
	public Object readAndSaveData(String fileName) throws GenericException {
		return null;
	}

	/**
	 * This method parses the CA.SM.Agent.xml and returns the Agent Type of List
	 * 
	 * @return
	 * @throws GenericException
	 */
	public HashMap<String, Agent> getAgents(Set<String> usedAgents)
			throws GenericException {

		final String methodName = "getAgents";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and the parameter passed is " + usedAgents);

		XMLEventReader eventReader = null;

		HashMap<String, Agent> agentMap = new HashMap<>();

		EventReaderContext agentReaderContext = getEventReaderContext(agentFile);
		Agent agentObject = new Agent();

		try {

			eventReader = agentReaderContext.getEventReader();
			while (eventReader.hasNext()) {

				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					String tagName = startElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {

						agentObject = (Agent) parseObject(eventReader, event,
								CasmConstants.AGENT);
						if (agentObject != null
								&& usedAgents.contains(agentObject.getxId())) {
							agentMap.put(agentObject.getName(), agentObject);
							LookupUtil.addXidToNamePair(agentObject.getxId(),
									agentObject.getName());
						}
					}
				}
				// If we reach the end of an item element, we add it to the
				// list
				if (event.isEndElement()) {
					EndElement endElement = event.asEndElement();
					String tagName = endElement.getName().getLocalPart();

					if (tagName.equals(XmlTagConstants.OBJECT)) {
						continue;
					}
				}
			}
		} catch (XMLStreamException e) {
			throw new GenericException("File Input Stream Error ", e);
		} finally {
			agentReaderContext.closeResources();
		}

		LookupUtil.setAgentsMap(agentMap);

		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns agentMap");

		return agentMap;
	}

	protected CasmGenericObject parseObject(XMLEventReader eventReader,
			XMLEvent currectEvent, String objectName) throws XMLStreamException {

		final String methodName = "parseObject";
		logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName
				+ " and the parameter passed is  objectName" + objectName);

		CasmGenericObject genObject = getObjectInstance(objectName);
		Map<String, String> objectPropertyMap = new HashMap<>();
		String propertyKey = null;

		StartElement firstElement = currectEvent.asStartElement();
		genObject.setxId(firstElement.getAttributeByName(
				new QName(XmlTagConstants.Xid)).getValue());

		while (eventReader.hasNext()) {

			XMLEvent event = eventReader.nextEvent();
			if (event.isStartElement()) {
				StartElement startElement = event.asStartElement();
				String tagName = startElement.getName().getLocalPart();

				switch (tagName) {

				case XmlTagConstants.PROPERTY:
					propertyKey = removePropertyNameSuffix(startElement
							.getAttributeByName(new QName(XmlTagConstants.NAME))
							.getValue());

					break;

				case XmlTagConstants.NUMBER_VALUE:
					event = eventReader.nextEvent();
					objectPropertyMap.put(
							propertyKey,
							getBitMappedValue(propertyKey, event.asCharacters()
									.getData()));
					break;

				case XmlTagConstants.BOOLEAN_VALUE:
					event = eventReader.nextEvent();
					objectPropertyMap.put(propertyKey, event.asCharacters()
							.getData());
					break;

				case XmlTagConstants.STRING_VALUE:
					event = eventReader.nextEvent();
					processStringValue(event, propertyKey, objectPropertyMap,
							genObject);
					break;

				case XmlTagConstants.XREF:
					event = eventReader.nextEvent();
					objectPropertyMap.put(propertyKey, event.asCharacters()
							.getData());
					break;

				case XmlTagConstants.XID:
					event = eventReader.nextEvent();
					objectPropertyMap.put(propertyKey, event.asCharacters()
							.getData());
					break;

				case XmlTagConstants.OBJECT:

					break;

				default:
					continue;
				}
			} else if (event.isEndElement()) {

				EndElement endElement = event.asEndElement();
				String tagName = endElement.getName().getLocalPart();

				if (tagName.equals(XmlTagConstants.OBJECT)) {
					genObject.setProperties(objectPropertyMap);
					break;
				}
			}
		}
		logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName
				+ " and returns genObject " + genObject.toString());
		return genObject;
	}

	protected CasmGenericObject getObjectInstance(String objectName) {
		CasmGenericObject genObject = null;

		switch (objectName) {

		case CasmConstants.AGENT:
			genObject = new Agent();
			break;
		}

		return genObject;
	}

}