package com.persistent.pmt.sourcesso.casm.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Agent extends CasmGenericObject {

  private Map<String, Agent> agent;

  private AgentConfig agentConfig;

  public Map<String, Agent> getAgent() {
    return agent;
  }

  public void setAgent(Map<String, Agent> agent) {
    this.agent = agent;
  }

  public AgentConfig getAgentConfig() {
    return agentConfig;
  }

  public void setAgentConfig(AgentConfig agentConfig) {
    this.agentConfig = agentConfig;
  }

}
