package com.persistent.pmt.sourcesso.casm.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.constant.casm.BitMappingEnum;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.generic.reader.GenericReader;
import com.persistent.pmt.sourcesso.generic.utils.LookupUtil;
import com.persistent.pmt.sourcesso.generic.utils.ReferenceUtil;

/**
 * @author Abstract implementation for all readers, contains common
 *         methods
 */
@PropertySource(value = { "classpath:application.properties" })
public abstract class AbstractXmlReader implements GenericReader {

  private static Logger logger = Logger.getLogger(AbstractXmlReader.class);
  private final String classname = AbstractXmlReader.class.getName();

  @Autowired
  Environment environment;
  
	@Autowired
	ThreadLocal<PMTContext> pmtContextThreadLocal;

  protected EventReaderContext getEventReaderContext(String inputFile) throws GenericException {

    XMLEventReader eventReader = null;
    InputStream in = null;
    try {

      PMTContext pmtContext = pmtContextThreadLocal.get();
    	
      XMLInputFactory inputFactory = XMLInputFactory.newInstance();
      // Value of node itself is returned as multiple events
      // This property ensures that all snippets of value node are
      // returned
      // as full value in one event.nextEvent()
      inputFactory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
      String basePath = environment.getProperty(CasmConstants.PROPERTY_CASM_XML_BASE_PATH);
      String environmentName = pmtContext.getEnvironmentValue();

      File file = new File(basePath + environmentName + "/" + inputFile);
      in = new FileInputStream(file);
      eventReader = inputFactory.createXMLEventReader(in);

    }
    catch (XMLStreamException | IOException e) {
      throw new GenericException("Error while reading source XML file: " + inputFile, e);
    }
    return new EventReaderContext(eventReader, in);
  }

  /**
   * Parse an Object node to retrieve all the properties in
   * CasmGenericObject. This parent method will be consumed to read
   * the XML files which does not need a separate bean class,
   * otherwise override this method in individual reader.
   * 
   * @param eventReader
   *          XMLEventReader handle
   * @param currectEvent
   *          XMLEvent object for Object tag
   * @param objectName
   *          Type of object
   * @return CasmGenericObject Object with all the properties of
   *         Object node
   * @throws XMLStreamException
   * @throws GenericException
   */
  protected CasmGenericObject parseObject(XMLEventReader eventReader, XMLEvent currectEvent,
      String objectName) throws XMLStreamException, GenericException {

    final String methodName = "parseObject";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName);

    CasmGenericObject genObject = new CasmGenericObject();
    Map<String, String> objectPropertyMap = new HashMap<>();
    String propertyKey = null;

    StartElement firstElement = currectEvent.asStartElement();
    Attribute firstElementAttribute =
        firstElement.getAttributeByName(new QName(XmlTagConstants.Xid));
    if (firstElementAttribute != null) {
      genObject.setxId(firstElementAttribute.getValue());
    }

    while (eventReader.hasNext()) {

      XMLEvent event = eventReader.nextEvent();
      if (event.isStartElement()) {
        StartElement startElement = event.asStartElement();
        String tagName = startElement.getName().getLocalPart();

        switch (tagName) {

          case XmlTagConstants.PROPERTY:
            propertyKey =
                startElement.getAttributeByName(new QName(XmlTagConstants.NAME)).getValue();
            break;

          case XmlTagConstants.BOOLEAN_VALUE:
            event = eventReader.nextEvent();
            objectPropertyMap.put(propertyKey, event.asCharacters().getData());
            break;

          case XmlTagConstants.NUMBER_VALUE:
            event = eventReader.nextEvent();
            objectPropertyMap.put(propertyKey,
                getBitMappedValue(propertyKey, event.asCharacters().getData()));
            break;

          case XmlTagConstants.STRING_VALUE:
            event = eventReader.nextEvent();
            processStringValue(event, propertyKey, objectPropertyMap, genObject);
            break;

          case XmlTagConstants.XREF:
            event = eventReader.nextEvent();
            String referenceId = event.asCharacters().getData();
            String referenceValue = ReferenceUtil.getReferenceById(referenceId);
            if (referenceValue != null) {
              objectPropertyMap.put(propertyKey, referenceValue);
            }
            break;

          case XmlTagConstants.XID:
            event = eventReader.nextEvent();
            processXid(event, propertyKey, objectPropertyMap);
            break;

          default:
            continue;
        }
      }
      else if (event.isEndElement()) {

        EndElement endElement = event.asEndElement();
        String tagName = endElement.getName().getLocalPart();

        if (tagName.equals(XmlTagConstants.OBJECT)) {
          genObject.setProperties(objectPropertyMap);
          LookupUtil.addXidToNamePair(genObject.getxId(), genObject.getName());
          break;
        }
      }
    }

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);
    return genObject;
  }

  /**
   * Process StringValue type of data to set to it to either Map or
   * GenericObject
   * 
   * @param event
   * @param propertyKey
   * @param objectPropertyMap
   * @param genObject
   */
  protected void processStringValue(XMLEvent event, String propertyKey,
      Map<String, String> objectPropertyMap, CasmGenericObject genObject) {

    final String methodName = "processStringValue";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName);

    String value = null;
    if (!event.isEndElement()) {
      value = event.asCharacters().getData();
    }

    if (null != objectPropertyMap.get(propertyKey) && null != value) {
      value = objectPropertyMap.get(propertyKey) + CasmConstants.COMMA + value;
    }

    if (XmlTagConstants.NAME.equals(propertyKey)) {
      genObject.setName(value);
    }
    else if (XmlTagConstants.DESCRIPTION.equals(propertyKey)) {
      genObject.setDescription(value);
    }
    else {
      objectPropertyMap.put(propertyKey, value);
    }

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);
  }

  /**
   * Process XID property to get the value
   * 
   * @param event
   * @param propertyKey
   * @param objectPropertyMap
   */
  protected void processXid(XMLEvent event, String propertyKey,
      Map<String, String> objectPropertyMap) {

    final String methodName = "processStringValue";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName);

    String xid = event.asCharacters().getData();
    if (null != objectPropertyMap.get(propertyKey)) {
      xid = objectPropertyMap.get(propertyKey) + CasmConstants.COMMA + xid;
    }
    objectPropertyMap.put(propertyKey, xid);

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);
  }

  /**
   * Get string value of integer value
   * 
   * @param propertyKeyName
   * @param keyNumericValueString
   * @return
   */
  protected String getBitMappedValue(String propertyKeyName, String keyNumericValueString) {

    final String methodName = "getObjectInstance";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName);

    String bitMappingValue = null;

    switch (propertyKeyName) {

      case XmlTagConstants.MODE:
        bitMappingValue =
            BitMappingEnum.DOMAIN_MODE.getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.LOCALAUTHENTICATIONTYPE:
        bitMappingValue = BitMappingEnum.LOCAL_AUTHENTICATION_TYPE
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.SIGNATUREALGO:
        bitMappingValue = BitMappingEnum.SIGNATURE_ALGO
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.STATUS:
        bitMappingValue =
            BitMappingEnum.STATUS.getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.ARTIFACTSIGNINGOPTION:
        bitMappingValue = BitMappingEnum.ARTIFACT_SIGNING_OPTION
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.POSTSIGNINGOPTION:
        bitMappingValue = BitMappingEnum.POST_SIGNING_OPTION
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.DELEGATEDAUTHTYPE:
        bitMappingValue = BitMappingEnum.DELEGATED_AUTH_TYPE
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.SLOSOAPSIGNOPTION:
        bitMappingValue = BitMappingEnum.SLO_SOAP_SIGN_OPTION
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.SESSIONNOTONORAFTERTYPE:
        bitMappingValue = BitMappingEnum.SESSION_NOT_ON_OR_AFTER_TYPE
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.AUTHNCONTEXTTYPE:
        bitMappingValue = BitMappingEnum.AUTHN_CONTEXT_TYPE
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.ALLOWTRANSACTIONTYPE:
        bitMappingValue = BitMappingEnum.ALLOW_TRANSACTION_TYPE
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.AUTHENTICATIONTYPE:
        bitMappingValue = BitMappingEnum.AUTHENTICATION_TYPE
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.AGENTTYPE_VENDORTYPE:
        bitMappingValue = BitMappingEnum.AGENTTYPE_VENDORTYPE
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

      case XmlTagConstants.AUTHSCHEME_TYPE:
        bitMappingValue = BitMappingEnum.AUTHSCHEME_TYPE
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;
      case XmlTagConstants.USERDIRECTORY_SEARCHSCOPE:
        bitMappingValue = BitMappingEnum.USERDIRECTORY_SEARCHSCOPE
            .getBitMapValue(Integer.parseInt(keyNumericValueString));
        break;

    }
    if (bitMappingValue != null) {
      keyNumericValueString = bitMappingValue;
    }

    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);
    return keyNumericValueString;
  }

  // // removes object name suffix for xId's
  // protected String removeXidSuffix(String fullXid) {
  //
  // String[] splitString =
  // fullXid.split(XmlTagConstants.XID_SPLIT_CHAR);
  // return splitString[1];
  // }

  // removes Name suffix for object's properties like
  // CA.SM::Domain.Name
  protected String removePropertyNameSuffix(String propertyName) {

    String[] splitString = propertyName.split(XmlTagConstants.PROPERTY_NAME_SPLIT_CHAR);
    return splitString[splitString.length - 1];
  }

  // removes Name suffix for object's name like CA.SM::Domain
  protected String removeObjectNameSuffix(String className) {

    String[] splitString = className.split(XmlTagConstants.OBJECT_NAME_SPLIT_CHAR);
    return splitString[splitString.length - 1];
  }

  protected String cleanseResourcePath(String resourcePathString) {	  

	 // String repeativeSlashRemovedString = resourcePathString.replaceAll("//*//*", "/*");
	  String nullRemovedString = resourcePathString.replaceAll("null", CasmConstants.EMPTY_STRING);	  
	  return nullRemovedString.replaceAll("/{2,}", CasmConstants.FORWARD_SLASH);	  	  
	  
  }

}
