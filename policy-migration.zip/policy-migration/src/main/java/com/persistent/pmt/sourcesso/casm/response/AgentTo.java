package com.persistent.pmt.sourcesso.casm.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AgentTo {

	private String name;
	private String type;
	private List<String> parentGroups;
	private List<String> childGroups;
	private List<String> agentMembers;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<String> getParentGroups() {
		return parentGroups;
	}
	public void setParentGroups(List<String> parentGroups) {
		this.parentGroups = parentGroups;
	}
	public List<String> getChildGroups() {
		return childGroups;
	}
	public void setChildGroups(List<String> childGroups) {
		this.childGroups = childGroups;
	}
	public List<String> getAgentMembers() {
		return agentMembers;
	}
	public void setAgentMembers(List<String> agentMembers) {
		this.agentMembers = agentMembers;
	}
	
	
}