package com.persistent.pmt.sourcesso.generic.mapper;

import com.persistent.pmt.exception.GenericException;

/**
 * @author shishir_kumar
 *
 */
public interface GenericMapper {

	public Object getMappedObject(Object object) throws GenericException;
	
}
