package com.persistent.pmt.sourcesso.casm.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseTo {

	private String name;
	private String agentTypeLink;
	private List<ResponseAttrTo> responseAttributes = new ArrayList<>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ResponseAttrTo> getResponseAttributes() {
		return responseAttributes;
	}

	public void setResponseAttributes(List<ResponseAttrTo> responseAttributes) {
		this.responseAttributes = responseAttributes;
	}

	public String getAgentTypeLink() {
		return agentTypeLink;
	}

	public void setAgentTypeLink(String agentTypeLink) {
		this.agentTypeLink = agentTypeLink;
	}

}
