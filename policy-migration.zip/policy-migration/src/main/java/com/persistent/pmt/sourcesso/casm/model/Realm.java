package com.persistent.pmt.sourcesso.casm.model;

import java.util.ArrayList;
import java.util.List;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.utils.StringUtils;;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Realm extends CasmGenericObject {
	
	private List<Rule> rules = new ArrayList<>();
	//Derived attributes
	@JsonIgnore
	private StringBuilder commaSeparatedRuleXid = new StringBuilder();

	public List<Rule> getRules() {
		return rules;
	}
	public StringBuilder getCommaSeparatedRuleXid() {
		return commaSeparatedRuleXid;
	}
		
	public Rule getRuleByXid(String xId) {
		
		Rule rule = null;
		for(Rule r : rules) {
			if(xId.equals(r.getxId())) {
				rule = r;
				break;
			}
		}
		return rule;
	}
	
	public boolean isParentRealm(){
		String parentRealmLink = this.getProperties().get(XmlTagConstants.PARENT_REALM_LINK); 
		if(StringUtils.isEmpty(parentRealmLink))
			return true;
		else
			return false;
		
	}
	public boolean isChildRealm(){
		String parentRealmLink = this.getProperties().get(XmlTagConstants.PARENT_REALM_LINK); 
		if(!StringUtils.isEmpty(parentRealmLink))
			return true;
		else
			return false;
		
	}	
	
	
}
