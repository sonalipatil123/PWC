package com.persistent.pmt.sourcesso.casm.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.sourcesso.casm.model.Domain;
import com.persistent.pmt.sourcesso.generic.response.BaseResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationDetailsImportResponse extends BaseResponse {

	private Domain domain;

	public ApplicationDetailsImportResponse() {
	}

	public ApplicationDetailsImportResponse(Domain domain) {
		super();
		this.domain = domain;
	}

	public Domain getDomain() {
		return domain;
	}

	public void setDomain(Domain domain) {
		this.domain = domain;
	}

}
