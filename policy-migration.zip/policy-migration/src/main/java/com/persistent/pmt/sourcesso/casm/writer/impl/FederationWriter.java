package com.persistent.pmt.sourcesso.casm.writer.impl;

import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.dao.ProviderDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Provider;
import com.persistent.pmt.sourcesso.casm.mapper.impl.SamlProviderMapper;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.reader.impl.UtilityReader;
import com.persistent.pmt.sourcesso.casm.writer.ObjectWriter;

@Component("federationWriter")
@PropertySource(value = { "classpath:application.properties" })
public class FederationWriter implements ObjectWriter {
	
  private static Logger logger = Logger.getLogger(FederationWriter.class);
  private final String classname = FederationWriter.class.getName();	

  @Autowired
  @Qualifier("providerDao")
  ProviderDao providerDao;

  @Autowired
  SamlProviderMapper samlProviderMapper;

  @Override
  public void write(List<? extends CasmGenericObject> objects) throws GenericException {
	
    final String methodName = "write";
    logger.log(Level.DEBUG, "Entering :: " + classname + ":" + methodName+"and the passed parameter is List that extends CasmGenericObject");  
	  
	for (CasmGenericObject partner : objects) {
	      Provider provider = samlProviderMapper.getMappedObject(partner);
	      providerDao.createProvider(provider);
	    }
    logger.log(Level.DEBUG, "Exiting :: " + classname + ":" + methodName);  

  }

}
