package com.persistent.pmt.sourcesso.casm.model;

public class Partner extends CasmGenericObject {

	private String type;
  private boolean isRemote;
	
	public Partner() {	
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

  public boolean isRemote() {
    return isRemote;
  }

  public void setIsRemote(boolean isRemote) {
    this.isRemote = isRemote;
  }

  @Override
  public String toString() {
    return "Partner [type=" + type + ", isRemote=" + isRemote + ", getxId()=" + getxId()
        + ", getName()=" + getName() + ", getDescription()=" + getDescription()
        + ", getProperties()=" + getProperties() + "]";
  }
}
