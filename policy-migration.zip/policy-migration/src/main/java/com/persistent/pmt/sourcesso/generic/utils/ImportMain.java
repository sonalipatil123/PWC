package com.persistent.pmt.sourcesso.generic.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.persistent.pmt.dao.ApplicationDao;
import com.persistent.pmt.dao.ProviderDao;
import com.persistent.pmt.dao.UserDataStoreDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.UserDataStore;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.sourcesso.casm.constant.MapperConstants;
import com.persistent.pmt.sourcesso.casm.mapper.impl.DomainEntityMapper;
import com.persistent.pmt.sourcesso.casm.mapper.impl.UserDataStoreMapper;
import com.persistent.pmt.sourcesso.casm.model.Agent;
import com.persistent.pmt.sourcesso.casm.model.AgentConfig;
import com.persistent.pmt.sourcesso.casm.model.AuthScheme;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.model.Domain;
import com.persistent.pmt.sourcesso.casm.model.Partner;
import com.persistent.pmt.sourcesso.casm.reader.impl.AgentConfigReader;
import com.persistent.pmt.sourcesso.casm.reader.impl.UserDirectoryReader;
import com.persistent.pmt.sourcesso.generic.reader.GenericReader;

@Component
@PropertySource(value = { "classpath:application.properties" })
public class ImportMain {

	@Autowired
	@Qualifier("domainReader")
	GenericReader domainReader;

	@Autowired
	@Qualifier("federationReader")
	GenericReader federationReader;

	@Autowired
	@Qualifier("referenceReader")
	GenericReader referenceReader;

	@Autowired
	@Qualifier("utilityReader")
	GenericReader utilityReader;

	@Autowired
	@Qualifier("agentReader")
	GenericReader agentReader;

	@Autowired
	@Qualifier("agentConfigReader")
	GenericReader agentConfigReader;

	@Autowired
	@Qualifier("authSchemeReader")
	GenericReader authSchemeReader;

	@Autowired
	@Qualifier("agentGroupReader")
	GenericReader agentGroupReader;

	@Autowired
	@Qualifier("userDirectoryReader")
	UserDirectoryReader userDirectoryReader;

	@Autowired
	Environment environment;

	@Autowired
	@Qualifier("userDataStoreDao")
	UserDataStoreDao userDataStoreDao;

	@Autowired
	@Qualifier("providerDao")
	ProviderDao providerDao;

	@Autowired
	@Qualifier("applicationDao")
	ApplicationDao applicationDao;

	@SuppressWarnings("unchecked")
	public GenericResponse<?> importXML() throws com.persistent.pmt.exception.GenericException {

		// Read references and populate map in ReferenceUtil class
		ReferenceUtil.setReferences((Map<String, String>) referenceReader.readAndSaveData());

		// // Read dependent XML files
		// List<CasmGenericObject> endpoints =
		// (List<CasmGenericObject>)
		// utilityReader.readAndSaveData(environment
		// .getProperty(CasmConstants.PROPERTY_CASM_XML_ENDPOINT));
		//
		// List<CasmGenericObject> userDirectoriList =
		// (List<CasmGenericObject>)
		// userDirectoryReader.readAndSaveData();
		// createUserDirectories(userDirectoriList);
		//
		// List<Partner> federationPartners = (List<Partner>)
		// federationReader.readAndSaveData();
		// createProviders(federationPartners);
		//
		// Map<String, Agent> agentMap = (Map<String, Agent>)
		// agentReader.readAndSaveData();
		// Map<String, AgentConfig> agentConfigs =
		// (Map<String, AgentConfig>) agentConfigReader.readAndSaveData();

		List<Domain> domains = (List<Domain>) domainReader.readAndSaveData();
		List<AuthScheme> authSchemes = (List<AuthScheme>) authSchemeReader.readAndSaveData();
		try {
			testDomainDAO(domains.get(426));
			testDomainDAO(domains.get(427));
			testDomainDAO(domains.get(428));
			testDomainDAO(domains.get(429));
			testDomainDAO(domains.get(430));
			testDomainDAO(domains.get(431));
			testDomainDAO(domains.get(432));
			testDomainDAO(domains.get(433));
		} catch (Exception e) {
		}
		List<Application> applications = null;

		GenericResponse<List<Application>> wrapperResponse = new GenericResponse<>();
		try {
			for (Domain domain : domains) {
				if (domain.getxId().equalsIgnoreCase("CA.SM::Domain@03-668ae8de-c09c-1029-a80f-8315aa6a0cb3")) {

					HashMap<String, Object> parameters = new HashMap<>();
					parameters.put(MapperConstants.DOMAIN, domain);
					parameters.put(MapperConstants.AUTH_SCHEMES, authSchemes);

					DomainEntityMapper domainEntityMapper = new DomainEntityMapper();
					applications = domainEntityMapper.getMappedObject(parameters);
					break;
				}
			}

			wrapperResponse.setContent(applications);
			wrapperResponse.setStatusCode(200);
			wrapperResponse.setMessage(GenericResponse.SUCCESS);
			wrapperResponse.setStatus(GenericResponse.SUCCESS);
		} catch (Exception e) {
			wrapperResponse.setStatusCode(500);
			wrapperResponse.setMessage(e.getMessage());
			wrapperResponse.setStatus(GenericResponse.FAILURE);
		}

		// Sample code to check API endpoint
		// ApplicationImportResponse response = new
		// ApplicationImportResponse();

		// response.setObjects(endpoints);
		// response.setPartners(federationPartners);
		// response.setDomainList(domains);
		// response.setAgentGroups((AgentGroups)
		// agentGroupReader.readAndSaveData());
		// response.setAuthSchemeList(authSchemes);
		// response.setAgentList(new ArrayList<>(agentMap.values()));
		// response.setAgentConfigList(new
		// ArrayList<>(agentConfigs.values()));

		return wrapperResponse;
	}

	// Test methods
	public void main() {

		try {
			domainReader.readAndSaveData();
			Set<String> usedAuthSchemes = LookupUtil.getAuthSchemes();
			Set<String> usedAgents = LookupUtil.getAgentIds();
			System.out.println("UsedAuthSchemes From Domain Reader:" + usedAuthSchemes);
			System.out.println(usedAuthSchemes.size());
			System.out.println("Used Agents From DomainReader:" + usedAgents);
			System.out.println(usedAgents.size());
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Test Case 1 - Agent Reader

		Map<String, Agent> agentMap = testAgentReader(agentReader);

		// Test Case 2 - AgentConfig Reader

		testAgentConfigReader(agentConfigReader);

		// Test Case 3 - get AgentConfigByName
		testGetAgentConfigByByName(agentMap, agentConfigReader);

		// Test Case 4 - Test Auth Schemes

		testAuthSchemesReader(authSchemeReader);

	}

	@SuppressWarnings("unchecked")
	public static Map<String, Agent> testAgentReader(GenericReader agentReader) {
		Map<String, Agent> agentMap = null;
		try {
			agentMap = (Map<String, Agent>) agentReader.readAndSaveData();
			System.out.println("Agents From AgentReader");
			for (String agent : agentMap.keySet()) {
				System.out.println(agent);
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		System.out.println("Agent Map from AgentReader:" + agentMap);
		System.out.println("Agent Map Size From AgentReader :" + agentMap.size());
		return agentMap;
	}

	private static void testGetAgentConfigByByName(Map<String, Agent> agentMap, GenericReader agentConfigReader) {
		System.out.println("In AgentConfigByName..");
		for (String agent : agentMap.keySet()) {
			AgentConfig agentConfig = ((AgentConfigReader) agentConfigReader).getAgentConfigByAgentName(agent);
			if (agentConfig != null) {
				System.out
						.println(agentConfig.getName() + ",Agent name=" + agent + "  " + agentConfig.getAgentToFQDN());
			} else {
				System.out.println(agent + " agent has no configuration..");
			}

		}
	}

	@SuppressWarnings("unchecked")
	public static void testAgentConfigReader(GenericReader agentConfigReader) {

		Map<String, AgentConfig> agentConfigs = null;
		try {
			agentConfigs = (Map<String, AgentConfig>) agentConfigReader.readAndSaveData();
		} catch (Exception e) {
			e.printStackTrace();

		}

		// System.out.println("AgentConfig List:" +
		// agentConfigs.toString());

		System.out.println(agentConfigs);
		System.out.println("AgentConfig Map Size:" + agentConfigs.size());

	}

	@SuppressWarnings("unchecked")
	public static void testAuthSchemesReader(GenericReader authSchemeReader) {

		List<AuthScheme> authSchemes = null;
		try {
			authSchemes = (List<AuthScheme>) authSchemeReader.readAndSaveData();
		} catch (Exception e) {
			e.printStackTrace();

		}

		System.out.println("AuthScheme List From AuthSchemeReader:" + authSchemes);
		System.out.println("AuthScheme List Size:" + authSchemes.size());

	}

	public void createProviders(List<Partner> partners) {
		/*
		 * try { SamlProviderMapper samlProviderMapper = new SamlProviderMapper(); for
		 * (Partner partner : partners) { // Provider provider = (Provider) //
		 * samlProviderMapper.getMappedObject(partner); //
		 * providerDao.createProvider(provider); } } catch (Exception e) {
		 * e.printStackTrace();
		 * 
		 * }
		 */
	}

	public void createUserDirectories(List<CasmGenericObject> userDirectories) {
		try {
			UserDataStoreMapper userDataStoreMapper = new UserDataStoreMapper();
			for (CasmGenericObject userDirectory : userDirectories) {
				UserDataStore userDataStore = (UserDataStore) userDataStoreMapper.getMappedObject(userDirectory);
				userDataStoreDao.createUserDataStore(userDataStore);
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void testDomainDAO(Domain d) throws com.persistent.pmt.exception.GenericException {

		// DomainEntityMapper mapper = new DomainEntityMapper();
		// List<Application> apps = (List<Application>) mapper.getMappedObject(d);
		// applicationDao.saveOrUpdateApplication(app);
	}

	@SuppressWarnings("unchecked")
	public List<Domain> getDomains() throws GenericException {

		return (List<Domain>) domainReader.readAndSaveData();
	}

}