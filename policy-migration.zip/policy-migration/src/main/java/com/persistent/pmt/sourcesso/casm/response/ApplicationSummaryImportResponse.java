package com.persistent.pmt.sourcesso.casm.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.model.ApplicationSummary;
import com.persistent.pmt.sourcesso.generic.response.BaseResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationSummaryImportResponse extends BaseResponse {

	private List<ApplicationSummary> applicationSummaryList;

	public ApplicationSummaryImportResponse(
			List<ApplicationSummary> applicationSummaryList) {
		super();
		this.applicationSummaryList = applicationSummaryList;
	}

	public List<ApplicationSummary> getApplicationSummaryList() {
		return applicationSummaryList;
	}

	public void setApplicationSummaryList(
			List<ApplicationSummary> applicationSummaryList) {
		this.applicationSummaryList = applicationSummaryList;
	}

}
