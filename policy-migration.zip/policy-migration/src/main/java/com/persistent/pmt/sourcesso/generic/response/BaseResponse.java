package com.persistent.pmt.sourcesso.generic.response;


/**
 * @author shishir_kumar
 *
 */

public class BaseResponse {


}
