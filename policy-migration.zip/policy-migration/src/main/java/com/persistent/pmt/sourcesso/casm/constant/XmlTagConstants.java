package com.persistent.pmt.sourcesso.casm.constant;

/**
 * @author shishir_kumar
 *
 * Holds constants specific to XML tags and attributes for CA SiteMinder.
 */
public class XmlTagConstants {

  public static final String IDPID = "IdPID";
  public static final String SPID = "SPID";
  public static final String NAME = "Name";
  public static final String DESCRIPTION = "Description";
  public static final String REFERENCES = "References";
  public static final String REFERENCE_VALUE = "ReferenceValue";
  public static final String STRING_VALUE = "StringValue";
  public static final String OBJECT = "Object";
  public static final String PROPERTY = "Property";
  public static final String LINK_VALUE = "LinkValue";
  public static final String XID = "XID";
  public static final String XREF = "XREF";
  public static final String NUMBER_VALUE = "NumberValue";
  public static final String BOOLEAN_VALUE = "BooleanValue";
  public static final String REFERENCEID = "ReferenceId";
  public static final String TYPE = "type";
  public static final String VALUE = "Value";
  public static final String IPADDRESSES = "IPAddresses";
  public static final String KEY_SPID = "KEY_SPID";
  public static final String KEY_RPID = "KEY_RPID";

  public static final String XID_SPLIT_CHAR = "@";
  public static final String PROPERTY_NAME_SPLIT_CHAR = "\\.";
  public static final String OBJECT_NAME_SPLIT_CHAR = "\\:";

  // Object Attributes constants
  public static final String MODE = "Mode";
  public static final String AUTH_SCHEME_LINK = "AuthSchemeLink";
  public static final String RULE_LINK = "RuleLink";
  public static final String PARENT_REALM_LINK = "ParentRealmLink";
  public static final String RESOURCE_FILTER = "ResourceFilter";
  public static final String RESOURCE = "Resource";
  public static final String RESPONSE_LINK = "ResponseLink";
  public static final String RULE_GROUP_LINK = "RuleGroupLink";
  public static final String RESPONSE_GROUP_LINK = "ResponseGroupLink";
  public static final String DESC = "Desc";
  public static final String AGENT_TYPE_LINK = "AgentTypeLink";
  public static final String HIDING_MASK = "HidingMask";
  public static final String SESSION_TYPE = "SessionType";
  public static final String PROTECT_ALL = "ProtectAll";
  public static final String ACTIONS = "Actions";
  public static final String ALLOW_ACCESS = "AllowAccess";
  public static final String FILTER_CLASS = "FilterClass";
  public static final String FILTER_PATH = "FilterPath";
  public static final String POLICY_FLAGS = "PolicyFlags";
  public static final String POLICY_RESOLUTION = "PolicyResolution";
  public static final String USER_DIRECTORY_LINK = "UserDirectoryLink";
  public static final String USER_DIRECTORIES_LINK = "UserDirectoriesLink";
  public static final String AGENT_GROUP_LINK = "AgentGroupLink";
  public static final String RESPONSES_LINK = "ResponsesLink";
  public static final String RULES_LINK = "RulesLink";
  public static final String AGENT_LINK = "AgentLink";
  public static final String USERDIRECTORY_SEARCHSCOPE = "SearchScope";
  public static final String AGENTTYPE_VENDORTYPE = "VendorType";
  public static final String AUTHSCHEME_TYPE = "Type";
  public static final String ATTRIBUTES = "Attributes";
  public static final String LEVEL = "Level";
  public static final String IS_ENABLED = "IsEnabled";
  
  // Tag attributes constants
  public static final String Xid = "Xid";
  public static final String CLASS = "Class";
  public static final String SPREMOTELINK = "SPRemoteLink";
  public static final String SPLOCALLINK = "SPLocalLink";
  public static final String IDPREMOTELINK = "IdPRemoteLink";
  public static final String IDPLOCALLINK = "IdPLocalLink";
  public static final String AGENTSLINK = "AgentsLink";
  public static final String AGENTGROUPSLINK = "AgentGroupsLink";

  // Federation attributes
  public static final String LOCALAUTHENTICATIONTYPE = "LocalAuthenticationType";
  public static final String SIGNATUREALGO = "SignatureAlgo";
  public static final String STATUS = "Status";
  public static final String ARTIFACTSIGNINGOPTION = "ArtifactSigningOption";
  public static final String POSTSIGNINGOPTION = "PostSigningOption";
  public static final String DELEGATEDAUTHTYPE = "DelegatedAuthType";
  public static final String SLOSOAPSIGNOPTION = "SloSoapSignOption";
  public static final String SESSIONNOTONORAFTERTYPE = "SessionNotOnOrAfterType";
  public static final String AUTHNCONTEXTTYPE = "AuthnContextType";
  public static final String ALLOWTRANSACTIONTYPE = "AllowTransactionType";
  public static final String AUTHENTICATIONTYPE = "AuthenticationType";
}

