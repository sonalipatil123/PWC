package com.persistent.pmt.sourcesso.casm.constant;

public class CasmConstants {

	public static final String DOMAIN = "Domain";
	public static final String REALM = "Realm";
	public static final String RESPONSE = "Response";
	public static final String POLICY = "Policy";
	public static final String RESPONSE_ATTR = "ResponseAttr";

}
