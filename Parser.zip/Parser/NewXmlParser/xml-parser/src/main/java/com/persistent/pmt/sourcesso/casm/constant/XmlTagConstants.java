package com.persistent.pmt.sourcesso.casm.constant;

public class XmlTagConstants {

	public static final String NAME = "Name";
	public static final String POLICY_DATA = "PolicyData";
	public static final String REFERENCES = "References";
	public static final String REFERENCE_VALUE = "ReferenceValue";
    public static final String STRING_VALUE = "StringValue";
    public static final String OBJECT = "Object";
    public static final String PROPERTY = "Property";
    public static final String LINK_VALUE = "LinkValue";
    public static final String XID = "XID";
    public static final String XREF = "xref";
    public static final String NUMBER_VALUE = "NumberValue";
    public static final String BOOLEAN_VALUE = "BooleanValue";
    
    
    public static final String XID_SPLIT_CHAR = "@";
    public static final String PROPERTY_NAME_SPLIT_CHAR = "\\.";
    public static final String OBJECT_NAME_SPLIT_CHAR = "\\:";
    
    
    //Object Attributes constants
    public static final String DOMAIN_MODE = "Mode";
    
    public static final String USERDIR_SEARCHSCOPE="SearchScope";
    
    
    //Tag attributes constants
    public static final String Xid = "Xid";
    public static final String CLASS = "Class";
    

    

    
}
