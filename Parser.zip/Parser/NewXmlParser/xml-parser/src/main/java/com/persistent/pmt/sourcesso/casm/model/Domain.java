package com.persistent.pmt.sourcesso.casm.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Domain extends CasmGenericObject {

	private String mode;
	private List<String> userDirectoryLinks = new ArrayList<>();
	private List<Response> responses = new ArrayList<>();
	private List<Realm> realms = new ArrayList<>();
	private List<Variable> varibales = new ArrayList<>();
	private List<Policy> policies = new ArrayList<>();
	private List<RuleGroup> ruleGroups = new ArrayList<>();
	private List<ResponseGroup> responseGroups = new ArrayList<>();
	
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public List<String> getUserDirectoryLinks() {
		return userDirectoryLinks;
	}
	public void setUserDirectoryLinks(List<String> userDirectoryLinks) {
		this.userDirectoryLinks = userDirectoryLinks;
	}
	public List<Response> getResponses() {
		return responses;
	}
	public void setResponses(List<Response> responses) {
		this.responses = responses;
	}
	public List<Realm> getRealms() {
		return realms;
	}
	public void setRealms(List<Realm> realms) {
		this.realms = realms;
	}
	public List<Variable> getVaribales() {
		return varibales;
	}
	public void setVaribales(List<Variable> varibales) {
		this.varibales = varibales;
	}
	public List<Policy> getPolicies() {
		return policies;
	}
	public void setPolicies(List<Policy> policies) {
		this.policies = policies;
	}
	public List<RuleGroup> getRuleGroups() {
		return ruleGroups;
	}
	public void setRuleGroups(List<RuleGroup> ruleGroups) {
		this.ruleGroups = ruleGroups;
	}
	public List<ResponseGroup> getResponseGroups() {
		return responseGroups;
	}
	public void setResponseGroups(List<ResponseGroup> responseGroups) {
		this.responseGroups = responseGroups;
	}
	
		
	
}
