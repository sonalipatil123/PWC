package com.persistent.pmt.sourcesso.casm.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * @author shishir_kumar
 *
 */
public enum BitMappingEnum {


	
	ADMIN_RIGHTS(new int[] {0, 1, 2, 4, 8, 16, 32, 47, 64}, "none", "ManageAllDomains", "ManageObjects", "ManageUsers",
			"ManageSecurity", "CacheManager", "RegisterTrustedHosts", "ManageEverything", "AccessSharedDB"),
	
	DOMAIN_MODE(new int[] {0, 1, 2, 4, 8}, "Default", "Hidden", "GlobalPoliciesApply", "Global", "Administration"), 
	
	
	
	USERDIR_SEARCHSCOPE(new int[] {0,1,2},"Base","OneLevel","SubTree");
	
	private Map<Integer, String> map = new HashMap<>();
	
	private BitMappingEnum(int[] keys, String... values) {
		
		int i = 0;
		for(String value : values) {
			map.put(keys[i], value);
			i++;
		}
	}
		
	/**
	 * @param key
	 * @return mapped String value to bit number
	 */
	public String getBitMapValue(Integer key) {
		
		return map.get(key);
	}
	
}
