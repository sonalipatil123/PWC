package com.persistent.pmt.sourcesso.casm.mapper;

import com.persistent.pmt.sourcesso.generic.mapper.GenericMapper;

public class AbstractXmlMapper implements GenericMapper {

}
