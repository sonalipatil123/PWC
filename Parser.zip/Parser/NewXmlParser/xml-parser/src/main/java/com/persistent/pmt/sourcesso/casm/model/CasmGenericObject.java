package com.persistent.pmt.sourcesso.casm.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CasmGenericObject {

	private String xId;
	private String name;
	private String description;
	private Map<String, String> properties;
	
	public String getxId() {
		return xId;
	}
	public void setxId(String xId) {
		this.xId = xId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Map<String, String> getProperties() {
		return properties;
	}
	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}
		
}
