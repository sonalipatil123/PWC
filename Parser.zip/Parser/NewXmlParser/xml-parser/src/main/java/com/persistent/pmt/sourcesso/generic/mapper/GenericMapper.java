package com.persistent.pmt.sourcesso.generic.mapper;

public interface GenericMapper {

	
}
