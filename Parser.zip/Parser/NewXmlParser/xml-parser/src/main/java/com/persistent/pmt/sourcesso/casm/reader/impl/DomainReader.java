package com.persistent.pmt.sourcesso.casm.reader.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.springframework.stereotype.Component;

import com.persistent.pmt.sourcesso.casm.constant.BitMappingEnum;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.model.Domain;
import com.persistent.pmt.sourcesso.casm.model.Policy;
import com.persistent.pmt.sourcesso.casm.model.Realm;
import com.persistent.pmt.sourcesso.casm.model.Response;
import com.persistent.pmt.sourcesso.casm.model.ResponseAttr;
import com.persistent.pmt.sourcesso.casm.reader.AbstractXmlReader;
import com.persistent.pmt.sourcesso.casm.response.ApplicationImportResponse;
import com.persistent.pmt.sourcesso.generic.exception.GenericException;
import com.persistent.pmt.sourcesso.generic.response.GenericResponse;

@Component
public class DomainReader extends AbstractXmlReader {

	
	@Override
	public GenericResponse readData() {
		
		return null;
	}

	@Override
	public GenericResponse readAndSaveData() throws GenericException {
				
//		List<Domain> domainList = new ArrayList<>();
//		Domain domain1 = new Domain();
//		domain1.setName("test Domain");
//		domainList.add(domain1);
		
		
		ApplicationImportResponse response = new ApplicationImportResponse();
		response.setDomainList(getDomainList());
		
		/*UsrDirRes res=new UserDirREs()
		 * 
		 * res=setUsrDirList(getusrDirList);
		 * */
		 
		
		return response;
	}
	
	private List<Domain> getDomainList() throws GenericException {
						
		XMLEventReader eventReader = getEventReader("CA.SM.Domain.xml");		
		List<Domain> domainList = new ArrayList<>();
   	 	Domain domainObject;
        
        try {
        	
           while (eventReader.hasNext()) {
           	
               XMLEvent event = eventReader.nextEvent();               
               if (event.isStartElement()) {
                   StartElement startElement = event.asStartElement();
                   String tagName = startElement.getName().getLocalPart();
                                    
                   if (tagName.equals(XmlTagConstants.OBJECT)) {
                   	
                	domainObject = (Domain)parseObject(eventReader, event, CasmConstants.DOMAIN);
                   	domainList.add(domainObject);
                   }               
               }
               // If we reach the end of an item element, we add it to the list
               if (event.isEndElement()) {
                   EndElement endElement = event.asEndElement();
                   String tagName = endElement.getName().getLocalPart();
                   
                    if (tagName.equals(XmlTagConstants.OBJECT)) {                    	
                    	continue;
                    }               
               }
             }
	      } catch (XMLStreamException e) {
	          throw new GenericException("File Input Stream Error ", e);
	      } 
	       return domainList;
		}		


	private CasmGenericObject parseObject(XMLEventReader eventReader, XMLEvent currectEvent, String objectName) throws XMLStreamException {
 	
		CasmGenericObject genObject = getObjectInstance(objectName);
		Map<String, String> objectPropertyMap = new HashMap<>();
		String propertyKey = null;
		
	 	StartElement firstElement = currectEvent.asStartElement();	 	
	 	genObject.setxId(removeXidSuffix(firstElement.getAttributeByName(new QName(XmlTagConstants.Xid)).getValue()));
 	
        while(eventReader.hasNext()) {
 		
        	XMLEvent event = eventReader.nextEvent();
	    	if (event.isStartElement()) {
	            StartElement startElement = event.asStartElement();
	            String tagName = startElement.getName().getLocalPart();
	            
	            switch(tagName) {
	            
	            	case XmlTagConstants.PROPERTY: 
	            		propertyKey = removePropertyNameSuffix(startElement.getAttributeByName(new QName(XmlTagConstants.NAME)).getValue());
		                break;		  
	            	
	            	case XmlTagConstants.NUMBER_VALUE:
	            		 event = eventReader.nextEvent();
	            		 objectPropertyMap.put(propertyKey, getBitMappedValue(propertyKey, event.asCharacters().getData()));
		            	 break;
		            	 
	            	case XmlTagConstants.BOOLEAN_VALUE:
	            		 event = eventReader.nextEvent();
	            		 objectPropertyMap.put(propertyKey, event.asCharacters().getData());
		            	 break;
		            
	            	case XmlTagConstants.STRING_VALUE:
	            		 event = eventReader.nextEvent();
	            		 objectPropertyMap.put(propertyKey, event.asCharacters().getData());
		            	 break;
		            	 		 
	            	/*case XREF:
	            		 event = eventReader.nextEvent();
	            		 linkValue.setXref(event.asCharacters().getData());
		            	 break;*/
		            	 
	            	case XmlTagConstants.XID:
	            		 event = eventReader.nextEvent();
	            		 objectPropertyMap.put(propertyKey, event.asCharacters().getData());
		            	 break;
		            	 	            	           	 
	            	case XmlTagConstants.OBJECT:
	            		 
	            		 StartElement subObjectStartElement = event.asStartElement();
	            		 String subObjectName = removeObjectNameSuffix(subObjectStartElement.getAttributeByName(new QName(XmlTagConstants.CLASS)).getValue());
	            		 
	            		 if(CasmConstants.REALM.equals(subObjectName)) {
	            			 Realm realm = (Realm)parseObject(eventReader, event, subObjectName);
	            			 Domain domain = (Domain)genObject;
	            			 domain.getRealms().add(realm);
	            		 } else if (CasmConstants.RESPONSE.equals(subObjectName)) {
	            			 Response response = (Response)parseObject(eventReader, event, subObjectName);
	            			 Domain domain = (Domain)genObject;
	            			 domain.getResponses().add(response);
	            		 } else if (CasmConstants.POLICY.equals(subObjectName)) {
	            			 Policy policy = (Policy)parseObject(eventReader, event, subObjectName);
	            			 Domain domain = (Domain)genObject;
	            			 domain.getPolicies().add(policy);
	            		 } else if (CasmConstants.RESPONSE_ATTR.equals(subObjectName)) {
	            			 ResponseAttr responseAttr = (ResponseAttr)parseObject(eventReader, event, subObjectName);
	            			 Response response = (Response)genObject;
	            			 response.getResponseAttributes().add(responseAttr);
	            		 }
		            	 break;
  
	            	default: continue;	            		
	            }	                            
	    	} else if (event.isEndElement()) {
	    		
	            EndElement endElement = event.asEndElement();
	            String tagName = endElement.getName().getLocalPart();
	            
	            if (tagName.equals(XmlTagConstants.OBJECT)) {
	            	genObject.setProperties(objectPropertyMap);  	
	            	break;
	            }      	            
	        }
        }     	
        return genObject;
     }
	

	private String getBitMappedValue(String propertyKeyName, String keyNumericValueString) {
		
		if(XmlTagConstants.DOMAIN_MODE.equals(propertyKeyName) && null != keyNumericValueString) {
			 return BitMappingEnum.DOMAIN_MODE.getBitMapValue(Integer.parseInt(keyNumericValueString));
		 }
		return keyNumericValueString;
	}

	
	private CasmGenericObject getObjectInstance(String objectName) {
		
		CasmGenericObject genObject = null;
		
		if(CasmConstants.DOMAIN.equals(objectName)) {
			genObject = new Domain();
		} else if(CasmConstants.REALM.equals(objectName)) {
			genObject = new Realm();
		} else if(CasmConstants.RESPONSE.equals(objectName)) {
			genObject = new Response();
		} else if(CasmConstants.POLICY.equals(objectName)) {
			genObject = new Policy();
		} else if(CasmConstants.RESPONSE_ATTR.equals(objectName)) {
			genObject = new ResponseAttr();
		}
		return genObject;
	}
	
}
