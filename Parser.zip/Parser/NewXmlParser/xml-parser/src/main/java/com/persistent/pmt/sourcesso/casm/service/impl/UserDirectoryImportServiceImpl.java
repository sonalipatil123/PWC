package com.persistent.pmt.sourcesso.casm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.persistent.pmt.sourcesso.generic.exception.GenericException;
import com.persistent.pmt.sourcesso.generic.reader.GenericReader;
import com.persistent.pmt.sourcesso.generic.response.GenericResponse;
import com.persistent.pmt.sourcesso.generic.service.DataImportService;

@Service("userDirectoryImportService")
public class UserDirectoryImportServiceImpl implements DataImportService {

	@Autowired
	@Qualifier("userDirectoryReader")
	GenericReader genericReader;

	@Override
	public GenericResponse importData() throws GenericException {
		
		
		//TODO Implement parallel processing of parallel objects to Domain like Agent, User Directory etc.
		
		return genericReader.readAndSaveData();
			
	}


}
