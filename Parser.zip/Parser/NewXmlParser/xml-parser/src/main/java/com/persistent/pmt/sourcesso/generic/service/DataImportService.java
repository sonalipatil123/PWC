package com.persistent.pmt.sourcesso.generic.service;

import com.persistent.pmt.sourcesso.generic.exception.GenericException;
import com.persistent.pmt.sourcesso.generic.response.GenericResponse;

/**
 * @author shishir_kumar
 *
 */
public interface DataImportService {

	/**
	 * @return generic Response which has requested source data.
	 * @throws GenericException
	 */
	public GenericResponse importData() throws GenericException;
		
}
