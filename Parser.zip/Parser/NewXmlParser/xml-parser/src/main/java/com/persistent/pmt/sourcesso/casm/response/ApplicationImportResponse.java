package com.persistent.pmt.sourcesso.casm.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.sourcesso.casm.model.Domain;
import com.persistent.pmt.sourcesso.generic.response.GenericResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationImportResponse extends GenericResponse {

	private List<Domain> domainList;

	public List<Domain> getDomainList() {
		return domainList;
	}

	public void setDomainList(List<Domain> domainList) {
		this.domainList = domainList;
	}
	
	
}
