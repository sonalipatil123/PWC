package com.persistent.pmt.sourcesso.casm.model;

//Parallel Object
public class Agent extends CasmGenericObject {
	
	private AgentType agentType;
		
}
