package com.persistent.pmt.sourcesso.casm.mapper.impl;

import com.persistent.pmt.sourcesso.casm.mapper.AbstractXmlMapper;

public class DomainMapper extends AbstractXmlMapper {

}
