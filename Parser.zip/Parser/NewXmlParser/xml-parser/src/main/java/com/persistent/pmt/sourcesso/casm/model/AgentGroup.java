package com.persistent.pmt.sourcesso.casm.model;

public class AgentGroup extends CasmGenericObject {

}
