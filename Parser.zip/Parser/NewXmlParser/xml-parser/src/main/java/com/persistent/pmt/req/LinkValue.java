package com.persistent.pmt.req;

public class LinkValue
{
    private String XREF;
    private String XID;

    public String getXID() {
		return XID;
	}

	public void setXID(String xID) {
		XID = xID;
	}

	public String getXREF ()
    {
        return XREF;
    }

    public void setXREF (String XREF)
    {
        this.XREF = XREF;
    }

    @Override
    public String toString()
    {
        return "UserDirectory [XREF = "+XREF+"]";
    }
}
		