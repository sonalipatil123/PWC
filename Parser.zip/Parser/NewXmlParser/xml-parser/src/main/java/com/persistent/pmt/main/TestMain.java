package com.persistent.pmt.main;

import com.persistent.pmt.sourcesso.casm.service.impl.ApplicationImportServiceImpl;
import com.persistent.pmt.sourcesso.casm.service.impl.UserDirectoryImportServiceImpl;
import com.persistent.pmt.sourcesso.generic.response.GenericResponse;

public class TestMain {



	public static void main(String[] args) throws Exception{

		//ApplicationImportServiceImpl as=new ApplicationImportServiceImpl();
		
		UserDirectoryImportServiceImpl ud=new UserDirectoryImportServiceImpl();
		
		
		
		ud.importData();
		


	}

}
