package com.persistent.pmt.sourcesso.casm.reader.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.springframework.stereotype.Component;

import com.persistent.pmt.sourcesso.casm.constant.BitMappingEnum;
import com.persistent.pmt.sourcesso.casm.constant.CasmConstants;
import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.casm.model.Domain;
import com.persistent.pmt.sourcesso.casm.model.Policy;
import com.persistent.pmt.sourcesso.casm.model.Realm;
import com.persistent.pmt.sourcesso.casm.model.Response;
import com.persistent.pmt.sourcesso.casm.model.ResponseAttr;
import com.persistent.pmt.sourcesso.casm.model.UserDirectory;
import com.persistent.pmt.sourcesso.casm.reader.AbstractXmlReader;
import com.persistent.pmt.sourcesso.casm.response.ApplicationImportResponse;
import com.persistent.pmt.sourcesso.casm.response.UserDirectoryImportResponse;
import com.persistent.pmt.sourcesso.generic.exception.GenericException;
import com.persistent.pmt.sourcesso.generic.response.GenericResponse;

@Component
public class UserDirectoryReader extends AbstractXmlReader {

	
	@Override
	public GenericResponse readData() {
		
		return null;
	}

	@Override
	public GenericResponse readAndSaveData() throws GenericException {
				

		//ApplicationImportResponse response = new ApplicationImportResponse();
		//response.setDomainList(getDomainList());
		
		System.out.println("read&save");
		 UserDirectoryImportResponse response = new UserDirectoryImportResponse();
		 response.setUserDirectoryList(getUserDirectoryList());
		
		
		 
		return response;
	}
	
	private List<UserDirectory> getUserDirectoryList() throws GenericException {
						
		XMLEventReader eventReader = getEventReader("UserDirectory.xml");		
		List<UserDirectory> userDirectoryList = new ArrayList<>();
		UserDirectory userDirectoryObject;
        
        try {
        	
           while (eventReader.hasNext()) {
           	
               XMLEvent event = eventReader.nextEvent();               
               if (event.isStartElement()) {
                   StartElement startElement = event.asStartElement();
                   String tagName = startElement.getName().getLocalPart();
                                    
                   if (tagName.equals(XmlTagConstants.OBJECT)) {
                   	
                	   userDirectoryObject = (UserDirectory)parseObject(eventReader, event, CasmConstants.USERDIRECTORY);
                	   userDirectoryList.add(userDirectoryObject);
                   }               
               }
               // If we reach the end of an item element, we add it to the list
               if (event.isEndElement()) {
                   EndElement endElement = event.asEndElement();
                   String tagName = endElement.getName().getLocalPart();
                   
                    if (tagName.equals(XmlTagConstants.OBJECT)) {                    	
                    	continue;
                    }               
               }
             }
	      } catch (XMLStreamException e) {
	          throw new GenericException("File Input Stream Error ", e);
	      } 
	       return userDirectoryList;
		}		


	private CasmGenericObject parseObject(XMLEventReader eventReader, XMLEvent currectEvent, String objectName) throws XMLStreamException {
 	
		//CasmGenericObject genObject = getObjectInstance(objectName);
		
		UserDirectory usrDirObj=new UserDirectory();
		Map<String, String> objectPropertyMap = new HashMap<>();
		String propertyKey = null;
		
	 	StartElement firstElement = currectEvent.asStartElement();	 	
	 	usrDirObj.setxId(removeXidSuffix(firstElement.getAttributeByName(new QName(XmlTagConstants.Xid)).getValue()));
 	
        while(eventReader.hasNext()) {
 		
        	XMLEvent event = eventReader.nextEvent();
	    	if (event.isStartElement()) {
	            StartElement startElement = event.asStartElement();
	            String tagName = startElement.getName().getLocalPart();
	            
	            switch(tagName) {
	            
	            	case XmlTagConstants.PROPERTY: 
	            		propertyKey = removePropertyNameSuffix(startElement.getAttributeByName(new QName(XmlTagConstants.NAME)).getValue());
		                break;		  
	            	
	            	case XmlTagConstants.NUMBER_VALUE:
	            		 event = eventReader.nextEvent();
	            		// objectPropertyMap.put(propertyKey, getBitMappedValue(propertyKey, event.asCharacters().getData()));
		            	 break;
		            	 
	            	case XmlTagConstants.BOOLEAN_VALUE:
	            		 event = eventReader.nextEvent();
	            		 objectPropertyMap.put(propertyKey, event.asCharacters().getData());
		            	 break;
		            
	            	case XmlTagConstants.STRING_VALUE:
	            		 event = eventReader.nextEvent();
	            		 objectPropertyMap.put(propertyKey, event.asCharacters().getData());
		            	 break;
		            	 		 
	            	/*case XREF:
	            		 event = eventReader.nextEvent();
	            		 linkValue.setXref(event.asCharacters().getData());
		            	 break;*/
		            	 
	            	case XmlTagConstants.XID:
	            		 event = eventReader.nextEvent();
	            		 objectPropertyMap.put(propertyKey, event.asCharacters().getData());
		            	 break;
		            	 	            	           	 
	            	case XmlTagConstants.OBJECT:
	            		 
	            		 break;
  
	            	default: continue;	            		
	            }	                            
	    	} else if (event.isEndElement()) {
	    		
	            EndElement endElement = event.asEndElement();
	            String tagName = endElement.getName().getLocalPart();
	            
	            if (tagName.equals(XmlTagConstants.OBJECT)) {
	            	usrDirObj.setProperties(objectPropertyMap);  	
	            	break;
	            }      	            
	        }
        }     	
        return usrDirObj;
     }
	
/*
	private String getBitMappedValue(String propertyKeyName, String keyNumericValueString) {
		
		if(XmlTagConstants.DOMAIN_MODE.equals(propertyKeyName) && null != keyNumericValueString) {
			 return BitMappingEnum.DOMAIN_MODE.getBitMapValue(Integer.parseInt(keyNumericValueString));
		 }
		return keyNumericValueString;
	}*/

	
	
}
