package com.persistent.pmt.sourcesso.casm.model.cds;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Certificate {

	private String xId;
	private Map<String, String> properties;
	
	public String getxId() {
		return xId;
	}
	public void setxId(String xId) {
		this.xId = xId;
	}
	public Map<String, String> getProperties() {
		return properties;
	}
	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}
		
}
