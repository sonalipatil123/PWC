package com.persistent.pmt.sourcesso.generic.constant;

public class PmtConstants {

}
