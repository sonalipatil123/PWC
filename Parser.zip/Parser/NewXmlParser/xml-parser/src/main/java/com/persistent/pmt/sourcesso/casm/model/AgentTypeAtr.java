package com.persistent.pmt.sourcesso.casm.model;

public class AgentTypeAtr extends CasmGenericObject {

}
