package com.persistent.pmt.sourcesso.casm.model;

import java.util.ArrayList;
import java.util.List;

import com.persistent.pmt.req.Property;



//Parallel Object
public class UserDirectory extends CasmGenericObject {

	private List<Property> propertyList = new ArrayList<>();
	//private List<UserDirectory> subObjectList = new ArrayList<>();
   

public List<Property> getPropertyList() {
	
	return propertyList;
}
/*
public List<UserDirectory> getSubObjectList() {
	
	return subObjectList;
}*/

@Override
public String toString() {
	/*return "UserDirObject " + super.toString() + " [propertyList=" + propertyList
			+ ", subObjectList=" + subObjectList + "]";
	*/
	return "UserDirObject " + super.toString() + " [propertyList=" + propertyList
			+  "]";
}



	
}
