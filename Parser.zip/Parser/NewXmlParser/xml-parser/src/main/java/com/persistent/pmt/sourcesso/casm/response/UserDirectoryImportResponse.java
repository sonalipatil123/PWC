package com.persistent.pmt.sourcesso.casm.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.sourcesso.casm.model.UserDirectory;
import com.persistent.pmt.sourcesso.generic.response.GenericResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserDirectoryImportResponse extends GenericResponse {

	private List<UserDirectory> userDirectoryList;

	
	public List<UserDirectory> getUserDirectoryList() {
		return userDirectoryList;
	}

	public void setUserDirectoryList(List<UserDirectory> userDirectoryList) {
		this.userDirectoryList = userDirectoryList;
	}

	
	
}

