package com.persistent.pmt.sourcesso.casm.model;

import java.util.List;

public class AgentType extends CasmGenericObject {

	private List<AgentTypeAtr> agentTypeAttrList;

	public List<AgentTypeAtr> getAgentTypeAttrList() {
		return agentTypeAttrList;
	}

	public void setAgentTypeAttrList(List<AgentTypeAtr> agentTypeAttrList) {
		this.agentTypeAttrList = agentTypeAttrList;
	}
	
	
}
