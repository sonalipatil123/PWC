package com.persistent.pmt.sourcesso.casm.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Response extends CasmGenericObject {
	
	private List<ResponseAttr> responseAttributes = new ArrayList<>();

	public List<ResponseAttr> getResponseAttributes() {
		return responseAttributes;
	}

	public void setResponseAttributes(List<ResponseAttr> responseAttributes) {
		this.responseAttributes = responseAttributes;
	}

	
}
