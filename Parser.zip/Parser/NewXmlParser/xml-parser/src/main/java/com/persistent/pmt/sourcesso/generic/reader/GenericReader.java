package com.persistent.pmt.sourcesso.generic.reader;

import com.persistent.pmt.sourcesso.generic.exception.GenericException;
import com.persistent.pmt.sourcesso.generic.response.GenericResponse;


public interface GenericReader {
	
	public GenericResponse readData() throws GenericException;
	public GenericResponse readAndSaveData() throws GenericException;
	
}
