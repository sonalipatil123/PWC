package com.persistent.pmt.sourcesso.casm.model;

//Parallel Object
public class AuthScheme {

}
