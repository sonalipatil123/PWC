package com.persistent.pmt.sourcesso.casm.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;

import org.apache.commons.net.ftp.FTPSClient;

import com.persistent.pmt.sourcesso.casm.constant.XmlTagConstants;
import com.persistent.pmt.sourcesso.casm.model.CasmGenericObject;
import com.persistent.pmt.sourcesso.generic.exception.GenericException;
import com.persistent.pmt.sourcesso.generic.reader.GenericReader;

public abstract class AbstractXmlReader implements GenericReader {

	//public abstract List<? extends CasmGenericObject> fetchObjectList() throws GenericException;
	
	protected XMLEventReader getEventReader(String inputFile) throws GenericException {
		
		XMLEventReader eventReader = null;
		try {
			
			
			/*File file = new File("source-config.properties");
			FileInputStream fileInput = new FileInputStream(file);
			Properties properties = new Properties();
			properties.load(fileInput);
			fileInput.close();*/			
			XMLInputFactory inputFactory = XMLInputFactory.newInstance();
			File file = new File("D:/UserDirectory.xml");
	        InputStream in = new FileInputStream(file);
	        
	        
		//	InputStream in = getFile("pt-dgtora3820", "oracle", "Welcome1", "/OAM/siteminder/bigfile", "CA.SM::Domain");
	        
	        eventReader = inputFactory.createXMLEventReader(in);  // close this after use
	        
		} catch(XMLStreamException | IOException e) {
			throw new GenericException("Error while reading source XML file: " + inputFile, e);
		}		         
         return eventReader;
	}
	
	
	
	  private FileInputStream getFile(String server, String username, String password, String folder, String fname) 
			  throws IOException {
	    
		  	         
	        FTPSClient ftps = null;
	        FileInputStream fin = null;

	            ftps = new FTPSClient();
	             
	            ftps.connect(server, 22);
	            ftps.login( username, password );	             
	            ftps.changeWorkingDirectory(folder);
	             
	            File file = new File(fname);
	            fin = new FileInputStream(file);
 	         
	        return fin;
	    }
	     
	  
		protected String removeXidSuffix(String fullXid) {
			
			String[] splitString = fullXid.split(XmlTagConstants.XID_SPLIT_CHAR);
			return splitString[1];
		}
		
		//removes Name suffix for object's properties like CA.SM::Domain.Name
		protected String removePropertyNameSuffix(String propertyName) {
			
			String[] splitString = propertyName.split(XmlTagConstants.PROPERTY_NAME_SPLIT_CHAR);			
			return splitString[splitString.length - 1];
		}
		
		//removes Name suffix for object's properties like CA.SM::Domain.Name
		protected String removeObjectNameSuffix(String className) {
			
			String[] splitString = className.split(XmlTagConstants.OBJECT_NAME_SPLIT_CHAR);			
			return splitString[splitString.length - 1];
		}		
		
	}
