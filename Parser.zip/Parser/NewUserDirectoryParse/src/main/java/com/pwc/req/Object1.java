package com.pwc.req;

import java.util.ArrayList;
import java.util.List;

import com.pwc.pojo.UserDirectory;
import com.pwc.model.AbstractTag;
import com.pwc.req.Property;
public class Object1 //extends AbstractTag
{
    private String ExportType;

    private String ClassName;

    private String CreatedDateTime;

    private String ModifiedDateTime;

    private String UpdateMethod;

    private String UpdatedBy;

    private List<Property> propertylist=new ArrayList<Property>();
    private List<Object1> subObjList=new ArrayList<Object1>();


    public String getExportType ()
    {
        return ExportType;
    }

    public void setExportType (String ExportType)
    {
        this.ExportType = ExportType;
    }

  

    public String getCreatedDateTime ()
    {
        return CreatedDateTime;
    }

    public void setCreatedDateTime (String CreatedDateTime)
    {
        this.CreatedDateTime = CreatedDateTime;
    }

    public String getModifiedDateTime ()
    {
        return ModifiedDateTime;
    }

    public void setModifiedDateTime (String ModifiedDateTime)
    {
        this.ModifiedDateTime = ModifiedDateTime;
    }

    public String getUpdateMethod ()
    {
        return UpdateMethod;
    }

    public void setUpdateMethod (String UpdateMethod)
    {
        this.UpdateMethod = UpdateMethod;
    }

    public String getUpdatedBy ()
    {
        return UpdatedBy;
    }

    public void setUpdatedBy (String UpdatedBy)
    {
        this.UpdatedBy = UpdatedBy;
    }

    	  
    public List<Property> getPropertylist() {
		return propertylist;
	}

	public void setPropertylist(List<Property> propertylist) {
		this.propertylist = propertylist;
	}

	
	public String getClassName() {
		return ClassName;
	}

	public void setClassName(String className) {
		ClassName = className;
	}

	

	public List<Object1> getSubObjectList() {
		// TODO Auto-generated method stub
		return subObjList;
	}

	@Override
	public String toString() {
	/*	return "Object1 [ExportType=" + ExportType + ", ClassName=" + ClassName + ", CreatedDateTime=" + CreatedDateTime
				+ ", ModifiedDateTime=" + ModifiedDateTime + ", UpdateMethod=" + UpdateMethod + ", UpdatedBy="
				+ UpdatedBy + ", propertylist=" + propertylist + ", subObjList=" + subObjList + ", getAttributes()="
				+ getAttributes() + ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + "]";*/
		
		/*return "Object1 " + super.toString() + " [propertyList=" + propertylist
				+ ", subObjectList=" + subObjList  +"]";*/
		return super.toString();
	}

	/*@Override
	public String toString() {
		return "Object [ExportType=" + ExportType + ", ClassName=" + ClassName + ", CreatedDateTime=" + CreatedDateTime
				+ ", ModifiedDateTime=" + ModifiedDateTime + ", UpdateMethod=" + UpdateMethod + ", UpdatedBy="
				+ UpdatedBy + ", propertylist=" + propertylist + ", subObjList=" + subObjList + "]";
	}*/
	
	
	
}
			
			