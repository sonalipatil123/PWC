package com.pwc.main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.List;

import com.pwc.pojo.UserDirectory;
import com.pwc.parser.UserDirParser;





public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		
		long startTime = System.currentTimeMillis();
		UserDirParser parser = new UserDirParser();
		
		//List<GenericObject> userDirObjectList = parser.getObjects("UserDirectory.xml");
		
		List<UserDirectory> userDirObjectList = parser.getObjects("UserDirectory.xml");
		int i=0;
		/*for(Object1 object : userDirObjectList) {
			System.out.println(object);
			System.out.println("i="+i);
			i++;
		}*/
		
		PrintStream o = new PrintStream(new File("log.txt"));
		System.setOut(o);
		
		for(Object object : userDirObjectList) {
			System.out.println(object);
		//	System.out.println("i="+i);
		//i++;
		}
	
        
		long endTime = System.currentTimeMillis();
		long timeTaken = endTime - startTime;
		
		System.out.println("Total time in seconds: " + timeTaken/1000);

}
	
}
