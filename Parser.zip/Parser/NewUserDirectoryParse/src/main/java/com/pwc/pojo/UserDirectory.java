package com.pwc.pojo;

import java.util.ArrayList;
import java.util.List;
import com.pwc.req.Object1;



import com.pwc.model.AbstractTag;
import com.pwc.req.Property;

public class UserDirectory extends  AbstractTag{
	private List<Property> propertyList = new ArrayList<>();
	private List<UserDirectory> subObjectList = new ArrayList<>();
    

public List<Property> getPropertyList() {
	
	return propertyList;
}

public List<UserDirectory> getSubObjectList() {
	
	return subObjectList;
}

@Override
public String toString() {
	return "UserDirObject " + super.toString() + " [propertyList=" + propertyList
			+ ", subObjectList=" + subObjectList + "]";
}





}



