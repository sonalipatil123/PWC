package com.pwc.parser;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import com.pwc.pojo.UserDirectory;
import com.pwc.req.LinkValue;
import com.pwc.req.Property;


public class UserDirParser {
	//static final String POLICY_DATA = "PolicyData";
   // static final String REFERENCES = "References";
   // static final String REFERENCE_VALUE = "ReferenceValue";
   static final String STRING_VALUE = "StringValue";
    static final String OBJECT = "Object";
    static final String PROPERTY = "Property";
    static final String LINK_VALUE = "LinkValue";
    static final String XID = "XID";
    static final String XREF = "xref";
    static final String NUMBER_VALUE = "NumberValue";
    static final String BOOLEAN_VALUE = "BooleanValue";
	
    
    @SuppressWarnings({ "unchecked", "restriction" })
    public List<UserDirectory> getObjects(String configFile) {
    	
    	
    	//System.out.println(configFile);
    	// List<GenericObject> objectList = new ArrayList<>();
    	 List<UserDirectory> objectList = new ArrayList<>();
    	 int counter = 0;
    	 UserDirectory UserDirObject;
         
        try {
            // First, create a new XMLInputFactory
            XMLInputFactory inputFactory = XMLInputFactory.newInstance();
            // Setup a new eventReader
            InputStream in = new FileInputStream(configFile);
            XMLEventReader eventReader = inputFactory.createXMLEventReader(in);
            // read the XML document          
                    
            while (eventReader.hasNext()) {
            	
                XMLEvent event = eventReader.nextEvent();
                
                if (event.isStartElement()) {
                    StartElement startElement = event.asStartElement();
                    String tagName = startElement.getName().getLocalPart();
                                
                    if (tagName.equals(OBJECT)) {
                    	
                    	UserDirObject = parseObject(eventReader, event);
                    	
                       // System.out.println("UsedirObj="+UserDirObject);

                    	objectList.add(UserDirObject);
                    	counter++;
                    }               
                }
                // If we reach the end of an item element, we add it to the list
                if (event.isEndElement()) {
                    EndElement endElement = event.asEndElement();
                    String tagName = endElement.getName().getLocalPart();
                    
                     if (tagName.equals(OBJECT)) {                    	
                    	continue;
                    }               
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (XMLStreamException e) {
            e.printStackTrace();
        } 
        System.out.println("Number of Objects: " + counter);
        return objectList;
    }
    
    
    @SuppressWarnings({ "unchecked" })
	private UserDirectory parseObject(XMLEventReader eventReader, XMLEvent currectEvent) throws XMLStreamException {
    	
    	UserDirectory UserDirObject = new UserDirectory();
    	Property property = new Property();
    	LinkValue linkValue = new LinkValue();
    	StartElement firstElement = currectEvent.asStartElement();
    	
    	 Iterator<Attribute> objectAttributes = firstElement.getAttributes();
         while (objectAttributes.hasNext()) {
             Attribute objectAttribute = objectAttributes.next();
            // System.out.println("objAttr:"+objectAttribute);
             UserDirObject.getAttributes().put(objectAttribute.getName().toString(), objectAttribute.getValue());
         }  
    	
         while(eventReader.hasNext()) {
    		
    		XMLEvent event = eventReader.nextEvent();
	    	if (event.isStartElement()) {
	            StartElement startElement = event.asStartElement();  //Returns this event as a start element event, may result in a class cast exception if this event is not a start element.

	            String tagName = startElement.getName().getLocalPart();
	            
	            switch(tagName) {
	            
	            	case PROPERTY: 
	            		property = new Property();
		                Iterator<Attribute> attributes = startElement.getAttributes();
		                while (attributes.hasNext()) {
		                    Attribute attribute = attributes.next();
		                    property.getAttributes().put(attribute.getName().toString(), attribute.getValue());
		                } 
		                break;
		            
	            	case LINK_VALUE:
	            		 linkValue = new LinkValue();   
	            		 break;
	            	
	            	case NUMBER_VALUE:
	            		 event = eventReader.nextEvent();
		            	 property.setNumberValue(event.asCharacters().getData());
		            	 break;
		            	 
	            	case BOOLEAN_VALUE:
	            		 event = eventReader.nextEvent();
		            	 property.setBooleanValue(event.asCharacters().getData());
		            	 break;
		            
	            	case STRING_VALUE:
	            		 event = eventReader.nextEvent();
		            	 property.setStringValue(event.asCharacters().getData());
		            	 break;
		            	 		 
	            	case XREF:
	            		 event = eventReader.nextEvent();
	            		 linkValue.setXREF(event.asCharacters().getData());
		            	 break;
		            	 
	            	case XID:
	            		 event = eventReader.nextEvent();
	            		 linkValue.setXID(event.asCharacters().getData());
		            	 break;
		            	 	            	           	 
	            	case OBJECT:
	            		UserDirectory subObject = parseObject(eventReader, event);
	            		 UserDirObject.getSubObjectList().add(subObject);
		            	 break;
     
	            	default: continue;	            		
	            }	                            
	    	} else if (event.isEndElement()) {
	    		
	            EndElement endElement = event.asEndElement();
	            String tagName = endElement.getName().getLocalPart();
	            
	            if (tagName.equals(PROPERTY)) {
	            	UserDirObject.getPropertyList().add(property);                   	
	            }
	            else if (tagName.equals(LINK_VALUE)) {
	            	property.setLinkValue(linkValue);                   	
	            }
	            else if (tagName.equals(OBJECT)) {
	            	break;	            	
	            }                
	        }
    	}     	
    	return UserDirObject;
    }
}
