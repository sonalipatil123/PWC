package com.pwc.XmlUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Map;

import com.pwc.tokenresolver.MapTokenResolver;
import com.pwc.tokenresolver.TokenReplacingReader;

public class XmlSourceGenerator {

	public String generateXmlSource(Map<String, String> tokenMap, String metadataTemplateName) {
		MapTokenResolver resolver = new MapTokenResolver(tokenMap);
		Reader source = getSource(metadataTemplateName, resolver);
		Reader reader = new TokenReplacingReader(source, resolver);
		String xmlSource = buildXmlSource(reader);
				
		return xmlSource;
	}
	
	public String generateXmlSource(ArrayList<Map<String, String>> tokenList, String metadataTemplateName) {
		String xmlSource = "";
		for (Map<String, String> tokenMap : tokenList) {
			xmlSource += generateXmlSource(tokenMap, metadataTemplateName);
		}
		return xmlSource;
	}

	private String buildXmlSource(Reader reader) {
		int data = -1;
		String xmlSource = "";
		
		try {
			data = reader.read();
			while (data != -1) {
				xmlSource += (char) data;
				data = reader.read();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return xmlSource;
	}

	private Reader getSource(String metadataTemplateName, MapTokenResolver resolver) {
		Reader source = null;
		try {
			source = new TokenReplacingReader(new FileReader(new File(metadataTemplateName)), resolver);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return source;
	}
}
