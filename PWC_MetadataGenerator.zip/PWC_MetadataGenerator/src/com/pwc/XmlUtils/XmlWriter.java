package com.pwc.XmlUtils;

import java.io.FileWriter;
import java.io.IOException;

public class XmlWriter {

	public static void stringToDom(String xmlSource, String fileName) {
	    FileWriter fw = null;
		try {
			fw = new FileWriter(fileName);
		    fw.write(xmlSource);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
		    try {
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
