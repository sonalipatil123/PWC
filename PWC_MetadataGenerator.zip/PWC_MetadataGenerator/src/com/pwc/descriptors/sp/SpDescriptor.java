package com.pwc.descriptors.sp;

import java.util.HashMap;
import java.util.Map;

import com.pwc.XmlUtils.XmlSourceGenerator;
import com.pwc.descriptors.core.Descriptor;

public class SpDescriptor implements Descriptor {

	public String getData() {
		String metadataTemplateName = "d:\\pwc\\SP_SSO_Descriptor_Template.xml";
		
		XmlSourceGenerator xmlSourceGenerator = new XmlSourceGenerator();
		String xmlSource = xmlSourceGenerator.generateXmlSource(getSpTokenMap(), metadataTemplateName);
		return xmlSource;
	}

	private Map<String, String> getSpTokenMap() {
		Map<String, String> tokenMap = new HashMap<String, String>();
		tokenMap.put("wantAssertionsSigned", "true");
		tokenMap.put("encryptionCertificate", "MIIC6jCCAdKgAwIBAgIQOzF2gaB0tLBM208wK5cFxzANBgkqhkiG9w0BAQsFADAxMS8wLQYDVQQDEyZBREZTIEVuY3J5cHRpb24gLSBzc28ucGVyc2lzdGVudC5jby5pbjAeFw0xNTA4MjYxMzEzMzBaFw0yMDA4MjYxMzEzMzBaMDExLzAtBgNVBAMTJkFERlMgRW5jcnlwdGlvbiAtIHNzby5wZXJzaXN0ZW50LmNvLmluMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4q6yQ9OAzrFYPD6Han1FTrrDXe837fwbQVuRzvjOOZTmMojLIaBqJ5DIaRH1qhxs2MHR/hzy4jDRTH42rQ0HRJBwEmw+5X3USbyaUPaJzj8A0r55GPR7cZLtEyN+dIH4UNj9jrA5X/ltvHIUB/jpLEoHGaUHkrx+d8uU2rUU+J68p4mujDxXM0v+aO5TIfn7Twjbxt55CcNUlmJpTKWlrKCkobEPnFYUaod8G+q0YsMtlfkiyW569v02BdJYSmFjdKCQMcnNK3bFLu4t6FEdvagdOX/BRayYdaOLMMNXhENQLlOnwoiZ4Zt0HrdR4FDlKfoonRcxo6Bxe1i8SX7RgwIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQB5wvTK+cRUeriLCz3NJ2NPljk5+cBPz9TdSXndysPthL0zCE9iX292GBMelnOqkjDWnnK2v7Vqp2dmUAnNxlZ3AC6v76KnuHgg17tm9482PeIfeTwh09TYIzHlR2rBfLnI77ouql2iURU6D4s7hw3ltXfg1IbKlY5GcKKjSmggDFAjOC6QNikQTL+yAlsDSNyPSEUxj14+6NKrhS2effJ5/hjI9UzLvN1GV0s6qMh1GaVZPy45YwV+hptu/U6DpST3/rlo3Wp6dN/oz50skbk6YS4kwMeIKQaNC3svvvZn6cYxzb/YwqGvD/YFkPtpsQwwF1KVyyI3JCHcO4jI0uHi");
		tokenMap.put("signingCertificate", "MIIC5DCCAcygAwIBAgIQIZtSMYaYyqZNjkF7JRydljANBgkqhkiG9w0BAQsFADAuMSwwKgYDVQQDEyNBREZTIFNpZ25pbmcgLSBzc28ucGVyc2lzdGVudC5jby5pbjAeFw0xNTA4MjYxMzEzNDJaFw0yMDA4MjYxMzEzNDJaMC4xLDAqBgNVBAMTI0FERlMgU2lnbmluZyAtIHNzby5wZXJzaXN0ZW50LmNvLmluMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyMORP8W15CWfv4vowatWEIgIlzUwud5kvEC4/dBEpkUqFktLe1Jjso+TtkoSStO3ZXXvk4IeCuEJ1ot240maIxBOKHsaVSId+Em9TMLnj1yj1MpSs7Snw3XzmvjCdWA0wfb84fmwmvkz3j2k6QsvNMXpUJKoaUZwJCemRgZMDWD6kHmXLthWgW0VGivyJGqsQe3MB45/T/QgIDHzmKdOTlegZa8Y1wIoRWlsEv5n2tK7NKOYWJ5T1re4NuxrYBofZdNl3MwcnXgul6JgeHCi4teQFjjNn9IF+VndOCvgD8vhNUDpwhtHPoHiheOTd/RFfabH/3Ehvy+84QYAEt3tXQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQCbguFPElwm1HBqX8oiSDcvFPizOLB0BvICs4io9/ZFzFEJQi+FWO2qi5cvzXobTLYGMNSsYGX166Rc+gQOd7rNB2NO+E1PVHIJAXtitSkl3eDS/QqJxK0poRHT1vKTnIcvPJ1i8DRO877WzUUC4kBCQhCnAihXeHRBkGbdXk+zXgDAp4miUDP0ApLD0YcVNv5vT04W+TdZe11MFbPXg6kCsX3yGW4Kg117zUUfaUoKeRu7jyTuKkZEayE7DWlcwEW2Tu84Rfj0DLotQsxOsjYe4/+WxYRejgOfB69KahZJnSaSD0EpfB6m8qP58W1tqPjl7adCebcj4SHroErsV8p3");
		tokenMap.put("redirectLogoutUrl", "https://sso.persistent.co.in/adfs/ls/");
		tokenMap.put("postLogoutUrl", "https://sso.persistent.co.in/adfs/ls/");
		tokenMap.put("postAcsUrl", "https://sso.persistent.co.in/adfs/ls/");
		tokenMap.put("artifactAcsUrl", "https://sso.persistent.co.in/adfs/ls/");
		tokenMap.put("redirectAcsUrl", "https://sso.persistent.co.in/adfs/ls/");
		return tokenMap;
	}
}
