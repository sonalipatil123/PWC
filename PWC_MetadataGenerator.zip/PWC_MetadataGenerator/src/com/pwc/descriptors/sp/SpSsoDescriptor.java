package com.pwc.descriptors.sp;

public class SpSsoDescriptor {
	
}
