package com.pwc.descriptors.entity;

import java.util.Map;

import com.pwc.descriptors.core.Descriptor;
import com.pwc.descriptors.core.DescriptorFactory;

public class EntityDescriptor {
	String metadataID;
	String entityID;
	Descriptor descriptorObj;
	Contacts contactObj;

	public EntityDescriptor(String descriptor) {
		DescriptorFactory descriptorFactory = new DescriptorFactory();
		this.descriptorObj = descriptorFactory.getDescriptor(descriptor);
		this.contactObj = new Contacts();
	}

	public Map<String, String> getEntityDescriptorData(Map<String, String> tokenMap) {

		tokenMap.put("metadataID", "_8bbb7258-c74d-414f-b497-7b4adcb4ff68");
		tokenMap.put("entityID", "http://sso.persistent.co.in/adfs/services/trust");
		tokenMap.put("referenceUri", "#_8bbb7258-c74d-414f-b497-7b4adcb4ff68");
		tokenMap.put("digestValue", "lkGg+7VBkbJA4MBFuwIndAdZReUD5vJcNU39Li8H29Y=");
		//keyDescriptorData
		tokenMap.put("signatureValue", "s2hwFcfnYoCxh45ohk2l1qrkKuQ8ePBGN6sAirfs/S6vH5BXK7RE8Rfm1/vxrHutTn2U3pmbKtiKsILJZLXiEgdHrgOYS0h+MObdEmjPwIGvaq1DvDPmp9Fhdh/EC6jVw24xzutwnrdWSFNCfbHc6Lkyp2WkMZr+VVlSUk0BsIYyUyVtrsIjLpxtdmguyGM0mNtkN82RY/9TvzokAYyPlVSLf4uoHKSy2vyq+2Z9J/w60TqqNWTOIsr+ob/XMiAYuAF8b3eWrnfTkccDsBuSihNeStWhlDyMNU4XKi56N1HE6BLQNEnJkB0I0OzPGKwGYpycIi2CV8Qe+l18zYwx+w==");
		tokenMap.put("certificateValue", "MIIC5DCCAcygAwIBAgIQIZtSMYaYyqZNjkF7JRydljANBgkqhkiG9w0BAQsFADAuMSwwKgYDVQQDEyNBREZTIFNpZ25pbmcgLSBzc28ucGVyc2lzdGVudC5jby5pbjAeFw0xNTA4MjYxMzEzNDJaFw0yMDA4MjYxMzEzNDJaMC4xLDAqBgNVBAMTI0FERlMgU2lnbmluZyAtIHNzby5wZXJzaXN0ZW50LmNvLmluMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyMORP8W15CWfv4vowatWEIgIlzUwud5kvEC4/dBEpkUqFktLe1Jjso+TtkoSStO3ZXXvk4IeCuEJ1ot240maIxBOKHsaVSId+Em9TMLnj1yj1MpSs7Snw3XzmvjCdWA0wfb84fmwmvkz3j2k6QsvNMXpUJKoaUZwJCemRgZMDWD6kHmXLthWgW0VGivyJGqsQe3MB45/T/QgIDHzmKdOTlegZa8Y1wIoRWlsEv5n2tK7NKOYWJ5T1re4NuxrYBofZdNl3MwcnXgul6JgeHCi4teQFjjNn9IF+VndOCvgD8vhNUDpwhtHPoHiheOTd/RFfabH/3Ehvy+84QYAEt3tXQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQCbguFPElwm1HBqX8oiSDcvFPizOLB0BvICs4io9/ZFzFEJQi+FWO2qi5cvzXobTLYGMNSsYGX166Rc+gQOd7rNB2NO+E1PVHIJAXtitSkl3eDS/QqJxK0poRHT1vKTnIcvPJ1i8DRO877WzUUC4kBCQhCnAihXeHRBkGbdXk+zXgDAp4miUDP0ApLD0YcVNv5vT04W+TdZe11MFbPXg6kCsX3yGW4Kg117zUUfaUoKeRu7jyTuKkZEayE7DWlcwEW2Tu84Rfj0DLotQsxOsjYe4/+WxYRejgOfB69KahZJnSaSD0EpfB6m8qP58W1tqPjl7adCebcj4SHroErsV8p3");
		tokenMap.put("descriptorData", getDescriptorData());
		tokenMap.put("organizationName", "Organization Name");
		tokenMap.put("organizationDisplayName", "Organization DisplayName");
		tokenMap.put("organizationUrl", "https://www.orgname.com");
		tokenMap.put("contactPersonData", getContactPersonData());
		return tokenMap;
	}

	private String getContactPersonData() {
		return this.contactObj.getData();
	}

	private String getDescriptorData() {
		return this.descriptorObj.getData();
	}
}
