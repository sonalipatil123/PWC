package com.pwc.descriptors.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.pwc.XmlUtils.XmlSourceGenerator;

public class Contacts {

	public String getData() {
		String metadataTemplateName = "d:\\pwc\\EntityDescriptor_ContactPerson_Iterator_Template.xml";
		
		XmlSourceGenerator xmlSourceGenerator = new XmlSourceGenerator();
		String xmlSource = xmlSourceGenerator.generateXmlSource(getContactPersonTokenList(), metadataTemplateName);
		return xmlSource;
	}

	private ArrayList<Map<String, String>> getContactPersonTokenList() {
		ArrayList<Map<String, String>> tokenList = new ArrayList<Map<String,String>>();
		tokenList.add(setContactData("technical", "Technical", "technical@asdsa.com"));
		tokenList.add(setContactData("support", "Support", "support@asdsa.com"));
		return tokenList;
	}

	private Map<String, String> setContactData(String contactType, String contactName, String contactEmail) {
		Map<String, String> tokenMap = new HashMap<String, String>();
		tokenMap.put("contactType", contactType);
		tokenMap.put("contactName", contactName);
		tokenMap.put("contactEmail", contactEmail);
		return tokenMap;
	}
}
