package com.pwc.descriptors.idp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.pwc.XmlUtils.XmlSourceGenerator;

public class IdpAttribute {

	public String getData() {
		String metadataTemplateName = "d:\\pwc\\IDP_SSO_Descriptor_Attribute_Iterator_Template.xml";
		
		XmlSourceGenerator xmlSourceGenerator = new XmlSourceGenerator();
		String xmlSource = xmlSourceGenerator.generateXmlSource(getIdpAttributeTokenList(), metadataTemplateName);
		return xmlSource;
	}

	private ArrayList<Map<String, String>> getIdpAttributeTokenList() {
		ArrayList<Map<String, String>> tokenList = new ArrayList<Map<String,String>>();
		tokenList.add(setIdpAttributeData("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress", "E-Mail Address"));
		tokenList.add(setIdpAttributeData("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname", "Given Name"));
		tokenList.add(setIdpAttributeData("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name", "Name"));
		tokenList.add(setIdpAttributeData("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn", "UPN"));
		tokenList.add(setIdpAttributeData("http://schemas.microsoft.com/ws/2008/06/identity/claims/role", "Role"));
		return tokenList;
	}

	private Map<String, String> setIdpAttributeData(String assertionAttributeName, String assertionAttributeFriendlyName) {
		Map<String, String> tokenMap = new HashMap<String, String>();
		tokenMap.put("assertionAttributeName", assertionAttributeName);
		tokenMap.put("assertionAttributeFriendlyName", assertionAttributeFriendlyName);
		return tokenMap;
	}

}
