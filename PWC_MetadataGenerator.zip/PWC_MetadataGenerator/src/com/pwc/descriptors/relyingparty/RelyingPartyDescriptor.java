package com.pwc.descriptors.relyingparty;

import com.pwc.descriptors.core.Descriptor;

public class RelyingPartyDescriptor implements Descriptor {

	public String getData() {
		String token = "";
		return token;
	}

}
