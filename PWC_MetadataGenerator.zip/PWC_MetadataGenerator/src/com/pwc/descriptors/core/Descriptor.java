package com.pwc.descriptors.core;

public interface Descriptor {
	public String getData();
}
