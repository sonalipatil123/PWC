package com.pwc.descriptors.core;

import com.pwc.descriptors.claimsprovider.ClaimsProviderDescriptor;
import com.pwc.descriptors.idp.IdpDescriptor;
import com.pwc.descriptors.relyingparty.RelyingPartyDescriptor;
import com.pwc.descriptors.sp.SpDescriptor;

public class DescriptorFactory {

	public Descriptor getDescriptor(String descriptor) {
		if("IdpDescriptor".equalsIgnoreCase(descriptor)) {
			return new IdpDescriptor();
		} else if("SpDescriptor".equalsIgnoreCase(descriptor)) {
			return new SpDescriptor();
		} else if("ClaimsProviderDescriptor".equalsIgnoreCase(descriptor)) {
			return new ClaimsProviderDescriptor();
		} else if("RelyingPartyDescriptor".equalsIgnoreCase(descriptor)) {
			return new RelyingPartyDescriptor();
		}		
		return null;
	}
}
