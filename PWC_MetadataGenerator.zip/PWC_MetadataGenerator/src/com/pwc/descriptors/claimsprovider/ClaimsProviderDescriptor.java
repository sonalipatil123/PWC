package com.pwc.descriptors.claimsprovider;

import com.pwc.descriptors.core.Descriptor;

public class ClaimsProviderDescriptor implements Descriptor {

	public String getData() {
		String token = "";
		return token;
	}

}
