package com.pwc.tokenobject;

import java.util.HashMap;
import java.util.Map;

import com.pwc.descriptors.entity.EntityDescriptor;

public class TokenObjectGenerator {
	Map<String, String> tokenMap = new HashMap<String, String>();
	
	public TokenObjectGenerator(Map<String, String> tokenMap) {
		this.tokenMap = tokenMap;
	}
	
	public Map<String, String> generateTokenObject(String descriptor) {
		EntityDescriptor entityDescriptor = new EntityDescriptor(descriptor);
		return entityDescriptor.getEntityDescriptorData(this.tokenMap);
	}
}
