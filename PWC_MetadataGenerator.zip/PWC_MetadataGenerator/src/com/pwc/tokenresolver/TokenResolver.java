package com.pwc.tokenresolver;

public interface TokenResolver {
	public String resolveToken(String tokenName);
}
