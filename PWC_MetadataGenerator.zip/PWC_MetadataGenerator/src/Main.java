import java.util.HashMap;
import java.util.Map;

import com.pwc.XmlUtils.XmlSourceGenerator;
import com.pwc.XmlUtils.XmlWriter;
import com.pwc.tokenobject.TokenObjectGenerator;

public class Main {

	public static void main(String[] args) {
		String metadataTemplateName = "d:\\pwc\\EntityDescriptor_Template.xml";
		String metadataFileName = "d:\\pwc\\SP_Metadata.xml";
		String descriptor = "SpDescriptor";
		//Options - IdpDescriptor / SpDescriptor / ClaimsProviderDescriptor / RelyingPartyDescriptor
		
		Map<String, String> tokenMap = new HashMap<String, String>();
		TokenObjectGenerator tokenObjectGenerator = new TokenObjectGenerator(tokenMap);
		
		XmlSourceGenerator xmlSourceGenerator = new XmlSourceGenerator();
		String xmlSource = xmlSourceGenerator.generateXmlSource(tokenObjectGenerator.generateTokenObject(descriptor), metadataTemplateName);
		
		XmlWriter.stringToDom(xmlSource, metadataFileName);
	}
}
