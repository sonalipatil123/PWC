package com.persistent.pmt.workflow;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.response.TargetResponse;

public interface ReadOpenAmArtifactWorkflow extends Workflow {

  public TargetResponse read(Object object) throws GenericException;

}
