package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude
public class Attribute {
	private boolean inherited;
	private Object value;

	public Attribute() {
		super();
	}

	public Attribute(boolean inherited, Object value) {
		super();
		this.inherited = inherited;
		this.value = value;
	}

  public Attribute(boolean inherited) {
    super();
    this.inherited = inherited;
  }

	public boolean getInherited() {
		return inherited;
	}

	public void setInherited(boolean inherited) {
		this.inherited = inherited;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

  @Override
  public String toString() {
    return "Attribute [inherited=" + inherited + ", value=" + value + "]";
  }

}
