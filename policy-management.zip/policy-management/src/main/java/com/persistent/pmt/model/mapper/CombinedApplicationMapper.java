package com.persistent.pmt.model.mapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.dao.ApplicationStateDao;
import com.persistent.pmt.dao.EnvironmentDao;
import com.persistent.pmt.model.Agent;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.ApplicationAttributes;
import com.persistent.pmt.model.ApplicationState;
import com.persistent.pmt.model.AuthenticationPolicy;
import com.persistent.pmt.model.AuthenticationScheme;
import com.persistent.pmt.model.AuthorizationPolicy;
import com.persistent.pmt.model.AuthorizationPolicyAttribute;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.model.Resource;
import com.persistent.pmt.model.Response;
import com.persistent.pmt.model.UserDataStore;
import com.persistent.pmt.to.openam.ApplicationCombineTO;
import com.persistent.pmt.to.openam.AuthNPolicyCombineTO;
import com.persistent.pmt.to.openam.AuthZPolicyCombineTO;
import com.persistent.pmt.to.openam.ConditionTO;
import com.persistent.pmt.to.openam.ResourceTO;
import com.persistent.pmt.to.openam.ResponseTO;

@Component
public class CombinedApplicationMapper {

  @Autowired
  ApplicationStateDao applicationStateDao;

  @Autowired
  EnvironmentDao environmentDao;

  public Application getApplicationEntity(ApplicationCombineTO applicationCombineTO) {

    Application application = new Application();

    application.setSourceRawData(applicationCombineTO.getSourceRawData());
    application.setName(applicationCombineTO.getName());
    application.setPepType(PMTConstants.PEP_TYPE_AGENT);
    application.setEnabled(true);
    if(null!=applicationCombineTO.getDescription())
    	 application.setDescription(applicationCombineTO.getDescription());

    Environment env =
        environmentDao.getEnvironmentByName(applicationCombineTO.getEnvironment());
    application.setEnvironment(env);

    // Application Attributes
    Map<String, String> attributesMap = applicationCombineTO.getAttributes();
    List<ApplicationAttributes> appAttributes = new ArrayList<>();
    ApplicationAttributes applicationAttribute;
    if (null != attributesMap) {
      for (String attrName : attributesMap.keySet()) {
        applicationAttribute = new ApplicationAttributes();
        applicationAttribute.setSourceAttrName(attrName);
        applicationAttribute.setSourceAttrValue(attributesMap.get(attrName));
        appAttributes.add(applicationAttribute);
      }
    }
    application.setAttributes(appAttributes);

    List<UserDataStore> userDataStores = new ArrayList<>();
    List<String> userDirectories = applicationCombineTO.getUserDirectoryIds();
    if (null != userDirectories) {
      for (String userDirectoryId : userDirectories) {
        UserDataStore userDataStore = new UserDataStore();
        userDataStore.setId(userDirectoryId);
        userDataStores.add(userDataStore);
      }
    }
    application.setUserDataStores(userDataStores);

    // Agent
    Agent agent = new Agent();
    agent.setId(applicationCombineTO.getAgentId());
    application.setAgent(agent);

    // Application State
    ApplicationState state =
        applicationStateDao.getApplicationStateByName(applicationCombineTO.getState());
    application.setApplicationState(state);

    // Authentication Policy
    List<AuthenticationPolicy> authenticationPolicies = new ArrayList<>();
    AuthenticationPolicy authenticationPolicy = null;
    AuthenticationScheme authScheme;
    List<AuthNPolicyCombineTO> authNPolicyTOList =
        applicationCombineTO.getAuthenticationPolicies();

    int selectedAuthenticationPolicyId = 0;
    if (null != authNPolicyTOList && !authNPolicyTOList.isEmpty()) {
      for (AuthNPolicyCombineTO authNPolicyTO : authNPolicyTOList) {
        if (authNPolicyTO.isSelected()) {
          selectedAuthenticationPolicyId = authNPolicyTO.getId();
          authScheme = new AuthenticationScheme();
          authScheme.setId(authNPolicyTO.getAuthSchemeId());
          authenticationPolicy = new AuthenticationPolicy();
          authenticationPolicy.setAuthenticationScheme(authScheme);
          authenticationPolicy.setName(authNPolicyTO.getName());
          authenticationPolicy.setEnabled(authNPolicyTO.getEnabled());
          authenticationPolicy
              .setAuthenticationLevel(Integer.parseInt(authNPolicyTO.getLevel()));
          authenticationPolicy.setDefaultEntity(true);
          authenticationPolicies.add(authenticationPolicy);
          break;
        }
      }
    }
    application.setAuthenticationPolicies(authenticationPolicies);

    // Authorization Policy
    Map<Integer, AuthorizationPolicy> selectedAuthZPolicies = new HashMap<>();
    Map<String, AuthorizationPolicy> resourceAuthZPolicyName = new HashMap<>();
    List<AuthorizationPolicy> authorizationPolicies = new ArrayList<>();
    AuthorizationPolicy authorizationPolicy = null;
    List<AuthZPolicyCombineTO> authZPolicyTOList =
        applicationCombineTO.getAuthorizationPolicies();

    if (null != authZPolicyTOList && !authZPolicyTOList.isEmpty()) {
      for (AuthZPolicyCombineTO authZPolicyTO : authZPolicyTOList) {
        if (authZPolicyTO.isSelected()) {
          authorizationPolicy = new AuthorizationPolicy();
          authorizationPolicy.setName(authZPolicyTO.getName());
          authorizationPolicy.setEnabled(authZPolicyTO.getEnabled());
          authorizationPolicy.setAuthorizationRule(authZPolicyTO.getAuthorizationRule());

          List<AuthorizationPolicyAttribute> authPolicyAttrs = new ArrayList<>();
          for (ConditionTO conditionTO : authZPolicyTO.getConditions()) {
            AuthorizationPolicyAttribute authAttr = new AuthorizationPolicyAttribute();
            authAttr.setName(conditionTO.getName());
            authAttr.setConditionType(conditionTO.getType());
            authAttr.setConditionValue(conditionTO.getValue());
            authAttr.setNegate(conditionTO.getNegate());
            authPolicyAttrs.add(authAttr);
          }
          authorizationPolicy.setAttributes(authPolicyAttrs);
          authorizationPolicies.add(authorizationPolicy);
          selectedAuthZPolicies.put(authZPolicyTO.getId(), authorizationPolicy);

          for (String resourceId : authZPolicyTO.getResources()) {
            resourceAuthZPolicyName.put(resourceId, authorizationPolicy);
          }
        }
      }
    }
    application.setAuthorizationPolicies(authorizationPolicies);

    // Resources
    List<Resource> resources = new LinkedList<>();
    Resource resource = null;
    List<ResourceTO> resourceToList = applicationCombineTO.getResources();

    if (null != resourceToList && !resourceToList.isEmpty()) {
      for (ResourceTO resourceTo : resourceToList) {
        resource = new Resource();
        resource.setUri(resourceTo.getUri());
        resource.setEnabled(resourceTo.isEnabled());
        resource.setAnonymous(resourceTo.isAnonymous());
        int rootResource = resourceTo.isRootResource() == true ? 1 : 0;
        resource.setRootResource(rootResource);
        resource.setResourceType(resourceTo.getResourceType());
        resource.setHttpMethods(new ArrayList<>(resourceTo.getActions()));

        if (null != authenticationPolicy)
          resource.setAuthenticationPolicy(authenticationPolicy);

        if (null != resourceAuthZPolicyName.get(String.valueOf(resourceTo.getId())))
          resource.setAuthorizationPolicy(resourceAuthZPolicyName.get(String.valueOf(resourceTo
              .getId())));

        resources.add(resource);
      }
    }
    application.setResources(resources);

    // Responses
    List<Response> responses = new ArrayList<>();
    Response response = null;
    List<ResponseTO> responseToList = applicationCombineTO.getResponses();

    if (null != responseToList && !responseToList.isEmpty()) {
      for (ResponseTO responseTO : responseToList) {
        response = new Response();
        if (null != authenticationPolicy && responseTO.getAuthNPolicyId() != 0
            && selectedAuthenticationPolicyId == responseTO.getAuthNPolicyId()) {
          response.setAuthenticationPolicy(authenticationPolicy);
        }
        // validate id clause
        else if (0 != responseTO.getAuthZPolicyId()
            && selectedAuthZPolicies.containsKey(responseTO.getAuthZPolicyId())) {
          response.setAuthorizationPolicy(selectedAuthZPolicies.get(responseTO
              .getAuthZPolicyId()));
        }
        if (null != response.getAuthenticationPolicy()
            || null != response.getAuthorizationPolicy()) {
          response.setName(responseTO.getName());
          response.setType(responseTO.getType());
          response.setValue(responseTO.getValue());
          response.setValueType(responseTO.getValueType());
          response.setDescription(responseTO.getDesc());
          responses.add(response);
        }
      }
    }
    application.setResponses(responses);

    return application;
  }

}
