/**
 * HostIdHelperImpl
 *
 * Helper implementation to fetch Host Identifier
 *
 * @author Abhishek
 */

package com.persistent.pmt.helper.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.naming.directory.SearchControls;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.filter.Filter;
import org.springframework.ldap.filter.LikeFilter;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.helper.UserStoreHelper;
import com.persistent.pmt.model.LdapGroup;
import com.persistent.pmt.model.LdapUser;
import com.persistent.pmt.model.User;
import com.persistent.pmt.model.mapper.LdapGroupMapper;
import com.persistent.pmt.model.mapper.LdapUserMapper;

@Repository
public class UserStoreHelperImpl implements UserStoreHelper {

	@Autowired
	@Qualifier("userLdapTemplate")
	LdapTemplate userLdapTemplate;

	@Autowired
	private Environment environment;

	private static final Logger logger = Logger.getLogger(UserStoreHelperImpl.class);

	public LdapUser getLdapUser(User user) {

		Map<String,String>ldapProperties = getLdapEntityProperties();
		LdapUserMapper userAttrMapper = new LdapUserMapper();
		userAttrMapper.setAttributeName(ldapProperties);

        String[] attributesNeeded = {"uid","givenName","sn","isMemberOf"};
        String returnAttributes = ldapProperties.get(PMTConstants.PROPERTY_LDAP_USER_RETURNATTRIBUTES);
        String userObjectClass = ldapProperties.get(PMTConstants.PROPERTY_LDAP_USER_OBJECTCLASS);
        String loginAttribute = ldapProperties.get(PMTConstants.PROPERTY_LDAP_USER_LOGINATTRIBUTE);

        if(!StringUtils.isEmpty(returnAttributes)) {
        	attributesNeeded = StringUtils.commaDelimitedListToStringArray(returnAttributes);
        }

		SearchControls searchControls = new SearchControls();
		searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        searchControls.setReturningAttributes(attributesNeeded);

		AndFilter filteragent = new AndFilter();
		filteragent.and(new EqualsFilter("objectclass",userObjectClass));
		filteragent.and(new EqualsFilter(loginAttribute, user.getUserName()));



		//GENERIC_PMT
		StringBuilder strBuilder = new StringBuilder("");
		String userStoreBase = strBuilder.toString();

		List<LdapUser> entities = userLdapTemplate.search(userStoreBase, filteragent.encode(), searchControls,
				userAttrMapper);

		if (entities != null && entities.size() > 0) {
			LdapUser ldapUser = (LdapUser) entities.get(0);
			setMemberCN(ldapUser);
			return ldapUser;
		}
		return null;
	}

    public List<LdapUser> getLdapUsers(String userId) {
        Map<String,String>ldapProperties = getLdapEntityProperties();
        String loginAttribute = ldapProperties.get(PMTConstants.PROPERTY_LDAP_USER_LOGINATTRIBUTE);

        return getLdapUsers(userId, new LikeFilter(loginAttribute,"*" + userId + "*"));
    }

    public List<LdapUser> getLdapUsers(String userId, Map<String,String> params) {
        if(params != null && !params.isEmpty()) {
            if (params.get("exact") != null &&
                    "true".equalsIgnoreCase(params.get("exact"))) {
                User user = new User();
                user.setUserName(userId);
                LdapUser u = getLdapUser(user);
                List<LdapUser> userList = new ArrayList<LdapUser>();
                userList.add(u);
                return userList;
            }
        }
        return getLdapUsers(userId);
    }

	public List<LdapUser> getLdapUsers(String userId, Filter filter) {

		logger.info("Entering getLdapUsers");
		List<LdapUser> ldapUserList = new ArrayList<>();
        String[] attributesNeeded = {"uid","givenName","sn","isMemberOf"};

        Map<String,String>ldapProperties = getLdapEntityProperties();
        String returnAttributes = ldapProperties.get(PMTConstants.PROPERTY_LDAP_USER_RETURNATTRIBUTES);
        String userObjectClass = ldapProperties.get(PMTConstants.PROPERTY_LDAP_USER_OBJECTCLASS);
    // String loginAttribute =
    // ldapProperties.get(PMTConstants.PROPERTY_LDAP_USER_LOGINATTRIBUTE);

        if(!StringUtils.isEmpty(returnAttributes)) {
        	attributesNeeded = StringUtils.commaDelimitedListToStringArray(returnAttributes);
        }

        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        searchControls.setReturningAttributes(attributesNeeded);

		AndFilter filteragent = new AndFilter();
        filteragent.and(new EqualsFilter("objectclass",userObjectClass));
		filteragent.and(filter);
		logger.info("filter for getLdapUsers ldap call:" + filteragent);

		//GENERIC_PMT
		StringBuilder strBuilder = new StringBuilder("");
		String userStoreBase = strBuilder.toString();

		LdapUserMapper userAttrMapper = new LdapUserMapper();
		userAttrMapper.setAttributeName(ldapProperties);
		List<LdapUser> entities = userLdapTemplate.search(userStoreBase, filteragent.encode(), searchControls,
				userAttrMapper);

		logger.info("search results : " + entities.size());

		for (LdapUser ldapUser : entities) {
			setMemberCN(ldapUser);
			ldapUserList.add(ldapUser);
		}

		logger.info("Exiting getLdapUsers");
		return ldapUserList;
	}

	private void setMemberCN(LdapUser ldapUser) {
		if (ldapUser.getMemberOf() == null)
			return;

		List<String> cns = new ArrayList<String>();
		String[] members = ldapUser.getMemberOf().split(":");
		for (String member : members) {
			String[] memberDetails = member.split(",");
			for (String memberDet : memberDetails) {
				String[] attr = memberDet.split("=");
				if (attr[0].equalsIgnoreCase("CN")) {
                    cns.add(attr[1]);
                    break; //GENERIC_PMT Quick fix. Inner for loop is not needed.
                }
			}
		}
		ldapUser.setMemberCN(cns);
	}

	@Override
	public List<LdapGroup> getLdapGroups(String groupId) {

		logger.info("Entering getLdapGroups");
		Map<String,String>ldapProperties = getLdapEntityProperties();
		String groupObjectClass = ldapProperties.get(PMTConstants.PROPERTY_LDAP_GROUP_OBJECTCLASS);

		List<LdapGroup> ldapGroupList = new ArrayList<>();
		SearchControls searchControls = new SearchControls();
		searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

		AndFilter filteragent = new AndFilter();
        filteragent.and(new EqualsFilter("objectclass",groupObjectClass));
		filteragent.and(new LikeFilter("cn", "*" + groupId + "*"));
		logger.info("filter for getLdapGroups ldap call:" + filteragent);

		//GENERIC_PMT
		StringBuilder strBuilder = new StringBuilder("");		
		String userStoreBase = strBuilder.toString();

		LdapGroupMapper groupMapper = new LdapGroupMapper();
		groupMapper.setAttributeName(ldapProperties);

		List<LdapGroup> entities = userLdapTemplate.search(userStoreBase, filteragent.encode(), searchControls,
				groupMapper);

		logger.info("search results : " + entities.size());
		for (LdapGroup ldapGroup : entities) {
			setMemberUid(ldapGroup);
			ldapGroupList.add(ldapGroup);

		}

		logger.info("Exiting getLdapGroups");
		return ldapGroupList;

	}

	private void setMemberUid(LdapGroup ldapGroup) {
		if (ldapGroup.getMember() == null)
			return;

		List<String> uids = new ArrayList<String>();
		String[] members = ldapGroup.getMember().split(":");
		for (String member : members) {
			String[] memberDetails = member.split(",");
			for (String memberDet : memberDetails) {
				String[] attr = memberDet.split("=");
				if (attr[0].equalsIgnoreCase("CN"))
					uids.add(attr[1]);
                    break; //GENERIC_PMT Quick fix. Inner for loop is not needed.
			}
		}
		ldapGroup.setMemberUid(uids);

	}

	@Override
	public boolean isLdapUser(String userId) {

		logger.info("Entering isLdapUser");
		boolean flag = false;

        String[] attributesNeeded = {"uid"};
        Map<String,String>ldapProperties = getLdapEntityProperties();
        String userObjectClass = ldapProperties.get(PMTConstants.PROPERTY_LDAP_USER_OBJECTCLASS);
        String loginAttribute = ldapProperties.get(PMTConstants.PROPERTY_LDAP_USER_LOGINATTRIBUTE);


        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        searchControls.setReturningAttributes(attributesNeeded);

		AndFilter filteragent = new AndFilter();
        filteragent.and(new EqualsFilter("objectclass",userObjectClass));
		filteragent.and(new EqualsFilter(loginAttribute, userId));
		logger.info("filter for isLdapUser ldap call:" + filteragent);

		//GENERIC_PMT
		StringBuilder strBuilder = new StringBuilder();
		String userStoreBase = strBuilder.toString();

		LdapUserMapper userMapper = new LdapUserMapper();
		userMapper.setAttributeName(ldapProperties);

		List<LdapUser> entities = userLdapTemplate.search(userStoreBase, filteragent.encode(), searchControls,
				userMapper);

		logger.info("search results : " + entities.size());

		if (entities != null && entities.size() > 0) {
			flag = true;
		}

		logger.info("Exiting isLdapUser");
		return flag;
	}

	@Override
	public boolean authenticate(String userId, String whatyouknow) {
        Map<String,String>ldapProperties = getLdapEntityProperties();
        String userObjectClass = ldapProperties.get(PMTConstants.PROPERTY_LDAP_USER_OBJECTCLASS);
        String loginAttribute = ldapProperties.get(PMTConstants.PROPERTY_LDAP_USER_LOGINATTRIBUTE);

		AndFilter filteragent = new AndFilter();
        filteragent.and(new EqualsFilter("objectclass",userObjectClass));
		filteragent.and(new EqualsFilter(loginAttribute, userId));
		logger.info("filter for isLdapUser ldap call:" + filteragent);

		//search under same base provided in property file.
		StringBuilder strBuilder = new StringBuilder("");
		String userStoreBase = strBuilder.toString();

		return userLdapTemplate.authenticate(userStoreBase, filteragent.encode(), whatyouknow);
	}

	private Map<String,String> getLdapEntityProperties(){
        Map<String,String> ldapprops = new HashMap<>();

		String returnAttributesMap = environment.getProperty(PMTConstants.PROPERTY_LDAP_USER_RETURNATTRIBUTES);
        String userObjectClass = environment.getProperty(PMTConstants.PROPERTY_LDAP_USER_OBJECTCLASS);
        String groupObjectClass = environment.getProperty(PMTConstants.PROPERTY_LDAP_GROUP_OBJECTCLASS);
        String loginAttribute = environment.getProperty(PMTConstants.PROPERTY_LDAP_USER_LOGINATTRIBUTE);
        String returnAttributes = "uid,givenName,sn,isMemberOf";

        if(!StringUtils.isEmpty(returnAttributesMap)) {
        	String [] attributeNameMap = StringUtils.commaDelimitedListToStringArray(returnAttributesMap);
        	Properties namevals= StringUtils.splitArrayElementsIntoProperties(attributeNameMap, "=");
        	returnAttributes = StringUtils.arrayToCommaDelimitedString(namevals.values().toArray(new String[0]));
        	for (final String name: namevals.stringPropertyNames())
        		ldapprops.put(name, namevals.getProperty(name));
        }

        if(StringUtils.isEmpty(userObjectClass)){
        	userObjectClass = "inetorgperson";
        }
        if(StringUtils.isEmpty(groupObjectClass)){
        	groupObjectClass = "groupofuniquenames";
        }
        if(StringUtils.isEmpty(loginAttribute)){
        	loginAttribute = "uid";
        }

        ldapprops.put(PMTConstants.PROPERTY_LDAP_USER_RETURNATTRIBUTES, returnAttributes);
        ldapprops.put(PMTConstants.PROPERTY_LDAP_USER_OBJECTCLASS,userObjectClass);
        ldapprops.put(PMTConstants.PROPERTY_LDAP_GROUP_OBJECTCLASS,groupObjectClass);
        ldapprops.put(PMTConstants.PROPERTY_LDAP_USER_LOGINATTRIBUTE,loginAttribute);
        return ldapprops;
	}

}
