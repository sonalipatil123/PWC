package com.persistent.pmt.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.PageImpl;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.response.ApplicationResponse;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.to.openam.ApplicationCombineTO;
import com.persistent.pmt.to.openam.ApplicationUpdateTO;

/**
 * 
 * @author Persistent Systems
 */
public interface ApplicationService {

  /**
   * Get the summary of all the applications
   * 
   * @param hashMap
   * 
   * @return
   * @throws GenericException
   */
  public PageImpl<Map<String, String>> getApplicationsSummary(String searchView)
      throws GenericException;

  /**
   * Get the details of an application by id
   * 
   * @param id
   * @return
   * @throws GenericException
   */
  public GenericResponse<?> getApplicationById(int id) throws GenericException;

  /**
   * Get the details of an application by name
   * 
   * @param name
   * @return
   * @throws GenericException
   */
  public PageImpl<Map<String, String>> getApplicationByName(String name, String searchView)
      throws GenericException;

  /**
   * Get the details of an application by Agent/Agent group name
   * 
   * @param agentName
   * @return
   * @throws GenericException
   */
  public PageImpl<Map<String, String>> getApplicationByAgentName(String agentName,
      String searchView) throws GenericException;

  /**
   * Get the details of an application by domain name
   * 
   * @param domainName
   * @return
   * @throws GenericException
   */
  public PageImpl<Map<String, String>> getApplicationByDomainName(String domainName,
      String searchView) throws GenericException;

  /**
   * Update the state of an application
   * 
   * @param id
   * @param state
   * @return
   * @throws GenericException
   */
  public GenericResponse<?> updateApplicationState(int id, String state)
      throws GenericException;

  public GenericResponse<?> createApplication(Application application) throws GenericException;

  public GenericResponse<ApplicationResponse> provisionApplication(int id)
      throws GenericException;

  public GenericResponse<?> getApplicationStatistics() throws GenericException;

  public GenericResponse<?> updateApplication(ApplicationUpdateTO applicationUpdateTO)
      throws GenericException;

  public GenericResponse<?> getLastUpdateForApplicationId(int id) throws GenericException;

  /**
   * Get combined application object
   * 
   * @param List
   *          <Integer>
   * @return ApplicationCombineTO
   * @throws GenericException
   */
  public ApplicationCombineTO getCombinedApplicationTO(List<Integer> appIds)
      throws GenericException;
  
  /**
   * Persist combined application object in DB
   * 
   * @param ApplicationCombineTO
   * @return newly created application id
   * @throws GenericException
   */
  public Application createCombinedApplication(ApplicationCombineTO applicationCombineTO)
		  throws GenericException;

  public LinkedHashMap<String, Long> fetchAppStatistics(Environment env);
  
  public GenericResponse<?> updateStateForAllApplications(List<Integer> AppIds, String state)
      throws GenericException;
}
