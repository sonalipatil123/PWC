package com.persistent.pmt.dao;

import com.persistent.pmt.model.AuthorizationPolicy;

public interface AuthorizationPolicyDao {

	AuthorizationPolicy createAuthorizationPolicy(
			AuthorizationPolicy authorizationPolicy);

}
