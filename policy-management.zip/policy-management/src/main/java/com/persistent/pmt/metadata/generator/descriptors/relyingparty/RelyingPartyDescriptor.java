package com.persistent.pmt.metadata.generator.descriptors.relyingparty;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.persistent.pmt.metadata.generator.XmlUtils.XmlSourceGenerator;
import com.persistent.pmt.metadata.generator.descriptors.core.Descriptor;

@Component
public class RelyingPartyDescriptor implements Descriptor {

	@Autowired
	XmlSourceGenerator xmlSourceGenerator;

	String template;

	public String getData() {
		String token = "";
		return token;
	}

	@Override
	public String getXMLData(Map<String, String> tokenMap) {
		String xmlSource = xmlSourceGenerator.generateXmlSource(tokenMap, template);
		return xmlSource;
	}

	@Override
	public void setTemplatePath(String template) {

		this.template = template;

	}

	@Override
	public Map<String, String> getDescriptorData(Map<String, String> tokenMap) {

		return tokenMap;
	}

}
