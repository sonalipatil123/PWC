package com.persistent.pmt.model;

import java.util.ArrayList;
import java.util.List;

/**
 * EnvironmentType
 * 
 * Enum for EnvironmentType
 * 
 * @author Persistent Systems
 */
public enum EnvironmentType {

	DEV,STAGE,PROD;
	
	public static List<String> getEnvironments(){
		List<String> environments =new ArrayList<>();
		for(EnvironmentType env:EnvironmentType.values()){
			environments.add(env.name());
		}
		return environments;
	}
}
