package com.persistent.pmt.dao.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.dao.AuditRecordDao;
import com.persistent.pmt.model.AuditRecord;
import com.persistent.pmt.model.AuditRecord.ACTIONS;

@PropertySource(value = { "classpath:application.properties" })
@Repository("auditRecordDao")
@Transactional
public class AuditRecordDaoImpl extends BaseDaoImpl implements AuditRecordDao {

  @Override
  public AuditRecord logAuditRecord(AuditRecord auditRecord) {
    getSession().save(auditRecord);
    return auditRecord;
  }

  @SuppressWarnings("unchecked")
  @Override
  public List<AuditRecord> getRecordsByActionAndStatus(int environment, List<ACTIONS> actions,
      String status, Map<String, Integer> pagingDetails) {
    Criteria criteria = createCriteria(AuditRecord.class);
    criteria.add(Restrictions.eq("environment.id", environment));
    if (actions != null && !actions.isEmpty()) {
      criteria.add(Restrictions.in("action", actions));
    }
    if (status != null && !status.isEmpty()) {
      criteria.add(Restrictions.eq("status", status));
    }
    criteria.addOrder(Order.desc("id"));
    prepareCriteriaForPaging(criteria, pagingDetails);
    return criteria.list();
  }

  @Override
  public Long getRecordCountByActionAndStatus(int environment, List<ACTIONS> actions,
      String status) {

    Criteria criteria = createCriteria(AuditRecord.class);
    criteria.add(Restrictions.eq("environment.id", environment));
    if (actions != null && !actions.isEmpty()) {
      criteria.add(Restrictions.in("action", actions));
    }
    if (status != null && !status.isEmpty()) {
      criteria.add(Restrictions.eq("status", status));
    }
    criteria.setProjection(Projections.rowCount());
    return ((Long) criteria.uniqueResult());
  }

  @Override
	public List<String> getProcessIdForAction(int environment, ACTIONS action) {
    Criteria criteria = createCriteria(AuditRecord.class);
    criteria.add(Restrictions.eq("environment.id", environment));
    if (action != null) {
      criteria.add(Restrictions.eq("action", action));
    }
    criteria.setProjection(Projections.max("processId"));
		return (List<String>) criteria.list();
  }

  private void prepareCriteriaForPaging(Criteria criteria, Map<String, Integer> pagingDetails) {
    if (pagingDetails != null && !pagingDetails.isEmpty()) {
      if (pagingDetails.containsKey("page")) {
        criteria.setFirstResult((pagingDetails.get("page"))
            * pagingDetails.get("numberPerPage"));
      }
      if (pagingDetails.containsKey("numberPerPage")) {
        criteria.setMaxResults(pagingDetails.get("numberPerPage"));
      }
    }
  }
}
