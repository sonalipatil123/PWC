package com.persistent.pmt.model;

public class User {

	private String id;
	private String userName;
	private String whatyouknow;
	private String role;
	private String groups;

	public User() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getGroups() {
		return groups;
	}

	public void setGroups(String groups) {
		this.groups = groups;
	}

	public String getWhatyouknow() {
		return whatyouknow;
	}

	public void setWhatyouknow(String whatyouknow) {
		this.whatyouknow = whatyouknow;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", role=" + role + ", groups=" + groups + "]";
	}

}
