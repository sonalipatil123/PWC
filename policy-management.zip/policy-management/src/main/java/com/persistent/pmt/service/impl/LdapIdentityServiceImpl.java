package com.persistent.pmt.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.persistent.pmt.helper.UserStoreHelper;
import com.persistent.pmt.model.LdapGroup;
import com.persistent.pmt.model.LdapUser;
import com.persistent.pmt.service.LdapIdentityService;

@Service("ldapIdentityService")
public class LdapIdentityServiceImpl implements LdapIdentityService {

	@Autowired
	UserStoreHelper userStoreHelper;

	public List<LdapUser> getLdapUsers(String userId) {
		return userStoreHelper.getLdapUsers(userId);

	}

	public List<LdapUser> getLdapUsers(String userId, Map<String,String> params) {
		return userStoreHelper.getLdapUsers(userId, params);

	}

	@Override
	public List<LdapGroup> getLdapGroups(String groupId) {
		return userStoreHelper.getLdapGroups(groupId);
	}

}
