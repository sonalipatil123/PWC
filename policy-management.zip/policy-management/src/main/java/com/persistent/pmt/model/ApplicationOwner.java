package com.persistent.pmt.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * ApplicationOwner
 * 
 * Entity model for ApplicationOwner
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "application_owner")
@JsonInclude(Include.NON_NULL)
public class ApplicationOwner {

	@Id
//	@SequenceGenerator(name = "SEQ_APPLICATION_OWNER", sequenceName = "SEQ_APPLICATION_OWNER", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_APPLICATION_OWNER")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	@JsonIgnore
	private int id;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "application_id")
	@JsonIgnore
	private Application application;

	@ElementCollection
	@CollectionTable(name = "application_owner_user", joinColumns = @JoinColumn(name = "applicationowner_id"))
	@Column(name = "users")
	private Set<String> users;

	@ElementCollection
	@CollectionTable(name = "application_owner_group", joinColumns = @JoinColumn(name = "applicationowner_id"))
	@Column(name = "groups")
	private Set<String> groups;

	public ApplicationOwner() {
	}

	public Set<String> getUsers() {
		return users;
	}

	public void setUsers(Set<String> users) {
		this.users = users;
	}

	public Set<String> getGroups() {
		return groups;
	}

	public void setGroups(Set<String> groups) {
		this.groups = groups;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ApplicationOwner [users=");
		builder.append(users);
		builder.append(", groups=");
		builder.append(groups);
		builder.append("]");
		return builder.toString();
	}
}
