package com.persistent.pmt.constant.casm;

public enum Criteria {
  REQUIRED, OPTIONAL, REQUISITE, SUFFICIENT
}
