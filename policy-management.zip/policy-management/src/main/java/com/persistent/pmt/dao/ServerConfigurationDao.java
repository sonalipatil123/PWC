package com.persistent.pmt.dao;

import java.util.List;

import com.persistent.pmt.model.PropertyStore;

/**
 * AdminDao
 * 
 * @author Persistent Systems
 */
public interface ServerConfigurationDao {

	/**
   * Get all system properties for the environment identified by id
   * 
   * @param environment
   * @return
   */
  public List<PropertyStore> getProperties(int environment);

  /**
   * Get all system properties for all environments
   * 
   * @param environment
   * @return
   */
  public List<PropertyStore> getProperties();

	/**
   * Get the value of property identified by name for environment
   * identified by environment
   * 
   * @param name
   * @param id
   * @return
   */
  public PropertyStore getPropertyValue(String propertyName, int environment);

  /**
   * Create a property in PROPERTY table
   * 
   * @param property
   * @return
   */
  public void createProperty(PropertyStore property);
  
  /**
   * Update a property in PROPERTY table
   * 
   * @param property
   * @return
   */
  public void updateProperty(PropertyStore property);

  public List<String> getLifeCycle();

	public List<PropertyStore> checkOtherImportInProgress(String propertyName);

}
