package com.persistent.pmt.model;

/**
 * ResponseHeader
 * 
 * Entity model for ResponseHeader
 * 
 * @author Persistent Systems
 */
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "response_header")
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class ResponseHeader {

	@JsonIgnore
	@Id
//	@SequenceGenerator(name = "SEQ_RESPONSE_HEADER", sequenceName = "SEQ_RESPONSE_HEADER", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_RESPONSE_HEADER")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "source_attribute_name")
	private String sourceAttributeName;

	@Column(name = "target_attribute_name")
	private String targetAttributeName;

	@ManyToOne
	@JoinColumn(name = "identity_mapping_id")
	private IdentityMapping identityMapping;

	@Column(name = "is_custom")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean custom;

	public ResponseHeader() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSourceAttributeName() {
		return sourceAttributeName;
	}

	public void setSourceAttributeName(String sourceAttributeName) {
		this.sourceAttributeName = sourceAttributeName;
	}

	public String getTargetAttributeName() {
		return targetAttributeName;
	}

	public void setTargetAttributeName(String targetAttributeName) {
		this.targetAttributeName = targetAttributeName;
	}

	public IdentityMapping getIdentityMapping() {
		return identityMapping;
	}

	public void setIdentityMapping(IdentityMapping identityMapping) {
		this.identityMapping = identityMapping;
	}

	public boolean isCustom() {
		return custom;
	}

	public void setCustom(boolean custom) {
		this.custom = custom;
	}

	@Override
	public String toString() {
		return "ResponseHeader [id=" + id + ", sourceAttributeName="
				+ sourceAttributeName + ", targetAttributeName="
				+ targetAttributeName + ", identityMapping=" + identityMapping
				+ "]";
	}

}
