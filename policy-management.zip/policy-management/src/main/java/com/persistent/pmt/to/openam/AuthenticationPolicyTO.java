package com.persistent.pmt.to.openam;

import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuthenticationPolicyTO {

  private int id;
  private String name;
  private String description;
  private Boolean enabled;
  private List<String> resources; // list of resource ids
  private String Scheme;
  private Boolean isPublic;
  private List<ResponseTO> responses;
  private Set<String> actions;
  private String schemeType;

  public String getSchemeType() {
    return schemeType;
  }

  public void setSchemeType(String schemeType) {
    this.schemeType = schemeType;
  }

  public AuthenticationPolicyTO() {
    super();
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Boolean getEnabled() {
    return enabled;
  }

  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  public List<String> getResources() {
    return resources;
  }

  public void setResources(List<String> resources) {
    this.resources = resources;
  }

  public String getScheme() {
    return Scheme;
  }

  public void setScheme(String scheme) {
    Scheme = scheme;
  }

  public Boolean getIsPublic() {
    return isPublic;
  }

  public void setIsPublic(Boolean isPublic) {
    this.isPublic = isPublic;
  }

  public List<ResponseTO> getResponses() {
    return responses;
  }

  public void setResponses(List<ResponseTO> responses) {
    this.responses = responses;
  }

  public Set<String> getActions() {
    return actions;
  }

  public void setActions(Set<String> actions) {
    this.actions = actions;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("AuthenticationPolicyTO [id=");
    builder.append(id);
    builder.append(", name=");
    builder.append(name);
    builder.append(", description=");
    builder.append(description);
    builder.append(", enabled=");
    builder.append(enabled);
    builder.append(", resources=");
    builder.append(resources);
    builder.append(", Scheme=");
    builder.append(Scheme);
    builder.append(", isPublic=");
    builder.append(isPublic);
    builder.append(", responses=");
    builder.append(responses);
    builder.append(", actions=");
    builder.append(actions);
    builder.append("]");
    return builder.toString();
  }

}
