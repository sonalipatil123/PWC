/**
 * DeleteAction
 * 
 * Interface for delete action
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.workflow.action;

public interface DeleteAction extends Action {

}
