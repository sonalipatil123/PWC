package com.persistent.pmt.workflow.action.mapper.casm;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.casm.PolicyGrammarConstants;
import com.persistent.pmt.dao.ProviderDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.Provider;
import com.persistent.pmt.service.ServerConfigurationService;
import com.persistent.pmt.view.openam.AdvancedOAuth2ClientConfig;
import com.persistent.pmt.view.openam.Attribute;
import com.persistent.pmt.view.openam.CoreOAuth2ClientConfig;
import com.persistent.pmt.view.openam.CoreOpenIDClientConfig;
import com.persistent.pmt.view.openam.CoreUmaClientConfig;
import com.persistent.pmt.view.openam.OAuth2ClientView;
import com.persistent.pmt.view.openam.SignEncOAuth2ClientConfig;
import com.persistent.pmt.workflow.action.mapper.GenericMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component
public class OAuth2ClientViewMapper implements GenericMapper {

  @Autowired
  ProviderDao providerDao;

  @Autowired
  @Qualifier("serverConfigurationService")
  ServerConfigurationService serverConfigurationService;

  @Override
  public Object getMappedObject(Object object, WorkFlowContext workFlowContext)
      throws GenericException {
    return getOAuth2ClientView((Application) object);
  }

  private OAuth2ClientView getOAuth2ClientView(Application application) throws GenericException {
    OAuth2ClientView oauth2ClientView = null;
    Provider provider = application.getProvider();

    if (provider != null) {
      String clientSecret =
          provider.getSourceAttrValueByName(PolicyGrammarConstants.CLIENT_SECRETE);
      String clientGroup =
          provider.getSourceAttrValueByName(PolicyGrammarConstants.CLIENT_GROUP);
      oauth2ClientView = new OAuth2ClientView();
      oauth2ClientView.setId(getId(provider));
      CoreOAuth2ClientConfig coreOAuth2ClientConfig = new CoreOAuth2ClientConfig();
      coreOAuth2ClientConfig.setUserpassword(clientSecret);

      Map<String, String> scopeClaimMap = application.getHeaderAndCookieResponseValue();
      coreOAuth2ClientConfig.setScopes(new Attribute(false, scopeClaimMap.values()));
      CoreOpenIDClientConfig coreOpenIDClientConfig = new CoreOpenIDClientConfig();
      coreOpenIDClientConfig.setClaims(new Attribute(false, scopeClaimMap.values()));

      // if client group is there all the attributes of
      // OAuthClient(except attributes set above)
      // will be created with inherited = true and blank value.
      if (clientGroup != null) {

        coreOAuth2ClientConfig.setAgentgroup(clientGroup);
        coreOAuth2ClientConfig.setStatus(new Attribute(false, PolicyGrammarConstants.ACTIVE));

        coreOAuth2ClientConfig.setClientType(new Attribute(true, ""));
        coreOAuth2ClientConfig.setRedirectionUris(new Attribute(true, new String[] {}));

        coreOAuth2ClientConfig.setDefaultScopes(new Attribute(true, new String[] {}));
        coreOAuth2ClientConfig.setClientName(new Attribute(true, new String[] {}));
        coreOAuth2ClientConfig.setAuthorizationCodeLifetime(new Attribute(true, 0));
        coreOAuth2ClientConfig.setRefreshTokenLifetime(new Attribute(true, 0));
        coreOAuth2ClientConfig.setAccessTokenLifetime(new Attribute(true, 0));

        oauth2ClientView.setCoreOAuth2ClientConfig(coreOAuth2ClientConfig);
        AdvancedOAuth2ClientConfig advancedOAuth2ClientConfig =
            new AdvancedOAuth2ClientConfig();
        advancedOAuth2ClientConfig.setName(new Attribute(true, new String[] {}));
        advancedOAuth2ClientConfig.setDescriptions(new Attribute(true, new String[] {}));
        advancedOAuth2ClientConfig.setRequestUris(new Attribute(true, new String[] {}));
        advancedOAuth2ClientConfig.setResponseTypes(new Attribute(true, new String[] {}));
        advancedOAuth2ClientConfig.setContacts(new Attribute(true, new String[] {}));
        advancedOAuth2ClientConfig.setTokenEndpointAuthMethod(new Attribute(true, ""));
        advancedOAuth2ClientConfig.setSectorIdentifierUri(new Attribute(true, ""));
        advancedOAuth2ClientConfig.setSubjectType(new Attribute(true, ""));
        advancedOAuth2ClientConfig.setUpdateAccessToken(new Attribute(true, ""));
        advancedOAuth2ClientConfig.setIsConsentImplied(new Attribute(true, true));
        advancedOAuth2ClientConfig.setMixUpMitigation(new Attribute(true, true));

        oauth2ClientView.setAdvancedOAuth2ClientConfig(advancedOAuth2ClientConfig);

        coreOpenIDClientConfig.setPostLogoutRedirectUri(new Attribute(true, new String[] {}));
        coreOpenIDClientConfig.setClientSessionUri(new Attribute(true, ""));
        coreOpenIDClientConfig.setDefaultMaxAge(new Attribute(true, 0));
        coreOpenIDClientConfig.setDefaultMaxAgeEnabled(new Attribute(true, true));
        coreOpenIDClientConfig.setJwtTokenLifetime(new Attribute(true, 0));

        oauth2ClientView.setCoreOpenIDClientConfig(coreOpenIDClientConfig);

        SignEncOAuth2ClientConfig signEncOAuth2ClientConfig = new SignEncOAuth2ClientConfig();
        signEncOAuth2ClientConfig.setJwksUri(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setJwksCacheTimeout(new Attribute(true, 0));
        signEncOAuth2ClientConfig.setJwkStoreCacheMissCacheTime(new Attribute(true, 0));
        signEncOAuth2ClientConfig.setTokenEndpointAuthSigningAlgorithm(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setJwkSet(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setIdTokenSignedResponseAlg(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setIdTokenEncryptionEnabled(new Attribute(true, true));
        signEncOAuth2ClientConfig.setIdTokenEncryptionAlgorithm(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setIdTokenEncryptionMethod(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setIdTokenPublicEncryptionKey(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setClientJwtPublicKey(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setPublicKeyLocation(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setUserinfoResponseFormat(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setUserinfoSignedResponseAlg(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setUserinfoEncryptedResponseAlg(new Attribute(true, ""));
        signEncOAuth2ClientConfig
            .setUserinfoEncryptedResponseEncryptionAlgorithm(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setRequestParameterSignedAlg(new Attribute(true, ""));
        signEncOAuth2ClientConfig.setRequestParameterEncryptedAlg(new Attribute(true, ""));
        signEncOAuth2ClientConfig
            .setRequestParameterEncryptedEncryptionAlgorithm(new Attribute(true, ""));

        oauth2ClientView.setSignEncOAuth2ClientConfig(signEncOAuth2ClientConfig);

        CoreUmaClientConfig coreUmaClientConfig = new CoreUmaClientConfig();
        coreUmaClientConfig.setClaimsRedirectionUris(new Attribute(true, new String[] {}));

        oauth2ClientView.setCoreUmaClientConfig(coreUmaClientConfig);
      }

    }
    return oauth2ClientView;
  }

  @Override
  public String getId(Object object) throws GenericException {
    return ((Provider) object).getSourceAttrValueByName(PolicyGrammarConstants.CLIENT_ID);
  }

}