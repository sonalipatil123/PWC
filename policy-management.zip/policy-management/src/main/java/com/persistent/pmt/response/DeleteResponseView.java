package com.persistent.pmt.response;

public class DeleteResponseView {

}
