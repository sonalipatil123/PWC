package com.persistent.pmt.helper;

import java.util.List;

import com.persistent.pmt.commons.context.TargetConnectionTemplate;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.GenericException;

public interface SSOAuthTokenHelper {

  String getAPIToken(TargetConnectionTemplate targetConnectionTemplate,
      List<WorkflowError> errors) throws GenericException;
}
