/**
 * ApplicationResponse
 * 
 * Service response for application
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.model.Application;

@JsonInclude(Include.NON_NULL)
public class ApplicationResponse {

  private int id;
  private String name;
  private String state;
  private String environment;

  public ApplicationResponse() {
    super();
  }

  public ApplicationResponse(Application application) {
    this.id = application.getId();
    this.name = application.getName();
    this.state = application.getApplicationState().getState();
    this.environment = application.getEnvironment().getName();
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getEnvironment() {
    return environment;
  }

  public void setEnvironment(String environment) {
    this.environment = environment;
  }

  @Override
  public String toString() {
    return "ApplicationResponse [id=" + id + ", name=" + name + ", state=" + state
        + ", environment=" + environment + "]";
  }

}
