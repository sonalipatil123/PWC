package com.persistent.pmt.to.openam;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuthZPolicyCombineTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6276915298412867618L;
	private int id;
	private String name;
	private String description;
	private boolean enabled;
	private List<String> resources;
	private List<ConditionTO> conditions;
	private String authorizationRule;
	private List<ResponseTO> responses;
	private Set<String> actions;
	private boolean selected;
	private String applicationName;
	

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public List<String> getResources() {
		return resources;
	}

	public void setResources(List<String> resources) {
		this.resources = resources;
	}

	public List<ConditionTO> getConditions() {
		return conditions;
	}

	public void setConditions(List<ConditionTO> conditions) {
		this.conditions = conditions;
	}

	public String getAuthorizationRule() {
		return authorizationRule;
	}

	public void setAuthorizationRule(String authorizationRule) {
		this.authorizationRule = authorizationRule;
	}

	public List<ResponseTO> getResponses() {
		return responses;
	}

	public void setResponses(List<ResponseTO> responses) {
		this.responses = responses;
	}

	public Set<String> getActions() {
		return actions;
	}

	public void setActions(Set<String> actions) {
		this.actions = actions;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	@Override
	protected AuthZPolicyCombineTO clone() {
		
		AuthZPolicyCombineTO clonedObject = new AuthZPolicyCombineTO();
		
		String clonedName = new String(this.name);
		String clonedDescription = null;
		if(null!=this.description)
			clonedDescription = new String(this.description);		
		Boolean clonedEnabled = new Boolean(this.enabled);
		List<String> clonedResources = new ArrayList<>(this.resources);
		List<ConditionTO> clonedConditions = new ArrayList<>(this.conditions);
		String clonedAuthorizationRule = null;
		if(null!=this.authorizationRule)
			clonedAuthorizationRule = new String(this.authorizationRule);
		List<ResponseTO> clonedResponses = new ArrayList<>(this.responses);
		Set<String> clonedActions = new HashSet<>(this.actions);
		String clonedAppName = null;
		if(null!=this.applicationName)
			clonedAppName = new String(this.applicationName);
				
		clonedObject.setId(id);
		clonedObject.setName(clonedName);
		clonedObject.setDescription(clonedDescription);
		clonedObject.setEnabled(clonedEnabled);
		clonedObject.setResources(clonedResources);
		clonedObject.setConditions(clonedConditions);
		clonedObject.setAuthorizationRule(clonedAuthorizationRule);
		clonedObject.setResponses(clonedResponses);
		clonedObject.setActions(clonedActions);
		clonedObject.setApplicationName(clonedAppName);
	
		return clonedObject;
		
	}
		
	
}
