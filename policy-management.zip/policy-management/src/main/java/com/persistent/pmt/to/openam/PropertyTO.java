package com.persistent.pmt.to.openam;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PropertyTO {

  private String key;
  private String value;
  private Integer environment;
  private String alias;
  private String type;

  public String getKey() {
    return key;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public Integer getEnvironment() {
    return environment;
  }

  public void setEnvironment(Integer environment) {
    this.environment = environment;
  }

  public String getAlias() {
    return alias;
  }

  public void setAlias(String alias) {
    this.alias = alias;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("PropertyTO [key=");
    builder.append(key);
    builder.append(", value=");
    builder.append(value);
    builder.append(", environment=");
    builder.append(environment);
    builder.append(", alias=");
    builder.append(alias);
    builder.append("]");
    return builder.toString();
  }

}
