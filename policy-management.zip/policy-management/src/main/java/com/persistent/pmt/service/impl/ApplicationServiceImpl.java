package com.persistent.pmt.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.constant.ApplicationFilter;
import com.persistent.pmt.constant.ApplicationState;
import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.casm.AuthenticationSchemeTypes;
import com.persistent.pmt.constant.casm.PolicyGrammarConstants;
import com.persistent.pmt.dao.AgentDao;
import com.persistent.pmt.dao.ApplicationDao;
import com.persistent.pmt.dao.ApplicationStateDao;
import com.persistent.pmt.dao.AuthenticationPolicyDao;
import com.persistent.pmt.dao.AuthenticationSchemeDao;
import com.persistent.pmt.dao.AuthorizationPolicyDao;
import com.persistent.pmt.dao.EnvironmentDao;
import com.persistent.pmt.dao.ProviderDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Agent;
import com.persistent.pmt.model.AgentAttributes;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.ApplicationAttributes;
import com.persistent.pmt.model.ApplicationSummary;
import com.persistent.pmt.model.AuthenticationPolicy;
import com.persistent.pmt.model.AuthenticationScheme;
import com.persistent.pmt.model.AuthorizationPolicy;
import com.persistent.pmt.model.ChangeHistory;
import com.persistent.pmt.model.ChangeHistory.ACTIONS;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.model.Provider;
import com.persistent.pmt.model.ProviderAttributes;
import com.persistent.pmt.model.Resource;
import com.persistent.pmt.model.Response;
import com.persistent.pmt.model.mapper.CombinedApplicationMapper;
import com.persistent.pmt.response.ApplicationResponse;
import com.persistent.pmt.response.ApplicationWorkflowResponse;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.service.ApplicationService;
import com.persistent.pmt.service.ChangeHistoryService;
import com.persistent.pmt.service.ValidationService;
import com.persistent.pmt.to.openam.ApplicationCombineTO;
import com.persistent.pmt.to.openam.ApplicationTO;
import com.persistent.pmt.to.openam.ApplicationUpdateTO;
import com.persistent.pmt.to.openam.ApplicatonStatsByStateTO;
import com.persistent.pmt.to.openam.AuthenticationPolicyTO;
import com.persistent.pmt.utils.AuditUtils;
import com.persistent.pmt.utils.AuditUtils.CONTEXT_FORMAT_TYPE;
import com.persistent.pmt.utils.AuditWriter;
import com.persistent.pmt.utils.MapperUtils;
import com.persistent.pmt.workflow.CreateWorkflow;

/**
 * 
 * @author Persistent Systems
 */
@Service("applicationService")
@Transactional
public class ApplicationServiceImpl implements ApplicationService {

  private static final Logger logger = Logger.getLogger(ApplicationServiceImpl.class);

  @Autowired
  ApplicationDao applicationDao;

  @Autowired
  EnvironmentDao environmentDao;

  @Autowired
  ApplicationStateDao applicationStateDao;

  @Autowired
  AuthenticationPolicyDao authenticationPolicyDao;

  @Autowired
  AuthorizationPolicyDao authorizationPolicyDao;

  @Autowired
  AgentDao agentDao;

  @Autowired
  ProviderDao providerDao;

  @Autowired
  ChangeHistoryService changeHistoryService;

  @Autowired
  CreateWorkflow createWorkflow;

  @Autowired
  AuthenticationSchemeDao authenticationSchemeDao;

  @Autowired
  ValidationService validationService;

  @Autowired
  ThreadLocal<PMTContext> pmtContextThreadLocal;

  @Autowired
  AuditWriter auditWriter;

  @Autowired
  org.springframework.core.env.Environment environment;

  @Autowired
  CombinedApplicationMapper combinedApplicationMapper;

  @Override
  public PageImpl<Map<String, String>> getApplicationsSummary(String searchView)
      throws GenericException {

    PageRequest pageable = null;
    Long totalCount = null;
    List<Map<String, String>> applications = null;

    PMTContext pmtContext = pmtContextThreadLocal.get();
    List<ApplicationSummary> applicationSummaryEntities = null;

    if (pmtContext.getApplicationFilters() != null
        && !pmtContext.getApplicationFilters().isEmpty()
        && ((String) pmtContext.getApplicationFilters().get(
            ApplicationFilter.ENVIRONMENT.getValue()) != null)) {
      Environment environment =
          environmentDao.getEnvironmentByName((String) pmtContext.getApplicationFilters().get(
              ApplicationFilter.ENVIRONMENT.getValue()));

      if (environment != null) {

        if (searchView.equalsIgnoreCase(PMTConstants.SEARCH_VIEW_IMPORT)) {
          totalCount =
              (applicationDao.getApplicationCount(environment.getId(),
                  com.persistent.pmt.constant.ApplicationState.getImportSummaryStates()))
                  .longValue();

          applicationSummaryEntities =
              applicationDao.getApplicationsSummary(environment.getId(),
                  com.persistent.pmt.constant.ApplicationState.getImportSummaryStates(),
                  pmtContext.getPagingDetails());
        }
        else if (searchView.equalsIgnoreCase(PMTConstants.SEARCH_VIEW_PMT)) {
          totalCount =
              (applicationDao.getApplicationCount(environment.getId(),
                  com.persistent.pmt.constant.ApplicationState.getApplicationSummaryStates()))
                  .longValue();

          applicationSummaryEntities =
              applicationDao.getApplicationsSummary(environment.getId(),
                  com.persistent.pmt.constant.ApplicationState.getApplicationSummaryStates(),
                  pmtContext.getPagingDetails());
        }

        if (applicationSummaryEntities != null && !applicationSummaryEntities.isEmpty()) {
          applications = new ArrayList<Map<String, String>>();
          for (ApplicationSummary applicationSummaryEntity : applicationSummaryEntities) {
            applications.add(MapperUtils.getApplicationSummaryTO(applicationSummaryEntity));
          }

          // paging
          pageable =
              new PageRequest(pmtContext.getPagingDetails().get("page"), pmtContext
                  .getPagingDetails().get("numberPerPage"));
        }
        else {
          throw new GenericException(
              "The server successfully processed the request but applications data not found.",
              HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
        }
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
    return new PageImpl<>(applications, pageable, totalCount);
  }

  @Override
  public GenericResponse<?> getApplicationById(int id) throws GenericException {

    GenericResponse<ApplicationTO> response = new GenericResponse<>();
    Application application = applicationDao.getApplicationById(id);

    if (null != application) {

      Provider provider =
          fetchApplicationProvider(application, application.getEnvironment().getName());
      if (null != provider) {
        application.setProvider(provider);
      }
      response.setContent(new ApplicationTO(application));
      response.setStatusCode(HttpStatus.OK.value());
      response.setMessage("Application found.");
      response.setStatus(GenericResponse.SUCCESS);

    }
    else {
      throw new GenericException(
          "The server successfully processed the request but application data not found.",
          HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
    }
    return response;
  }

  @Override
  public PageImpl<Map<String, String>> getApplicationByName(String name, String searchView)
      throws GenericException {

    Long totalCount = null;
    PMTContext pmtContext = pmtContextThreadLocal.get();
    List<ApplicationSummary> applicationSummaryEntities = null;
    List<Map<String, String>> applications;
    PageRequest pageable;

    if (pmtContext.getApplicationFilters() != null
        && !pmtContext.getApplicationFilters().isEmpty()
        && ((String) pmtContext.getApplicationFilters().get(
            ApplicationFilter.ENVIRONMENT.getValue()) != null)) {
      Environment environment =
          environmentDao.getEnvironmentByName((String) pmtContext.getApplicationFilters().get(
              ApplicationFilter.ENVIRONMENT.getValue()));

      if (environment != null) {

        if (searchView.equalsIgnoreCase(PMTConstants.SEARCH_VIEW_IMPORT)) {
          totalCount =
              applicationDao.getApplicationSearchCountByName(environment.getId(),
                  com.persistent.pmt.constant.ApplicationState.getImportSummaryStates(), name);

          applicationSummaryEntities =
              applicationDao.getApplicationByName(environment.getId(), name,
                  com.persistent.pmt.constant.ApplicationState.getImportSummaryStates(),
                  pmtContext.getPagingDetails());
        }
        else if (searchView.equalsIgnoreCase(PMTConstants.SEARCH_VIEW_PMT)) {
          totalCount =
              applicationDao.getApplicationSearchCountByName(environment.getId(),
                  com.persistent.pmt.constant.ApplicationState.getApplicationSummaryStates(),
                  name);

          applicationSummaryEntities =
              applicationDao.getApplicationByName(environment.getId(), name,
                  com.persistent.pmt.constant.ApplicationState.getApplicationSummaryStates(),
                  pmtContext.getPagingDetails());
        }

        if (null != applicationSummaryEntities && !applicationSummaryEntities.isEmpty()) {
          applications = new ArrayList<>();
          for (ApplicationSummary applicationSummaryEntity : applicationSummaryEntities) {
            applications.add(MapperUtils.getApplicationSummaryTO(applicationSummaryEntity));
          }
          pageable =
              new PageRequest(pmtContext.getPagingDetails().get("page"), pmtContext
                  .getPagingDetails().get("numberPerPage"));
        }
        else {
          throw new GenericException(
              "The server successfully processed the request but application data not found.",
              HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
        }
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
    return new PageImpl<>(applications, pageable, totalCount);
  }

  @Override
  public PageImpl<Map<String, String>> getApplicationByDomainName(String domainName,
      String searchView) throws GenericException {

    Long totalCount = null;
    PMTContext pmtContext = pmtContextThreadLocal.get();
    List<ApplicationSummary> applicationSummaryEntities = null;
    List<Map<String, String>> applications = null;
    PageRequest pageable;

    if (pmtContext.getApplicationFilters() != null
        && !pmtContext.getApplicationFilters().isEmpty()
        && ((String) pmtContext.getApplicationFilters().get(
            ApplicationFilter.ENVIRONMENT.getValue()) != null)) {

      Environment environment =
          environmentDao.getEnvironmentByName((String) pmtContext.getApplicationFilters().get(
              ApplicationFilter.ENVIRONMENT.getValue()));

      if (environment != null) {

        List<ApplicationAttributes> appAttrList =
            applicationDao.getAppAttributesForDomainName(domainName);
        if (null != appAttrList && !appAttrList.isEmpty()) {
          List<Integer> idList = new ArrayList<>();
          for (ApplicationAttributes appAttr : appAttrList) {
            idList.add(appAttr.getApplication().getId());
          }

          if (searchView.equalsIgnoreCase(PMTConstants.SEARCH_VIEW_IMPORT)) {

            totalCount =
                applicationDao.getApplicationSearchCountByIdList(environment.getId(),
                    com.persistent.pmt.constant.ApplicationState.getImportSummaryStates(),
                    idList);

            applicationSummaryEntities =
                applicationDao.getApplicationsByStateEnvAndIdList(environment.getId(), idList,
                    com.persistent.pmt.constant.ApplicationState.getImportSummaryStates(),
                    pmtContext.getPagingDetails());

          }
          else if (searchView.equalsIgnoreCase(PMTConstants.SEARCH_VIEW_PMT)) {

            totalCount =
                applicationDao.getApplicationSearchCountByIdList(environment.getId(),
                    com.persistent.pmt.constant.ApplicationState.getApplicationSummaryStates(),
                    idList);

            applicationSummaryEntities =
                applicationDao.getApplicationsByStateEnvAndIdList(environment.getId(), idList,
                    com.persistent.pmt.constant.ApplicationState.getApplicationSummaryStates(),
                    pmtContext.getPagingDetails());
          }

          if (!applicationSummaryEntities.isEmpty()) {
            applications = new ArrayList<>();
            for (ApplicationSummary applicationSummaryEntity : applicationSummaryEntities) {
              applications.add(MapperUtils.getApplicationSummaryTO(applicationSummaryEntity));
            }
            pageable =
                new PageRequest(pmtContext.getPagingDetails().get("page"), pmtContext
                    .getPagingDetails().get("numberPerPage"));
          }
          else {
            throw new GenericException(
                "The server successfully processed the request but application data not found.",
                HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
          }
        }
        else {
          throw new GenericException(
              "The server successfully processed the request but application data not found.",
              HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
        }
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
    return new PageImpl<>(applications, pageable, totalCount);
  }

  @Override
  public PageImpl<Map<String, String>> getApplicationByAgentName(String agentName,
      String searchView) throws GenericException {

    Long totalCount = null;
    PMTContext pmtContext = pmtContextThreadLocal.get();
    List<ApplicationSummary> applicationSummaryEntities = null;
    List<Map<String, String>> applications = null;
    PageRequest pageable = null;

    if (pmtContext.getApplicationFilters() != null
        && !pmtContext.getApplicationFilters().isEmpty()
        && ((String) pmtContext.getApplicationFilters().get(
            ApplicationFilter.ENVIRONMENT.getValue()) != null)) {

      Environment environment =
          environmentDao.getEnvironmentByName((String) pmtContext.getApplicationFilters().get(
              ApplicationFilter.ENVIRONMENT.getValue()));

      if (environment != null) {
        List<Agent> agentList = agentDao.getAgentsByName(agentName, environment.getName());

        if (!agentList.isEmpty()) {

          if (searchView.equalsIgnoreCase(PMTConstants.SEARCH_VIEW_IMPORT)) {

            totalCount =
                applicationDao.getApplicationSearchCountByAgentName(environment.getId(),
                    com.persistent.pmt.constant.ApplicationState.getImportSummaryStates(),
                    agentList);

            applicationSummaryEntities =
                applicationDao.getApplicationsForAgentHierachy(environment.getId(), agentList,
                    com.persistent.pmt.constant.ApplicationState.getImportSummaryStates(),
                    pmtContext.getPagingDetails());

          }
          else if (searchView.equalsIgnoreCase(PMTConstants.SEARCH_VIEW_PMT)) {

            totalCount =
                applicationDao.getApplicationSearchCountByAgentName(environment.getId(),
                    com.persistent.pmt.constant.ApplicationState.getApplicationSummaryStates(),
                    agentList);

            applicationSummaryEntities =
                applicationDao.getApplicationsForAgentHierachy(environment.getId(), agentList,
                    com.persistent.pmt.constant.ApplicationState.getApplicationSummaryStates(),
                    pmtContext.getPagingDetails());
          }

          if (null != applicationSummaryEntities && !applicationSummaryEntities.isEmpty()) {
            applications = new ArrayList<>();
            for (ApplicationSummary applicationSummaryEntity : applicationSummaryEntities) {
              applications.add(MapperUtils.getApplicationSummaryTO(applicationSummaryEntity));
            }
            pageable =
                new PageRequest(pmtContext.getPagingDetails().get("page"), pmtContext
                    .getPagingDetails().get("numberPerPage"));
          }
          else {
            throw new GenericException(
                "The server successfully processed the request but application data not found.",
                HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
          }
        }
        else {
          throw new GenericException(
              "The server successfully processed the request but application data not found.",
              HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
        }
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
    return new PageImpl<>(applications, pageable, totalCount);
  }

  @Override
  public GenericResponse<?> updateApplicationState(int id, String state)
      throws GenericException {
    GenericResponse<ApplicationTO> response = new GenericResponse<>();

    Application application = applicationDao.getApplicationById(id);
    com.persistent.pmt.model.ApplicationState newState = null;
    if (application != null) {
      newState = applicationStateDao.getApplicationStateByName(state);
      if (newState != null) {
        application.setApplicationState(newState);
        application = applicationDao.saveOrUpdateApplication(application);

        changeHistoryService.createChangeHistory(id, ACTIONS.STATE_UPDATE,
            "Application state has been successfully updated to '" + state + "'.",
            PMTConstants.SUCCESS);
        response.setContent(new ApplicationTO(application));
        response.setStatusCode(HttpStatus.OK.value());
        response.setMessage("Application state has been successfully updated to '" + state
            + "'.");
        response.setStatus(GenericResponse.SUCCESS);
      }
      else {
        changeHistoryService.createChangeHistory(id, ACTIONS.STATE_UPDATE,
            "Failed to update application state to '" + state
                + "' since state specified is invalid.", PMTConstants.FAILURE);
        throw new GenericException("Failed to update application state to '" + state
            + "' since state specified is invalid.", HttpStatus.NOT_FOUND.value(),
            GenericResponse.FAILURE);
      }

    }
    else {
      changeHistoryService.createChangeHistory(id, ACTIONS.STATE_UPDATE,
          "Failed to update application state to '" + state + "' since application with id: "
              + id + "  does not exist.", PMTConstants.FAILURE);
      throw new GenericException("Failed to update application state to '" + state
          + "' since application with id: " + id + "  does not exist.",
          HttpStatus.NOT_FOUND.value(), GenericResponse.FAILURE);
    }

    return response;
  }

  @Override
  public GenericResponse<?> createApplication(Application application) throws GenericException {
    GenericResponse<Application> genericResponse = new GenericResponse<>();

    if (application != null) {
      HashMap<String, AuthorizationPolicy> authorizationPolicies =
          new HashMap<String, AuthorizationPolicy>();
      HashMap<String, AuthenticationPolicy> authenticationPolicies =
          new HashMap<String, AuthenticationPolicy>();
      List<AuthenticationPolicy> authnPolicies = application.getAuthenticationPolicies();
      List<AuthorizationPolicy> authzPolicies = application.getAuthorizationPolicies();

      if (null != authzPolicies) {
        for (AuthorizationPolicy authzPolicy : authzPolicies) {
          AuthorizationPolicy authorizationPolicy =
              authorizationPolicyDao.createAuthorizationPolicy(authzPolicy);
          authorizationPolicies.put(authorizationPolicy.getName(), authorizationPolicy);
        }
      }

      if (null != authnPolicies) {
        for (AuthenticationPolicy authnpolicy : authnPolicies) {
          AuthenticationPolicy authenticationPolicy =
              authenticationPolicyDao.createAuthenticationPolicy(authnpolicy);
          authenticationPolicies.put(authenticationPolicy.getName(), authenticationPolicy);
        }
      }

      application.setAuthorizationPolicies(new ArrayList<AuthorizationPolicy>(
          authorizationPolicies.values()));

      application.setAuthenticationPolicies(new ArrayList<AuthenticationPolicy>(
          authenticationPolicies.values()));

      List<Resource> resources = application.getResources();
      if (resources != null && !resources.isEmpty()) {
        for (Resource resource : resources) {
          AuthenticationPolicy resourceAuthnPolicy = resource.getAuthenticationPolicy();
          if (resourceAuthnPolicy != null) {
            if (authenticationPolicies.containsKey(resourceAuthnPolicy.getName())) {
              resource.setAuthenticationPolicy(authenticationPolicies.get(resourceAuthnPolicy
                  .getName()));
            }
          }

          AuthorizationPolicy resourceAuthzPolicy = resource.getAuthorizationPolicy();
          if (resourceAuthzPolicy != null) {
            if (authorizationPolicies.containsKey(resourceAuthzPolicy.getName())) {
              resource.setAuthorizationPolicy(authorizationPolicies.get(resourceAuthzPolicy
                  .getName()));
            }
          }
        }
      }

      List<Response> responses = application.getResponses();
      if (responses != null && !responses.isEmpty()) {
        for (Response response : responses) {

          AuthenticationPolicy resourceAuthnPolicy = response.getAuthenticationPolicy();
          if (resourceAuthnPolicy != null) {
            if (authenticationPolicies.containsKey(resourceAuthnPolicy.getName())) {
              response.setAuthenticationPolicy(application.getDefaultAuthenticationPolicy());
            }
          }

          AuthorizationPolicy responseAuthzPolicy = response.getAuthorizationPolicy();
          if (responseAuthzPolicy != null) {
            if (authorizationPolicies.containsKey(responseAuthzPolicy.getName())) {
              response.setAuthorizationPolicy(authorizationPolicies.get(responseAuthzPolicy
                  .getName()));
            }
          }
        }
      }
      Application createdApplication = applicationDao.saveOrUpdateApplication(application);
      genericResponse.setContent(createdApplication);
      genericResponse.setMessage("Application has been created successfully.");
      genericResponse.setStatus(GenericResponse.SUCCESS);
      genericResponse.setStatusCode(HttpStatus.OK.value());

    }
    else {
      throw new GenericException("Application information is empty.",
          HttpStatus.INTERNAL_SERVER_ERROR.value(), GenericResponse.FAILURE);
    }
    return genericResponse;
  }

  @Override
  public GenericResponse<?> getApplicationStatistics() throws GenericException {

    GenericResponse<HashMap<String, LinkedHashMap<String, Long>>> response =
        new GenericResponse<>();
    response.setMessage("Application statistics returned successfully.");
    response.setStatus(GenericResponse.SUCCESS);
    response.setStatusCode(HttpStatus.OK.value());

    HashMap<String, LinkedHashMap<String, Long>> applicationStatistics = new LinkedHashMap<>();
    List<Environment> environment = environmentDao.getAllEnvironments();
    if (environment != null) {
      for (Environment env : environment) {
        LinkedHashMap<String, Long> stateCountMap = fetchAppStatistics(env);
        applicationStatistics.put(env.getName(), stateCountMap);
      }
    }
    else {
      throw new GenericException("Ennvironment Data Not Found", HttpStatus.NO_CONTENT.value(),
          GenericResponse.FAILURE);
    }
    response.setContent(applicationStatistics);

    return response;
  }

  public LinkedHashMap<String, Long> fetchAppStatistics(Environment env) {
    long totalFilteredCount = 0;
    LinkedHashMap<String, Long> stateCountMap = new LinkedHashMap<>();
    Long totalApplicationCount = null;
    totalApplicationCount = applicationDao.getApplicationCount(env.getId(), null);

    List<ApplicatonStatsByStateTO> applicatonStatsByStatsList =
        applicationDao.getApplicationStatistics(env.getId());
    totalFilteredCount = 0;
    for (ApplicatonStatsByStateTO stateCount : applicatonStatsByStatsList) {

      if (!stateCount.getState().equals(ApplicationState.DRAFTED.name())
          && !stateCount.getState().equals(ApplicationState.DECOMMISSIONED.name())
          && !stateCount.getState().equals(ApplicationState.PROVISION_UPDATE.name())
          && !stateCount.getState().equals(ApplicationState.COMBINED.name())) {
        stateCountMap.put(stateCount.getState(), stateCount.getCount());
        totalFilteredCount = totalFilteredCount + stateCount.getCount();
      }
    }
    stateCountMap.put(PMTConstants.TOTAL_FILTERED_COUNT, totalFilteredCount);
    stateCountMap.put("TOTAL", totalApplicationCount.longValue());
    return stateCountMap;
  }

  @Override
  public GenericResponse<ApplicationResponse> provisionApplication(int id)
      throws GenericException {

    Application application = applicationDao.getApplicationById(id);
    validateApplicationForProvision(id, application);

    Provider provider =
        fetchApplicationProvider(application, pmtContextThreadLocal.get().getEnvironmentValue());
    if (null != provider) {
      application.setProvider(provider);
    }
    createWorkflow.start(application);

    // update application state to Provisioned
    application.setApplicationState(applicationStateDao
        .getApplicationStateByName(ApplicationState.PROVISIONED.name()));

    // This is the entry in context column of ChangeHsitory table
    // to record app specific context.
    StringBuilder context = new StringBuilder();
    if (PMTConstants.PEP_TYPE_FEDERATION.equals(application.getPepType())
        && AuthenticationSchemeTypes.AUTHN_SCHEME_OAUTH.getValue().equals(
            application.getDefaultAuthScheme().getType())) {
      context.append("scope_claim_names=");
    }

    Map<String, String> responseMap = application.getHeaderAndCookieResponseValue();

    createChangeHistoryContext(context, responseMap);
    changeHistoryService.createChangeHistory(application.getId(),
        ChangeHistory.ACTIONS.PROVISION, context.toString(), PMTConstants.SUCCESS);

    ApplicationWorkflowResponse applicationWorkflowResponse =
        new ApplicationWorkflowResponse(application);
    GenericResponse<ApplicationResponse> response = new GenericResponse<ApplicationResponse>();
    response.setContent(applicationWorkflowResponse);
    response.setMessage("Application has been provisioned successfully.");
    response.setStatusCode(HttpStatus.OK.value());
    response.setStatus(GenericResponse.SUCCESS);
    logger.log(Level.INFO, "Application provisioned successfully");

    return response;
  }

  private void createChangeHistoryContext(StringBuilder context, Map<String, String> responseMap) {
    if (responseMap != null) {
      boolean flag = false;
      for (Entry<String, String> entry : responseMap.entrySet()) {
        if (flag) {
          context.append("|");
        }
        else {
          flag = true;
        }
        context.append(entry.getKey() + "=" + entry.getValue());
      }
    }
  }

  public void validateApplicationForProvision(int id, Application application)
      throws GenericException {
    if (application == null) {
      throw new GenericException("Application with id " + id + " does not exist.",
          HttpStatus.NOT_FOUND.value(), GenericResponse.FAILURE);
    }
    // This method validates the application name does not containing
    // special characters and application name is not duplicate
    validationService.validateApplicationName(application.getName(), application.getId());

    checkProvisionEligibility(application);

    if (application.getDefaultAuthScheme() != null
        && ((PMTConstants.PEP_TYPE_AGENT.equalsIgnoreCase(application.getPepType()) && !AuthenticationSchemeTypes.AUTHN_SCHEME_SAML2
            .getValue().equalsIgnoreCase(application.getDefaultAuthScheme().getType())) || (PMTConstants.PEP_TYPE_FEDERATION
            .equalsIgnoreCase(application.getPepType()) && AuthenticationSchemeTypes.AUTHN_SCHEME_OAUTH
            .getValue().equalsIgnoreCase(application.getDefaultAuthScheme().getType())))) {
      validateApplicationData(application);
    }
  }

  private void validateApplicationData(Application application) throws GenericException {
    if (application != null) {
      Agent agent = application.getAgent();
      if (PolicyGrammarConstants.AGENT_TYPE_GROUP.equals(agent.getType())) {
        String groupAgents =
            agent
                .getSourceAttributeValueByName(PolicyGrammarConstants.AGENT_ATTRIBUE_GROUP_AGENTS);
        if (groupAgents != null && !groupAgents.isEmpty()) {
          String[] agentNames = groupAgents.split(",");
          List<Agent> agentList =
              agentDao.getAgentListByNames(new ArrayList<String>(Arrays.asList(agentNames)));
          for (Agent groupAgent : agentList) {
            checkIfAgentFQDNInvalid(application, groupAgent);
          }
        }
        else {
          throw new GenericException("Application with id " + application.getId()
              + " can not be provisioned. Reason: Agent Group with name: " + agent.getId()
              + " and id: " + agent.getId() + " does not contain any agent.",
              HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
        }
      }
      else {
        checkIfAgentFQDNInvalid(application, agent);
      }
    }
  }

  private void checkIfAgentFQDNInvalid(Application application, Agent agent)
      throws GenericException {

    boolean isFQDNPresent = false;
    for (AgentAttributes attribute : agent.getAttributes()) {
      if (PolicyGrammarConstants.AGENT_ATTRIBUE_FQDN.equalsIgnoreCase(attribute
          .getSourceAttrName())) {
        isFQDNPresent = true;
        break;
      }
    }

    if (!isFQDNPresent) {
      // Audit record neddReview Type
      auditWriter.write(com.persistent.pmt.model.AuditRecord.ACTIONS.PROVISION,
          PMTConstants.NEED_REVIEW,
          environment.getProperty(AuditPropertyConstants.AGENT_NOT_HAVING_FQDN), "",
          new Object[] { agent.getName(), agent.getId() });

      throw new GenericException("Application with id " + application.getId()
          + " can not be provisioned. Reason: Agent with name: " + agent.getName()
          + " and id: " + agent.getId()
          + " does not have Fully Qualified Domain Name(FQDN) value.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }

  }

  /**
   * This method checks if the application is eligible to be
   * provisioned in target system
   * 
   * @param Application
   * @throws GenericException
   */
  private void checkProvisionEligibility(Application application) throws GenericException {
    if (!(ApplicationState.READY_TO_PROVISION.name().equalsIgnoreCase(
        application.getApplicationState().getState())
        || ApplicationState.PROVISION_UPDATE.name().equalsIgnoreCase(
            application.getApplicationState().getState()) || ApplicationState.IMPORTED.name()
        .equalsIgnoreCase(application.getApplicationState().getState()))) {
      throw new GenericException(
          "Application to be provisioned should be in 'READY_TO_PROVISION' or 'PROVISION_UPDATE' or 'IMPORTED' state",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
  }

  @Override
  public GenericResponse<?> updateApplication(ApplicationUpdateTO applicationUpdateTO)
      throws GenericException {
    GenericResponse<ApplicationUpdateTO> genericResponse = new GenericResponse<>();
    ApplicationTO applicationTO = applicationUpdateTO.getApplicationTO();
    List<String> attributes = applicationUpdateTO.getAttributes();
    Provider provider = null;
    // This method validates the application name does not containing
    // special characters and application name is not duplicate
    validationService.validateApplicationName(applicationTO.getName(), applicationTO.getId());
    Application application = applicationDao.getApplicationById(applicationTO.getId());
    if (application == null) {
      throw new GenericException("Application with id " + applicationTO.getId()
          + " does not exist", HttpStatus.NOT_FOUND.value(), GenericResponse.FAILURE);
    }
    String originalName = application.getName();
    String originalDescription = application.getDescription();
    String originalScheme = application.getDefaultAuthScheme().getName();
    for (String attribute : attributes) {
      if (attribute.equals("name")) {
        provider =
            fetchApplicationProvider(application, application.getEnvironment().getName());
        if (provider != null) {
          provider.setName(applicationTO.getName());
        }
        application.setName(applicationTO.getName());
      }
      else if (attribute.equals("description")) {
        application.setDescription(applicationTO.getDescription());
      }
      else if (attribute.equals("authenticationPolicies")) {
        // search authentication scheme by name. create authentication
        // policy and set that authentication scheme object
        // add this authentication policy to authentication policy
        // list in application
        AuthenticationPolicy authenticationPolicy =
            application.getDefaultAuthenticationPolicy();
        // Application payload contains only 1 authentication policy,
        // which is default one.
        AuthenticationPolicyTO authenticationPolicyTO =
            applicationTO.getAuthenticationPolicies().get(0);

        if (authenticationPolicyTO.getScheme().equalsIgnoreCase("SAML")
            || authenticationPolicyTO.getScheme().equalsIgnoreCase("OAUTH")) {
          application.setPepType(PMTConstants.PEP_TYPE_FEDERATION);
        }
        AuthenticationScheme authenticationScheme =
            authenticationSchemeDao.getAuthenticationSchemeByName(authenticationPolicyTO
                .getScheme());

        if (authenticationScheme != null) {
          authenticationPolicy.setAuthenticationScheme(authenticationScheme);
        }
        else {
          throw new GenericException(
              "Unable to update application. Authentication scheme selected ("
                  + authenticationPolicyTO.getScheme() + ") is not valid/available.");
        }
      }
    }

    application.setApplicationState(applicationStateDao
        .getApplicationStateByName(ApplicationState.READY_TO_PROVISION.name()));
    Application updatedApplication = applicationDao.saveOrUpdateApplication(application);
    if (provider != null) {
      providerDao.updateProvider(provider);
    }
    List<ChangeHistory> changeHistoryList =
        changeHistoryService.getRecords(applicationTO.getId(), ACTIONS.UPDATE);
    if (changeHistoryList != null && !changeHistoryList.isEmpty()) {
      String contextString = changeHistoryList.get(0).getContext();
      if (contextString.contains("OriginalValues")) {
        changeHistoryService.createChangeHistory(updatedApplication.getId(),
            ChangeHistory.ACTIONS.UPDATE,
            "Attributes=" + StringUtils.collectionToCommaDelimitedString(attributes),
            PMTConstants.SUCCESS);
      }
    }
    else {
      changeHistoryService.createChangeHistory(updatedApplication.getId(),
          ChangeHistory.ACTIONS.UPDATE,
          "Attributes=" + StringUtils.collectionToCommaDelimitedString(attributes)
              + "|OriginalValues=" + "name:" + originalName + ", description:"
              + originalDescription + ", scheme:" + originalScheme, PMTConstants.SUCCESS);
    }

    ApplicationTO applicationTO2 = new ApplicationTO(updatedApplication);
    applicationUpdateTO.setApplicationTO(applicationTO2);
    genericResponse.setContent(applicationUpdateTO);
    genericResponse.setMessage("Application has been updated successfully.");
    genericResponse.setStatus(GenericResponse.SUCCESS);
    genericResponse.setStatusCode(HttpStatus.OK.value());
    return genericResponse;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.persistent.pmt.service.ApplicationService#
   * getLastUpdateForApplicationId(int) This method prepare
   * consolidated list of changed attribute names from all the UPDATE
   * type change history record of a given application.
   */
  @SuppressWarnings("unchecked")
  @Override
  public GenericResponse<?> getLastUpdateForApplicationId(int id) throws GenericException {
    GenericResponse<ApplicationUpdateTO> response = new GenericResponse<>();
    GenericResponse<ApplicationTO> res =
        (GenericResponse<ApplicationTO>) getApplicationById(id);
    ApplicationTO applicationTO = res.getContent();
    ApplicationUpdateTO applicationUpdateTO = new ApplicationUpdateTO();
    applicationUpdateTO.setApplicationTO(applicationTO);
    List<ChangeHistory> changeHistoryList = changeHistoryService.getRecords(id, ACTIONS.UPDATE);

    List<String> attributes = new ArrayList<>();
    Set<String> uniqueAttributes = new HashSet<>();
    for (ChangeHistory changeHistory : changeHistoryList) {
      if (changeHistory != null && changeHistory.getContext() != null
          && changeHistory.getContext().indexOf("=") > 0) {
        Set<String> keys =
            (HashSet<String>) AuditUtils.parseContext(changeHistory.getContext(), "Attributes",
                CONTEXT_FORMAT_TYPE.KEYS);
        uniqueAttributes.addAll(keys);
      }

    }
    attributes.addAll(uniqueAttributes);
    applicationUpdateTO.setAttributes(attributes);
    response.setStatus(GenericResponse.SUCCESS);
    response.setStatusCode(HttpStatus.OK.value());
    response.setContent(applicationUpdateTO);
    return response;
  }

  private Provider fetchApplicationProvider(Application application, String environment) {

    Provider provider = null;
    // apply change to fetch provider details
    // Fed + saml : fetch KEY_SPID from application attributes and
    // find match in rovider attribute
    // Agent + Fed : fetch KEY_IdPID from auth scheme attribuite and
    // match in provider attribute
    // only fed : fetch provider name from application attribute and
    // match in provider name
    String pepType = application.getPepType();

    AuthenticationScheme authScheme = application.getDefaultAuthScheme();
    if (PMTConstants.PEP_TYPE_AGENT.equals(pepType) && null != authScheme
        && AuthenticationSchemeTypes.AUTHN_SCHEME_SAML2.getValue().equals(authScheme.getType())) {

      String keyIdpId = authScheme.getSourceAttValueByName(PMTConstants.KEY_IDPID);
      if (null != keyIdpId) {
        List<ProviderAttributes> attrList =
            providerDao.getProviderAttributesBySourceAttr(PMTConstants.IDPID, keyIdpId);
        provider = fetchProviderByXIDandEnv(provider, environment, attrList);
      }
    }
    else if (PMTConstants.PEP_TYPE_FEDERATION.equals(pepType) && null != authScheme) {

      if (AuthenticationSchemeTypes.AUTHN_SCHEME_WSFED.getValue().equals(authScheme.getType())) {
        // This is the case where application is originally WSFED SP
        // application
        String providerName =
            application.getSourceAttributeValueByName(PMTConstants.PROVIDER_NAME);
        // fetch provider directly by provider name
        if (null != providerName) {
          List<ProviderAttributes> attrList =
              providerDao
                  .getProviderAttributesBySourceAttr(PMTConstants.KEY_RPID, providerName);
          provider = fetchProviderByXIDandEnv(provider, environment, attrList);
        }
      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_SAML.getValue().equals(
          authScheme.getType())
          || AuthenticationSchemeTypes.AUTHN_SCHEME_OAUTH.getValue().equals(
              authScheme.getType())) {
        // This is a case where User changes the scheme of originally
        // agent based application
        // to SAML or OAUTH
        provider = providerDao.getProviderByName(application.getName());

      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_SAML2.getValue().equals(
          authScheme.getType())) {
        // This is the case where application is originally SAML SP
        // application
        String providerName =
            application.getSourceAttributeValueByName(PMTConstants.PROVIDER_NAME);
        if (null != providerName) {
          List<ProviderAttributes> attrList =
              providerDao.getProviderAttributesBySourceAttr(PMTConstants.SPID, providerName);
          provider = fetchProviderByXIDandEnv(provider, environment, attrList);
        }
      }
    }
    return provider;
  }

  private Provider fetchProviderByXIDandEnv(Provider provider, String environment,
      List<ProviderAttributes> attrList) {
    if (attrList != null && !attrList.isEmpty()) {
      for (ProviderAttributes attr : attrList) {
        for (ProviderAttributes providerAttributes : attr.fetchProvider().getAttributes()) {
          if ("XID".equals(providerAttributes.getSourceAttrName())) {

            if (environment != null && providerAttributes.getSourceAttrValue() != null
                && providerAttributes.getSourceAttrValue().contains(environment)) {
              provider = providerAttributes.fetchProvider();
            }
            break;
          }
        }
        if (provider != null) {
          break;
        }
      }
    }
    return provider;
  }

  @Override
  public ApplicationCombineTO getCombinedApplicationTO(List<Integer> appIds)
      throws GenericException {

    List<Application> applications = applicationDao.getApplicationsById(appIds);
    ApplicationCombineTO appCombineTO = null;
    if (applications.size() > 1) {

      appCombineTO = new ApplicationCombineTO(applications);
    }
    else {
      throw new GenericException("One or more of selected applications does not exists",
          HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
    }
    return appCombineTO;
  }

  @Override
  public Application createCombinedApplication(ApplicationCombineTO applicationCombineTO)
      throws GenericException {

    // Validating application name before creating combine application
    validationService.validateApplicationName(applicationCombineTO.getName(), 0);
    Application createdApplication = null;
    Application combinedApplication =
        combinedApplicationMapper.getApplicationEntity(applicationCombineTO);

    if (null != combinedApplication) {
      List<AuthenticationPolicy> authnPolicies =
          combinedApplication.getAuthenticationPolicies();
      List<AuthorizationPolicy> authzPolicies = combinedApplication.getAuthorizationPolicies();

      if (null != authzPolicies) {
        for (AuthorizationPolicy authzPolicy : authzPolicies) {
          authorizationPolicyDao.createAuthorizationPolicy(authzPolicy);
        }
      }
      if (null != authnPolicies) {
        for (AuthenticationPolicy authnpolicy : authnPolicies) {
          authenticationPolicyDao.createAuthenticationPolicy(authnpolicy);
        }
      }
      createdApplication = applicationDao.saveOrUpdateApplication(combinedApplication);
      for (Integer appId : applicationCombineTO.getCombinedAppIds()) {
        updateApplicationState(appId,
            com.persistent.pmt.constant.ApplicationState.COMBINED.name());
      }
    }
    else {
      throw new GenericException(
          "Unable to combine applications since combined applications data is blank empty.",
          HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
    }
    return createdApplication;
  }

  @Override
  public GenericResponse<?> updateStateForAllApplications(List<Integer> appIds, String state)
      throws GenericException {
    GenericResponse<List<ApplicationTO>> response = new GenericResponse<>();

    List<Application> applications = applicationDao.getApplicationsById(appIds);
    com.persistent.pmt.model.ApplicationState newState = null;
    List<ApplicationTO> applicationsTO = new ArrayList<ApplicationTO>();
    if (applications != null && !applications.isEmpty()) {
      newState = applicationStateDao.getApplicationStateByName(state);

      if (newState != null) {
        List<Application> updatedApplications =
            applicationDao.updateApplicationsStateById(applications, newState);

        for (Application app : updatedApplications) {
          changeHistoryService.createChangeHistory(app.getId(), ACTIONS.STATE_UPDATE,
              "Application state has been successfully updated to '" + state + "'.",
              PMTConstants.SUCCESS);
          applicationsTO.add(new ApplicationTO(app));
        }

        response.setContent(applicationsTO);
        response.setStatusCode(HttpStatus.OK.value());
        response.setMessage("Application state has been successfully updated to '" + state
            + "'.");
        response.setStatus(GenericResponse.SUCCESS);
      }
      else {
        for (Integer ids : appIds) {
          changeHistoryService.createChangeHistory(ids, ACTIONS.STATE_UPDATE,
              "Failed to update application state to '" + state
                  + "' since state specified is invalid.", PMTConstants.FAILURE);
        }
        throw new GenericException("Failed to update application state to '" + state
            + "' since state specified is invalid.", HttpStatus.NOT_FOUND.value(),
            GenericResponse.FAILURE);
      }
    }
    else {
      for (Integer ids : appIds) {
        changeHistoryService.createChangeHistory(ids, ACTIONS.STATE_UPDATE,
            "Failed to update application state to '" + state + "' since application with id: "
                + ids + "  does not exist.", PMTConstants.FAILURE);
      }
      throw new GenericException("Failed to update application state to '" + state
          + "' since application  does not exist.", HttpStatus.NOT_FOUND.value(),
          GenericResponse.FAILURE);
    }

    return response;
  }
}
