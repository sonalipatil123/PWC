package com.persistent.pmt.utils;

import java.io.ByteArrayInputStream;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@Configuration
@DependsOn({ "multipartResolver" })
public class MultiPartFormUtils {

	@Autowired
	CommonsMultipartResolver multipartResolver;

	public static String multiPartFileRead(MultipartFile file) {
		String content = "";

		if (!file.isEmpty()) {
			try {
				ByteArrayInputStream stream = new ByteArrayInputStream(
						file.getBytes());
				content = IOUtils.toString(stream, "UTF-8");
			} catch (Exception e) {
				return "You failed to upload " + file.getOriginalFilename()
						+ " => " + e.getMessage();
			}
		} else {
			return "You failed to upload " + file.getOriginalFilename()
					+ " because the file was empty.";
		}

		return content;
	}
}
