package com.persistent.pmt.to.openam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.model.Provider;
import com.persistent.pmt.model.ProviderAttributes;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProviderTO {

  private String name;
  private String description;
  private String type;
  private boolean remote;
  private Map<String, String> providerAttributesMap = new HashMap<>();

  public ProviderTO() {
  }

  public ProviderTO(Provider provider) {
    this.name = provider.getName();
    this.description = provider.getDescription();
    this.type = provider.getType();
    this.remote = provider.isRemote();
    List<ProviderAttributes> attributes = provider.getAttributes();
    for (ProviderAttributes attribute : attributes) {
      if (attribute != null) {
        if (attribute.getSourceAttrName() != null && attribute.getSourceAttrValue() != null) {
          providerAttributesMap.put(attribute.getSourceAttrName(),
              attribute.getSourceAttrValue());
        }
      }
    }

  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public boolean isRemote() {
    return remote;
  }

  public void setRemote(boolean remote) {
    this.remote = remote;
  }

  public Map<String, String> getProviderAttributesMap() {
    return providerAttributesMap;
  }

  public void setProviderAttributesMap(Map<String, String> providerAttributesMap) {
    this.providerAttributesMap = providerAttributesMap;
  }

  @Override
  public String toString() {

    StringBuilder builder = new StringBuilder();
    builder.append("ProviderTO [name=");
    builder.append(name);
    builder.append(", description=");
    builder.append(description);
    builder.append(", type=");
    builder.append(type);
    builder.append(", remote=");
    builder.append(remote);
    builder.append(", providerAttributesMap=");
    builder.append(providerAttributesMap);
    builder.append("]");

    return builder.toString();

  }

}
