package com.persistent.pmt.metadata.generator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.MapperConstants;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.metadata.generator.XmlUtils.XmlSourceGenerator;
import com.persistent.pmt.metadata.generator.XmlUtils.XmlWriter;
import com.persistent.pmt.metadata.generator.descriptors.core.Descriptor;
import com.persistent.pmt.metadata.generator.descriptors.core.DescriptorFactory;
import com.persistent.pmt.metadata.generator.descriptors.entity.Contacts;
import com.persistent.pmt.metadata.generator.descriptors.entity.EntityDescriptor;
import com.persistent.pmt.metadata.generator.descriptors.idp.IdpAttribute;

@Component
public class MetadataGenerator {

	@Autowired
	DescriptorFactory descriptorFactory;

	@Autowired
	XmlSourceGenerator xmlSourceGenerator;

	@Autowired
	EntityDescriptor entityDescriptor;

	@Autowired
	IdpAttribute idpAttribute;

	@Autowired
	Contacts contacts;

	public String generateMetadata(Map<String, String> tokenMap, String providerName, 
			String templatePath, String creationPath, Map<String, String> map, String descriptor)
			throws GenericException {

		Descriptor descriptorAttrObj = null;

		// creates an instance of IdP attribute
		if (MapperConstants.IDP_DESCRIPTOR.equals(descriptor)) {
			descriptorAttrObj = idpAttribute;
			descriptorAttrObj.setTemplatePath(templatePath + "/" + map.get(MapperConstants.IDP_ATTRIBUTE_TEMPLATE));
		}

		// descriptor factory creates the instance of descriptor that user want to
		// create
		// Ex.SpDescriptor
		Descriptor descriptorObj = descriptorFactory.getDescriptor(descriptor, descriptorAttrObj);
		descriptorObj.setTemplatePath(templatePath + "/" + map.get(MapperConstants.DESCRIPTOR_TEMPLATE));
		tokenMap = descriptorObj.getDescriptorData(tokenMap);

		// creates an instance of Contacts
		contacts.setTemplatePath(templatePath + "/" + map.get(MapperConstants.CONTACTS_TEMPLATE));

		// forms the descriptorEntities map by passing tokenMap
		entityDescriptor.setDescriptor(descriptorObj);
		entityDescriptor.setContact(contacts);
		entityDescriptor.setTemplatePath(templatePath + "/" + map.get(MapperConstants.ENTITY_TEMPLATE));
		tokenMap = entityDescriptor.getDescriptorData(tokenMap);

		// xmlSourceGenerator reads the template and generates metadata file from that
		// template with values of tokenMap map
		String xmlSource = entityDescriptor.getXMLData(tokenMap);


		// this is the name of metadata file which user want to create
		String metadataFileName = creationPath + "/" + providerName + ".xml";
		XmlWriter.stringToDom(xmlSource, metadataFileName);
		return xmlSource;
	}
}
