package com.persistent.pmt.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.dao.ApplicationDao;
import com.persistent.pmt.dao.ProviderDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Provider;
import com.persistent.pmt.model.ProviderAttributes;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.service.ProviderService;
import com.persistent.pmt.to.openam.ProviderTO;

@Service("providerService")
@Transactional
public class ProviderServiceImpl implements ProviderService {

	@Autowired
	ApplicationDao applicationDao;

	@Autowired
	ProviderDao providerDao;

	@Override
	public GenericResponse<?> getProviders(String type) throws GenericException {
		GenericResponse<List<ProviderTO>> response = new GenericResponse<>();
		List<ProviderTO> list = new ArrayList<>();
		response.setMessage("Providers returned successfully.");
		response.setStatus(GenericResponse.SUCCESS);
		response.setStatusCode(HttpStatus.OK.value());
		List<Provider> providerList = applicationDao.getProviders(type);
		for (Provider provider : providerList) {
			ProviderTO providerTO = new ProviderTO(provider);
			list.add(providerTO);
		}
		response.setContent(list);
		return response;
	}

	@Override
	public GenericResponse<?> createProviders(ProviderTO providerTO) throws GenericException {
		GenericResponse<Provider> response = new GenericResponse<>();
		Map<String, Object> map = new HashMap<String, Object>();
		if (providerTO != null) {

			Provider providerExists = providerDao.getProviderByName(providerTO.getName());
			if (providerExists != null) {
				providerExists.setName(providerTO.getName());
				providerExists.setDescription(providerTO.getDescription());
				providerExists.setType(providerTO.getType());
				providerExists.setRemote(providerTO.isRemote());
				List<ProviderAttributes> providerAttributesList = providerExists.getAttributes();

				for (ProviderAttributes attribute : providerAttributesList) {
					map.put(attribute.getSourceAttrName(), attribute);
				}

				for (Entry<String, String> entry : providerTO.getProviderAttributesMap().entrySet()) {
					if (map.containsKey(entry.getKey())) {
						((ProviderAttributes) map.get(entry.getKey())).setSourceAttrValue(entry.getValue());
					} else {
						ProviderAttributes providerAttributes = new ProviderAttributes();
						providerAttributes.setSourceAttrName(entry.getKey());
						providerAttributes.setSourceAttrValue(entry.getValue());
						providerAttributesList.add(providerAttributes);
					}
				}

				providerExists.setAttributes(providerAttributesList);
				providerDao.updateProvider(providerExists);
				response.setContent(providerExists);

			} else {
				Provider provider = new Provider();
				provider.setName(providerTO.getName());
				provider.setDescription(providerTO.getDescription());
				provider.setType(providerTO.getType());

				List<ProviderAttributes> providerAttributesList = new ArrayList<>();
				for (Map.Entry<String, String> providerToAttributes : providerTO.getProviderAttributesMap()
						.entrySet()) {
					if (providerToAttributes != null) {
						if (providerToAttributes.getKey() != null && providerToAttributes.getValue() != null) {
							ProviderAttributes providerAttributes = new ProviderAttributes();
							providerAttributes.setSourceAttrName(providerToAttributes.getKey());
							providerAttributes.setSourceAttrValue(providerToAttributes.getValue());

							providerAttributesList.add(providerAttributes);
						}
					}
				}
				provider.setAttributes(providerAttributesList);
				providerDao.createProvider(provider);
				response.setContent(provider);
			}
			response.setMessage("Provider has been created successfully.");
			response.setStatus(GenericResponse.SUCCESS);
			response.setStatusCode(HttpStatus.OK.value());
		} else {
			throw new GenericException("Provider information is empty.", HttpStatus.INTERNAL_SERVER_ERROR.value(),
					GenericResponse.FAILURE);
		}
		return response;
	}

}
