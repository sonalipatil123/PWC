package com.persistent.pmt.to.openam;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConditionTO implements Serializable {
  /**
	 * 
	 */
	private static final long serialVersionUID = -7674782549305682211L;
	private String name;
  private String type;
  private String value;
  private boolean negate;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public Boolean getNegate() {
    return negate;
  }

  public void setNegate(Boolean negate) {
    this.negate = negate;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("ConditionTO [name=");
    builder.append(name);
    builder.append(", type=");
    builder.append(type);
    builder.append(", value=");
    builder.append(value);
    builder.append(", negate=");
    builder.append(negate);
    builder.append("]");
    return builder.toString();
  }

}
