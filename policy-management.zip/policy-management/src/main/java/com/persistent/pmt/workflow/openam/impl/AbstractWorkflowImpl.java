package com.persistent.pmt.workflow.openam.impl;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.persistent.pmt.commons.context.TargetConnectionTemplate;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.helper.SSOAuthTokenHelper;
import com.persistent.pmt.service.ServerConfigurationService;

public abstract class AbstractWorkflowImpl {

  @Autowired
  @Qualifier("openAMApiTokenHelper")
  protected SSOAuthTokenHelper ssoAuthTokenHelper;

  @Autowired
  protected Environment environment;

  @Autowired
  ServerConfigurationService serverConfigurationService;

  protected WorkFlowContext createWorkflowContext(String lifeCycle, List<WorkflowError> errors)
      throws GenericException {
    WorkFlowContext context = new WorkFlowContext();

    TargetConnectionTemplate targetConnectionTemplate =
        serverConfigurationService.getTargetConnectionTemplate();

    String ssoToken = ssoAuthTokenHelper.getAPIToken(targetConnectionTemplate, errors);
    context.setToken(PMTConstants.CONTEXT_AUTHTOKEN, ssoToken);
    context.setToken(PMTConstants.CONTEXT_LIFECYCLE, lifeCycle);
    context.setToken(PMTConstants.CONTEXT_API_BASE_URL, targetConnectionTemplate.getApiUrl());
    context.setToken(PMTConstants.CONTEXT_ADMIN_PASSWORD,
        targetConnectionTemplate.getAdminPassword());
    context.setToken(PMTConstants.CONTEXT_ADMIN_USER, targetConnectionTemplate.getAdminUser());

    context
        .setToken(PMTConstants.CONTEXT_API_VERSION, targetConnectionTemplate.getApiVersion());

    return context;

  }

  protected String getNewWorkflowId() {
    SecureRandom random = new SecureRandom();
    return new BigInteger(130, random).toString(32);
  }
}
