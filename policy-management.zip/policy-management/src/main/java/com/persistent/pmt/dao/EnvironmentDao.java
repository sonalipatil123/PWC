/**
 * EnvironmentDao
 * 
 * DAO interface for Environment
 */

package com.persistent.pmt.dao;

import java.util.List;

import com.persistent.pmt.model.Environment;

public interface EnvironmentDao {

	public Environment getEnvironmentByName(String name);

  public Environment getEnvironmentNameById(int id);

  public List<Environment> getAllEnvironments();

}
