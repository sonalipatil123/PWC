package com.persistent.pmt.to.openam;

import java.util.Map;

public class PropsTO {

  Map<String, String> system;
  Map<String, String> target;

  public Map<String, String> getSystem() {
    return system;
  }

  public void setSystem(Map<String, String> source) {
    this.system = source;
  }

  public Map<String, String> getTarget() {
    return target;
  }

  public void setTarget(Map<String, String> target) {
    this.target = target;
  }

}
