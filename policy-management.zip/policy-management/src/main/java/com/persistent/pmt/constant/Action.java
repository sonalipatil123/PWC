/**
 * 
 */
package com.persistent.pmt.constant;

/**
 * @author akriti_gupta
 *
 */
public enum Action {

	GET, PUT, POST, DELETE

}
