package com.persistent.pmt.response.openam;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Result {

  private String _id;
  private String _rev;
  @JsonIgnore
  private Map<String, Object> signEncOAuth2ClientConfig;
  @JsonIgnore
  private Map<String, Object> coreOAuth2ClientConfig;
  @JsonIgnore
  private Map<String, Object> coreOpenIDClientConfig;
  @JsonIgnore
  private Map<String, Object> advancedOAuth2ClientConfig;
  @JsonIgnore
  private Map<String, Object> coreUmaClientConfig;
  @JsonIgnore
  private Type _type;

  public String get_id() {
    return _id;
  }

  public void set_id(String _id) {
    this._id = _id;
  }

  public String get_rev() {
    return _rev;
  }

  public void set_rev(String _rev) {
    this._rev = _rev;
  }

  public Map<String, Object> getSignEncOAuth2ClientConfig() {
    return signEncOAuth2ClientConfig;
  }

  public void setSignEncOAuth2ClientConfig(Map<String, Object> signEncOAuth2ClientConfig) {
    this.signEncOAuth2ClientConfig = signEncOAuth2ClientConfig;
  }

  public Map<String, Object> getCoreOAuth2ClientConfig() {
    return coreOAuth2ClientConfig;
  }

  public void setCoreOAuth2ClientConfig(Map<String, Object> coreOAuth2ClientConfig) {
    this.coreOAuth2ClientConfig = coreOAuth2ClientConfig;
  }

  public Map<String, Object> getCoreOpenIDClientConfig() {
    return coreOpenIDClientConfig;
  }

  public void setCoreOpenIDClientConfig(Map<String, Object> coreOpenIDClientConfig) {
    this.coreOpenIDClientConfig = coreOpenIDClientConfig;
  }

  public Map<String, Object> getAdvancedOAuth2ClientConfig() {
    return advancedOAuth2ClientConfig;
  }

  public void setAdvancedOAuth2ClientConfig(Map<String, Object> advancedOAuth2ClientConfig) {
    this.advancedOAuth2ClientConfig = advancedOAuth2ClientConfig;
  }

  public Map<String, Object> getCoreUmaClientConfig() {
    return coreUmaClientConfig;
  }

  public void setCoreUmaClientConfig(Map<String, Object> coreUmaClientConfig) {
    this.coreUmaClientConfig = coreUmaClientConfig;
  }

  public Type get_type() {
    return _type;
  }

  public void set_type(Type _type) {
    this._type = _type;
  }

  @Override
  public String toString() {
    return "Result [_id=" + _id + ", _rev=" + _rev + ", signEncOAuth2ClientConfig="
        + signEncOAuth2ClientConfig + ", coreOAuth2ClientConfig=" + coreOAuth2ClientConfig
        + ", coreOpenIDClientConfig=" + coreOpenIDClientConfig
        + ", advancedOAuth2ClientConfig=" + advancedOAuth2ClientConfig
        + ", coreUmaClientConfig=" + coreUmaClientConfig + ", _type=" + _type + "]";
  }

}
