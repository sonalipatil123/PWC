package com.persistent.pmt.constant;

public class MapperConstants {

	public static final String POLICY_SET_APPLICATION_TYPE = "iPlanetAMWebAgentService";
	public static final String SEPARATOR_COMMA = ",";
	public static final String SEPARATOR_PIPE = "|";
	public static final String SEPARATOR_EQUAL_TO = "=";
	public static final String ACTION_ALLOW = "Allow";
	public static final String RESOURCE_PREFIX = "*://*:*";
	public static final String RESPONSE_REDIRECT_ON_ACCEPT = "WebAgent-OnAccept-Redirect";
	public static final String RESPONSE_REDIRECT_ON_REJECT = "WebAgent-OnReject-Redirect";
	public static final String RESPONSE_HEADER = "WebAgent-HTTP-Cookie-Variable";
	public static final String RESPONSE_COOKIE = "WebAgent-HTTP-Header-Variable";
	public static final String PROPERTY_CASM_XML_BASE_PATH = "casm.xml.basepath";
	public static final String METADATA_FOLDER = "metadata";
	public static final String METADATA_TEMPLATE_FOLDER = "template";
	public static final String METADATA_CREATION_FOLDER = "createdmetadata";

	public static final String IDP_DESCRIPTOR = "IdpDescriptor";
	public static final String SP_DESCRIPTOR = "SpDescriptor";
	public static final String CLAIMS_PROVIDER_DESCRIPTOR = "ClaimsProviderDescriptor";
	public static final String RELYING_PARTY_DESCRIPTOR = "RelyingPartyDescriptor";
	public static final String DESCRIPTOR_TEMPLATE = "DescriptorTemplate";
	public static final String CONTACTS_TEMPLATE = "ContactsTemplate";
	public static final String ENTITY_TEMPLATE = "EntityTemplate";
	public static final String IDP_ATTRIBUTE_TEMPLATE = "IdPAttributeTemplate";

}
