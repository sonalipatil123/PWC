package com.persistent.pmt.workflow.action.openam.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.constant.casm.RestConstants;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.executor.openam.CircleOfTrustExecutor;
import com.persistent.pmt.executor.openam.OAuthGroupExecutor;
import com.persistent.pmt.response.TargetResponse;
import com.persistent.pmt.view.openam.ReadQueryObject;
import com.persistent.pmt.workflow.action.ReadAction;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component("openAMCommonReadActionImpl")
public class OpenAMCommonReadActionImpl implements ReadAction {

  @Autowired
  OAuthGroupExecutor oAuthGroupExecutor;

  @Autowired
  CircleOfTrustExecutor circleOfTrustExecutor;

  @Override
  public Object execute(Object object, List<WorkflowError> errors, WorkFlowContext context)
      throws Exception {
    TargetResponse targetResponse = null;
    ReadQueryObject readObjectQuery = (ReadQueryObject) object;
    if (readObjectQuery != null) {
      HashMap<String, String> params = new HashMap<String, String>();
      params.put(RestConstants.REQUEST_PATH_REALM_NAME, context.getRealmName());
      Artifact artifact = readObjectQuery.getObjectType();
      if (artifact.equals(Artifact.OAUTH_GROUP)) {
        targetResponse =
            oAuthGroupExecutor.get(readObjectQuery, Product.OPENAM, artifact, params, context);
      }
      else if (artifact.equals(Artifact.CIRCLE_OF_TRUST)) {
        targetResponse =
            circleOfTrustExecutor.get(readObjectQuery, Product.OPENAM, artifact, params,
                context);
      }
    }
    return targetResponse;
  }
}
