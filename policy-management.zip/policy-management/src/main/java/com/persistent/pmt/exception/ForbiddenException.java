package com.persistent.pmt.exception;

import org.springframework.http.HttpStatus;

import com.persistent.pmt.response.GenericResponse;



public class ForbiddenException extends Exception {

	private static final long serialVersionUID = 1L;
	private GenericResponse errorResponse;

	public ForbiddenException(String message) {
		errorResponse = new GenericResponse();
		errorResponse.setStatusCode(HttpStatus.FORBIDDEN.value());
		errorResponse.setMessage(message);
		errorResponse.setStatus(GenericResponse.FAILURE);
	}

	public GenericResponse getErrorResponse() {
		return errorResponse;
	}

	public void setErrorResponse(GenericResponse errorResponse) {
		this.errorResponse = errorResponse;
	}
}
