package com.persistent.pmt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * RedirectURI
 * 
 * Entity model for RedirectURI
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "redirect_uri")
public class RedirectURI {

	@JsonIgnore
	@Id
//	@SequenceGenerator(name = "SEQ_REDIRECT_URI", sequenceName = "SEQ_REDIRECT_URI", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_REDIRECT_URI")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "uri")
	private String uri;

	@ManyToOne
	@JoinColumn(name = "oauth_client_id")
	private OAuthClient oauthClient;

	public RedirectURI() {
		super();
	}

	public RedirectURI(String uri) {
		this.uri = uri;
	}

	public RedirectURI(int id, String uri) {
		this.id = id;
		this.uri = uri;
	}

	public RedirectURI(String uri, OAuthClient oauthClient) {
		this.uri = uri;
		this.oauthClient = oauthClient;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public OAuthClient getOauthClient() {
		return oauthClient;
	}

	public void setOauthClient(OAuthClient oauthClient) {
		this.oauthClient = oauthClient;
	}

	@Override
	public String toString() {
		return uri;
	}

}
