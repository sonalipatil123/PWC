package com.persistent.pmt.response.openam;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.response.TargetResponse;

@JsonInclude(Include.NON_NULL)
public class AgentResponse implements TargetResponse {
	
	private String _id;
	private String _rev;
	private Attribute profileAttributeMap;
	private Attribute fqdnMapping;
	private Attribute responseAttributeMap;
	private Attribute continuousSecurityHeaders;
	private String userpassword;
	private Attribute continuousSecurityCookies;
	private Attribute sessionAttributeMap;
	private Attribute secureCookies;
	private Attribute configurationCleanupInterval;
	private Attribute anonymousUserId;
	private Attribute ignorePreferredNamingUrl;
	private Attribute overrideProxyHostAndPort;
	private Attribute agentLocale;
	private Attribute postDataCachePeriod;
	private Attribute overrideRequestProtocol;
	private Attribute auditLogLocation;
	private Attribute cookieName;
	private Attribute encodeUrlSpecialCharacters;
	private Attribute userIdParameter;
	private Attribute policyEvaluationApplication;
	private Attribute policyEvaluationRealm;
	private Attribute checkUserInDomino;
	private Attribute profileAttributeFetchMode;
	private Attribute invertNotEnforcedUrls;
	private Attribute retrieveClientHostname;
	private Attribute status;
	private Attribute cdsso;
	private Attribute notificationsEnabled;
	private Attribute cdssoCookieDomain;
	private Attribute remoteLogFilename;
	private Attribute remoteLogSendInterval;
	private Attribute cdssoUrls;
	private Attribute clientHostnameHeader;
	private Attribute cdssoRootUrl;
	private Attribute amLogoutUrl;
	private Attribute ssoOnlyMode;
	private Attribute ignoreServerCheck;
	private Attribute ltpaTokenConfigurationname;
	private Attribute responseAttributeFetchMode;
	private Attribute agentUriPrefix;
	private Attribute userIdParameterType;
	private Attribute amLoginUrl;
	private Attribute profileAttributesCookieMaxAge;
	private Attribute configurationPollingInterval;
	private Attribute anonymousUserEnabled;
	private Attribute sessionAttributeFetchMode;
	private Attribute ssoCachePollingInterval;
	private Attribute cdssoRedirectUri;
	private Attribute idleSessionTimeoutUrl;
	private Attribute ignorePathInfo;
	private Attribute fqdnCheck;
	private Attribute localAuditLogRotation;
	private Attribute loadBalanced;
	private Attribute cookieResetEnabled;
	private Attribute webSocketConnectionIntervalInMinutes;
	private Attribute postDataPreservation;
	private Attribute agentConfigChangeNotificationsEnabled;
	private Attribute gotoParameterName;
	private Attribute authenticationType;
	private Attribute fetchAttributesForNotEnforcedUrls;
	private Attribute attributeMultiValueSeparator;
	private Attribute agentConnectionTimeout;
	private Attribute profileAttributesCookiePrefix;
	private Attribute changeProtocolToHttps;
	private Attribute debugLogRotation;
	private Attribute overrideRequestHost;
	private Attribute showPasswordInHeader;
	private Attribute policyCachePollingInterval;
	private Attribute customProperties;
	private Attribute useLtpaToken;
	private Attribute auditAccessType;
	private Attribute cookieResetList;
	private Attribute overrideRequestPort;
	private Attribute fqdnDefault;
	private Attribute logoutResetCookies;
	private Attribute agentNotificationUrl;
	private Attribute encodeSpecialCharsInCookies;
	private Attribute logonAndImpersonation;
	private Attribute encodeProfileAttributes;
	private Attribute accessDeniedUrl;
	private Attribute localAuditRotationSize;
	private Attribute jwtName;
	private Attribute ignorePathInfoForNotEnforcedUrls;
	private Attribute clientIpValidation;
	private Attribute caseInsensitiveUrlComparison;
	private Attribute notEnforcedUrls;
	private Attribute debugRotationSize;
	private Attribute filterConfiguredWithOwa;
	private Attribute notEnforcedIps;
	private Attribute policyClockSkew;
	private Attribute agentDebugLevel;
	private Attribute ltpaTokenOrganizationName;
	private Attribute overrideNotificationUrl;
	private Attribute repositoryLocation;
	private Attribute fetchPoliciesFromRootResource;
	private Attribute primaryServerPollingPeriod;
	private Attribute applicationLogoutUrls;
	private Attribute clientIpHeader;
	private Attribute ltpaTokenCookieName;
	private Attribute filterPriority;
	private Attribute logoutRedirectUrl;
	private Attribute replayPasswordKey;
	private Type _type;
	private boolean inherited;
	private String value;

	public AgentResponse() {
		super();
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String get_rev() {
		return _rev;
	}

	public void set_rev(String _rev) {
		this._rev = _rev;
	}

	public Attribute getProfileAttributeMap() {
		return profileAttributeMap;
	}

	public void setProfileAttributeMap(Attribute profileAttributeMap) {
		this.profileAttributeMap = profileAttributeMap;
	}

	public Attribute getFqdnMapping() {
		return fqdnMapping;
	}

	public void setFqdnMapping(Attribute fqdnMapping) {
		this.fqdnMapping = fqdnMapping;
	}

	public Attribute getResponseAttributeMap() {
		return responseAttributeMap;
	}

	public void setResponseAttributeMap(Attribute responseAttributeMap) {
		this.responseAttributeMap = responseAttributeMap;
	}

	public Attribute getContinuousSecurityHeaders() {
		return continuousSecurityHeaders;
	}

	public void setContinuousSecurityHeaders(Attribute continuousSecurityHeaders) {
		this.continuousSecurityHeaders = continuousSecurityHeaders;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public Attribute getContinuousSecurityCookies() {
		return continuousSecurityCookies;
	}

	public void setContinuousSecurityCookies(Attribute continuousSecurityCookies) {
		this.continuousSecurityCookies = continuousSecurityCookies;
	}

	public Attribute getSessionAttributeMap() {
		return sessionAttributeMap;
	}

	public void setSessionAttributeMap(Attribute sessionAttributeMap) {
		this.sessionAttributeMap = sessionAttributeMap;
	}

	public Attribute getSecureCookies() {
		return secureCookies;
	}

	public void setSecureCookies(Attribute secureCookies) {
		this.secureCookies = secureCookies;
	}

	public Attribute getConfigurationCleanupInterval() {
		return configurationCleanupInterval;
	}

	public void setConfigurationCleanupInterval(
			Attribute configurationCleanupInterval) {
		this.configurationCleanupInterval = configurationCleanupInterval;
	}

	public Attribute getAnonymousUserId() {
		return anonymousUserId;
	}

	public void setAnonymousUserId(Attribute anonymousUserId) {
		this.anonymousUserId = anonymousUserId;
	}

	public Attribute getIgnorePreferredNamingUrl() {
		return ignorePreferredNamingUrl;
	}

	public void setIgnorePreferredNamingUrl(Attribute ignorePreferredNamingUrl) {
		this.ignorePreferredNamingUrl = ignorePreferredNamingUrl;
	}

	public Attribute getOverrideProxyHostAndPort() {
		return overrideProxyHostAndPort;
	}

	public void setOverrideProxyHostAndPort(Attribute overrideProxyHostAndPort) {
		this.overrideProxyHostAndPort = overrideProxyHostAndPort;
	}

	public Attribute getAgentLocale() {
		return agentLocale;
	}

	public void setAgentLocale(Attribute agentLocale) {
		this.agentLocale = agentLocale;
	}

	public Attribute getPostDataCachePeriod() {
		return postDataCachePeriod;
	}

	public void setPostDataCachePeriod(Attribute postDataCachePeriod) {
		this.postDataCachePeriod = postDataCachePeriod;
	}

	public Attribute getOverrideRequestProtocol() {
		return overrideRequestProtocol;
	}

	public void setOverrideRequestProtocol(Attribute overrideRequestProtocol) {
		this.overrideRequestProtocol = overrideRequestProtocol;
	}

	public Attribute getAuditLogLocation() {
		return auditLogLocation;
	}

	public void setAuditLogLocation(Attribute auditLogLocation) {
		this.auditLogLocation = auditLogLocation;
	}

	public Attribute getCookieName() {
		return cookieName;
	}

	public void setCookieName(Attribute cookieName) {
		this.cookieName = cookieName;
	}

	public Attribute getEncodeUrlSpecialCharacters() {
		return encodeUrlSpecialCharacters;
	}

	public void setEncodeUrlSpecialCharacters(Attribute encodeUrlSpecialCharacters) {
		this.encodeUrlSpecialCharacters = encodeUrlSpecialCharacters;
	}

	public Attribute getUserIdParameter() {
		return userIdParameter;
	}

	public void setUserIdParameter(Attribute userIdParameter) {
		this.userIdParameter = userIdParameter;
	}

	public Attribute getPolicyEvaluationApplication() {
		return policyEvaluationApplication;
	}

	public void setPolicyEvaluationApplication(Attribute policyEvaluationApplication) {
		this.policyEvaluationApplication = policyEvaluationApplication;
	}

	public Attribute getPolicyEvaluationRealm() {
		return policyEvaluationRealm;
	}

	public void setPolicyEvaluationRealm(Attribute policyEvaluationRealm) {
		this.policyEvaluationRealm = policyEvaluationRealm;
	}

	public Attribute getCheckUserInDomino() {
		return checkUserInDomino;
	}

	public void setCheckUserInDomino(Attribute checkUserInDomino) {
		this.checkUserInDomino = checkUserInDomino;
	}

	public Attribute getProfileAttributeFetchMode() {
		return profileAttributeFetchMode;
	}

	public void setProfileAttributeFetchMode(Attribute profileAttributeFetchMode) {
		this.profileAttributeFetchMode = profileAttributeFetchMode;
	}

	public Attribute getInvertNotEnforcedUrls() {
		return invertNotEnforcedUrls;
	}

	public void setInvertNotEnforcedUrls(Attribute invertNotEnforcedUrls) {
		this.invertNotEnforcedUrls = invertNotEnforcedUrls;
	}

	public Attribute getRetrieveClientHostname() {
		return retrieveClientHostname;
	}

	public void setRetrieveClientHostname(Attribute retrieveClientHostname) {
		this.retrieveClientHostname = retrieveClientHostname;
	}

	public Attribute getStatus() {
		return status;
	}

	public void setStatus(Attribute status) {
		this.status = status;
	}

	public Attribute getCdsso() {
		return cdsso;
	}

	public void setCdsso(Attribute cdsso) {
		this.cdsso = cdsso;
	}

	public Attribute getNotificationsEnabled() {
		return notificationsEnabled;
	}

	public void setNotificationsEnabled(Attribute notificationsEnabled) {
		this.notificationsEnabled = notificationsEnabled;
	}

	public Attribute getCdssoCookieDomain() {
		return cdssoCookieDomain;
	}

	public void setCdssoCookieDomain(Attribute cdssoCookieDomain) {
		this.cdssoCookieDomain = cdssoCookieDomain;
	}

	public Attribute getRemoteLogFilename() {
		return remoteLogFilename;
	}

	public void setRemoteLogFilename(Attribute remoteLogFilename) {
		this.remoteLogFilename = remoteLogFilename;
	}

	public Attribute getRemoteLogSendInterval() {
		return remoteLogSendInterval;
	}

	public void setRemoteLogSendInterval(Attribute remoteLogSendInterval) {
		this.remoteLogSendInterval = remoteLogSendInterval;
	}

	public Attribute getCdssoUrls() {
		return cdssoUrls;
	}

	public void setCdssoUrls(Attribute cdssoUrls) {
		this.cdssoUrls = cdssoUrls;
	}

	public Attribute getClientHostnameHeader() {
		return clientHostnameHeader;
	}

	public void setClientHostnameHeader(Attribute clientHostnameHeader) {
		this.clientHostnameHeader = clientHostnameHeader;
	}

	public Attribute getCdssoRootUrl() {
		return cdssoRootUrl;
	}

	public void setCdssoRootUrl(Attribute cdssoRootUrl) {
		this.cdssoRootUrl = cdssoRootUrl;
	}

	public Attribute getAmLogoutUrl() {
		return amLogoutUrl;
	}

	public void setAmLogoutUrl(Attribute amLogoutUrl) {
		this.amLogoutUrl = amLogoutUrl;
	}

	public Attribute getSsoOnlyMode() {
		return ssoOnlyMode;
	}

	public void setSsoOnlyMode(Attribute ssoOnlyMode) {
		this.ssoOnlyMode = ssoOnlyMode;
	}

	public Attribute getIgnoreServerCheck() {
		return ignoreServerCheck;
	}

	public void setIgnoreServerCheck(Attribute ignoreServerCheck) {
		this.ignoreServerCheck = ignoreServerCheck;
	}

	public Attribute getLtpaTokenConfigurationname() {
		return ltpaTokenConfigurationname;
	}

	public void setLtpaTokenConfigurationname(Attribute ltpaTokenConfigurationname) {
		this.ltpaTokenConfigurationname = ltpaTokenConfigurationname;
	}

	public Attribute getResponseAttributeFetchMode() {
		return responseAttributeFetchMode;
	}

	public void setResponseAttributeFetchMode(Attribute responseAttributeFetchMode) {
		this.responseAttributeFetchMode = responseAttributeFetchMode;
	}

	public Attribute getAgentUriPrefix() {
		return agentUriPrefix;
	}

	public void setAgentUriPrefix(Attribute agentUriPrefix) {
		this.agentUriPrefix = agentUriPrefix;
	}

	public Attribute getUserIdParameterType() {
		return userIdParameterType;
	}

	public void setUserIdParameterType(Attribute userIdParameterType) {
		this.userIdParameterType = userIdParameterType;
	}

	public Attribute getAmLoginUrl() {
		return amLoginUrl;
	}

	public void setAmLoginUrl(Attribute amLoginUrl) {
		this.amLoginUrl = amLoginUrl;
	}

	public Attribute getProfileAttributesCookieMaxAge() {
		return profileAttributesCookieMaxAge;
	}

	public void setProfileAttributesCookieMaxAge(
			Attribute profileAttributesCookieMaxAge) {
		this.profileAttributesCookieMaxAge = profileAttributesCookieMaxAge;
	}

	public Attribute getConfigurationPollingInterval() {
		return configurationPollingInterval;
	}

	public void setConfigurationPollingInterval(
			Attribute configurationPollingInterval) {
		this.configurationPollingInterval = configurationPollingInterval;
	}

	public Attribute getAnonymousUserEnabled() {
		return anonymousUserEnabled;
	}

	public void setAnonymousUserEnabled(Attribute anonymousUserEnabled) {
		this.anonymousUserEnabled = anonymousUserEnabled;
	}

	public Attribute getSessionAttributeFetchMode() {
		return sessionAttributeFetchMode;
	}

	public void setSessionAttributeFetchMode(Attribute sessionAttributeFetchMode) {
		this.sessionAttributeFetchMode = sessionAttributeFetchMode;
	}

	public Attribute getSsoCachePollingInterval() {
		return ssoCachePollingInterval;
	}

	public void setSsoCachePollingInterval(Attribute ssoCachePollingInterval) {
		this.ssoCachePollingInterval = ssoCachePollingInterval;
	}

	public Attribute getCdssoRedirectUri() {
		return cdssoRedirectUri;
	}

	public void setCdssoRedirectUri(Attribute cdssoRedirectUri) {
		this.cdssoRedirectUri = cdssoRedirectUri;
	}

	public Attribute getIdleSessionTimeoutUrl() {
		return idleSessionTimeoutUrl;
	}

	public void setIdleSessionTimeoutUrl(Attribute idleSessionTimeoutUrl) {
		this.idleSessionTimeoutUrl = idleSessionTimeoutUrl;
	}

	public Attribute getIgnorePathInfo() {
		return ignorePathInfo;
	}

	public void setIgnorePathInfo(Attribute ignorePathInfo) {
		this.ignorePathInfo = ignorePathInfo;
	}

	public Attribute getFqdnCheck() {
		return fqdnCheck;
	}

	public void setFqdnCheck(Attribute fqdnCheck) {
		this.fqdnCheck = fqdnCheck;
	}

	public Attribute getLocalAuditLogRotation() {
		return localAuditLogRotation;
	}

	public void setLocalAuditLogRotation(Attribute localAuditLogRotation) {
		this.localAuditLogRotation = localAuditLogRotation;
	}

	public Attribute getLoadBalanced() {
		return loadBalanced;
	}

	public void setLoadBalanced(Attribute loadBalanced) {
		this.loadBalanced = loadBalanced;
	}

	public Attribute getCookieResetEnabled() {
		return cookieResetEnabled;
	}

	public void setCookieResetEnabled(Attribute cookieResetEnabled) {
		this.cookieResetEnabled = cookieResetEnabled;
	}

	public Attribute getWebSocketConnectionIntervalInMinutes() {
		return webSocketConnectionIntervalInMinutes;
	}

	public void setWebSocketConnectionIntervalInMinutes(
			Attribute webSocketConnectionIntervalInMinutes) {
		this.webSocketConnectionIntervalInMinutes = webSocketConnectionIntervalInMinutes;
	}

	public Attribute getPostDataPreservation() {
		return postDataPreservation;
	}

	public void setPostDataPreservation(Attribute postDataPreservation) {
		this.postDataPreservation = postDataPreservation;
	}

	public Attribute getAgentConfigChangeNotificationsEnabled() {
		return agentConfigChangeNotificationsEnabled;
	}

	public void setAgentConfigChangeNotificationsEnabled(
			Attribute agentConfigChangeNotificationsEnabled) {
		this.agentConfigChangeNotificationsEnabled = agentConfigChangeNotificationsEnabled;
	}

	public Attribute getGotoParameterName() {
		return gotoParameterName;
	}

	public void setGotoParameterName(Attribute gotoParameterName) {
		this.gotoParameterName = gotoParameterName;
	}

	public Attribute getAuthenticationType() {
		return authenticationType;
	}

	public void setAuthenticationType(Attribute authenticationType) {
		this.authenticationType = authenticationType;
	}

	public Attribute getFetchAttributesForNotEnforcedUrls() {
		return fetchAttributesForNotEnforcedUrls;
	}

	public void setFetchAttributesForNotEnforcedUrls(
			Attribute fetchAttributesForNotEnforcedUrls) {
		this.fetchAttributesForNotEnforcedUrls = fetchAttributesForNotEnforcedUrls;
	}

	public Attribute getAttributeMultiValueSeparator() {
		return attributeMultiValueSeparator;
	}

	public void setAttributeMultiValueSeparator(
			Attribute attributeMultiValueSeparator) {
		this.attributeMultiValueSeparator = attributeMultiValueSeparator;
	}

	public Attribute getAgentConnectionTimeout() {
		return agentConnectionTimeout;
	}

	public void setAgentConnectionTimeout(Attribute agentConnectionTimeout) {
		this.agentConnectionTimeout = agentConnectionTimeout;
	}

	public Attribute getProfileAttributesCookiePrefix() {
		return profileAttributesCookiePrefix;
	}

	public void setProfileAttributesCookiePrefix(
			Attribute profileAttributesCookiePrefix) {
		this.profileAttributesCookiePrefix = profileAttributesCookiePrefix;
	}

	public Attribute getChangeProtocolToHttps() {
		return changeProtocolToHttps;
	}

	public void setChangeProtocolToHttps(Attribute changeProtocolToHttps) {
		this.changeProtocolToHttps = changeProtocolToHttps;
	}

	public Attribute getDebugLogRotation() {
		return debugLogRotation;
	}

	public void setDebugLogRotation(Attribute debugLogRotation) {
		this.debugLogRotation = debugLogRotation;
	}

	public Attribute getOverrideRequestHost() {
		return overrideRequestHost;
	}

	public void setOverrideRequestHost(Attribute overrideRequestHost) {
		this.overrideRequestHost = overrideRequestHost;
	}

	public Attribute getShowPasswordInHeader() {
		return showPasswordInHeader;
	}

	public void setShowPasswordInHeader(Attribute showPasswordInHeader) {
		this.showPasswordInHeader = showPasswordInHeader;
	}

	public Attribute getPolicyCachePollingInterval() {
		return policyCachePollingInterval;
	}

	public void setPolicyCachePollingInterval(Attribute policyCachePollingInterval) {
		this.policyCachePollingInterval = policyCachePollingInterval;
	}

	public Attribute getCustomProperties() {
		return customProperties;
	}

	public void setCustomProperties(Attribute customProperties) {
		this.customProperties = customProperties;
	}

	public Attribute getUseLtpaToken() {
		return useLtpaToken;
	}

	public void setUseLtpaToken(Attribute useLtpaToken) {
		this.useLtpaToken = useLtpaToken;
	}

	public Attribute getAuditAccessType() {
		return auditAccessType;
	}

	public void setAuditAccessType(Attribute auditAccessType) {
		this.auditAccessType = auditAccessType;
	}

	public Attribute getCookieResetList() {
		return cookieResetList;
	}

	public void setCookieResetList(Attribute cookieResetList) {
		this.cookieResetList = cookieResetList;
	}

	public Attribute getOverrideRequestPort() {
		return overrideRequestPort;
	}

	public void setOverrideRequestPort(Attribute overrideRequestPort) {
		this.overrideRequestPort = overrideRequestPort;
	}

	public Attribute getFqdnDefault() {
		return fqdnDefault;
	}

	public void setFqdnDefault(Attribute fqdnDefault) {
		this.fqdnDefault = fqdnDefault;
	}

	public Attribute getLogoutResetCookies() {
		return logoutResetCookies;
	}

	public void setLogoutResetCookies(Attribute logoutResetCookies) {
		this.logoutResetCookies = logoutResetCookies;
	}

	public Attribute getAgentNotificationUrl() {
		return agentNotificationUrl;
	}

	public void setAgentNotificationUrl(Attribute agentNotificationUrl) {
		this.agentNotificationUrl = agentNotificationUrl;
	}

	public Attribute getEncodeSpecialCharsInCookies() {
		return encodeSpecialCharsInCookies;
	}

	public void setEncodeSpecialCharsInCookies(Attribute encodeSpecialCharsInCookies) {
		this.encodeSpecialCharsInCookies = encodeSpecialCharsInCookies;
	}

	public Attribute getLogonAndImpersonation() {
		return logonAndImpersonation;
	}

	public void setLogonAndImpersonation(Attribute logonAndImpersonation) {
		this.logonAndImpersonation = logonAndImpersonation;
	}

	public Attribute getEncodeProfileAttributes() {
		return encodeProfileAttributes;
	}

	public void setEncodeProfileAttributes(Attribute encodeProfileAttributes) {
		this.encodeProfileAttributes = encodeProfileAttributes;
	}

	public Attribute getAccessDeniedUrl() {
		return accessDeniedUrl;
	}

	public void setAccessDeniedUrl(Attribute accessDeniedUrl) {
		this.accessDeniedUrl = accessDeniedUrl;
	}

	public Attribute getLocalAuditRotationSize() {
		return localAuditRotationSize;
	}

	public void setLocalAuditRotationSize(Attribute localAuditRotationSize) {
		this.localAuditRotationSize = localAuditRotationSize;
	}

	public Attribute getJwtName() {
		return jwtName;
	}

	public void setJwtName(Attribute jwtName) {
		this.jwtName = jwtName;
	}

	public Attribute getIgnorePathInfoForNotEnforcedUrls() {
		return ignorePathInfoForNotEnforcedUrls;
	}

	public void setIgnorePathInfoForNotEnforcedUrls(
			Attribute ignorePathInfoForNotEnforcedUrls) {
		this.ignorePathInfoForNotEnforcedUrls = ignorePathInfoForNotEnforcedUrls;
	}

	public Attribute getClientIpValidation() {
		return clientIpValidation;
	}

	public void setClientIpValidation(Attribute clientIpValidation) {
		this.clientIpValidation = clientIpValidation;
	}

	public Attribute getCaseInsensitiveUrlComparison() {
		return caseInsensitiveUrlComparison;
	}

	public void setCaseInsensitiveUrlComparison(
			Attribute caseInsensitiveUrlComparison) {
		this.caseInsensitiveUrlComparison = caseInsensitiveUrlComparison;
	}

	public Attribute getNotEnforcedUrls() {
		return notEnforcedUrls;
	}

	public void setNotEnforcedUrls(Attribute notEnforcedUrls) {
		this.notEnforcedUrls = notEnforcedUrls;
	}

	public Attribute getDebugRotationSize() {
		return debugRotationSize;
	}

	public void setDebugRotationSize(Attribute debugRotationSize) {
		this.debugRotationSize = debugRotationSize;
	}

	public Attribute getFilterConfiguredWithOwa() {
		return filterConfiguredWithOwa;
	}

	public void setFilterConfiguredWithOwa(Attribute filterConfiguredWithOwa) {
		this.filterConfiguredWithOwa = filterConfiguredWithOwa;
	}

	public Attribute getNotEnforcedIps() {
		return notEnforcedIps;
	}

	public void setNotEnforcedIps(Attribute notEnforcedIps) {
		this.notEnforcedIps = notEnforcedIps;
	}

	public Attribute getPolicyClockSkew() {
		return policyClockSkew;
	}

	public void setPolicyClockSkew(Attribute policyClockSkew) {
		this.policyClockSkew = policyClockSkew;
	}

	public Attribute getAgentDebugLevel() {
		return agentDebugLevel;
	}

	public void setAgentDebugLevel(Attribute agentDebugLevel) {
		this.agentDebugLevel = agentDebugLevel;
	}

	public Attribute getLtpaTokenOrganizationName() {
		return ltpaTokenOrganizationName;
	}

	public void setLtpaTokenOrganizationName(Attribute ltpaTokenOrganizationName) {
		this.ltpaTokenOrganizationName = ltpaTokenOrganizationName;
	}

	public Attribute getOverrideNotificationUrl() {
		return overrideNotificationUrl;
	}

	public void setOverrideNotificationUrl(Attribute overrideNotificationUrl) {
		this.overrideNotificationUrl = overrideNotificationUrl;
	}

	public Attribute getRepositoryLocation() {
		return repositoryLocation;
	}

	public void setRepositoryLocation(Attribute repositoryLocation) {
		this.repositoryLocation = repositoryLocation;
	}

	public Attribute getFetchPoliciesFromRootResource() {
		return fetchPoliciesFromRootResource;
	}

	public void setFetchPoliciesFromRootResource(
			Attribute fetchPoliciesFromRootResource) {
		this.fetchPoliciesFromRootResource = fetchPoliciesFromRootResource;
	}

	public Attribute getPrimaryServerPollingPeriod() {
		return primaryServerPollingPeriod;
	}

	public void setPrimaryServerPollingPeriod(Attribute primaryServerPollingPeriod) {
		this.primaryServerPollingPeriod = primaryServerPollingPeriod;
	}

	public Attribute getApplicationLogoutUrls() {
		return applicationLogoutUrls;
	}

	public void setApplicationLogoutUrls(Attribute applicationLogoutUrls) {
		this.applicationLogoutUrls = applicationLogoutUrls;
	}

	public Attribute getClientIpHeader() {
		return clientIpHeader;
	}

	public void setClientIpHeader(Attribute clientIpHeader) {
		this.clientIpHeader = clientIpHeader;
	}

	public Attribute getLtpaTokenCookieName() {
		return ltpaTokenCookieName;
	}

	public void setLtpaTokenCookieName(Attribute ltpaTokenCookieName) {
		this.ltpaTokenCookieName = ltpaTokenCookieName;
	}

	public Attribute getFilterPriority() {
		return filterPriority;
	}

	public void setFilterPriority(Attribute filterPriority) {
		this.filterPriority = filterPriority;
	}

	public Attribute getLogoutRedirectUrl() {
		return logoutRedirectUrl;
	}

	public void setLogoutRedirectUrl(Attribute logoutRedirectUrl) {
		this.logoutRedirectUrl = logoutRedirectUrl;
	}

	public Attribute getReplayPasswordKey() {
		return replayPasswordKey;
	}

	public void setReplayPasswordKey(Attribute replayPasswordKey) {
		this.replayPasswordKey = replayPasswordKey;
	}

	public Type get_type() {
		return _type;
	}

	public void set_type(Type _type) {
		this._type = _type;
	}

	public boolean isInherited() {
		return inherited;
	}

	public void setInherited(boolean inherited) {
		this.inherited = inherited;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
