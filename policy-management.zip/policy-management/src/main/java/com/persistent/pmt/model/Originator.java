package com.persistent.pmt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * Originator
 * 
 * Entity model for Originator
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "originator")
public class Originator {

	@Id
//	@GenericGenerator(name = "originator_generator", strategy = "increment")
//	@GeneratedValue(generator = "originator_generator")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	public Originator() {
		super();
	}

	public Originator(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Originator [id=" + id + ", name=" + name + "]";
	}

}
