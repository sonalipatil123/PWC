/**
 * FilterContext
 * 
 * Context for filters ( used only in policy-migration) * 
 * 
 * @author abgrover
 */
package com.persistent.pmt.commons.context;

import java.util.List;

public class FilterContext {

	private List<String> filters;

	public List<String> getFilters() {
		return filters;
	}

	public void setFilters(List<String> filters) {
		this.filters = filters;
	}

}
