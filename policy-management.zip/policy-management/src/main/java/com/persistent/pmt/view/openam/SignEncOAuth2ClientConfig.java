package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class SignEncOAuth2ClientConfig {
  private Attribute jwksUri;
  private Attribute jwksCacheTimeout;
  private Attribute jwkStoreCacheMissCacheTime;
  private Attribute tokenEndpointAuthSigningAlgorithm;
  private Attribute jwkSet;
  private Attribute idTokenSignedResponseAlg;
  private Attribute idTokenEncryptionEnabled;
  private Attribute idTokenEncryptionAlgorithm;
  private Attribute idTokenEncryptionMethod;
  private Attribute idTokenPublicEncryptionKey;
  private Attribute publicKeyLocation;
  private Attribute clientJwtPublicKey;
  private Attribute userinfoResponseFormat;
  private Attribute userinfoSignedResponseAlg;
  private Attribute userinfoEncryptedResponseAlg;
  private Attribute userinfoEncryptedResponseEncryptionAlgorithm;
  private Attribute requestParameterSignedAlg;
  private Attribute requestParameterEncryptedAlg;
  private Attribute requestParameterEncryptedEncryptionAlgorithm;

  public SignEncOAuth2ClientConfig() {
    super();
  }

  public Attribute getJwksUri() {
    return jwksUri;
  }

  public void setJwksUri(Attribute jwksUri) {
    this.jwksUri = jwksUri;
  }

  public Attribute getJwksCacheTimeout() {
    return jwksCacheTimeout;
  }

  public void setJwksCacheTimeout(Attribute jwksCacheTimeout) {
    this.jwksCacheTimeout = jwksCacheTimeout;
  }

  public Attribute getJwkStoreCacheMissCacheTime() {
    return jwkStoreCacheMissCacheTime;
  }

  public void setJwkStoreCacheMissCacheTime(Attribute jwkStoreCacheMissCacheTime) {
    this.jwkStoreCacheMissCacheTime = jwkStoreCacheMissCacheTime;
  }

  public Attribute getTokenEndpointAuthSigningAlgorithm() {
    return tokenEndpointAuthSigningAlgorithm;
  }

  public void setTokenEndpointAuthSigningAlgorithm(Attribute tokenEndpointAuthSigningAlgorithm) {
    this.tokenEndpointAuthSigningAlgorithm = tokenEndpointAuthSigningAlgorithm;
  }

  public Attribute getJwkSet() {
    return jwkSet;
  }

  public void setJwkSet(Attribute jwkSet) {
    this.jwkSet = jwkSet;
  }

  public Attribute getIdTokenSignedResponseAlg() {
    return idTokenSignedResponseAlg;
  }

  public void setIdTokenSignedResponseAlg(Attribute idTokenSignedResponseAlg) {
    this.idTokenSignedResponseAlg = idTokenSignedResponseAlg;
  }

  public Attribute getIdTokenEncryptionEnabled() {
    return idTokenEncryptionEnabled;
  }

  public void setIdTokenEncryptionEnabled(Attribute idTokenEncryptionEnabled) {
    this.idTokenEncryptionEnabled = idTokenEncryptionEnabled;
  }

  public Attribute getIdTokenEncryptionAlgorithm() {
    return idTokenEncryptionAlgorithm;
  }

  public void setIdTokenEncryptionAlgorithm(Attribute idTokenEncryptionAlgorithm) {
    this.idTokenEncryptionAlgorithm = idTokenEncryptionAlgorithm;
  }

  public Attribute getIdTokenEncryptionMethod() {
    return idTokenEncryptionMethod;
  }

  public void setIdTokenEncryptionMethod(Attribute idTokenEncryptionMethod) {
    this.idTokenEncryptionMethod = idTokenEncryptionMethod;
  }

  public Attribute getIdTokenPublicEncryptionKey() {
    return idTokenPublicEncryptionKey;
  }

  public void setIdTokenPublicEncryptionKey(Attribute idTokenPublicEncryptionKey) {
    this.idTokenPublicEncryptionKey = idTokenPublicEncryptionKey;
  }

  public Attribute getClientJwtPublicKey() {
    return clientJwtPublicKey;
  }

  public void setClientJwtPublicKey(Attribute clientJwtPublicKey) {
    this.clientJwtPublicKey = clientJwtPublicKey;
  }

  public Attribute getUserinfoResponseFormat() {
    return userinfoResponseFormat;
  }

  public void setUserinfoResponseFormat(Attribute userinfoResponseFormat) {
    this.userinfoResponseFormat = userinfoResponseFormat;
  }

  public Attribute getUserinfoSignedResponseAlg() {
    return userinfoSignedResponseAlg;
  }

  public void setUserinfoSignedResponseAlg(Attribute userinfoSignedResponseAlg) {
    this.userinfoSignedResponseAlg = userinfoSignedResponseAlg;
  }

  public Attribute getUserinfoEncryptedResponseAlg() {
    return userinfoEncryptedResponseAlg;
  }

  public void setUserinfoEncryptedResponseAlg(Attribute userinfoEncryptedResponseAlg) {
    this.userinfoEncryptedResponseAlg = userinfoEncryptedResponseAlg;
  }

  public Attribute getUserinfoEncryptedResponseEncryptionAlgorithm() {
    return userinfoEncryptedResponseEncryptionAlgorithm;
  }

  public void setUserinfoEncryptedResponseEncryptionAlgorithm(
      Attribute userinfoEncryptedResponseEncryptionAlgorithm) {
    this.userinfoEncryptedResponseEncryptionAlgorithm =
        userinfoEncryptedResponseEncryptionAlgorithm;
  }

  public Attribute getRequestParameterSignedAlg() {
    return requestParameterSignedAlg;
  }

  public void setRequestParameterSignedAlg(Attribute requestParameterSignedAlg) {
    this.requestParameterSignedAlg = requestParameterSignedAlg;
  }

  public Attribute getRequestParameterEncryptedEncryptionAlgorithm() {
    return requestParameterEncryptedEncryptionAlgorithm;
  }

  public void setRequestParameterEncryptedEncryptionAlgorithm(
      Attribute requestParameterEncryptedEncryptionAlgorithm) {
    this.requestParameterEncryptedEncryptionAlgorithm =
        requestParameterEncryptedEncryptionAlgorithm;
  }

  public Attribute getPublicKeyLocation() {
    return publicKeyLocation;
  }

  public void setPublicKeyLocation(Attribute publicKeyLocation) {
    this.publicKeyLocation = publicKeyLocation;
  }

  public Attribute getRequestParameterEncryptedAlg() {
    return requestParameterEncryptedAlg;
  }

  public void setRequestParameterEncryptedAlg(Attribute requestParameterEncryptedAlg) {
    this.requestParameterEncryptedAlg = requestParameterEncryptedAlg;
  }

  @Override
  public String toString() {
    return "SignEncOAuth2ClientConfig [jwksUri=" + jwksUri + ", jwksCacheTimeout="
        + jwksCacheTimeout + ", jwkStoreCacheMissCacheTime=" + jwkStoreCacheMissCacheTime
        + ", tokenEndpointAuthSigningAlgorithm=" + tokenEndpointAuthSigningAlgorithm
        + ", jwkSet=" + jwkSet + ", idTokenSignedResponseAlg=" + idTokenSignedResponseAlg
        + ", idTokenEncryptionEnabled=" + idTokenEncryptionEnabled
        + ", idTokenEncryptionAlgorithm=" + idTokenEncryptionAlgorithm
        + ", idTokenEncryptionMethod=" + idTokenEncryptionMethod
        + ", idTokenPublicEncryptionKey=" + idTokenPublicEncryptionKey + ", publicKeyLocation="
        + publicKeyLocation + ", clientJwtPublicKey=" + clientJwtPublicKey
        + ", userinfoResponseFormat=" + userinfoResponseFormat + ", userinfoSignedResponseAlg="
        + userinfoSignedResponseAlg + ", userinfoEncryptedResponseAlg="
        + userinfoEncryptedResponseAlg + ", userinfoEncryptedResponseEncryptionAlgorithm="
        + userinfoEncryptedResponseEncryptionAlgorithm + ", requestParameterSignedAlg="
        + requestParameterSignedAlg + ", requestParameterEncryptedAlg="
        + requestParameterEncryptedAlg + ", requestParameterEncryptedEncryptionAlgorithm="
        + requestParameterEncryptedEncryptionAlgorithm + "]";
  }

}
