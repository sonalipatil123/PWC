/**
 * FunctionalValidationException
 * 
 * Exception class for functional validations
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.exception;

import java.util.List;

import com.persistent.pmt.error.WorkflowError;

public class FunctionalValidationException extends Exception {

	private static final long serialVersionUID = -5050498717350778958L;

	private List<WorkflowError> errors;

	public FunctionalValidationException() {
		super();
	}

	public FunctionalValidationException(Throwable t) {
		super(t);
	}

	public FunctionalValidationException(String message) {
		super(message);
	}

	public FunctionalValidationException(List<WorkflowError> errors) {
		this.errors = errors;
	}

	public FunctionalValidationException(String message, List<WorkflowError> errors) {
		super(message);
		this.errors = errors;
	}

	public List<WorkflowError> getErrors() {
		return errors;
	}

	public void setErrors(List<WorkflowError> errors) {
		this.errors = errors;
	}

}
