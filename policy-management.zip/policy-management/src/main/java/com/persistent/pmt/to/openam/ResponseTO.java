package com.persistent.pmt.to.openam;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7460703093989309742L;
	private String name;
	private String type;
	private String value;
	private String desc;
	private String valueType;
	private int authZPolicyId;
	private int authNPolicyId;
	
	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getValueType() {
		return valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public int getAuthZPolicyId() {
		return authZPolicyId;
	}

	public void setAuthZPolicyId(int authZPolicyId) {
		this.authZPolicyId = authZPolicyId;
	}

	public int getAuthNPolicyId() {
		return authNPolicyId;
	}

	public void setAuthNPolicyId(int authNPolicyId) {
		this.authNPolicyId = authNPolicyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseTO [name=");
		builder.append(name);
		builder.append(", type=");
		builder.append(type);
		builder.append(", value=");
		builder.append(value);
		builder.append("]");
		return builder.toString();
	}

}
