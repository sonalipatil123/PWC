package com.persistent.pmt.model;

import java.util.List;

public class LdapUser {

	private String userid;
	private String givenName;
	private String surname;
	private String memberOf;
	private List<String> memberCN;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getMemberOf() {
		return memberOf;
	}

	public void setMemberOf(String memberOf) {
		this.memberOf = memberOf;
	}

	public List<String> getMemberCN() {
		return memberCN;
	}

	public void setMemberCN(List<String> memberCN) {
		this.memberCN = memberCN;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("LdapUser [userid=");
		builder.append(userid);
		builder.append(", givenName=");
		builder.append(givenName);
		builder.append(", surname=");
		builder.append(surname);
		builder.append(", memberOf=");
		builder.append(memberOf);
		builder.append(", memberCN=");
		builder.append(memberCN);
		builder.append("]");
		return builder.toString();
	}

}

