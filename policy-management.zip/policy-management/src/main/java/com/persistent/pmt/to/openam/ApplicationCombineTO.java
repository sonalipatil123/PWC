package com.persistent.pmt.to.openam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.ApplicationAttributes;
import com.persistent.pmt.model.ApplicationOwner;
import com.persistent.pmt.model.ApplicationState;
import com.persistent.pmt.model.AuthenticationPolicy;
import com.persistent.pmt.model.AuthorizationPolicy;
import com.persistent.pmt.model.AuthorizationPolicyAttribute;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.model.Originator;
import com.persistent.pmt.model.Platform;
import com.persistent.pmt.model.Resource;
import com.persistent.pmt.model.Response;
import com.persistent.pmt.model.UserDataStore;
import com.persistent.pmt.utils.CommonUtils;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationCombineTO {

  private Integer id;
  private List<Integer> combinedAppIds;
  private List<Map<String, String>> combineApplications;
  private String name;
  private String state;
  private String contextRoot;
  private String originator;
  private String environment;
  private boolean requireHTTPS;
  private boolean external;
  private boolean webService;
  private String appPortfolioId;
  private String platform;
  private boolean enabled;
  private String agentType;
  private String agent;
  private String agentId;
  private String description;
  private List<String> userDirectories;
  private List<String> userDirectoryIds;
  private List<ResourceTO> resources;
  private List<AuthNPolicyCombineTO> authenticationPolicies;
  private List<AuthZPolicyCombineTO> authorizationPolicies;
  private ApplicationOwner owner;
  private String provider;
  private List<ResponseTO> responses;

  private String sourceRawData;
  private Map<String, String> attributes;

  public ApplicationCombineTO() {

  }

  public ApplicationCombineTO(List<Application> applications) {

    StringBuilder newApplicationTempId = new StringBuilder();
    List<Integer> appIdList = new ArrayList<>();
    List<Map<String, String>> combineApps = new ArrayList<>();

    for (Application application : applications) {

      newApplicationTempId.append(application.getId());
      appIdList.add(application.getId());

      Map<String, String> appDetails = new HashMap<>();
      appDetails.put("applicationId", String.valueOf(application.getId()));
      appDetails.put("applicationName", application.getName());
      List<ApplicationAttributes> appAttributes = application.getAttributes();
      for (ApplicationAttributes attr : appAttributes) {
        if ("domainName".equals(attr.getSourceAttrName()))
          appDetails.put("domainName", attr.getSourceAttrValue());
      }
      appDetails.put("domainId", String.valueOf(application.getId()));
      combineApps.add(appDetails);
    }

    this.sourceRawData = applications.get(0).getSourceRawData();
    this.combineApplications = combineApps;
    this.combinedAppIds = appIdList;
    this.agentType = applications.get(0).getPepType();

    if (applications.get(0).getAgent() != null) {
      this.agent = applications.get(0).getAgent().getName();
      this.agentId = applications.get(0).getAgent().getId();
    }
    ApplicationState state = applications.get(0).getApplicationState();
    if (state != null)
      this.state = state.getState();

    Platform platform = applications.get(0).getPlatform();
    if (platform != null)
      this.platform = platform.getName();

    Originator originator = applications.get(0).getOriginator();
    if (originator != null)
      this.originator = originator.getName();

    Environment environment = applications.get(0).getEnvironment();
    if (environment != null)
      this.environment = environment.getName();

    this.owner = applications.get(0).getOwner();

    populateApplicationAttributes(applications.get(0));
    Map<String, Object> dataMap = populateResources(applications);
    populateResponses(applications);
    getUserDirectoriesList(applications);
    getAuthenticationPolicy(applications);
    getAuthorizationPolicies(applications, dataMap);

    // Raw attributes
    // Get application attributes for any application
    // as all belong to same domain will have same set of attributes

  }

  private void populateApplicationAttributes(Application application) {

    List<ApplicationAttributes> appAttributes = application.getAttributes();
    Map<String, String> appAttrMap = new HashMap<>();
    if (null != appAttributes) {
      for (ApplicationAttributes attr : appAttributes) {
        appAttrMap.put(attr.getSourceAttrName(), attr.getSourceAttrValue());
      }
    }
    this.attributes = appAttrMap;
  }

  private void populateResponses(List<Application> applications) {

    List<ResponseTO> responseToList = new ArrayList<>();
    ResponseTO responseTO;

    for (Application application : applications) {

      List<Response> responses = application.getResponses();
      if (null != responses && !responses.isEmpty()) {

        for (Response response : responses) {
          responseTO = new ResponseTO();
          responseTO.setName(response.getName());
          responseTO.setType(response.getType());
          responseTO.setValue(response.getValue());
          responseTO.setValueType(response.getValueType());
          responseTO.setDesc(response.getDescription());
          if (null != response.getAuthenticationPolicy())
            responseTO.setAuthNPolicyId(response.getAuthenticationPolicy().getId());
          if (null != response.getAuthorizationPolicy())
            responseTO.setAuthZPolicyId((response.getAuthorizationPolicy().getId()));

          responseToList.add(responseTO);
        }
      }
    }
    this.responses = responseToList;
  }

  private Map<String, Object> populateResources(List<Application> applications) {

    Map<String, String> resIdMap = new HashMap<>();
    Map<String, Object> dataMap = new HashMap<>();
    Map<String, ResourceTO> resourceToMap = new HashMap<>();
    Set<String> duplicateResources = new HashSet<>();
    for (Application application : applications) {

      List<Resource> resources = application.getResources();
      if (resources != null && !resources.isEmpty()) {

        for (Resource resource : resources) {

          ResourceTO resourceTO;
          if (resourceToMap.containsKey(resource.getUri())) {
            resourceTO = resourceToMap.get(resource.getUri());
            duplicateResources.add(String.valueOf(resourceTO.getId()));
            resIdMap.put(String.valueOf(resourceTO.getId()), String.valueOf(resource.getId()));
            resourceTO.setId(resource.getId());
            resourceTO.getActions().addAll(resource.getHttpMethods());
            duplicateResources.add(String.valueOf(resource.getId()));
          }
          else {
            resourceTO = new ResourceTO();
            resourceTO.setId(resource.getId());
            resourceTO.setUri(resource.getUri());
            resourceTO.setAnonymous(resource.isAnonymous());
            resourceTO.setEnabled(resource.isEnabled());
            resourceTO.setResourceType(resource.getResourceType());
            boolean isRootResource = (resource.getRootResource() == 0) ? false : true;
            resourceTO.setRootResource(isRootResource);
            resourceTO.setRuleSetId(resource.getRuleSetId());
            resourceTO.setRuleSetName(resource.getRuleSetName());
            resourceTO.setTargetId(resource.getTargetId());
            resourceTO.setTargetName(resource.getTargetName());
            resourceTO.setActions(new HashSet<>(resource.getHttpMethods()));
            resourceTO.setSuccessCriteria(resource.getSuccessCriteria());
          }

          /*
           * if(resourceToMap.containsKey(resourceTO.getUri())) {
           * 
           * ResourceCombineTO existingResourceTO =
           * resourceToMap.get(resourceTO.getUri());
           * 
           * if (resource.getAuthenticationPolicy() != null) {
           * resourceTO
           * .setAuthenticationPolicy(String.valueOf(resource
           * .getAuthenticationPolicy().getId())); }
           * 
           * if (resource.getAuthorizationPolicy() != null) {
           * resourceTO.setAuthorizationPolicy(String.valueOf(resource
           * .getAuthorizationPolicy().getId())); }
           * 
           * } else {
           * 
           * 
           * if (resource.getAuthenticationPolicy() != null) {
           * resourceTO.setAuthenticationPolicy(new
           * ArrayList(String.valueOf(resource
           * .getAuthenticationPolicy().getId()))); }
           * 
           * if (resource.getAuthorizationPolicy() != null) {
           * resourceTO.setAuthorizationPolicy(String.valueOf(resource
           * .getAuthorizationPolicy().getId())); }
           * 
           * }
           */

          resourceToMap.put(resourceTO.getUri(), resourceTO);
        }

      }
    }
    this.resources = new ArrayList<>(resourceToMap.values());
    dataMap.put("resourceMap", resourceToMap);
    dataMap.put("duplicateResources", duplicateResources);
    dataMap.put("resourceIdMap", resIdMap);
    return dataMap;
  }

  private void getUserDirectoriesList(List<Application> applications) {

    Set<String> userDirectoryList = new HashSet<>();
    Set<String> userDirectoryIds = new HashSet<>();
    for (Application application : applications) {

      List<UserDataStore> userDataStores = application.getUserDataStores();
      for (UserDataStore userDataStore : userDataStores) {
        userDirectoryList.add(userDataStore.getName());
        userDirectoryIds.add(userDataStore.getId());
      }
    }
    this.userDirectories = new ArrayList<>(userDirectoryList);
    this.userDirectoryIds = new ArrayList<>(userDirectoryIds);
  }

  private void getAuthenticationPolicy(List<Application> applications) {

    List<AuthNPolicyCombineTO> autheNPolicies = new ArrayList<>();
    for (Application application : applications) {

      AuthenticationPolicy authNPolicy = application.getDefaultAuthenticationPolicy();
      if (authNPolicy != null) {

        AuthNPolicyCombineTO authNCombinePolicyTO = new AuthNPolicyCombineTO();
        authNCombinePolicyTO.setId(authNPolicy.getId());
        authNCombinePolicyTO.setName(authNPolicy.getName());
        authNCombinePolicyTO.setApplicationName(application.getName());
        if (authNPolicy.getDescription() != null) {
          authNCombinePolicyTO.setDescription(authNPolicy.getDescription());
        }
        else {
          authNCombinePolicyTO.setDescription("");
        }
        authNCombinePolicyTO.setEnabled(authNPolicy.isEnabled());
        authNCombinePolicyTO.setIsPublic(authNPolicy.isSystemSpecific());

        if (authNPolicy.getAuthenticationScheme() != null) {
          authNCombinePolicyTO.setScheme(authNPolicy.getAuthenticationScheme().getName());
          authNCombinePolicyTO.setSchemeType(authNPolicy.getAuthenticationScheme().getType());
          authNCombinePolicyTO.setLevel(authNPolicy.getAuthenticationScheme().getLevel());
          authNCombinePolicyTO.setAuthSchemeId(authNPolicy.getAuthenticationScheme().getId());
        }

        if (application.getResources() != null && !application.getResources().isEmpty()) {
          List<String> uniqueResources = new ArrayList<>();
          Set<String> actions = new HashSet<>();

          for (Resource resource : application.getResources()) {
            if (resource.getAuthenticationPolicy() != null
                && resource.getAuthenticationPolicy().getId() == authNCombinePolicyTO.getId()) {
              uniqueResources.add(String.valueOf(resource.getId()));
              actions.addAll(resource.getHttpMethods());
            }
          }
          authNCombinePolicyTO.setResources(uniqueResources);
          authNCombinePolicyTO.setActions(actions);
        }

        if (application.getResponses() != null && !application.getResponses().isEmpty()) {
          List<ResponseTO> responseTOs = new ArrayList<>();

          for (Response response : application.getResponses()) {
            if (response.getAuthenticationPolicy() != null) {
              if (response.getAuthenticationPolicy().getId() == authNCombinePolicyTO.getId()) {
                ResponseTO responseTO = new ResponseTO();
                responseTO.setName(response.getName());
                responseTO.setType(response.getType());
                responseTO.setValue(response.getValue());
                responseTOs.add(responseTO);
              }
            }
          }
          authNCombinePolicyTO.setResponses(responseTOs);
        }

        autheNPolicies.add(authNCombinePolicyTO);
      }
    }
    this.authenticationPolicies = autheNPolicies;
  }

  @SuppressWarnings("unchecked")
  private void getAuthorizationPolicies(List<Application> applications,
      Map<String, Object> dataMap) {

    Set<String> duplicateResources = (Set<String>) dataMap.get("duplicateResources");
    /*
     * Map<String, ResourceTO> resourceMap = (Map<String, ResourceTO>)
     * dataMap .get("resourceMap");
     */
    Map<String, String> resourceIdMap = (Map<String, String>) dataMap.get("resourceIdMap");

    List<AuthZPolicyCombineTO> authzPolicyTOList = new ArrayList<>();

    for (Application application : applications) {

      List<AuthorizationPolicy> authzPolicies = application.getAuthorizationPolicies();
      if (authzPolicies != null && !authzPolicies.isEmpty()) {

        for (AuthorizationPolicy authzPolicy : authzPolicies) {

          AuthZPolicyCombineTO authzPolicyTO = new AuthZPolicyCombineTO();
          authzPolicyTO.setId(authzPolicy.getId());
          authzPolicyTO.setName(authzPolicy.getName());
          authzPolicyTO.setDescription(authzPolicy.getDescription());
          authzPolicyTO.setAuthorizationRule(authzPolicy.getAuthorizationRule());
          authzPolicyTO.setEnabled(authzPolicy.isEnabled());
          authzPolicyTO.setApplicationName(application.getName());

          if (application.getResources() != null && !application.getResources().isEmpty()) {
            List<Resource> resources = application.getResources();
            List<String> uniqueResources = new ArrayList<>();
            Set<String> actions = new HashSet<>();

            for (Resource resource : resources) {
              if (resource.getAuthorizationPolicy() != null
                  && resource.getAuthorizationPolicy().getId() == authzPolicyTO.getId()) {
                uniqueResources.add(String.valueOf(resource.getId()));
                actions.addAll(resource.getHttpMethods());
              }
            }
            authzPolicyTO.setResources(uniqueResources);
            authzPolicyTO.setActions(actions);
          }

          if (application.getResponses() != null && !application.getResponses().isEmpty()) {
            List<ResponseTO> responseTOs = new ArrayList<>();
            for (Response response : application.getResponses()) {
              if (response.getAuthorizationPolicy() != null) {
                if (response.getAuthorizationPolicy().getId() == authzPolicyTO.getId()) {
                  ResponseTO responseTO = new ResponseTO();
                  responseTO.setName(response.getName());
                  responseTO.setType(response.getType());
                  responseTO.setValue(response.getValue());
                  responseTOs.add(responseTO);
                }
              }
            }
            authzPolicyTO.setResponses(responseTOs);
          }

          List<AuthorizationPolicyAttribute> attributes = authzPolicy.getAttributes();
          if (attributes != null) {
            List<ConditionTO> conditionTOs = new ArrayList<>();
            for (AuthorizationPolicyAttribute attribute : attributes) {
              ConditionTO conditionTO = new ConditionTO();
              conditionTO.setName(attribute.getName());
              conditionTO.setNegate(attribute.isNegate());
              conditionTO.setType(attribute.getConditionType());
              conditionTO.setValue(attribute.getConditionValue());

              conditionTOs.add(conditionTO);
            }
            authzPolicyTO.setConditions(conditionTOs);
          }
          // authzPolicyTO.setAttributes(attributes);
          authzPolicyTOList.add(authzPolicyTO);
        }
      }
    }
    List<AuthZPolicyCombineTO> clonedAuthZPolicies = new ArrayList<>();
    ListIterator<AuthZPolicyCombineTO> authZPolicyIterator = authzPolicyTOList.listIterator();
    while (authZPolicyIterator.hasNext()) {

      AuthZPolicyCombineTO authZPolicyCombineTO = authZPolicyIterator.next();
      List<String> authZResources = authZPolicyCombineTO.getResources();

      if (null != authZResources && authZResources.size() == 1) {
        if (!duplicateResources.contains(authZResources.get(0))) {
          authZPolicyCombineTO.setSelected(true);
        }
        else {
          List<String> newResource = new ArrayList<>();
          if (null != resourceIdMap.get(authZResources.get(0))) {
            newResource.add(resourceIdMap.get(authZResources.get(0)));
          }
          else {
            newResource.add(authZResources.get(0));
          }
          authZPolicyCombineTO.setResources(newResource);
        }
      }
      else if (null != authZResources && !authZResources.isEmpty()) {

        ListIterator<String> resourceIterator = authZResources.listIterator();
        while (resourceIterator.hasNext()) {
          String resourceId = resourceIterator.next();
          if (duplicateResources.contains(resourceId)) {

            AuthZPolicyCombineTO clonedAuthZPolicy =
                (AuthZPolicyCombineTO) CommonUtils.deepCopy(authZPolicyCombineTO);
            List<String> clonedResource = new ArrayList<>();
            if (null != resourceIdMap.get(resourceId))
              resourceId = resourceIdMap.get(resourceId);
            clonedResource.add(resourceId);
            clonedAuthZPolicy.setName(clonedAuthZPolicy.getName() + "-CLONED");
            clonedAuthZPolicy.setResources(clonedResource);
            clonedAuthZPolicy.setSelected(false);
            clonedAuthZPolicies.add(clonedAuthZPolicy);
            resourceIterator.remove();
          }
        }
        authZPolicyCombineTO.setSelected(true);
        if (null != authZPolicyCombineTO.getResources()
            && authZPolicyCombineTO.getResources().isEmpty())
          authZPolicyIterator.remove();
      }
      else
        authZPolicyIterator.remove();
    }
    authzPolicyTOList.addAll(clonedAuthZPolicies);
    this.authorizationPolicies = authzPolicyTOList;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public List<Integer> getCombinedAppIds() {
    return combinedAppIds;
  }

  public void setCombinedAppIds(List<Integer> combinedAppIds) {
    this.combinedAppIds = combinedAppIds;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getContextRoot() {
    return contextRoot;
  }

  public void setContextRoot(String contextRoot) {
    this.contextRoot = contextRoot;
  }

  public String getOriginator() {
    return originator;
  }

  public void setOriginator(String originator) {
    this.originator = originator;
  }

  public String getEnvironment() {
    return environment;
  }

  public void setEnvironment(String environment) {
    this.environment = environment;
  }

  public boolean isRequireHTTPS() {
    return requireHTTPS;
  }

  public void setRequireHTTPS(boolean requireHTTPS) {
    this.requireHTTPS = requireHTTPS;
  }

  public boolean isExternal() {
    return external;
  }

  public void setExternal(boolean external) {
    this.external = external;
  }

  public boolean isWebService() {
    return webService;
  }

  public void setWebService(boolean webService) {
    this.webService = webService;
  }

  public String getAppPortfolioId() {
    return appPortfolioId;
  }

  public void setAppPortfolioId(String appPortfolioId) {
    this.appPortfolioId = appPortfolioId;
  }

  public String getPlatform() {
    return platform;
  }

  public void setPlatform(String platform) {
    this.platform = platform;
  }

  public Boolean getEnabled() {
    return enabled;
  }

  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  public String getAgentType() {
    return agentType;
  }

  public void setAgentType(String agentType) {
    this.agentType = agentType;
  }

  public String getAgent() {
    return agent;
  }

  public void setAgent(String agent) {
    this.agent = agent;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public List<String> getUserDirectories() {
    return userDirectories;
  }

  public void setUserDirectories(List<String> userDirectories) {
    this.userDirectories = userDirectories;
  }

  public List<ResourceTO> getResources() {
    return resources;
  }

  public void setResources(List<ResourceTO> resources) {
    this.resources = resources;
  }

  public List<AuthNPolicyCombineTO> getAuthenticationPolicies() {
    return authenticationPolicies;
  }

  public void setAuthenticationPolicies(List<AuthNPolicyCombineTO> authenticationPolicies) {
    this.authenticationPolicies = authenticationPolicies;
  }

  public List<AuthZPolicyCombineTO> getAuthorizationPolicies() {
    return authorizationPolicies;
  }

  public void setAuthorizationPolicies(List<AuthZPolicyCombineTO> authorizationPolicies) {
    this.authorizationPolicies = authorizationPolicies;
  }

  public ApplicationOwner getOwner() {
    return owner;
  }

  public void setOwner(ApplicationOwner owner) {
    this.owner = owner;
  }

  public String getProvider() {
    return provider;
  }

  public void setProvider(String provider) {
    this.provider = provider;
  }

  public List<Map<String, String>> getCombineApplications() {
    return combineApplications;
  }

  public void setCombineApplications(List<Map<String, String>> combineApplications) {
    this.combineApplications = combineApplications;
  }

  public List<String> getUserDirectoryIds() {
    return userDirectoryIds;
  }

  public void setUserDirectoryIds(List<String> userDirectoryIds) {
    this.userDirectoryIds = userDirectoryIds;
  }

  public String getAgentId() {
    return agentId;
  }

  public void setAgentId(String agentId) {
    this.agentId = agentId;
  }

  public List<ResponseTO> getResponses() {
    return responses;
  }

  public void setResponses(List<ResponseTO> responses) {
    this.responses = responses;
  }

  public String getSourceRawData() {
    return sourceRawData;
  }

  public void setSourceRawData(String sourceRawData) {
    this.sourceRawData = sourceRawData;
  }

  public Map<String, String> getAttributes() {
    return attributes;
  }

  public void setAttributes(Map<String, String> attributes) {
    this.attributes = attributes;
  }

}
