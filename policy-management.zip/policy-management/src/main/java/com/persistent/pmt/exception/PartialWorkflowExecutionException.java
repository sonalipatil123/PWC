/**
 * PartialWorkflowExecutionException
 * 
 * Exception for partial workflow executions
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.exception;

import java.util.List;

import com.persistent.pmt.error.WorkflowError;

public class PartialWorkflowExecutionException extends WorkflowException {

	private static final long serialVersionUID = 1487800924867141586L;

	public PartialWorkflowExecutionException() {
		super();
	}

	public PartialWorkflowExecutionException(Throwable t) {
		super(t);
	}

	public PartialWorkflowExecutionException(List<WorkflowError> errors) {
		super(errors);
	}

	public PartialWorkflowExecutionException(String message, List<WorkflowError> errors) {
		super(message, errors);
	}

}
