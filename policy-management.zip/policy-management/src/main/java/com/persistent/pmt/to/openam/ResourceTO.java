package com.persistent.pmt.to.openam;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResourceTO {

  private int id;
  private String uri;
  private boolean enabled;
  private boolean anonymous;
  private int targetId;
  private int ruleSetId;
  private String successCriteria;
  private String authenticationPolicy;
  private boolean rootResource;
  private String targetName;
  private String ruleSetName;
  private Set<String> actions;
  private String authorizationPolicy;
  private String resourceType;

  public ResourceTO() {
    super();
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getUri() {
    return uri;
  }

  public void setUri(String uri) {
    this.uri = uri;
  }

  public boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }

  public boolean isAnonymous() {
    return anonymous;
  }

  public void setAnonymous(boolean anonymous) {
    this.anonymous = anonymous;
  }

  public int getTargetId() {
    return targetId;
  }

  public void setTargetId(int targetId) {
    this.targetId = targetId;
  }

  public int getRuleSetId() {
    return ruleSetId;
  }

  public void setRuleSetId(int ruleSetId) {
    this.ruleSetId = ruleSetId;
  }

  public String getSuccessCriteria() {
    return successCriteria;
  }

  public void setSuccessCriteria(String successCriteria) {
    this.successCriteria = successCriteria;
  }

  public String getAuthenticationPolicy() {
    return authenticationPolicy;
  }

  public void setAuthenticationPolicy(String authenticationPolicy) {
    this.authenticationPolicy = authenticationPolicy;
  }

  public boolean isRootResource() {
    return rootResource;
  }

  public void setRootResource(boolean rootResource) {
    this.rootResource = rootResource;
  }

  public String getTargetName() {
    return targetName;
  }

  public void setTargetName(String targetName) {
    this.targetName = targetName;
  }

  public String getRuleSetName() {
    return ruleSetName;
  }

  public void setRuleSetName(String ruleSetName) {
    this.ruleSetName = ruleSetName;
  }

  public Set<String> getActions() {
    return actions;
  }

  public void setActions(Set<String> actions) {
    this.actions = actions;
  }

  public String getAuthorizationPolicy() {
    return authorizationPolicy;
  }

  public void setAuthorizationPolicy(String authorizationPolicy) {
    this.authorizationPolicy = authorizationPolicy;
  }

  public String getResourceType() {
    return resourceType;
  }

  public void setResourceType(String resourceType) {
    this.resourceType = resourceType;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("ResourceTO [id=");
    builder.append(id);
    builder.append(", uri=");
    builder.append(uri);
    builder.append(", enabled=");
    builder.append(enabled);
    builder.append(", anonymous=");
    builder.append(anonymous);
    builder.append(", targetId=");
    builder.append(targetId);
    builder.append(", ruleSetId=");
    builder.append(ruleSetId);
    builder.append(", successCriteria=");
    builder.append(successCriteria);
    builder.append(", authenticationPolicy=");
    builder.append(authenticationPolicy);
    builder.append(", rootResource=");
    builder.append(rootResource);
    builder.append(", targetName=");
    builder.append(targetName);
    builder.append(", ruleSetName=");
    builder.append(ruleSetName);
    builder.append(", actions=");
    builder.append(actions);
    builder.append(", authorizationPolicy=");
    builder.append(authorizationPolicy);
    builder.append(", resourceType=");
    builder.append(resourceType);
    builder.append("]");
    return builder.toString();
  }


}
