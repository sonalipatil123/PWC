package com.persistent.pmt.view.openam;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Subject {
  private String type;
  private List<?> subjects;

  public Subject() {
    super();
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public List<?> getSubjects() {
    return subjects;
  }

  public void setSubjects(List<?> subjects) {
    this.subjects = subjects;
  }

  @Override
  public String toString() {
    return "Subject [type=" + type + ", subjects=" + subjects + "]";
  }

}
