package com.persistent.pmt.view.openam;

import java.util.HashSet;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.view.TargetView;

@JsonInclude(Include.NON_NULL)
public class PolicyView implements TargetView {

  @JsonIgnore
  private String id;
  private String[] resources;
  private String description;
  private String applicationName;
  private String name;
  private Map<String, Boolean> actionValues;
  private String resourceTypeUuid;
  private String creationDate;
  private String createdBy;
  private String lastModifiedBy;
  private boolean active;
  private String lastModifiedDate;
  private Condition condition;
  private Subject subject;
  private HashSet<ResponseAttributes> resourceAttributes;

  public PolicyView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String[] getResources() {
    return resources;
  }

  public void setResources(String[] resources) {
    this.resources = resources;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getApplicationName() {
    return applicationName;
  }

  public void setApplicationName(String applicationName) {
    this.applicationName = applicationName;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Map<String, Boolean> getActionValues() {
    return actionValues;
  }

  public void setActionValues(Map<String, Boolean> actionValues) {
    this.actionValues = actionValues;
  }

  public String getResourceTypeUuid() {
    return resourceTypeUuid;
  }

  public void setResourceTypeUuid(String resourceTypeUuid) {
    this.resourceTypeUuid = resourceTypeUuid;
  }

  public String getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(String creationDate) {
    this.creationDate = creationDate;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public String getLastModifiedBy() {
    return lastModifiedBy;
  }

  public void setLastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  public String getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(String lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  public Condition getCondition() {
    return condition;
  }

  public void setCondition(Condition condition) {
    this.condition = condition;
  }

  public Subject getSubject() {
    return subject;
  }

  public void setSubject(Subject subject) {
    this.subject = subject;
  }

  public HashSet<ResponseAttributes> getResourceAttributes() {
    return resourceAttributes;
  }

  public void setResourceAttributes(HashSet<ResponseAttributes> resourceAttributes) {
    this.resourceAttributes = resourceAttributes;
  }
}
