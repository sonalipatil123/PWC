package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CoreUmaClientConfig {
  private Attribute claimsRedirectionUris;

  public Attribute getClaimsRedirectionUris() {
    return claimsRedirectionUris;
  }

  public void setClaimsRedirectionUris(Attribute claimsRedirectionUris) {
    this.claimsRedirectionUris = claimsRedirectionUris;
  }

  @Override
  public String toString() {
    return "CoreUmaClientConfig [claimsRedirectionUris=" + claimsRedirectionUris + "]";
  }

}
