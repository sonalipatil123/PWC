/**
 * AuthorizationPolicy
 * 
 * Entity model for authorization policy
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * AuthorizationPolicy
 * 
 * Entity model for AuthorizationPolicy
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "authorization_policy")
public class AuthorizationPolicy {


	@Id
//	@SequenceGenerator(name = "SEQ_AUTHORIZATION_POLICY", sequenceName = "SEQ_AUTHORIZATION_POLICY", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_AUTHORIZATION_POLICY")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "resource_id")
	private String resourceId;

	@JsonIgnore
	@Transient
	private int targetId;

	@Column(name = "negate")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean negate;

	@Column(name = "description")
	private String description;

	@Column(name = "system_specific")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean systemSpecific;

	@Column(name = "class")
	private String className;

	@Column(name = "life_cycle")
	private String lifeCycle;

	@JsonIgnore
	@Column(name = "target_name")
	private String targetName;

	@ManyToOne
	@JoinColumn(name = "application_id")
	private Application application;

	@Column(name = "authorization_rule")
	private String authorizationRule;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "auth_policy_id")
	private List<AuthorizationPolicyAttribute> attributes;

	@Transient
	private List<Resource> resources;

	@Transient
	private List<Response> responses;

	@Transient
	private boolean defaultEntity;

	@Column(name = "enabled")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean enabled;

	public AuthorizationPolicy() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public int getTargetId() {
		return targetId;
	}

	public void setTargetId(int targetId) {
		this.targetId = targetId;
	}

	public boolean isNegate() {
		return negate;
	}

	public void setNegate(boolean negate) {
		this.negate = negate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isSystemSpecific() {
		return systemSpecific;
	}

	public void setSystemSpecific(boolean systemSpecific) {
		this.systemSpecific = systemSpecific;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getLifeCycle() {
		return lifeCycle;
	}

	public void setLifeCycle(String lifeCycle) {
		this.lifeCycle = lifeCycle;
	}

	public String getTargetName() {
		return targetName;
	}

	public void setTargetName(String targetName) {
		this.targetName = targetName;
	}

	public String getAuthorizationRule() {
		return authorizationRule;
	}

	public void setAuthorizationRule(String authorizationRule) {
		this.authorizationRule = authorizationRule;
	}

	public List<AuthorizationPolicyAttribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<AuthorizationPolicyAttribute> attributes) {
		this.attributes = attributes;
	}

	public List<Resource> getResources() {
		return resources;
	}

	public void setResources(List<Resource> resources) {
		this.resources = resources;
	}

	public List<Response> getResponses() {
		return responses;
	}

	public void setResponses(List<Response> responses) {
		this.responses = responses;
	}

	public boolean isDefaultEntity() {
		return defaultEntity;
	}

	public void setDefaultEntity(boolean defaultEntity) {
		this.defaultEntity = defaultEntity;
	}

	public boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("AuthorizationPolicy [id=");
    builder.append(id);
    builder.append(", name=");
    builder.append(name);
    builder.append(", resourceId=");
    builder.append(resourceId);
    builder.append(", targetId=");
    builder.append(targetId);
    builder.append(", negate=");
    builder.append(negate);
    builder.append(", description=");
    builder.append(description);
    builder.append(", systemSpecific=");
    builder.append(systemSpecific);
    builder.append(", className=");
    builder.append(className);
    builder.append(", lifeCycle=");
    builder.append(lifeCycle);
    builder.append(", targetName=");
    builder.append(targetName);
    builder.append(", application=");
    builder.append(application);
    builder.append(", authorizationRule=");
    builder.append(authorizationRule);
    builder.append(", attributes=");
    builder.append(attributes);
    builder.append(", resources=");
    builder.append(resources);
    builder.append(", responses=");
    builder.append(responses);
    builder.append(", defaultEntity=");
    builder.append(defaultEntity);
    builder.append(", enabled=");
    builder.append(enabled);
    builder.append("]");
    return builder.toString();
  }

}
