/**
 * ExceptionControllerAdvice
 * 
 * Exception handler for various exceptions across the application
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.exception.handler;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.JDBCException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;

import com.persistent.pmt.constant.RequestStatus;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.FunctionalValidationException;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.exception.ValidationException;
import com.persistent.pmt.exception.WorkflowException;
import com.persistent.pmt.response.ApplicationHostOperationResponse;
import com.persistent.pmt.response.ErrorResponse;
import com.persistent.pmt.response.GenericResponse;

@ControllerAdvice
public class ExceptionControllerAdvice {

  private static final Logger logger = Logger.getLogger(ExceptionControllerAdvice.class);

  /**
   * Exception handler method for HttpClientErrorException
   * 
   * @param ex
   * @return ResponseEntity<ErrorResponse>
   * @throws Exception
   */
  @ExceptionHandler(HttpClientErrorException.class)
  public ResponseEntity<ErrorResponse> exceptionHandler(HttpClientErrorException ex)
      throws Exception {
    ErrorResponse response = new ErrorResponse();
    response.setStatusCode(ex.getRawStatusCode());
    response.setStatus(RequestStatus.FAILED.getValue());
    response.setMessage(ex.getResponseBodyAsString());

    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @ExceptionHandler(WorkflowException.class)
  public ResponseEntity<GenericResponse<ErrorMessage>> handleException(WorkflowException ex) {
    GenericResponse<ErrorMessage> response = new GenericResponse<>();
    List<String> errors = new ArrayList<>();
    for (WorkflowError error : ex.getErrors()) {
      errors.add(error.toString());
    }
    response.setContent(new ErrorMessage(errors));
    response.setMessage(ex.getMessage());
    response.setStatus(RequestStatus.FAILED.getValue());
    response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

    return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  /**
   * Exception handler method for GenericException
   * 
   * @param ex
   * @return ResponseEntity<ErrorResponse>
   */
  @ExceptionHandler(GenericException.class)
  public ResponseEntity<ErrorResponse> exceptionHandler(GenericException ex) {
    ErrorResponse response = new ErrorResponse();
    response.setStatusCode(ex.getStatusCode());
    if (ex.getStatus() == null)
      response.setStatus(RequestStatus.FAILED.getValue());
    else
      response.setStatus(ex.getStatus());

    response.setMessage(ex.getMessage());
    if (ex.getStatusCode() == 0)
      return new ResponseEntity<>(response, HttpStatus.OK);
    else
      return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
  }

  /**
   * Exception handler method for ValidationException
   * 
   * @param ex
   * @return ResponseEntity<GenericResponse<ErrorMessage>>
   */
  @ExceptionHandler(ValidationException.class)
  public ResponseEntity<GenericResponse<ErrorMessage>> handleException(ValidationException ex) {
    GenericResponse<ErrorMessage> response = new GenericResponse<>();
    List<FieldError> fieldErrors = ex.getResult().getFieldErrors();
    List<ObjectError> globalErrors = ex.getResult().getGlobalErrors();
    List<String> errors = new ArrayList<>(fieldErrors.size() + globalErrors.size());
    String error;
    for (FieldError fieldError : fieldErrors) {
      error = fieldError.getField() + " : " + fieldError.getDefaultMessage();
      errors.add(error);
    }
    for (ObjectError objectError : globalErrors) {
      error = objectError.getObjectName() + " : " + objectError.getDefaultMessage();
      errors.add(error);
    }

    response.setContent(new ErrorMessage(errors));
    response.setMessage("Payload validation failed.");
    // response.setStatus(RequestStatus.FAILED.getValue());
    response.setStatus(RequestStatus.BAD_REQUEST.getValue());

    response.setStatusCode(HttpStatus.BAD_REQUEST.value());

    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(FunctionalValidationException.class)
  public ResponseEntity<ApplicationHostOperationResponse> exceptionHandler(
      FunctionalValidationException ex) {
    ApplicationHostOperationResponse response = new ApplicationHostOperationResponse();
    response.setStatus(RequestStatus.FAILED.getValue());
    response.setMessage(ex.getLocalizedMessage());
    response.setErrors(ex.getErrors());

    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  /**
   * Exception handler method for HttpMessageNotReadableException
   * 
   * @param ex
   * @return ResponseEntity<ErrorResponse>
   */
  @ExceptionHandler(HttpMessageNotReadableException.class)
  public ResponseEntity<ErrorResponse> exceptionHandler(HttpMessageNotReadableException ex) {
    ErrorResponse response = new ErrorResponse();
    response.setStatusCode(HttpStatus.BAD_REQUEST.value());
    response.setStatus(RequestStatus.FAILED.getValue());
    response.setMessage("Invalid JSON data.");

    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
  }

  /**
   * Exception handler method for JDBCException
   * 
   * @param ex
   * @return ResponseEntity<ErrorResponse>
   */
  @ExceptionHandler(JDBCException.class)
  public ResponseEntity<ErrorResponse> exceptionHandler(JDBCException ex) {
    logger.log(Level.ERROR, "Operation Failed", ex);
    ErrorResponse response = new ErrorResponse();
    response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    response.setStatus(RequestStatus.FAILED.getValue());
    response
        .setMessage("The server encountered an internal error and was unable to complete your request.");
    return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  /**
   * Exception handler method for
   * HttpRequestMethodNotSupportedException
   * 
   * @param ex
   * @return ResponseEntity<ErrorResponse>
   */
  @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
  public ResponseEntity<ErrorResponse> exceptionHandler(
      HttpRequestMethodNotSupportedException ex) {
    logger.log(Level.ERROR, "Operation Failed", ex);
    ErrorResponse response = new ErrorResponse();
    response.setStatusCode(HttpStatus.BAD_REQUEST.value());
    response.setStatus(RequestStatus.BAD_REQUEST.getValue());
    response.setMessage("Request method is not supported.");
    return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
  }

  /**
   * Exception handler method for Exception
   * 
   * @param ex
   * @return ResponseEntity<ErrorResponse>
   */
  @ExceptionHandler(Exception.class)
  public ResponseEntity<ErrorResponse> exceptionHandler(Exception ex) {
    logger.log(Level.ERROR, "Operation Failed", ex);
    ErrorResponse response = new ErrorResponse();
    response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    response.setStatus(RequestStatus.FAILED.getValue());
    response
        .setMessage("The server encountered an internal error and was unable to complete your request.");

    return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
  }
}
