package com.persistent.pmt.dao.impl;

import org.springframework.stereotype.Repository;

import com.persistent.pmt.dao.AuthorizationPolicyDao;
import com.persistent.pmt.model.AuthorizationPolicy;

@Repository("authorizationPolicyDao")
public class AuthorizationPolicyDaoImpl extends BaseDaoImpl implements
		AuthorizationPolicyDao {

	@Override
	public AuthorizationPolicy createAuthorizationPolicy(
			AuthorizationPolicy authorizationPolicy) {
		getSession().save(authorizationPolicy);
		return authorizationPolicy;
	}

}
