package com.persistent.pmt.constant;

public class PMTConstants {

  public static final String CONTEXT_API_BASE_URL = "openam.api.base.url";
  public static final String CONTEXT_LIFECYCLE = "LifeCycle";
  public static final String CONTEXT_AUTHTOKEN = "AuthToken";
  public static final String CONTEXT_BASE_URL = "openam.url";

  public static final String CONTEXT_ADMIN_PASSWORD = "openam.password";
  public static final String CONTEXT_ADMIN_USER = "openam.admin";
  public static final String CONTEXT_API_VERSION = "openam.api.version";

  public static final String HEADER_AUTHORIZATION = "iPlanetDirectoryPro";
  public static final String HEADER_CONTENT_TYPE = "Content-Type";
  public static final String HEADER_OPEN_AM_USERNAME = "X-OpenAM-Username";
  public static final String HEADER_OPEN_AM_PASSWORD = "X-OpenAM-Password";
  public static final String HEADER_OPEN_AM_API_VERSION = "Accept-API-Version";
  public static final String HEADER_ACCEPT = "Accept";
  public static final String TYPE_JSON = "application/json";

  public static final String SERVER_CONFIG_SYSTEM = "SYSTEM";
  public static final String SERVER_CONFIG_TARGET = "TARGET";

  public static final String PROVIDER_NAME = "providerName";
  public static final String DOMAIN_NAME = "domainName";
  public static final String REALM_NAME = "realmName";
  public static final String ID = "id";

  public static final String PEP_TYPE_FEDERATION = "FEDERATED";
  public static final String PEP_TYPE_AGENT = "AGENT";
  //
  // Provider Types
  public static final String PROVIDER_IDP = "IDP";
  public static final String PROVIDER_WSFEDSP = "WSFEDSP";
  public static final String PROVIDER_SAML2 = "SAML2";

  // Auth Scheme Type
  public static final String AUTH_SCHEME_TYPE_WSFED = "WSFED";
  public static final String AUTH_SCHEME_TYPE_SAML2 = "SAML2";

  // provider Attributes
  public static final String IDPID = "IdPID";
  public static final String SPID = "SPID";
  public static final String KEY_RPID = "KEY_RPID";

  // AuthScheme Attributes
  public static final String KEY_IDPID = "KEY_IdPID";
  public static final String KEY_SPID = "SPID";
  public static final String ATTRIBUTES_LINK = "AttributesLink";

  // EntityCOnfig Pleaceholder
  public static final String ENTITY_CONFIG_COT = "$COTVAL$";
  public static final String ENTITY_CONFIG_ID = "$ENTITY_ID";
  public static final String ENTITY_METAALIAS = "$METAALIAS";
  public static final String PROVIDER_DISPLAY_NAME = "$DISPLAY_NAME$";
  public static final String ATTRIBUTE_MAP = "$attributeMap$";

  public static final String CUSTOM_ALTERNATE_SCHEME = "custom.alternate.scheme";

  // serachView Parameter Values
  public static final String SEARCH_VIEW_IMPORT = "import";
  public static final String SEARCH_VIEW_PMT = "pmt";

  // Constants to define application.properties property names
  public static final String PROPERTY_LDAP_USER_RETURNATTRIBUTES = "ldap.user.returnattributes";
  public static final String PROPERTY_LDAP_USER_OBJECTCLASS = "ldap.user.objectclass";
  public static final String PROPERTY_LDAP_GROUP_OBJECTCLASS = "ldap.group.objectclass";
  public static final String PROPERTY_LDAP_USER_LOGINATTRIBUTE = "ldap.user.loginattribute";
  public static final String PROPERTY_ADMIN_GROUP_NAME = "pmt_admin_group";
  public static final String PROPERTY_MANAGER_GROUP_NAME = "pmt_manager_group";
  public static final String PROPERTY_AUDITOR_GROUP_NAME = "pmt_auditor_group";

  // Report Type
  public static final String IMPORT = "IMPORT";
  public static final String PROVISION = "PROVISION";
  public static final String CHANGEHISTORY = "CHANGEHISTORY";

  // Constants for Auditing
  public static final String SUCCESS = "SUCCESS";
  public static final String NEED_REVIEW = "NEED_REVIEW";
  public static final String SUCCESS_COUNT = "SUCCESS_COUNT";
  public static final String FAILURE = "FAILURE";
  public static final String DATE_FORMATTER = "yyyy-MM-dd hh:mm:ss.SSS";

  // Constatnts for statistics API
  public static final String ENVIRONMENT_ID = "environmentId";
  public static final String ENVIRONMENT_NAME = "environmentName";
  public static final String STATISTICS = "statistics";
  public static final String ZERO = "0";

  // Constatnts for provisioning statistics
  public static final String TOTAL = "total";
  public static final String READY_TO_PROVISION = "readyToProvision";
  public static final String SUCCESSFUL = "successful";
  public static final String FAILED = "failed";
  public static final String REPORT_PROVISION = "provision";

  // Constatnts for changeHistory statistics
  public static final String CHANGE_TOTAL = "total";
  public static final String CHANGE_MODIFIED = "modified";
  public static final String CHANGE_PROVISIONED = "provisioned";
  public static final String CHANGE_HISTORY = "changeHistory";

  // Constatnts for Import statistics
  public static final String IMPORT_TOTAL = "total";
  public static final String IMPORT_SUCCESSFUL = "successful";
  public static final String IMPORT_FAILED = "failed";
  public static final String IMPORT_LABEL = "import";
  public static final String IMPORT_NEED_REVIEW = "needReview";
  public static final String IMPORT_Import_Status = "ImportStatus";
  public static final String TOTAL_FILTERED_COUNT = "TOTAL_FILTERED_COUNT";

	// Constant for EntityID
	public static final String ENTITY_ID = "EntityID";

}
