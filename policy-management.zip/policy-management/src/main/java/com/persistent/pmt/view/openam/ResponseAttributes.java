package com.persistent.pmt.view.openam;

public class ResponseAttributes {

  private String type;
  private String propertyName;
  private String[] propertyValues;

  public ResponseAttributes() {
    super();
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getPropertyName() {
    return propertyName;
  }

  public void setPropertyName(String propertyName) {
    this.propertyName = propertyName;
  }

  public String[] getPropertyValues() {
    return propertyValues;
  }

  public void setPropertyValues(String[] propertyValues) {
    this.propertyValues = propertyValues;
  }

}
