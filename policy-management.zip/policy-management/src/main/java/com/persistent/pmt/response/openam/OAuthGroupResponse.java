package com.persistent.pmt.response.openam;

import java.util.List;

import com.persistent.pmt.response.TargetResponse;

public class OAuthGroupResponse implements TargetResponse {

	private List<Result> result;
	private String remainingPagedResults;
	private String totalPagedResults;
	private String resultCount;
	private String pagedResultsCookie;
	private String totalPagedResultsPolicy;

	public String getRemainingPagedResults() {
		return remainingPagedResults;
	}

	public void setRemainingPagedResults(String remainingPagedResults) {
		this.remainingPagedResults = remainingPagedResults;
	}

	public List<Result> getResult() {
		return result;
	}

	public void setResult(List<Result> result) {
		this.result = result;
	}

	public String getTotalPagedResults() {
		return totalPagedResults;
	}

	public void setTotalPagedResults(String totalPagedResults) {
		this.totalPagedResults = totalPagedResults;
	}

	public String getResultCount() {
		return resultCount;
	}

	public void setResultCount(String resultCount) {
		this.resultCount = resultCount;
	}

	public String getPagedResultsCookie() {
		return pagedResultsCookie;
	}

	public void setPagedResultsCookie(String pagedResultsCookie) {
		this.pagedResultsCookie = pagedResultsCookie;
	}

	public String getTotalPagedResultsPolicy() {
		return totalPagedResultsPolicy;
	}

	public void setTotalPagedResultsPolicy(String totalPagedResultsPolicy) {
		this.totalPagedResultsPolicy = totalPagedResultsPolicy;
	}

	@Override
	public String toString() {
		return "ClassPojo [remainingPagedResults = " + remainingPagedResults
				+ ", result = " + result + ", totalPagedResults = "
				+ totalPagedResults + ", resultCount = " + resultCount
				+ ", pagedResultsCookie = " + pagedResultsCookie
				+ ", totalPagedResultsPolicy = " + totalPagedResultsPolicy
				+ "]";
	}
}