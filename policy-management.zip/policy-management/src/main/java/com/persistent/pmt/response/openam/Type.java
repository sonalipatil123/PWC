package com.persistent.pmt.response.openam;

public class Type {
  private String _id;
  private String name;
  private boolean collection;

  public String get_id() {
    return _id;
  }

  public void set_id(String _id) {
    this._id = _id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public boolean isCollection() {
    return collection;
  }

  public void setCollection(boolean collection) {
    this.collection = collection;
  }

  @Override
  public String toString() {
    return "Type [_id=" + _id + ", name=" + name + ", collection=" + collection + "]";
  }

}