package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class WindowsDesktopModuleView implements ModuleView {

  @JsonIgnore
  private String id;
  private boolean lookupUserInRealm;
  private int authenticationLevel;
  private String keytabFileName;
  private String principalName;
  private String[] trustedKerberosRealms;
  private String kerberosServerName;
  private String kerberosRealm;
  private boolean returnPrincipalWithDomainName;

  public WindowsDesktopModuleView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public boolean getLookupUserInRealm() {
    return lookupUserInRealm;
  }

  public void setLookupUserInRealm(boolean lookupUserInRealm) {
    this.lookupUserInRealm = lookupUserInRealm;
  }

  public int getAuthenticationLevel() {
    return authenticationLevel;
  }

  public void setAuthenticationLevel(int authenticationLevel) {
    this.authenticationLevel = authenticationLevel;
  }

  public String getKeytabFileName() {
    return keytabFileName;
  }

  public void setKeytabFileName(String keytabFileName) {
    this.keytabFileName = keytabFileName;
  }

  public String getPrincipalName() {
    return principalName;
  }

  public void setPrincipalName(String principalName) {
    this.principalName = principalName;
  }

  public String[] getTrustedKerberosRealms() {
    return trustedKerberosRealms;
  }

  public void setTrustedKerberosRealms(String[] trustedKerberosRealms) {
    this.trustedKerberosRealms = trustedKerberosRealms;
  }

  public String getKerberosServerName() {
    return kerberosServerName;
  }

  public void setKerberosServerName(String kerberosServerName) {
    this.kerberosServerName = kerberosServerName;
  }

  public String getKerberosRealm() {
    return kerberosRealm;
  }

  public void setKerberosRealm(String kerberosRealm) {
    this.kerberosRealm = kerberosRealm;
  }

  public boolean getReturnPrincipalWithDomainName() {
    return returnPrincipalWithDomainName;
  }

  public void setReturnPrincipalWithDomainName(boolean returnPrincipalWithDomainName) {
    this.returnPrincipalWithDomainName = returnPrincipalWithDomainName;
  }

}