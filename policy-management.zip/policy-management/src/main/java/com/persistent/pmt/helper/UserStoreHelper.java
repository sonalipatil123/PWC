package com.persistent.pmt.helper;

import java.util.List;
import java.util.Map;

import com.persistent.pmt.model.LdapGroup;
import com.persistent.pmt.model.LdapUser;
import com.persistent.pmt.model.User;

public interface UserStoreHelper {

	public LdapUser getLdapUser(User user);

	public List<LdapUser> getLdapUsers(String userId);

	public List<LdapUser> getLdapUsers(String userId, Map<String,String> params);

	public List<LdapGroup> getLdapGroups(String groupId);

	public boolean isLdapUser(String userId);
	
	public boolean authenticate(String userId, String whatyouknow);
}
