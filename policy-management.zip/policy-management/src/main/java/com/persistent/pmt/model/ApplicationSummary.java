package com.persistent.pmt.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

/**
 * ApplicationSummary
 * 
 * Entity model for ApplicationSummary
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "application")
public class ApplicationSummary {

	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "pep_type")
	private String pepType;

	@Column(name = "enabled")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean enabled;

	@ManyToOne
	@JoinColumn(name = "state_id")
	private ApplicationState applicationState;

	@ManyToOne
	@JoinColumn(name = "platform_id")
	private Platform platform;

	@ManyToOne
	@JoinColumn(name = "originator_id")
	private Originator originator;

	@ManyToOne
	@JoinColumn(name = "environment_id")
	private Environment environment;

	@Column(name = "description")
	private String description;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "agent_id")
	private Agent agent;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "application_id")
	private List<ApplicationAttributes> attributes;

	public ApplicationSummary() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPepType() {
		return pepType;
	}

	public void setPepType(String pepType) {
		this.pepType = pepType;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public ApplicationState getApplicationState() {
		return applicationState;
	}

	public void setApplicationState(ApplicationState applicationState) {
		this.applicationState = applicationState;
	}

	public Platform getPlatform() {
		return platform;
	}

	public void setPlatform(Platform platform) {
		this.platform = platform;
	}

	public Originator getOriginator() {
		return originator;
	}

	public void setOriginator(Originator originator) {
		this.originator = originator;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Agent getAgent() {
		return agent;
	}

	public void setAgent(Agent agent) {
		this.agent = agent;
	}

	public List<ApplicationAttributes> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<ApplicationAttributes> attributes) {
		this.attributes = attributes;
	}
}
