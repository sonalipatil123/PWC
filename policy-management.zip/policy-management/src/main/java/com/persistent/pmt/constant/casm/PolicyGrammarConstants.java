package com.persistent.pmt.constant.casm;

public class PolicyGrammarConstants {
	public static final String METADATA = "metadata";
	public static final String IDENTITY_PROVIDER = "identityProvider";
	public static final String METADATA_URL = "metadataURL";
	public static final String SAML = "SAML";
	public static final String OAUTH = "OAUTH";

  // OAUTH2Client fields
  public static final String CLIENT_GROUP = "clientGroup";
  public static final String CLIENT_ID = "clientId";
  public static final String CLIENT_SECRETE = "clientSecret";

  public static final String ACTIVE = "Active";

  // system configuration property names
  public static final String OAUTH_GROUP_ENABLED = "oauthGroupEnabled";
  public static final String COPY_OAUTH_GROUP_PROPERTY = "copyOAuthGroupProperty";
  public static final String RESPONSE_ATTR_FETCH_MODE = "responseAttributeFetchMode";
  public static final String OPENAM_SERVER_URL = "openam.server.url";
  public static final String AGENT_SSL_PORT_REGEX = "agent.ssl.port.regex";
  public static final String AGENT_POLICY_EVALUATION_REALM = "agent.policy.evaluation.realm";
  public static final String OAUTH_AGENT_CREATION_REQUIRED = "oauthAgentCreationRequired";

	public static final String XML_File = "application/xml";
	
  public static final String RESPONSE_TYPE_HEADER = "HEADER";
  public static final String RESPONSE_TYPE_COOKIE = "COOKIE";

  // agent attributes for
  public static final String AGENT_ATTRIBUE_FQDN = "fqdn";
  public static final String AGENT_ATTRIBUE_LOGOFF_URI = "LogoffUri";
  public static final String AGENT_ATTRIBUE_GROUP_AGENTS = "Group_Agents";
  public static final String DUMMY_FQDN_VALUE = "dummy.pwc.internal.com";

  public static final String AGENT_TYPE_GROUP = "AgentGroup";
  public static final String AGENT_TYPE_AGENT = "Agent";

}
