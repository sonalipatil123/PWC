package com.persistent.pmt.response.openam;

public class PolicySetResponse {

  private String[] attributeNames;
  private String entitlementCombiner;
  private String[] subjects;
  private String[] resourceTypeUuids;
  private String applicationType;
  private String editable;
  private String[] conditions;
  private String creationDate;
  private String createdBy;
  private Object resourceComparator;
  private String description;
  private String name;
  private String lastModifiedBy;
  private String lastModifiedDate;
  private Object saveIndex;
  private Object searchIndex;
  private String displayName;

  public PolicySetResponse(String[] attributeNames, String entitlementCombiner,
      String[] subjects, String[] resourceTypeUuids, String applicationType, String editable,
      String[] conditions, String creationDate, String createdBy, Object resourceComparator,
      String description, String name, String lastModifiedBy, String lastModifiedDate,
      Object saveIndex, Object searchIndex, String displayName) {
    super();
    this.attributeNames = attributeNames;
    this.entitlementCombiner = entitlementCombiner;
    this.subjects = subjects;
    this.resourceTypeUuids = resourceTypeUuids;
    this.applicationType = applicationType;
    this.editable = editable;
    this.conditions = conditions;
    this.creationDate = creationDate;
    this.createdBy = createdBy;
    this.resourceComparator = resourceComparator;
    this.description = description;
    this.name = name;
    this.lastModifiedBy = lastModifiedBy;
    this.lastModifiedDate = lastModifiedDate;
    this.saveIndex = saveIndex;
    this.searchIndex = searchIndex;
    this.displayName = displayName;
  }

  public PolicySetResponse() {
    super();
    // TODO Auto-generated constructor stub
  }

  public String[] getAttributeNames() {
    return attributeNames;
  }

  public void setAttributeNames(String[] attributeNames) {
    this.attributeNames = attributeNames;
  }

  public String getEntitlementCombiner() {
    return entitlementCombiner;
  }

  public void setEntitlementCombiner(String entitlementCombiner) {
    this.entitlementCombiner = entitlementCombiner;
  }

  public String[] getSubjects() {
    return subjects;
  }

  public void setSubjects(String[] subjects) {
    this.subjects = subjects;
  }

  public String[] getResourceTypeUuids() {
    return resourceTypeUuids;
  }

  public void setResourceTypeUuids(String[] resourceTypeUuids) {
    this.resourceTypeUuids = resourceTypeUuids;
  }

  public String getApplicationType() {
    return applicationType;
  }

  public void setApplicationType(String applicationType) {
    this.applicationType = applicationType;
  }

  public String getEditable() {
    return editable;
  }

  public void setEditable(String editable) {
    this.editable = editable;
  }

  public String[] getConditions() {
    return conditions;
  }

  public void setConditions(String[] conditions) {
    this.conditions = conditions;
  }

  public String getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(String creationDate) {
    this.creationDate = creationDate;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public Object getResourceComparator() {
    return resourceComparator;
  }

  public void setResourceComparator(Object resourceComparator) {
    this.resourceComparator = resourceComparator;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLastModifiedBy() {
    return lastModifiedBy;
  }

  public void setLastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
  }

  public String getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(String lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  public Object getSaveIndex() {
    return saveIndex;
  }

  public void setSaveIndex(Object saveIndex) {
    this.saveIndex = saveIndex;
  }

  public Object getSearchIndex() {
    return searchIndex;
  }

  public void setSearchIndex(Object searchIndex) {
    this.searchIndex = searchIndex;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

}
