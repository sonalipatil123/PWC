package com.persistent.pmt.response;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude
public interface TargetResponse {

}
