package com.persistent.pmt.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * ChangeHistory
 * 
 * Entity model for ChangeHistory
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "CHANGE_HISTORY")
public class ChangeHistory {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "id")
  private int id;

  @Column(name = "APP_ID")
  private int applicationId;

  @Column(name = "VERSION")
  private Long version;

  @Enumerated(EnumType.STRING)
  @Column(name = "ACTION")
  private ACTIONS action;

  @Column(name = "DATA")
  private String data;

  @Column(name = "MANAGED_BY")
  private String managedBy;

  @Column(name = "MANAGED_ON")
  private Timestamp managedOn;

  @Column(name = "CONTEXT")
  private String context;

  @ManyToOne
  @JoinColumn(name = "ENVIRONMENT_ID")
  private Environment environment;

  @Column(name = "STATUS")
  private String status;

  public ChangeHistory() {

  }

  public ChangeHistory(long version, ACTIONS action, String changeHistoryMessage,
      String managedBy, Timestamp timestamp, int applicationId, Environment environment,
      String context, String status) {
    this.version = version;
    this.action = action;
    this.data = changeHistoryMessage;
    this.managedBy = managedBy;
    this.managedOn = timestamp;
    this.applicationId = applicationId;
    this.environment = environment;
    this.context = context;
    this.status = status;
  }

  public ChangeHistory(ACTIONS action, String changeHistoryMessage, String managedBy,
      Timestamp timestamp, int applicationId, Environment environment, String context,
      String status) {
    this.action = action;
    this.data = changeHistoryMessage;
    this.managedBy = managedBy;
    this.managedOn = timestamp;
    this.applicationId = applicationId;
    this.environment = environment;
    this.context = context;
    this.status = status;
  }

  public enum ACTIONS {
    IMPORT_ALL,
    IMPORT,
    CREATE,
    STATE_UPDATE,
    UPDATE,
    DELETE,
    PROVISION,
    DECOMMISSION,
    LOGIN,
    LOGOUT
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getApplicationId() {
    return applicationId;
  }

  public void setApplicationId(int applicationId) {
    this.applicationId = applicationId;
  }

  public long getVersion() {
    return version;
  }

  public void setVersion(long version) {
    this.version = version;
  }

  public ACTIONS getAction() {
    return action;
  }

  public void setAction(ACTIONS action) {
    this.action = action;
  }

  public String getData() {
    return data;
  }

  public void setData(String data) {
    this.data = data;
  }

  public String getManagedBy() {
    return managedBy;
  }

  public void setManagedBy(String managedBy) {
    this.managedBy = managedBy;
  }

  public Timestamp getManagedOn() {
    return managedOn;
  }

  public void setManagedOn(Timestamp managedOn) {
    this.managedOn = managedOn;
  }

  public String getContext() {
    return context;
  }

  /**
   * Context information related to the audit record.
   * 
   * @param context
   *          string value in format context1=value|context2=value,
   *          where value itself could be 1. key=value with each pair
   *          separated by comma 2. keys with each key separated by
   *          comma Example: attributes
   *          =name,description|someotherconteext
   *          =key1=val1|somethingelse =key1,key2
   */
  public void setContext(String context) {
    this.context = context;
  }

  public Environment getEnvironment() {
    return environment;
  }

  public void setEnvironment(Environment environment) {
    this.environment = environment;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public void setVersion(Long version) {
    this.version = version;
  }

}
