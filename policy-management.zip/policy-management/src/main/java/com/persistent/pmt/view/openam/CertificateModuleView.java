package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_NULL)
public class CertificateModuleView implements ModuleView {

  @JsonIgnore
  private String id;
	private int authenticationLevel;
	private String otherCertificateAttributeToProfileMapping;
	private String crlMatchingCertificateAttribute;
	private String ldapCertificateAttribute;
	private String[] certificateLdapServers;
	private String crlHttpParameters;
	private String clientCertificateHttpHeaderName;
	private boolean cacheCRLsInMemory;
	private String[] trustedRemoteHosts;
	private boolean matchCertificateToCRL;
	private boolean updateCRLsFromDistributionPoint;
	private String userBindPassword;
	private boolean matchCACertificateToCRL;
	private boolean sslEnabled;
	private boolean ocspValidationEnabled;
	private String certificateAttributeToProfileMapping;
	private String userBindDN;
	@JsonProperty("iplanet-am-auth-cert-gw-cert-preferred")
	private boolean iplanetAmAuthCertGwCertPreferred;
	private String certificateAttributeProfileMappingExtension;
	private boolean matchCertificateInLdap;
	private String[] ldapSearchStartDN;

	public CertificateModuleView() {
		super();
	}

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

	public int getAuthenticationLevel() {
		return authenticationLevel;
	}

	public void setAuthenticationLevel(int authenticationLevel) {
		this.authenticationLevel = authenticationLevel;
	}

	public String getOtherCertificateAttributeToProfileMapping() {
		return otherCertificateAttributeToProfileMapping;
	}

	public void setOtherCertificateAttributeToProfileMapping(
			String otherCertificateAttributeToProfileMapping) {
		this.otherCertificateAttributeToProfileMapping = otherCertificateAttributeToProfileMapping;
	}

	public String getCrlMatchingCertificateAttribute() {
		return crlMatchingCertificateAttribute;
	}

	public void setCrlMatchingCertificateAttribute(
			String crlMatchingCertificateAttribute) {
		this.crlMatchingCertificateAttribute = crlMatchingCertificateAttribute;
	}

	public String getLdapCertificateAttribute() {
		return ldapCertificateAttribute;
	}

	public void setLdapCertificateAttribute(String ldapCertificateAttribute) {
		this.ldapCertificateAttribute = ldapCertificateAttribute;
	}

	public String[] getCertificateLdapServers() {
		return certificateLdapServers;
	}

	public void setCertificateLdapServers(String[] certificateLdapServers) {
		this.certificateLdapServers = certificateLdapServers;
	}

	public String getCrlHttpParameters() {
		return crlHttpParameters;
	}

	public void setCrlHttpParameters(String crlHttpParameters) {
		this.crlHttpParameters = crlHttpParameters;
	}

	public String getClientCertificateHttpHeaderName() {
		return clientCertificateHttpHeaderName;
	}

	public void setClientCertificateHttpHeaderName(
			String clientCertificateHttpHeaderName) {
		this.clientCertificateHttpHeaderName = clientCertificateHttpHeaderName;
	}

	public boolean getCacheCRLsInMemory() {
		return cacheCRLsInMemory;
	}

	public void setCacheCRLsInMemory(boolean cacheCRLsInMemory) {
		this.cacheCRLsInMemory = cacheCRLsInMemory;
	}

	public String[] getTrustedRemoteHosts() {
		return trustedRemoteHosts;
	}

	public void setTrustedRemoteHosts(String[] trustedRemoteHosts) {
		this.trustedRemoteHosts = trustedRemoteHosts;
	}

	public boolean getMatchCertificateToCRL() {
		return matchCertificateToCRL;
	}

	public void setMatchCertificateToCRL(boolean matchCertificateToCRL) {
		this.matchCertificateToCRL = matchCertificateToCRL;
	}

	public boolean getUpdateCRLsFromDistributionPoint() {
		return updateCRLsFromDistributionPoint;
	}

	public void setUpdateCRLsFromDistributionPoint(
			boolean updateCRLsFromDistributionPoint) {
		this.updateCRLsFromDistributionPoint = updateCRLsFromDistributionPoint;
	}

	public String getUserBindPassword() {
		return userBindPassword;
	}

	public void setUserBindPassword(String userBindPassword) {
		this.userBindPassword = userBindPassword;
	}

	public boolean getMatchCACertificateToCRL() {
		return matchCACertificateToCRL;
	}

	public void setMatchCACertificateToCRL(boolean matchCACertificateToCRL) {
		this.matchCACertificateToCRL = matchCACertificateToCRL;
	}

	public boolean getSslEnabled() {
		return sslEnabled;
	}

	public void setSslEnabled(boolean sslEnabled) {
		this.sslEnabled = sslEnabled;
	}

	public boolean getOcspValidationEnabled() {
		return ocspValidationEnabled;
	}

	public void setOcspValidationEnabled(boolean ocspValidationEnabled) {
		this.ocspValidationEnabled = ocspValidationEnabled;
	}

	public String getCertificateAttributeToProfileMapping() {
		return certificateAttributeToProfileMapping;
	}

	public void setCertificateAttributeToProfileMapping(
			String certificateAttributeToProfileMapping) {
		this.certificateAttributeToProfileMapping = certificateAttributeToProfileMapping;
	}

	public String getUserBindDN() {
		return userBindDN;
	}

	public void setUserBindDN(String userBindDN) {
		this.userBindDN = userBindDN;
	}

	public boolean getIplanetAmAuthCertGwCertPreferred() {
		return iplanetAmAuthCertGwCertPreferred;
	}

	public void setIplanetAmAuthCertGwCertPreferred(
			boolean iplanetAmAuthCertGwCertPreferred) {
		this.iplanetAmAuthCertGwCertPreferred = iplanetAmAuthCertGwCertPreferred;
	}

	public String getCertificateAttributeProfileMappingExtension() {
		return certificateAttributeProfileMappingExtension;
	}

	public void setCertificateAttributeProfileMappingExtension(
			String certificateAttributeProfileMappingExtension) {
		this.certificateAttributeProfileMappingExtension = certificateAttributeProfileMappingExtension;
	}

	public boolean getMatchCertificateInLdap() {
		return matchCertificateInLdap;
	}

	public void setMatchCertificateInLdap(boolean matchCertificateInLdap) {
		this.matchCertificateInLdap = matchCertificateInLdap;
	}

	public String[] getLdapSearchStartDN() {
		return ldapSearchStartDN;
	}

	public void setLdapSearchStartDN(String[] ldapSearchStartDN) {
		this.ldapSearchStartDN = ldapSearchStartDN;
	}

}
