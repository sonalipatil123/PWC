package com.persistent.pmt.service;

import java.util.List;
import java.util.Map;

import com.persistent.pmt.model.LdapGroup;
import com.persistent.pmt.model.LdapUser;

public interface LdapIdentityService {

	public List<LdapUser> getLdapUsers(String userId);

	public List<LdapUser> getLdapUsers(String userId, Map<String,String> searcparams);

	public List<LdapGroup> getLdapGroups(String groupId);
}
