/**
 * 
 */
package com.persistent.pmt.constant;

/**
 * @author akriti_gupta
 *
 */
public enum Product {

	OPENAM;

}
