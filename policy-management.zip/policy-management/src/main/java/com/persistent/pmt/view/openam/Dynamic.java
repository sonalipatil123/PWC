package com.persistent.pmt.view.openam;

public class Dynamic {

  private int maxIdleTime;
  private int maxCachingTime;
  private int maxSessionTime;
  private int quotaLimit;

  public Dynamic() {
    super();
  }

  public int getMaxIdleTime() {
    return maxIdleTime;
  }

  public void setMaxIdleTime(int maxIdleTime) {
    this.maxIdleTime = maxIdleTime;
  }

  public int getMaxCachingTime() {
    return maxCachingTime;
  }

  public void setMaxCachingTime(int maxCachingTime) {
    this.maxCachingTime = maxCachingTime;
  }

  public int getMaxSessionTime() {
    return maxSessionTime;
  }

  public void setMaxSessionTime(int maxSessionTime) {
    this.maxSessionTime = maxSessionTime;
  }

  public int getQuotaLimit() {
    return quotaLimit;
  }

  public void setQuotaLimit(int quotaLimit) {
    this.quotaLimit = quotaLimit;
  }

  @Override
  public String toString() {
    return "ClassPojo [maxIdleTime = " + maxIdleTime + ", maxCachingTime = " + maxCachingTime
        + ", maxSessionTime = " + maxSessionTime + ", quotaLimit = " + quotaLimit + "]";
  }
}
