package com.persistent.pmt.dao.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.dao.ChangeHistoryDao;
import com.persistent.pmt.model.ChangeHistory;
import com.persistent.pmt.model.ChangeHistory.ACTIONS;

@PropertySource(value = { "classpath:application.properties" })
@Repository("changeHistoryDao")
@Transactional
public class ChangeHistoryDaoImpl extends BaseDaoImpl implements ChangeHistoryDao {

  @Override
  public ChangeHistory logChangeHistory(ChangeHistory changeHistory) {
    getSession().save(changeHistory);
    return changeHistory;
  }

  @SuppressWarnings("unchecked")
  @Override
  public List<Long> getVersion(int appId) {
    Criteria criteria = createCriteria(ChangeHistory.class);
    criteria.add(Restrictions.eq("applicationId", appId));
    criteria.setProjection(Projections.max("version"));
    return (List<Long>) criteria.list();
  }

  @SuppressWarnings("unchecked")
  @Override
  public List<ChangeHistory> getRecords(int appId, ACTIONS action) {
    Criteria criteria = createCriteria(ChangeHistory.class);
    criteria.add(Restrictions.eq("applicationId", appId))
        .add(Restrictions.eq("action", action)).addOrder(Order.asc("version"));
    return criteria.list();

  }

  @SuppressWarnings("unchecked")
  @Override
  public List<ChangeHistory> getRecordsByActionAndStatus(int environment,
      List<ACTIONS> actions, String status, Map<String, Integer> pagingDetails) {
    Criteria criteria = createCriteria(ChangeHistory.class);
    criteria.add(Restrictions.eq("environment.id", environment));
    if (actions != null && !actions.isEmpty()) {
      criteria.add(Restrictions.in("action", actions));
    }
    if (status != null && !status.isEmpty()) {
      criteria.add(Restrictions.eq("status", status));
    }
    prepareCriteriaForPaging(criteria, pagingDetails);
    criteria.addOrder(Order.desc("id"));
    return criteria.list();
  }

  @Override
  public Long getRecordCountByActionAndStatus(int environment, List<ACTIONS> actions,
      String status, boolean distinct) {
    Criteria criteria = createCriteria(ChangeHistory.class);
    criteria.add(Restrictions.eq("environment.id", environment));
    if (actions != null && !actions.isEmpty()) {
      criteria.add(Restrictions.in("action", actions));
    }
    if (status != null && !status.isEmpty()) {
      criteria.add(Restrictions.eq("status", status));
    }
    if (distinct) {
      criteria.setProjection(Projections.countDistinct("applicationId"));
    }
    else {
      criteria.setProjection(Projections.rowCount());
    }
    return ((Long) criteria.uniqueResult());
  }

  private void prepareCriteriaForPaging(Criteria criteria, Map<String, Integer> pagingDetails) {
    if (pagingDetails != null && !pagingDetails.isEmpty()) {
      if (pagingDetails.containsKey("page")) {
        criteria.setFirstResult((pagingDetails.get("page"))
            * pagingDetails.get("numberPerPage"));
      }
      if (pagingDetails.containsKey("numberPerPage")) {
        criteria.setMaxResults(pagingDetails.get("numberPerPage"));
      }
    }
  }
}
