package com.persistent.pmt.workflow.action.openam.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.WorkflowType;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.WorkflowException;
import com.persistent.pmt.executor.openam.ModuleExecutor;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.response.TargetResponse;
import com.persistent.pmt.utils.AuditWriter;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.view.openam.AnonymousModuleView;
import com.persistent.pmt.view.openam.CertificateModuleView;
import com.persistent.pmt.view.openam.HttpBasicModuleView;
import com.persistent.pmt.view.openam.LDAPModuleView;
import com.persistent.pmt.view.openam.LegacyOAuth2OpenIdConnectModuleView;
import com.persistent.pmt.view.openam.ModuleView;
import com.persistent.pmt.view.openam.OpenIdConnectIdTokenBearerModuleView;
import com.persistent.pmt.view.openam.SAML2ModuleView;
import com.persistent.pmt.view.openam.WindowsDesktopModuleView;
import com.persistent.pmt.workflow.action.CreateAction;
import com.persistent.pmt.workflow.action.mapper.casm.ModuleViewMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component("createModuleAction")
@Order(value = 5)
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class CreateModuleActionImpl implements CreateAction {

  private static final Logger logger = Logger.getLogger(CreateModuleActionImpl.class);

  @Autowired
  @Qualifier("openAMModuleExecutor")
  ModuleExecutor moduleExecutor;

  @Autowired
  ModuleViewMapper moduleMapper;

  @Autowired
  AuditWriter auditWriter;

  @Autowired
  Environment environment;

  @SuppressWarnings("unchecked")
  @Override
  public Object execute(Object object, List<WorkflowError> errors,
      WorkFlowContext workFlowContext) throws Exception {
    logger.log(Level.INFO, "CreateModuleActionImpl execute START");
    Application application = (Application) object;

    List<ModuleView> moduleViews = null;
    try {

      moduleViews =
          (List<ModuleView>) moduleMapper.getMappedObject(application, workFlowContext);
      workFlowContext.setModuleViews(moduleViews);

      if (moduleViews != null && !moduleViews.isEmpty()) {
        List<ModuleView> rollbackModuleViewsOnFailure = new ArrayList<ModuleView>();
        workFlowContext.setRollbackModuleViewsOnFailure(rollbackModuleViewsOnFailure);

        for (ModuleView moduleView : moduleViews) {

          if (moduleView instanceof LDAPModuleView) {
            TargetResponse response =
                moduleExecutor.get(
                    application,
                    Product.OPENAM,
                    getModuleType(moduleView),
                    CommonUtils.createOpenAMParamMap(getModuleId(moduleView),
                        workFlowContext.getRealmName()), workFlowContext);

            if (response != null) {
              // Audit log for module already existing in target
              // system
              workFlowContext.getModuleAuditData().append(
                  MessageFormat.format(
                      environment.getProperty(AuditPropertyConstants.TARGET_ACTION_EXISTS),
                      new Object[] { "LDAP Module", getModuleId(moduleView) }));
              continue;
            }
          }
          moduleExecutor.create(
              application,
              moduleView,
              Product.OPENAM,
              getModuleType(moduleView),
              CommonUtils.createOpenAMParamMap(getModuleId(moduleView),
                  workFlowContext.getRealmName()), workFlowContext);

          workFlowContext.getModuleAuditData().append(
              MessageFormat.format(
                  environment.getProperty(AuditPropertyConstants.TARGET_ACTION_SUCCESS),
                  new Object[] { "Module", getModuleId(moduleView) }));

          if (!(moduleView instanceof LDAPModuleView)) {
            rollbackModuleViewsOnFailure.add(moduleView);
          }
        }
        // Audit log for success
        auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS,
            environment.getProperty(AuditPropertyConstants.TARGET_ARTIFACT_ACTION_SUCCESS),
            workFlowContext.getModuleAuditData().toString(), new Object[] { "Module(s)",
                application.getName(), application.getId() });
      }
      else {
        // Audit log for empty module views
        workFlowContext.getModuleAuditData().append(
            MessageFormat.format(
                environment.getProperty(AuditPropertyConstants.TARGET_ACTION_DATA_NOT_VALID),
                new Object[] { "Module" }));
        logger.log(Level.INFO, "CreateAgentActionImpl execute | ModuleViews are empty.");
        throw new Exception("Provision Application Failed | ModuleViews are empty");
      }
    }
    catch (HttpClientErrorException ex) {
      // Audit Log for artifact creation failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE),
          workFlowContext.getModuleAuditData().toString(),
          new Object[] { "Module", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getResponseBodyAsString());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    catch (Exception ex) {
      // Audit Log for artifact creation failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE),
          workFlowContext.getModuleAuditData().toString(),
          new Object[] { "Module", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);
    }

    logger.log(Level.INFO, "CreateModuleActionImpl execute END");
    return application;
  }

  @Override
  public Object rollback(Object object, List<WorkflowError> errors, WorkFlowContext context)
      throws Exception {
    logger.log(Level.INFO, "CreateModuleActionImpl rollback START");
    Application application = (Application) object;
    try {
      if (context.getRollbackModuleViewsOnFailure() != null
          && !context.getRollbackModuleViewsOnFailure().isEmpty()) {

        logger.log(Level.INFO, "CreateModuleActionImpl rollback STARTED");
        for (ModuleView moduleView : context.getRollbackModuleViewsOnFailure()) {
          moduleExecutor
              .delete(
                  application,
                  Product.OPENAM,
                  getModuleType(moduleView),
                  CommonUtils.createOpenAMParamMap(getModuleId(moduleView),
                      context.getRealmName()), context);

          // Audit log for rollback success
          auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS,
              environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_SUCCESS),
              "", new Object[] { "Module", getModuleId(moduleView), application.getName(),
                  application.getId() });

        }
      }
      logger.log(Level.INFO, "CreateModuleActionImpl rollback END");
    }
    catch (HttpClientErrorException ex) {
      // Audit log for rollback failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
          new Object[] { "Module", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to rollback module for application: "
                  + ex.getResponseBodyAsString());
      errors.add(error);
      logger.log(Level.ERROR, "Failed to rollback module for application with id: "
          + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    catch (Exception ex) {
      // Audit log for rollback failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
          new Object[] { "Module", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to rollback module for application: "
                  + ex.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR, "Failed to rollback module for application with id: "
          + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    return application;
  }

  private Artifact getModuleType(ModuleView moduleView) {
    Artifact artifact = null;
    if (moduleView instanceof LDAPModuleView) {
      artifact = Artifact.MODULE_LDAP;
    }
    else if (moduleView instanceof SAML2ModuleView) {
      artifact = Artifact.MODULE_SAML;
    }
    else if (moduleView instanceof LegacyOAuth2OpenIdConnectModuleView) {
      artifact = Artifact.MODULE_OAUTH2;
    }
    else if (moduleView instanceof OpenIdConnectIdTokenBearerModuleView) {
      artifact = Artifact.MODULE_OPENID_CONNECT;
    }
    else if (moduleView instanceof CertificateModuleView) {
      artifact = Artifact.MODULE_CERT;
    }
    else if (moduleView instanceof WindowsDesktopModuleView) {
      artifact = Artifact.MODULE_WIN_DESKTOP_SSO;
    }
    else if (moduleView instanceof AnonymousModuleView) {
      artifact = Artifact.MODULE_ANONYMOUS;
    }
    else if (moduleView instanceof HttpBasicModuleView) {
      artifact = Artifact.MODULE_HTTP_BASIC;
    }
    return artifact;
  }

  private String getModuleId(ModuleView moduleView) {
    String id = "";
    if (moduleView instanceof LDAPModuleView) {
      id = ((LDAPModuleView) moduleView).getId();
    }
    else if (moduleView instanceof SAML2ModuleView) {
      id = ((SAML2ModuleView) moduleView).getId();
    }
    else if (moduleView instanceof LegacyOAuth2OpenIdConnectModuleView) {
      id = ((LegacyOAuth2OpenIdConnectModuleView) moduleView).getId();
    }
    else if (moduleView instanceof OpenIdConnectIdTokenBearerModuleView) {
      id = ((OpenIdConnectIdTokenBearerModuleView) moduleView).getId();
    }
    else if (moduleView instanceof CertificateModuleView) {
      id = ((CertificateModuleView) moduleView).getId();
    }
    else if (moduleView instanceof WindowsDesktopModuleView) {
      id = ((WindowsDesktopModuleView) moduleView).getId();
    }
    else if (moduleView instanceof AnonymousModuleView) {
      id = ((AnonymousModuleView) moduleView).getId();
    }
    else if (moduleView instanceof HttpBasicModuleView) {
      id = ((HttpBasicModuleView) moduleView).getId();
    }
    return id;
  }
}
