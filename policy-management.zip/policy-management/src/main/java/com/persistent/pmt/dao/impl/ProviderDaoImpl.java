package com.persistent.pmt.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.dao.ProviderDao;
import com.persistent.pmt.model.Provider;
import com.persistent.pmt.model.ProviderAttributes;

/**
 * ProviderDaoImpl
 * 
 * Implementation of ProviderDao
 * 
 * @author Persistent Systems
 */
@PropertySource(value = { "classpath:application.properties" })
@Repository("providerDao")
@Transactional
public class ProviderDaoImpl extends BaseDaoImpl implements ProviderDao {

  /**
   * This method creates a provider into PMT database
   */
  @Override
  public Provider createProvider(Provider provider) {
    getSession().save(provider);
    return provider;
  }

  
  /**
   * This method creates a provider into PMT database
   */
@Override
public Provider getProviderByName(String name) {
	Criteria criteria = createCriteria(Provider.class);
    criteria.add(Restrictions.eq("name", name));
    return (Provider) criteria.uniqueResult();
}


@Override
public void updateProvider(Provider provider) {	
	getSession().saveOrUpdate(provider);
}

	/**
	 * This method fetches provider by id
	 */
	@Override
	public Provider getProviderById(int providerId) {
		
		Criteria criteria = createCriteria(Provider.class);
	    criteria.add(Restrictions.eq("id", providerId));
	    return (Provider) criteria.uniqueResult();
	}
	
	/**
	 * This method fetches provider by id
	 */
	@Override
	public List<ProviderAttributes> getProviderAttributesBySourceAttr(String sourceAttrName, String sourceAttrValue) {
		
		Criteria criteria = createCriteria(ProviderAttributes.class);
	    criteria.add(Restrictions.eq("sourceAttrName", sourceAttrName));
	    criteria.add(Restrictions.eq("sourceAttrValue", sourceAttrValue));
	    return (List<ProviderAttributes>) criteria.list();	    
	}

}
