package com.persistent.pmt.utils;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.util.StringUtils;

import com.persistent.pmt.constant.MapperConstants;

public class AuditUtils {

  public enum CONTEXT_FORMAT_TYPE {
    KEYS, KEYVALS
  }

  /* parseContext */
  /**
   * Context information related to the audit record.
   * 
   * @param context
   *          string value in format context1=value|context2=value,
   *          where value itself could be 1. key=value with each pair
   *          separated by comma 2. keys with each key separated by
   *          comma Example:
   *          attributes=name,description|someotherconteext
   *          =key1=val1|somethingelse=key1,key2
   * @returns null for wrong format type. Returns Set for keys format
   *          and map for KEUVALS format. Caller can typecast bsaed on
   *          the context.
   */
  public static Object parseContext(String context, String contextName,
      CONTEXT_FORMAT_TYPE contextFormatType) {
    if (contextFormatType.equals(CONTEXT_FORMAT_TYPE.KEYS)) {
      Set<String> uniqueAttributes = new HashSet<>();
      Collections.addAll(uniqueAttributes, getContextKeys(context, contextName));
      return uniqueAttributes;
    }
    else if (contextFormatType.equals(CONTEXT_FORMAT_TYPE.KEYVALS)) {
      return getContextKeyVals(context, contextName);

    }
    return null;
  }

  public static String[] getContextKeys(String context, String contextName) {
    String[] tokens = {};
    String searchStr = new StringBuilder().append(contextName).append("=").toString();

    if (context != null && context.indexOf(searchStr) >= 0) {
      context =
          context.substring(context.indexOf(searchStr) + searchStr.length(), context.length());
      if (context.indexOf('|') > 0) {
        context = context.substring(0, context.indexOf('|'));
        context = StringUtils.trimTrailingCharacter(context, '|');
      }
      if (context != null) {
        tokens =
            StringUtils.delimitedListToStringArray(context, MapperConstants.SEPARATOR_COMMA);
        return tokens;
      }
    }
    return tokens;
  }

  public static Map<String, String> getContextKeyVals(String context, String contextName) {
    String[] keyvalpairs = getContextKeys(context, contextName);
    Map<String, String> pairs = new HashMap<String, String>();
    String[] keyval = {};
    for (String s : keyvalpairs) {
      keyval = StringUtils.delimitedListToStringArray(s, "=");
      pairs.put(keyval[0], keyval[1]);
    }
    return pairs;
  }

}
