package com.persistent.pmt.to.openam;

import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuthNPolicyCombineTO {

	  private int id;
	  private String name;
	  private String description;
	  private boolean enabled;
	  private List<String> resources; // list of resource ids
	  private String scheme;
	  private boolean isPublic;
	  private List<ResponseTO> responses;
	  private Set<String> actions;
	  private String schemeType;
	  private boolean selected;
	  private String applicationName;
	  private String level;
	  private String authSchemeId;
	  	  
	public String getAuthSchemeId() {
		return authSchemeId;
	}
	public void setAuthSchemeId(String authSchemeId) {
		this.authSchemeId = authSchemeId;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Boolean getEnabled() {
		return enabled;
	}
	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}
	public List<String> getResources() {
		return resources;
	}
	public void setResources(List<String> resources) {
		this.resources = resources;
	}
	public String getScheme() {
		return scheme;
	}
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}
	public Boolean getIsPublic() {
		return isPublic;
	}
	public void setIsPublic(Boolean isPublic) {
		this.isPublic = isPublic;
	}
	public List<ResponseTO> getResponses() {
		return responses;
	}
	public void setResponses(List<ResponseTO> responses) {
		this.responses = responses;
	}
	public Set<String> getActions() {
		return actions;
	}
	public void setActions(Set<String> actions) {
		this.actions = actions;
	}
	public String getSchemeType() {
		return schemeType;
	}
	public void setSchemeType(String schemeType) {
		this.schemeType = schemeType;
	}
	public boolean isSelected() {
		return selected;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	  
	  
}
