package com.persistent.pmt.workflow.action.mapper.casm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.commons.context.UserContext;
import com.persistent.pmt.constant.MapperConstants;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.User;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.utils.MapperUtils;
import com.persistent.pmt.view.openam.PolicySetView;
import com.persistent.pmt.workflow.action.mapper.GenericMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component
public class PolicySetViewMapper implements GenericMapper {

  @Autowired
  ThreadLocal<PMTContext> pmtContextThreadLocal;

  @Override
  public Object getMappedObject(Object object, WorkFlowContext workFlowContext)
      throws GenericException {
    return getPolicySetView((Application) object);
  }

  @Override
  public String getId(Object object) throws GenericException {
    return CommonUtils.formatString(((Application) object).getName(),
        MapperUtils.getInvalidCharacters());
  }

  private Object getPolicySetView(Application application) throws GenericException {

    PolicySetView policySetView = null;

    if (application != null) {
      policySetView = new PolicySetView();

      policySetView.setId(getId(application));
      policySetView.setName(getId(application));

      policySetView.setDisplayName(getId(application));
      policySetView.setDescription(application.getDescription());
      policySetView.setApplicationType(MapperConstants.POLICY_SET_APPLICATION_TYPE);
      policySetView.setEditable("true");

      PMTContext pmtContext = pmtContextThreadLocal.get();
      if (pmtContext != null && pmtContext.getUserContext() != null) {
        User user = pmtContext.getUserContext().getUser(UserContext.USER);
        if (user != null) {
          policySetView.setCreatedBy(user.getUserName());
        }
      }

      policySetView.setConditions(setConditions());
      policySetView.setSubjects(setSubjects());

    }
    return policySetView;
  }

  private String[] setConditions() {
    return new String[] { "LEAuthLevel", "Policy", "Script", "AuthenticateToService",
        "SimpleTime", "AMIdentityMembership", "OR", "IPv6", "IPv4", "SessionProperty",
        "AuthScheme", "AuthLevel", "NOT", "Transaction", "AuthenticateToRealm", "AND",
        "ResourceEnvIP", "LDAPFilter", "OAuth2Scope", "Session" };
  }

  private String[] setSubjects() {
    return new String[] { "Policy", "NOT", "OR", "JwtClaim", "AuthenticatedUsers", "AND",
        "Identity", "NONE" };
  }
}
