package com.persistent.pmt.metadata.generator.descriptors.core;

import java.util.Map;

public interface Descriptor {

	public String getXMLData(Map<String, String> tokenMap);

	public void setTemplatePath(String templatePath);

	public Map<String, String> getDescriptorData(Map<String, String> tokenMap);
}
