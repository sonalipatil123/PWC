package com.persistent.pmt.response.openam;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class HttpBasicModuleResponse implements ModuleResponse {

  private String _rev;

  private Type _type;

  private String authenticationLevel;

  private String _id;

  private String backendModuleName;

  public String get_rev() {
    return _rev;
  }

  public void set_rev(String _rev) {
    this._rev = _rev;
  }

  public Type get_type() {
    return _type;
  }

  public void set_type(Type _type) {
    this._type = _type;
  }

  public String getAuthenticationLevel() {
    return authenticationLevel;
  }

  public void setAuthenticationLevel(String authenticationLevel) {
    this.authenticationLevel = authenticationLevel;
  }

  public String get_id() {
    return _id;
  }

  public void set_id(String _id) {
    this._id = _id;
  }

  public String getBackendModuleName() {
    return backendModuleName;
  }

  public void setBackendModuleName(String backendModuleName) {
    this.backendModuleName = backendModuleName;
  }

}
