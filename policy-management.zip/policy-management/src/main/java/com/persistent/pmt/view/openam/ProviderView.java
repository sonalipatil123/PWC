package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.response.openam.Type;
import com.persistent.pmt.view.TargetView;

@JsonInclude(Include.NON_NULL)
public class ProviderView implements TargetView {
  String _id;
  String metadata;
  String entityConfig;
  Type type;

  public String get_id() {
    return _id;
  }

  public void set_id(String _id) {
    this._id = _id;
  }

  public String getMetadata() {
    return metadata;
  }

  public void setMetadata(String metadata) {
    this.metadata = metadata;
  }

  public String getEntityConfig() {
    return entityConfig;
  }

  public void setEntityConfig(String entityConfig) {
    this.entityConfig = entityConfig;
  }

  public Type getType() {
    return type;
  }

  public void setType(Type type) {
    this.type = type;
  }

}
