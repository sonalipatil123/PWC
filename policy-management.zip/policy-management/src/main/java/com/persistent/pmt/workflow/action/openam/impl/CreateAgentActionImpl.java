package com.persistent.pmt.workflow.action.openam.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.WorkflowType;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.WorkflowException;
import com.persistent.pmt.executor.openam.AgentExecutor;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.utils.AuditWriter;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.view.openam.AgentView;
import com.persistent.pmt.workflow.action.CreateAction;
import com.persistent.pmt.workflow.action.mapper.casm.AgentViewMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component("createAgentAction")
@Order(value = 3)
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class CreateAgentActionImpl implements CreateAction {

  private static final Logger logger = Logger.getLogger(CreateAgentActionImpl.class);

  @Autowired
  @Qualifier("openAMAgentExecutor")
  AgentExecutor agentExecutor;

  @Autowired
  AgentViewMapper agentViewMapper;

  @Autowired
  AuditWriter auditWriter;

  @Autowired
  Environment environment;

  @SuppressWarnings("unchecked")
  @Override
  public Object execute(Object object, List<WorkflowError> errors, WorkFlowContext context)
      throws Exception {

    logger.log(Level.INFO, "CreateAgentActionImpl execute START");

    Application application = (Application) object;

    try {

      List<AgentView> agentViews =
          (List<AgentView>) agentViewMapper.getMappedObject(application, context);
      if (agentViews != null && !agentViews.isEmpty()) {
        List<AgentView> rollbackAgentViewsOnFailure = new ArrayList<AgentView>();
        context.setRollbackAgentViewsOnFailure(rollbackAgentViewsOnFailure);
        for (AgentView agentView : agentViews) {
          if (isAgentExists(application, agentView, context)) {
            // Audit log if agent already exists in target system
            context.getAgentAuditData().append(
                MessageFormat.format(
                    environment.getProperty(AuditPropertyConstants.TARGET_ACTION_EXISTS),
                    new Object[] { "Agent", agentView.getId() }));
            continue;
          }
          agentExecutor.create(application, agentView, Product.OPENAM, Artifact.AGENT,
              CommonUtils.createOpenAMParamMap(agentView.getId(), context.getRealmName()),
              context);
          // Audit log if agent created successfully
          context.getAgentAuditData().append(
              MessageFormat.format(
                  environment.getProperty(AuditPropertyConstants.TARGET_ACTION_SUCCESS),
                  new Object[] { "Agent", agentView.getId() }));

          rollbackAgentViewsOnFailure.add(agentView);

        }
        // Audit log for success
        auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS,
            environment.getProperty(AuditPropertyConstants.TARGET_ARTIFACT_ACTION_SUCCESS),
            context.getAgentAuditData().toString(),
            new Object[] { "Agent(s)", application.getName(), application.getId() });
      }
      else {

        // Audit log for not valid data
        context.getAgentAuditData().append(
            MessageFormat.format(
                environment.getProperty(AuditPropertyConstants.TARGET_ACTION_DATA_NOT_VALID),
                new Object[] { "Agent" }));
        logger.log(Level.INFO, "CreateAgentActionImpl execute | AgentViews are empty.");
        throw new Exception("Provision Application Failed | AgentViews are empty");
      }

    }
    catch (HttpClientErrorException ex) {

      // Audit Log for artifact creation failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE, environment
          .getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE), context
          .getAgentAuditData().toString(), new Object[] { "Agent", application.getName(),
          application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getResponseBodyAsString());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    catch (Exception ex) {

      // Audit Log for artifact creation failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE, environment
          .getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE), context
          .getAgentAuditData().toString(), new Object[] { "Agent", application.getName(),
          application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    logger.log(Level.INFO, "CreateAgentActionImpl execute END");
    return application;
  }

  private boolean isAgentExists(Application application, AgentView agentView,
      WorkFlowContext context) {
    try {
      agentExecutor.get(application, Product.OPENAM, Artifact.AGENT,
          CommonUtils.createOpenAMParamMap(agentView.getId(), context.getRealmName()), context);
      return true;
    }
    catch (HttpClientErrorException ex) {
      return false;
    }
  }

  @Override
  public Object rollback(Object object, List<WorkflowError> errors, WorkFlowContext context)
      throws Exception {
    logger.log(Level.INFO, "CreateAgentActionImpl rollback START");
    Application application = (Application) object;
    List<AgentView> rollbackAgentViews = context.getRollbackAgentViewsOnFailure();
    try {
      if (rollbackAgentViews != null && !rollbackAgentViews.isEmpty()) {
        logger.log(Level.INFO, "CreateAgentActionImpl rollback STARTED");
        for (AgentView agentView : rollbackAgentViews) {
          agentExecutor.delete(application, Product.OPENAM, Artifact.AGENT,
              CommonUtils.createOpenAMParamMap(agentView.getId(), context.getRealmName()),
              context);

          // Audit log for rollback success
          auditWriter.write(
              ACTIONS.PROVISION,
              PMTConstants.SUCCESS,
              environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_SUCCESS),
              "",
              new Object[] { "Agent", agentView.getId(), application.getName(),
                  application.getId() });
        }
      }
    }
    catch (HttpClientErrorException ex) {

      // Audit log for rollback failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
          new Object[] { "Agent", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to rollback  Agent for application: "
                  + ex.getResponseBodyAsString());
      errors.add(error);
      logger.log(Level.ERROR, "Failed to rollback Agent for application with id: "
          + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    catch (Exception ex) {

      // Audit log for rollback failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
          new Object[] { "Agent", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to rollback Agent for application: "
                  + ex.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR, "Failed to rollback Agent for application with id: "
          + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    logger.log(Level.INFO, "CreateAgentActionImpl rollback END");
    return application;
  }
}
