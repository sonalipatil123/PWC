package com.persistent.pmt.response.openam;

public class Dynamic {
	private int maxSessionTime;
	private int maxIdleTime;
	private int maxCachingTime;
	private int quotaLimit;

	public int getMaxSessionTime() {
		return maxSessionTime;
	}

	public void setMaxSessionTime(int maxSessionTime) {
		this.maxSessionTime = maxSessionTime;
	}

	public int getMaxIdleTime() {
		return maxIdleTime;
	}

	public void setMaxIdleTime(int maxIdleTime) {
		this.maxIdleTime = maxIdleTime;
	}

	public int getMaxCachingTime() {
		return maxCachingTime;
	}

	public void setMaxCachingTime(int maxCachingTime) {
		this.maxCachingTime = maxCachingTime;
	}

	public int getQuotaLimit() {
		return quotaLimit;
	}

	public void setQuotaLimit(int quotaLimit) {
		this.quotaLimit = quotaLimit;
	}

}
