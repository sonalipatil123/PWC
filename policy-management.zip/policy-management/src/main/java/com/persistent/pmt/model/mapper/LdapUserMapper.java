package com.persistent.pmt.model.mapper;

import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

import org.springframework.ldap.core.AttributesMapper;

import com.persistent.pmt.model.LdapUser;
import com.persistent.pmt.utils.CommonUtils;

public class LdapUserMapper implements AttributesMapper<LdapUser> {

	Map<String,String> attributeName = new HashMap<>();;
	
	public void setAttributeName(Map<String, String> attributeName) {
		this.attributeName = attributeName;
	}

	@Override
	public LdapUser mapFromAttributes(Attributes attributes) throws NamingException {
		LdapUser user = new LdapUser();
		// user.setUserid(CommonUtils.getStringValue(attributes.get("userid")));
		/*
		 * UserId field is null when data is fetched from AD To fix this issue
		 * we have used name field of AD response
		 */
				
		user.setUserid(CommonUtils.getStringValue(attributes.get((attributeName != null && attributeName.get("userid") != null) ? attributeName.get("userid"): "uid")));
		user.setGivenName(CommonUtils.getStringValue(attributes.get((attributeName != null && attributeName.get("givenName") != null) ? attributeName.get("givenName"): "givenName")));
		user.setSurname(CommonUtils.getStringValue(attributes.get((attributeName != null && attributeName.get("surname") != null) ? attributeName.get("surname"): "sn")));
		user.setMemberOf(CommonUtils.getMultiValuedString(attributes.get((attributeName != null && attributeName.get("memberOf") != null) ? attributeName.get("memberOf"): "isMemberOf")));
		return user;
	}

}