package com.persistent.pmt.view.openam;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.view.TargetView;

@JsonInclude(Include.NON_NULL)
public class ResourceTypeView implements TargetView {

  @JsonIgnore
  private String id;
  private String creationDate;
  private String[] patterns;
  private String createdBy;
  private String description;
  private String name;
  private String lastModifiedBy;
  private String lastModifiedDate;
  private String uuid;
  private Map<String, Boolean> actions;

  public ResourceTypeView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(String creationDate) {
    this.creationDate = creationDate;
  }

  public String[] getPatterns() {
    return patterns;
  }

  public void setPatterns(String[] patterns) {
    this.patterns = patterns;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLastModifiedBy() {
    return lastModifiedBy;
  }

  public void setLastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
  }

  public String getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(String lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  public Map<String, Boolean> getActions() {
    return actions;
  }

  public void setActions(Map<String, Boolean> actions) {
    this.actions = actions;
  }

}
