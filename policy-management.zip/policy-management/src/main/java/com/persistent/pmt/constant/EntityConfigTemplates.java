package com.persistent.pmt.constant;

public class EntityConfigTemplates {

  public static final String REMOTE_IDP_CONFIG_XML =
      "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<EntityConfig entityID=\""
          + PMTConstants.ENTITY_CONFIG_ID
          + "\" hosted=\"false\"\n\txmlns=\"urn:sun:fm:SAML:2.0:entityconfig\">\n\t<IDPSSOConfig>\n\t\t<Attribute name=\"description\"/>\n\t\t<Attribute name=\"signingCertAlias\"/>\n\t\t<Attribute name=\"encryptionCertAlias\"/>\n\t\t<Attribute name=\"basicAuthOn\"/>\n\t\t<Attribute name=\"basicAuthUser\"/>\n\t\t<Attribute name=\"basicAuthPassword\"/>\n\t\t<Attribute name=\"autofedEnabled\"/>\n\t\t<Attribute name=\"autofedAttribute\"/>\n\t\t<Attribute name=\"assertionEffectiveTime\"/>\n\t\t<Attribute name=\"idpAuthncontextMapper\"/>\n\t\t<Attribute name=\"idpAuthncontextClassrefMapping\"/>\n\t\t<Attribute name=\"idpAccountMapper\"/>\n\t\t<Attribute name=\"idpDisableNameIDPersistence\"/>\n\t\t<Attribute name=\"idpAttributeMapper\"/>\n\t\t<Attribute name=\"assertionIDRequestMapper\"/>\n\t\t<Attribute name=\"nameIDFormatMap\"/>\n\t\t<Attribute name=\"idpECPSessionMapper\"/>\n\t\t<Attribute name=\"attributeMap\">\n\t\t\t<Value>uid=uid</Value>\n\t\t</Attribute>\n\t\t<Attribute name=\"wantNameIDEncrypted\"/>\n\t\t<Attribute name=\"wantArtifactResolveSigned\"/>\n\t\t<Attribute name=\"wantLogoutRequestSigned\"/>\n\t\t<Attribute name=\"wantLogoutResponseSigned\"/>\n\t\t<Attribute name=\"wantMNIRequestSigned\"/>\n\t\t<Attribute name=\"wantMNIResponseSigned\"/>\n\t\t<Attribute name=\"cotlist\">\n\t\t\t<Value>"
          + PMTConstants.ENTITY_CONFIG_COT
          + "</Value>\n\t\t</Attribute>\n\t\t<Attribute name=\"discoveryBootstrappingEnabled\"/>\n\t\t<Attribute name=\"assertionCacheEnabled\"/>\n\t\t<Attribute name=\"assertionNotBeforeTimeSkew\"/>\n\t\t<Attribute name=\"saeAppSecretList\"/>\n\t\t<Attribute name=\"saeIDPUrl\"/>\n\t\t<Attribute name=\"AuthUrl\"/>\n\t\t<Attribute name=\"appLogoutUrl\"/>\n\t\t<Attribute name=\"idpSessionSyncEnabled\"/>\n\t\t<Attribute name=\"relayStateUrlList\"/>\n\t</IDPSSOConfig>\n</EntityConfig>\n";

  public static final String REMOTE_SP_CONFIG_XML =
      "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<EntityConfig "
          + "entityID=\""
          + PMTConstants.ENTITY_CONFIG_ID
          + "\" hosted=\"false\" xmlns=\"urn:sun:fm:SAML:2.0:entityconfig\">\n    <SPSSOConfig>\n      "
          + "<Attribute name=\"wantLogoutResponseSigned\"/>\n        <Attribute name=\"wantAttributeEncrypted\"/>\n        <Attribute name=\"spAuthncontextMapper\"/>\n        <Attribute name=\"alwaysIdpProxy\"/>\n        <Attribute name=\"autofedAttribute\"/>\n        <Attribute name=\"spSessionSyncEnabled\"/>\n        <Attribute name=\"spAuthncontextComparisonType\"/>\n        <Attribute name=\"idpProxyList\"/>\n        <Attribute name=\"spDoNotWriteFederationInfo\"/>\n        <Attribute name=\"wantPOSTResponseSigned\"/>\n        <Attribute name=\"localAuthURL\"/>\n        <Attribute name=\"wantMNIRequestSigned\"/>\n        <Attribute name=\"spAdapterEnv\"/>\n        <Attribute name=\"basicAuthPassword\"/>\n        <Attribute name=\"transientUser\"/>\n "
          + "<Attribute name=\"cotlist\">\n            <Value>"
          + PMTConstants.ENTITY_CONFIG_COT
          + "</Value>\n        "
          + "</Attribute>\n "
          + "<Attribute name=\"spAttributeMapper\"/>\n        <Attribute name=\"saeSPUrl\"/>\n        <Attribute name=\"responseArtifactMessageEncoding\">\n            <Value>URI</Value>\n        </Attribute>\n        <Attribute name=\"useNameIDAsSPUserID\"/>\n        <Attribute name=\"wantAssertionEncrypted\"/>\n        <Attribute name=\"saml2AuthModuleName\"/>\n        <Attribute name=\"signingCertAlias\"/>\n        <Attribute name=\"relayStateUrlList\"/>\n        <Attribute name=\"appLogoutUrl\"/>\n        <Attribute name=\"useIntroductionForIDPProxy\"/>\n        <Attribute name=\"ECPRequestIDPListGetComplete\"/>\n         "
          + "<Attribute name=\"attributeMap\">\n "
          + PMTConstants.ATTRIBUTE_MAP
          + "    </Attribute>\n    <Attribute name=\"spAuthncontextClassrefMapping\"/>\n        <Attribute name=\"wantMNIResponseSigned\"/>\n        <Attribute name=\"wantLogoutRequestSigned\"/>\n        <Attribute name=\"metaAlias\"/>\n        <Attribute name=\"ECPRequestIDPListFinderImpl\"/>\n        <Attribute name=\"spAccountMapper\"/>\n        <Attribute name=\"includeRequestedAuthnContext\"/>\n        <Attribute name=\"spAdapter\"/>\n        <Attribute name=\"ECPRequestIDPList\"/>\n        <Attribute name=\"saeAppSecretList\"/>\n        <Attribute name=\"idpProxyCount\"/>\n        <Attribute name=\"wantArtifactResponseSigned\"/>\n        <Attribute name=\"basicAuthOn\"/>\n        <Attribute name=\"wantNameIDEncrypted\"/>\n        <Attribute name=\"basicAuthUser\"/>\n        <Attribute name=\"saeSPLogoutUrl\"/>\n        <Attribute name=\"intermediateUrl\"/>\n        <Attribute name=\"useIDPFinder\"/>\n        <Attribute name=\"encryptionCertAlias\"/>\n        <Attribute name=\"defaultRelayState\"/>\n        <Attribute name=\"assertionTimeSkew\"/>\n        <Attribute name=\"autofedEnabled\"/>\n        <Attribute name=\"enableIDPProxy\"/>\n    </SPSSOConfig>\n</EntityConfig>\n\n";

  public static final String WSFED_HOSTED_SP_CONFIG_XML =
      "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
          + "<FederationConfig FederationID=\""
          + PMTConstants.ENTITY_CONFIG_ID
          + "\" hosted=\"false\" xmlns=\"urn:sun:fm:wsfederation:1.0:federationconfig\">\n"
          + "<SPSSOConfig>\r\n      <Attribute name=\"assertionEffectiveTime\"/>\r\n  "
          + "    <Attribute name=\"displayName\">\r\n        <Value>"
          + PMTConstants.PROVIDER_DISPLAY_NAME
          + "</Value>\r\n      </Attribute>\r\n"
          + "   <Attribute name=\"spAuthncontextMapper\"/>\r\n      <Attribute name=\"AccountRealmCookieName\"/>\r\n      <Attribute name=\"attributeMap\"/>\r\n      <Attribute name=\"AccountRealmSelection\"/>\r\n      <Attribute name=\"spAuthncontextClassrefMapping\"/>\r\n      <Attribute name=\"autofedAttribute\"/>\r\n      <Attribute name=\"cotlist\">\r\n        <Value>"
          + PMTConstants.ENTITY_CONFIG_COT
          + "</Value>\r\n      </Attribute>\r\n      <Attribute name=\"spAttributeMapper\"/>\r\n      <Attribute name=\"spAuthncontextComparisonType\"/>\r\n      <Attribute name=\"spAccountMapper\"/>\r\n      <Attribute name=\"defaultRelayState\"/>\r\n      <Attribute name=\"HomeRealmDiscoveryService\"/>\r\n      <Attribute name=\"wreplyList\"/>\r\n      <Attribute name=\"assertionTimeSkew\"/>\r\n      <Attribute name=\"wantAssertionSigned\">\r\n        <Value>true</Value>\r\n      </Attribute>\r\n      <Attribute name=\"autofedEnabled\"/>\r\n    </SPSSOConfig>\r\n  </FederationConfig>";
}
