package com.persistent.pmt.utils;

import org.apache.log4j.Level;

public class AlertLevel extends Level {

	private static final long serialVersionUID = 1L;
	private static final String ALERT_MSG = "ALERT";

	public static final int ALERT_LEVEL_INT = Level.FATAL_INT + 1;

	public static final Level ALERT = new AlertLevel(ALERT_LEVEL_INT, "ALERT",
			0);

	protected AlertLevel(int level, String levelStr, int syslogEquivalent) {
		super(level, levelStr, syslogEquivalent);
	}

	public static Level toLevel(String arg) {
		if (arg != null && arg.toUpperCase().equals(ALERT_MSG)) {
			return ALERT;
		}
		return (Level) toLevel(arg, Level.DEBUG);
	}

	public static Level toLevel(int level) {
		if (level == ALERT_LEVEL_INT) {
			return ALERT;
		}
		return (Level) toLevel(level, Level.DEBUG);
	}

	public static Level toLevel(int level, Level defaultLevel) {
		if (level == ALERT_LEVEL_INT) {
			return ALERT;
		}
		return Level.toLevel(level, defaultLevel);
	}

	public static Level toLevel(String arg, Level defaultLevel) {
		if (arg != null && arg.toUpperCase().equals(ALERT_MSG)) {
			return ALERT;
		}
		return Level.toLevel(arg, defaultLevel);
	}

}
