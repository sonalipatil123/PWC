/**
 * EnvironmentDaoImpl
 * 
 * DAO implementation for Environment
 */

package com.persistent.pmt.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.dao.EnvironmentDao;
import com.persistent.pmt.model.Environment;

@Repository("environmentDao")
@Transactional
public class EnvironmentDaoImpl extends BaseDaoImpl implements EnvironmentDao {

	/**
	 * This method fetches the environment of specific name
	 * 
	 * @param String
	 * @return Environment
	 */
	@Override
	public Environment getEnvironmentByName(String name) {
		Criteria criteria = createCriteria(Environment.class);
		criteria.add(Restrictions.eq("name", name).ignoreCase());
		return (Environment) criteria.uniqueResult();
	}

  @Override
  public Environment getEnvironmentNameById(int id) {
    Criteria criteria = createCriteria(Environment.class);
    criteria.add(Restrictions.eq("id", id));

    return (Environment) criteria.uniqueResult();
  }

  @SuppressWarnings("unchecked")
  @Override
  public List<Environment> getAllEnvironments() {
    Criteria criteria = createCriteria(Environment.class);
    criteria.addOrder(Order.desc("id"));

    return (List<Environment>) criteria.list();
  }

}
