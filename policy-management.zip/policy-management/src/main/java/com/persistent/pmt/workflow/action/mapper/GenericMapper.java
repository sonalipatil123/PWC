package com.persistent.pmt.workflow.action.mapper;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

/**
 * @author shishir_kumar
 *
 */
public interface GenericMapper {

  public Object getMappedObject(Object object, WorkFlowContext workFlowContext)
      throws GenericException;

  public String getId(Object object) throws GenericException;

}
