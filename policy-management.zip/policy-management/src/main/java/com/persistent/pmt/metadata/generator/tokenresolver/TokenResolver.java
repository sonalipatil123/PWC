package com.persistent.pmt.metadata.generator.tokenresolver;

public interface TokenResolver {
	public String resolveToken(String tokenName);
}
