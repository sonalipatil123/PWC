package com.persistent.pmt.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Agent
 * 
 * Entity model for Agent
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "agent")
public class Agent {

  @Id
  @Column(name = "id")
  private String id;

  @Column(name = "name")
  private String name;

  @Column(name = "description")
  private String description;

  @Column(name = "password")
  private String password;

  @Column(name = "type")
  private String type;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "agent_id")
  private List<AgentAttributes> attributes;

  public Agent() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public List<AgentAttributes> getAttributes() {
    return attributes;
  }

  public void setAttributes(List<AgentAttributes> attributes) {
    this.attributes = attributes;
  }

  public String getSourceAttributeValueByName(String sourceAttrName) {

    if (null == sourceAttrName)
      return null;

    String sourceAttrValue = null;
    for (AgentAttributes attribute : attributes) {
      if (sourceAttrName.equalsIgnoreCase(attribute.getSourceAttrName())) {
        sourceAttrValue = attribute.getSourceAttrValue();
        break;
      }
    }
    return sourceAttrValue;
  }
}
