package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.view.TargetView;

@JsonInclude(Include.NON_NULL)
public class AdvancedOAuth2ClientConfig implements TargetView {
  private Attribute name;
  private Attribute descriptions;
  private Attribute requestUris;
  private Attribute responseTypes;
  private Attribute contacts;
  private Attribute tokenEndpointAuthMethod;
  private Attribute sectorIdentifierUri;
  private Attribute subjectType;
  private Attribute updateAccessToken;
  private Attribute isConsentImplied;
  private Attribute mixUpMitigation;

  public AdvancedOAuth2ClientConfig() {
    super();
  }

  public Attribute getName() {
    return name;
  }

  public void setName(Attribute name) {
    this.name = name;
  }

  public Attribute getDescriptions() {
    return descriptions;
  }

  public void setDescriptions(Attribute descriptions) {
    this.descriptions = descriptions;
  }

  public Attribute getRequestUris() {
    return requestUris;
  }

  public void setRequestUris(Attribute requestUris) {
    this.requestUris = requestUris;
  }

  public Attribute getResponseTypes() {
    return responseTypes;
  }

  public void setResponseTypes(Attribute responseTypes) {
    this.responseTypes = responseTypes;
  }

  public Attribute getContacts() {
    return contacts;
  }

  public void setContacts(Attribute contacts) {
    this.contacts = contacts;
  }

  public Attribute getTokenEndpointAuthMethod() {
    return tokenEndpointAuthMethod;
  }

  public void setTokenEndpointAuthMethod(Attribute tokenEndpointAuthMethod) {
    this.tokenEndpointAuthMethod = tokenEndpointAuthMethod;
  }

  public Attribute getSectorIdentifierUri() {
    return sectorIdentifierUri;
  }

  public void setSectorIdentifierUri(Attribute sectorIdentifierUri) {
    this.sectorIdentifierUri = sectorIdentifierUri;
  }

  public Attribute getSubjectType() {
    return subjectType;
  }

  public void setSubjectType(Attribute subjectType) {
    this.subjectType = subjectType;
  }

  public Attribute getUpdateAccessToken() {
    return updateAccessToken;
  }

  public void setUpdateAccessToken(Attribute updateAccessToken) {
    this.updateAccessToken = updateAccessToken;
  }

  public Attribute getIsConsentImplied() {
    return isConsentImplied;
  }

  public void setIsConsentImplied(Attribute isConsentImplied) {
    this.isConsentImplied = isConsentImplied;
  }

  public Attribute getMixUpMitigation() {
    return mixUpMitigation;
  }

  public void setMixUpMitigation(Attribute mixUpMitigation) {
    this.mixUpMitigation = mixUpMitigation;
  }

  @Override
  public String toString() {
    return "AdvancedOAuth2ClientConfig [name=" + name + ", descriptions=" + descriptions
        + ", requestUris=" + requestUris + ", responseTypes=" + responseTypes + ", contacts="
        + contacts + ", tokenEndpointAuthMethod=" + tokenEndpointAuthMethod
        + ", sectorIdentifierUri=" + sectorIdentifierUri + ", subjectType=" + subjectType
        + ", updateAccessToken=" + updateAccessToken + ", isConsentImplied=" + isConsentImplied
        + ", mixUpMitigation=" + mixUpMitigation + "]";
  }

}
