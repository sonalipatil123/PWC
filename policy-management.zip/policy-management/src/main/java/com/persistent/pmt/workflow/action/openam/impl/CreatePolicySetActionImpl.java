package com.persistent.pmt.workflow.action.openam.impl;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.WorkflowType;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.WorkflowException;
import com.persistent.pmt.executor.openam.PolicySetExecutor;
import com.persistent.pmt.executor.openam.ResourceTypeExecutor;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.response.openam.ResourceTypeResponse;
import com.persistent.pmt.utils.AuditWriter;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.view.openam.PolicySetView;
import com.persistent.pmt.workflow.action.CreateAction;
import com.persistent.pmt.workflow.action.mapper.casm.PolicySetViewMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component("createPolicySetAction")
@Order(value = 1)
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class CreatePolicySetActionImpl implements CreateAction {

  private static final Logger logger = Logger.getLogger(CreatePolicySetActionImpl.class);

  @Autowired
  @Qualifier("openAMPolicySetExecutor")
  PolicySetExecutor policySetExecutor;

  @Autowired
  @Qualifier("openAMResourceTypeExecutor")
  ResourceTypeExecutor resourceTypeExecutor;

  @Autowired
  PolicySetViewMapper policySetViewMapper;

  @Autowired
  AuditWriter auditWriter;

  @Autowired
  Environment environment;

  @Override
  public Object execute(Object object, List<WorkflowError> errors,
      WorkFlowContext workFlowContext) throws Exception {

    logger.log(Level.INFO, "CreatePolicySetActionImpl execute START");
    Application application = (Application) object;
    HashMap<String, String> resourceParamMap =
        CommonUtils.createOpenAMParamMap(null, workFlowContext.getRealmName());
    resourceParamMap.put("name", "URL");

    try {
      PolicySetView policySetView =
          (PolicySetView) policySetViewMapper.getMappedObject(application, workFlowContext);

      ResourceTypeResponse resourceTypeResponse =
          (ResourceTypeResponse) resourceTypeExecutor.get(application, Product.OPENAM,
              Artifact.RESOURCE_TYPE, resourceParamMap, workFlowContext);
      String resourceType = resourceTypeResponse.getUuid();

      policySetView.setResourceTypeUuids(new String[] { resourceType });
      workFlowContext.setResourceType(resourceType);

      policySetExecutor.create(
          application,
          policySetView,
          Product.OPENAM,
          Artifact.POLICY_SET,
          CommonUtils.createOpenAMParamMap(policySetView.getId(),
              workFlowContext.getRealmName()), workFlowContext);
      workFlowContext.setPolicySetRollbackOnFailure(true);

      // Audit log for success
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS, environment
          .getProperty(AuditPropertyConstants.TARGET_ARTIFACT_ACTION_DETAILS_SUCCESS),
          workFlowContext.getPolicySetAuditData().toString(), new Object[] { "PolicySet",
              policySetView.getId(), application.getName(), application.getId() });
    }
    catch (HttpClientErrorException ex) {

      // Audit Log for artifact creation failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE),
          workFlowContext.getPolicySetAuditData().toString(), new Object[] { "PolicySet",
              application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getResponseBodyAsString());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    catch (Exception ex) {
      // Audit Log for artifact creation failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE),
          workFlowContext.getPolicySetAuditData().toString(), new Object[] { "PolicySet",
              application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    logger.log(Level.INFO, "CreatePolicySetActionImpl execute END");
    return application;
  }

  @Override
  public Object rollback(Object object, List<WorkflowError> errors, WorkFlowContext context)
      throws Exception {
    logger.log(Level.INFO, "CreatePolicySetActionImpl rollback START");
    Application application = (Application) object;
    try {
      if (context.isPolicySetRollbackOnFailure()) {
        policySetExecutor.delete(
            application,
            Product.OPENAM,
            Artifact.POLICY_SET,
            CommonUtils.createOpenAMParamMap(policySetViewMapper.getId(object),
                context.getRealmName()), context);

        // Audit log for rollback success
        auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS,
            environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_SUCCESS), "",
            new Object[] { "PolicySet", policySetViewMapper.getId(object), application.getId(),
                application.getName() });
      }
    }
    catch (HttpClientErrorException ex) {

      // Audit log for rollback failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
          new Object[] { "PolicySet", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to rollback  Policy Set for application: "
                  + ex.getResponseBodyAsString());
      errors.add(error);
      logger.log(Level.ERROR, "Failed to rollback Policy Set for application with id: "
          + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    catch (Exception ex) {
      // Audit log for rollback failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
          new Object[] { "PolicySet", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to rollback Policy Set for application: "
                  + ex.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR, "Failed to rollback Policy Set for application with id: "
          + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    logger.log(Level.INFO, "CreatePolicySetActionImpl rollback END");
    return application;
  }
}
