package com.persistent.pmt.service.impl;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.commons.context.UserContext;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.dao.AuditRecordDao;
import com.persistent.pmt.dao.EnvironmentDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.AuditRecord;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.service.AuditRecordService;
import com.persistent.pmt.utils.AuditUtils;
import com.persistent.pmt.utils.AuditUtils.CONTEXT_FORMAT_TYPE;
import com.persistent.pmt.utils.StringUtils;

/**
 * @author Persistent Systems
 *
 */

@Service("auditRecordService")
@Transactional
public class AuditRecordServiceImpl implements AuditRecordService {

  @Autowired
  ThreadLocal<PMTContext> pmtContextThreadLocal;

  @Autowired
  EnvironmentDao environmentDao;

  @Autowired
  AuditRecordDao auditRecordDao;

  @Override
  public PageImpl<AuditRecord> getReportData(List<ACTIONS> actions, String status)
      throws GenericException {
    PageRequest pageable = null;
    List<AuditRecord> totalRecords = null;
    Long totalRecordsCount = null;
    PMTContext pmtContext = pmtContextThreadLocal.get();
    String envName = pmtContext.getEnvironmentValue();
    if (envName != null) {
      Environment environment = environmentDao.getEnvironmentByName(envName);

      if (environment != null) {
        totalRecords =
            auditRecordDao.getRecordsByActionAndStatus(environment.getId(), actions, status,
                pmtContext.getPagingDetails());
        if (totalRecords != null && !totalRecords.isEmpty()) {
          totalRecordsCount =
              (auditRecordDao.getRecordCountByActionAndStatus(environment.getId(), actions,
                  status)).longValue();

          pageable =
              new PageRequest(pmtContext.getPagingDetails().get("page"), pmtContext
                  .getPagingDetails().get("numberPerPage"));
        }
        else {
          throw new GenericException(
              "The server successfully processed the request but report data not found.",
              HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
        }
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }

    return new PageImpl<>(totalRecords, pageable, totalRecordsCount);
  }

  @Override
  public void createAuditRecord(ACTIONS action, String status, String message, String context,
      Object... paramList) throws GenericException {

    long version = 0L;
    Object[] arr = null;
    PMTContext pmtContext = pmtContextThreadLocal.get();
    String user = pmtContext.getUserContext().getUser(UserContext.USER).getUserName();
    String envName = pmtContext.getEnvironmentValue();
    Environment env = environmentDao.getEnvironmentByName(envName);

    if (env != null) {

      if (paramList != null && paramList.length != 0) {
        arr = paramList;
        message = MessageFormat.format(message, arr);
      }
      if (StringUtils.isEmpty(context)) {
        context = "";
      }

      auditRecordDao.logAuditRecord(new AuditRecord(version, action, message, user,
          new Timestamp(System.currentTimeMillis()), pmtContext.getProcessId(), env, context,
          status));
    }
    else {
      throw new GenericException("Environment specified is either invalid or data not found.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
  }

  @Override
  public int getMaxProcessIdForImportAll(int environmentId) {
    Integer processId = 0;
		List<String> processIdList =
        auditRecordDao.getProcessIdForAction(environmentId, AuditRecord.ACTIONS.IMPORT_ALL);

    if (processIdList != null && !processIdList.isEmpty() && processIdList.get(0) != null) {
			processId = Integer.parseInt(processIdList.get(0));
    }
    processId++;
    return processId;
  }

  @Override
  public GenericResponse<?> getImportStatistics() throws GenericException {
    GenericResponse<Object> response = new GenericResponse<>();

    List<AuditRecord> records = null;
    PMTContext pmtContext = pmtContextThreadLocal.get();
    String environmentName = pmtContext.getEnvironmentValue();
    if (environmentName != null) {
      Environment environment = environmentDao.getEnvironmentByName(environmentName);
      if (environment != null) {
        Map<Object, Object> responseMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> statisticsMap = new LinkedHashMap<Object, Object>();
        Map<String, Long> statesCounts = new LinkedHashMap<String, Long>();

        ArrayList<ACTIONS> actions = new ArrayList<ACTIONS>();
        actions.add(AuditRecord.ACTIONS.IMPORT_ALL);
        records =
            auditRecordDao.getRecordsByActionAndStatus(environment.getId(), actions,
                PMTConstants.SUCCESS_COUNT, pmtContext.getPagingDetails());

        Long needReviewCount =
            auditRecordDao.getRecordCountByActionAndStatus(environment.getId(), actions,
                PMTConstants.NEED_REVIEW);

        String success = PMTConstants.ZERO;
        if (records != null && !records.isEmpty()) {
          AuditRecord latestRecord = records.get(0);
          if (latestRecord != null && latestRecord.getContext() != null
              && latestRecord.getContext().contains("=")) {

            @SuppressWarnings("unchecked")
            Map<String, String> statusMap =
                (HashMap<String, String>) AuditUtils.parseContext(latestRecord.getContext(),
                    PMTConstants.IMPORT_Import_Status, CONTEXT_FORMAT_TYPE.KEYVALS);

            success = statusMap.get(PMTConstants.IMPORT_SUCCESSFUL);
          }
        }
        statesCounts.put(PMTConstants.IMPORT_SUCCESSFUL, Long.valueOf(success));
        statesCounts.put(PMTConstants.IMPORT_NEED_REVIEW, needReviewCount);

        statisticsMap.put(PMTConstants.IMPORT_LABEL, statesCounts);

        responseMap.put(PMTConstants.ENVIRONMENT_ID, environment.getId());
        responseMap.put(PMTConstants.ENVIRONMENT_NAME, environment.getName());
        responseMap.put(PMTConstants.STATISTICS, statisticsMap);

        response.setContent(responseMap);
        response.setStatusCode(HttpStatus.OK.value());
        response.setMessage("Report data returned successfully.");
        response.setStatus(GenericResponse.SUCCESS);
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
    return response;
  }
}
