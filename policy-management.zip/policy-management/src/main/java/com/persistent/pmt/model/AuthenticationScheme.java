/**
 * AuthenticationPolicy
 * 
 * Entity model for authentication policy
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * AuthenticationScheme
 * 
 * Entity model for AuthenticationScheme
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "authentication_scheme")
public class AuthenticationScheme {

	@Id
	@Column(name = "id")
	private String id;

	@Column(name = "name")
	private String name;

	@Column(name = "type")
	private String type;

	@Column(name = "description")
	private String description;

	@Column(name = "authentication_level")
	private String level;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "authn_scheme_id")
	private List<AuthenticationSchemeAttributes> attributes;

	public AuthenticationScheme() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public List<AuthenticationSchemeAttributes> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<AuthenticationSchemeAttributes> attributes) {
		this.attributes = attributes;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AuthenticationScheme [id=");
		builder.append(id);
		builder.append(", name=");
		builder.append(name);
		builder.append(", type=");
		builder.append(type);
		builder.append(", description=");
		builder.append(description);
		builder.append(", level=");
		builder.append(level);
		builder.append(", attributes=");
		builder.append(attributes);
		builder.append("]");
		return builder.toString();
	}
	
	public String getSourceAttValueByName(String sourceAttrName) {
		
		String attrValue = null;
		if(null==sourceAttrName)
			return attrValue;
		
		for(AuthenticationSchemeAttributes attr : attributes) {			
			if(sourceAttrName.equalsIgnoreCase(attr.getSourceAttrName())) {
				attrValue = attr.getSourceAttrValue();
				break;
			}
		}
		return attrValue;
	}

}
