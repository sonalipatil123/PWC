package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LegacyOAuth2OpenIdConnectModuleView implements ModuleView {

  @JsonIgnore
  private String id;
  private String authenticationEndpointUrl;
  private String userProfileServiceUrl;
  private String mailGatewayClass;
  private String scope;
  private String smtpUsername;
  private String openidConnectContextValue;
  private String accountProviderClass;
  private String[] accountMapperConfiguration;
  private boolean saveAttributesInSession;
  private String ssoProxyUrl;
  private String smtpPassword;
  private String[] attributeMapperConfiguration;
  private String accessTokenParameterName;
  private int authenticationLevel;
  private String[] attributeMappingClasses;
  private String smtpFromAddress;
  private String oauth2EmailAttribute;
  private String smtpHostPort;
  private String smtpHostName;
  private String accountMapperClass;
  private String logoutBehaviour;
  private String accessTokenEndpointUrl;
  private boolean promptForPassword;
  private String clientSecret;
  private String clientId;
  private boolean mixUpMitigation;
  private boolean mapToAnonymousUser;
  private String anonymousUserName;
  private String openidConnectContextType;
  private String openidConnectIssuer;
  private String smtpSslEnabled;
  private boolean createAccount;
  private String oauth2LogoutServiceUrl;

  public LegacyOAuth2OpenIdConnectModuleView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getAuthenticationEndpointUrl() {
    return authenticationEndpointUrl;
  }

  public void setAuthenticationEndpointUrl(String authenticationEndpointUrl) {
    this.authenticationEndpointUrl = authenticationEndpointUrl;
  }

  public String getUserProfileServiceUrl() {
    return userProfileServiceUrl;
  }

  public void setUserProfileServiceUrl(String userProfileServiceUrl) {
    this.userProfileServiceUrl = userProfileServiceUrl;
  }

  public String getMailGatewayClass() {
    return mailGatewayClass;
  }

  public void setMailGatewayClass(String mailGatewayClass) {
    this.mailGatewayClass = mailGatewayClass;
  }

  public String getScope() {
    return scope;
  }

  public void setScope(String scope) {
    this.scope = scope;
  }

  public String getSmtpUsername() {
    return smtpUsername;
  }

  public void setSmtpUsername(String smtpUsername) {
    this.smtpUsername = smtpUsername;
  }

  public String getOpenidConnectContextValue() {
    return openidConnectContextValue;
  }

  public void setOpenidConnectContextValue(String openidConnectContextValue) {
    this.openidConnectContextValue = openidConnectContextValue;
  }

  public String getAccountProviderClass() {
    return accountProviderClass;
  }

  public void setAccountProviderClass(String accountProviderClass) {
    this.accountProviderClass = accountProviderClass;
  }

  public String[] getAccountMapperConfiguration() {
    return accountMapperConfiguration;
  }

  public void setAccountMapperConfiguration(String[] accountMapperConfiguration) {
    this.accountMapperConfiguration = accountMapperConfiguration;
  }

  public boolean getSaveAttributesInSession() {
    return saveAttributesInSession;
  }

  public void setSaveAttributesInSession(boolean saveAttributesInSession) {
    this.saveAttributesInSession = saveAttributesInSession;
  }

  public String getSsoProxyUrl() {
    return ssoProxyUrl;
  }

  public void setSsoProxyUrl(String ssoProxyUrl) {
    this.ssoProxyUrl = ssoProxyUrl;
  }

  public String getSmtpPassword() {
    return smtpPassword;
  }

  public void setSmtpPassword(String smtpPassword) {
    this.smtpPassword = smtpPassword;
  }

  public String[] getAttributeMapperConfiguration() {
    return attributeMapperConfiguration;
  }

  public void setAttributeMapperConfiguration(String[] attributeMapperConfiguration) {
    this.attributeMapperConfiguration = attributeMapperConfiguration;
  }

  public String getAccessTokenParameterName() {
    return accessTokenParameterName;
  }

  public void setAccessTokenParameterName(String accessTokenParameterName) {
    this.accessTokenParameterName = accessTokenParameterName;
  }

  public int getAuthenticationLevel() {
    return authenticationLevel;
  }

  public void setAuthenticationLevel(int authenticationLevel) {
    this.authenticationLevel = authenticationLevel;
  }

  public String[] getAttributeMappingClasses() {
    return attributeMappingClasses;
  }

  public void setAttributeMappingClasses(String[] attributeMappingClasses) {
    this.attributeMappingClasses = attributeMappingClasses;
  }

  public String getSmtpFromAddress() {
    return smtpFromAddress;
  }

  public void setSmtpFromAddress(String smtpFromAddress) {
    this.smtpFromAddress = smtpFromAddress;
  }

  public String getOauth2EmailAttribute() {
    return oauth2EmailAttribute;
  }

  public void setOauth2EmailAttribute(String oauth2EmailAttribute) {
    this.oauth2EmailAttribute = oauth2EmailAttribute;
  }

  public String getSmtpHostPort() {
    return smtpHostPort;
  }

  public void setSmtpHostPort(String smtpHostPort) {
    this.smtpHostPort = smtpHostPort;
  }

  public String getSmtpHostName() {
    return smtpHostName;
  }

  public void setSmtpHostName(String smtpHostName) {
    this.smtpHostName = smtpHostName;
  }

  public String getAccountMapperClass() {
    return accountMapperClass;
  }

  public void setAccountMapperClass(String accountMapperClass) {
    this.accountMapperClass = accountMapperClass;
  }

  public String getLogoutBehaviour() {
    return logoutBehaviour;
  }

  public void setLogoutBehaviour(String logoutBehaviour) {
    this.logoutBehaviour = logoutBehaviour;
  }

  public String getAccessTokenEndpointUrl() {
    return accessTokenEndpointUrl;
  }

  public void setAccessTokenEndpointUrl(String accessTokenEndpointUrl) {
    this.accessTokenEndpointUrl = accessTokenEndpointUrl;
  }

  public boolean getPromptForPassword() {
    return promptForPassword;
  }

  public void setPromptForPassword(boolean promptForPassword) {
    this.promptForPassword = promptForPassword;
  }

  public String getClientSecret() {
    return clientSecret;
  }

  public void setClientSecret(String clientSecret) {
    this.clientSecret = clientSecret;
  }

  public String getClientId() {
    return clientId;
  }

  public void setClientId(String clientId) {
    this.clientId = clientId;
  }

  public boolean getMixUpMitigation() {
    return mixUpMitigation;
  }

  public void setMixUpMitigation(boolean mixUpMitigation) {
    this.mixUpMitigation = mixUpMitigation;
  }

  public boolean getMapToAnonymousUser() {
    return mapToAnonymousUser;
  }

  public void setMapToAnonymousUser(boolean mapToAnonymousUser) {
    this.mapToAnonymousUser = mapToAnonymousUser;
  }

  public String getAnonymousUserName() {
    return anonymousUserName;
  }

  public void setAnonymousUserName(String anonymousUserName) {
    this.anonymousUserName = anonymousUserName;
  }

  public String getOpenidConnectContextType() {
    return openidConnectContextType;
  }

  public void setOpenidConnectContextType(String openidConnectContextType) {
    this.openidConnectContextType = openidConnectContextType;
  }

  public String getOpenidConnectIssuer() {
    return openidConnectIssuer;
  }

  public void setOpenidConnectIssuer(String openidConnectIssuer) {
    this.openidConnectIssuer = openidConnectIssuer;
  }

  public String getSmtpSslEnabled() {
    return smtpSslEnabled;
  }

  public void setSmtpSslEnabled(String smtpSslEnabled) {
    this.smtpSslEnabled = smtpSslEnabled;
  }

  public boolean getCreateAccount() {
    return createAccount;
  }

  public void setCreateAccount(boolean createAccount) {
    this.createAccount = createAccount;
  }

  public String getOauth2LogoutServiceUrl() {
    return oauth2LogoutServiceUrl;
  }

  public void setOauth2LogoutServiceUrl(String oauth2LogoutServiceUrl) {
    this.oauth2LogoutServiceUrl = oauth2LogoutServiceUrl;
  }

}
