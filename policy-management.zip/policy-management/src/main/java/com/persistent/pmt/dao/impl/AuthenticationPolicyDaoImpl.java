/**
 * AuthenticationPolicyDaoImpl
 * 
 * DAO implementations for authentication policy
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.dao.impl;

import org.springframework.stereotype.Repository;

import com.persistent.pmt.dao.AuthenticationPolicyDao;
import com.persistent.pmt.model.AuthenticationPolicy;

@Repository("authenticationPolicyDao")
public class AuthenticationPolicyDaoImpl extends BaseDaoImpl implements
		AuthenticationPolicyDao {

	@Override
	public AuthenticationPolicy createAuthenticationPolicy(
			AuthenticationPolicy authenticationPolicy) {
		getSession().save(authenticationPolicy);
		return authenticationPolicy;
	}

}
