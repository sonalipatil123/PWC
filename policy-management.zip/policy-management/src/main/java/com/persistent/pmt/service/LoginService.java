/**
 * LoginService
 * 
 * Service interface for Login/Logout operations
 * 
 * @author Persistent Systems
 */
package com.persistent.pmt.service;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.User;
import com.persistent.pmt.response.GenericResponse;

public interface LoginService {

	public GenericResponse<?> login(User user) throws GenericException;

}
