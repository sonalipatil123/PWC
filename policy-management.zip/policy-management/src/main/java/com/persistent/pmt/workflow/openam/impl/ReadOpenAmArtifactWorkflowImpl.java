package com.persistent.pmt.workflow.openam.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.WorkflowType;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.constant.casm.PolicyGrammarConstants;
import com.persistent.pmt.dao.EnvironmentDao;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.exception.WorkflowException;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.response.TargetResponse;
import com.persistent.pmt.utils.AlertLevel;
import com.persistent.pmt.utils.AuditWriter;
import com.persistent.pmt.view.openam.ReadQueryObject;
import com.persistent.pmt.workflow.ReadOpenAmArtifactWorkflow;
import com.persistent.pmt.workflow.action.ReadAction;

@Component
@PropertySource(value = { "classpath:application.properties", "classpath:auditMessages.properties" })
public class ReadOpenAmArtifactWorkflowImpl extends AbstractWorkflowImpl implements ReadOpenAmArtifactWorkflow {

	private static final Logger logger = Logger.getLogger(CreateApplicationWorkflowImpl.class);

	@Autowired
	@Qualifier("readActions")
	private Map<Artifact, ReadAction> readAactions;

	@Autowired
	EnvironmentDao environmentDao;

	@Autowired
	ThreadLocal<PMTContext> pmtContextThreadLocal;

	@Autowired
	AuditWriter auditWriter;

	@Autowired
	org.springframework.core.env.Environment environmentprop;

	@Override
	public void start(Object object) throws WorkflowException {
	}

	@Override
	public TargetResponse read(Object object) throws GenericException {
		String workflowId = getNewWorkflowId();

		logger.log(AlertLevel.ALERT, "==============================================");
		logger.log(AlertLevel.ALERT, "Workflow to Read OpenAm Artifact in target STARTS (id: " + workflowId + ")");

		TargetResponse response = null;
		ReadQueryObject readQueryObject = (ReadQueryObject) object;

		PMTContext pmtContext = pmtContextThreadLocal.get();
		if (pmtContext.getEnvironmentValue() != null) {
			Environment environment = environmentDao.getEnvironmentByName(pmtContext.getEnvironmentValue());

			List<WorkflowError> errors = new ArrayList<WorkflowError>();

			if (readAactions != null && !readAactions.isEmpty()) {
				try {
					WorkFlowContext context = createWorkflowContext(environment.getName(), errors);
					if (context != null) {
						context.setRealmName(serverConfigurationService
								.getPropertyValue(PolicyGrammarConstants.AGENT_POLICY_EVALUATION_REALM));
						ReadAction readAction = readAactions.get(readQueryObject.getObjectType());
						Object readResponse = readAction.execute(readQueryObject, errors, context);
						if (readResponse != null) {
							response = (TargetResponse) readResponse;
						}
						// Audit log for read artifact success
						auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS,
								environmentprop.getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_READ_SUCCESS),
								"", new Object[] { readQueryObject.getObjectType() });
					} else {

						// Audit log for empty artifact response
						auditWriter.write(ACTIONS.PROVISION, PMTConstants.NEED_REVIEW,
								environmentprop
										.getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_RESPONSE_EMPTY),
								"", new Object[] { readQueryObject.getObjectType() });
					}
				} catch (Exception ex) {

					// Audit log for read artifact failure

					auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
							environmentprop.getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_READ_FAILURE), "",
							new Object[] { readQueryObject.getObjectType() });

					logger.log(Level.ERROR, "Read Workflow execution failed", ex);
				}
			} else {

				// Audit log for read artifact failure

				auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
						environmentprop.getProperty(
								AuditPropertyConstants.TARGET_ACTION_ARTIFACT_READ_FAILURE_ACTIONLIST_EMPTY),
						"", new Object[] { readQueryObject.getObjectType() });

				WorkflowError error = new WorkflowError(WorkflowType.READ.toString(), "Workflow Id:",
						Integer.parseInt(workflowId), 0,
						"Failed to Read OpenAM Artifacts since read action list is empty");
				errors.add(error);

			}
			if (!errors.isEmpty()) {
				throw new WorkflowException("Failed to read OpenAM artifacts.", errors);
			}
		}
		return response;
	}
}
