package com.persistent.pmt.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.DiffBuilder;
import org.apache.commons.lang3.builder.DiffResult;
import org.apache.commons.lang3.builder.Diffable;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Nationalized;
import org.hibernate.annotations.Type;

import com.persistent.pmt.constant.MapperConstants;

/**
 * Application
 * 
 * Entity model for application
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "application")
public class Application implements Diffable<Application> {


@Id
  // @SequenceGenerator(name = "SEQ_APPLICATION", sequenceName =
  // "SEQ_APPLICATION", allocationSize = 1)
  // @GeneratedValue(strategy = GenerationType.SEQUENCE, generator =
  // "SEQ_APPLICATION")
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "id")
  private int id;

  @Column(name = "name")
  private String name;

  @Column(name = "context_root")
  private String contextRoot;

  @Column(name = "pep_type")
  private String pepType;

  @Column(name = "enabled")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean enabled;

  @Column(name = "externalapp")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean external;

  @Column(name = "require_https")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean requireHTTPS;

  @ManyToOne
  @JoinColumn(name = "state_id")
  private ApplicationState applicationState;

  @ManyToOne
  @JoinColumn(name = "platform_id")
  private Platform platform;

  @ManyToOne
  @JoinColumn(name = "originator_id")
  private Originator originator;

  @ManyToOne
  @JoinColumn(name = "environment_id")
  private Environment environment;

  @ManyToOne
  @JoinColumn(name = "identity_mapping_id")
  private IdentityMapping identityMapping;

  @Column(name = "pep_id")
  private int pepId;

  @Column(name = "webservice")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean webService;

  @Column(name = "description")
  private String description;

  @Column(name = "app_portfolio_id")
  private String appPortfolioId;

  @Column(name = "authn_req_list_name")
  private String authenticationRequirementListName;

  @Column(name = "legacy_identity_mapping_name")
  private String legacyIdentityMappingName;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "application_id")
  private List<AuthenticationPolicy> authenticationPolicies;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "application_id")
  private List<Resource> resources;

  @ManyToMany(cascade = CascadeType.ALL)
  @JoinTable(name = "application_host_configuration", joinColumns = { @JoinColumn(name = "application_id") }, inverseJoinColumns = { @JoinColumn(name = "host_configuration_id") })
  private List<HostConfiguration> hostConfigurations;

  @OneToOne(mappedBy = "application", cascade = CascadeType.ALL, orphanRemoval = true)
  private ApplicationOwner owner;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "application_id")
  private List<LegacyDetails> legacyDetails;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "application_id")
  private List<AuthorizationPolicy> authorizationPolicies;

  @ManyToMany
  @JoinTable(name = "application_user_data_store", joinColumns = { @JoinColumn(name = "application_id") }, inverseJoinColumns = { @JoinColumn(name = "user_data_store_id") })
  private List<UserDataStore> userDataStores;

  @OneToOne
  @JoinColumn(name = "agent_id")
  private Agent agent;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "application_id")
  private List<ApplicationAttributes> attributes;

  @Column(name = "source_raw_data", columnDefinition = "nclob")
  @Nationalized
  private String sourceRawData;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "application_id")
  private List<Response> responses;

  @Column(name = "inactive_policy_data")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean inactivePolicyData;

  @Transient
  private Provider provider;

  public Application() {
    super();
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getContextRoot() {
    return contextRoot;
  }

  public void setContextRoot(String contextRoot) {
    this.contextRoot = contextRoot;
  }

  public String getPepType() {
    return pepType;
  }

  public void setPepType(String pepType) {
    this.pepType = pepType;
  }

  public boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }

  public boolean isExternal() {
    return external;
  }

  public void setExternal(boolean external) {
    this.external = external;
  }

  public boolean isRequireHTTPS() {
    return requireHTTPS;
  }

  public void setRequireHTTPS(boolean requireHTTPS) {
    this.requireHTTPS = requireHTTPS;
  }

  public ApplicationState getApplicationState() {
    return applicationState;
  }

  public void setApplicationState(ApplicationState applicationState) {
    this.applicationState = applicationState;
  }

  public Platform getPlatform() {
    return platform;
  }

  public void setPlatform(Platform platform) {
    this.platform = platform;
  }

  public Originator getOriginator() {
    return originator;
  }

  public void setOriginator(Originator originator) {
    this.originator = originator;
  }

  public Environment getEnvironment() {
    return environment;
  }

  public void setEnvironment(Environment environment) {
    this.environment = environment;
  }

  public IdentityMapping getIdentityMapping() {
    return identityMapping;
  }

  public void setIdentityMapping(IdentityMapping identityMapping) {
    this.identityMapping = identityMapping;
  }

  public int getPepId() {
    return pepId;
  }

  public void setPepId(int pepId) {
    this.pepId = pepId;
  }

  public boolean isWebService() {
    return webService;
  }

  public void setWebService(boolean webService) {
    this.webService = webService;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getAppPortfolioId() {
    return appPortfolioId;
  }

  public void setAppPortfolioId(String appPortfolioId) {
    this.appPortfolioId = appPortfolioId;
  }

  public String getAuthenticationRequirementListName() {
    return authenticationRequirementListName;
  }

  public void setAuthenticationRequirementListName(String authenticationRequirementListName) {
    this.authenticationRequirementListName = authenticationRequirementListName;
  }

  public String getLegacyIdentityMappingName() {
    return legacyIdentityMappingName;
  }

  public void setLegacyIdentityMappingName(String legacyIdentityMappingName) {
    this.legacyIdentityMappingName = legacyIdentityMappingName;
  }

  public List<AuthenticationPolicy> getAuthenticationPolicies() {
    return authenticationPolicies;
  }

  public void setAuthenticationPolicies(List<AuthenticationPolicy> authenticationPolicies) {
    this.authenticationPolicies = authenticationPolicies;
  }

  public List<Resource> getResources() {
    return resources;
  }

  public void setResources(List<Resource> resources) {
    this.resources = resources;
  }

  public List<HostConfiguration> getHostConfigurations() {
    return hostConfigurations;
  }

  public void setHostConfigurations(List<HostConfiguration> hostConfigurations) {
    this.hostConfigurations = hostConfigurations;
  }

  public ApplicationOwner getOwner() {
    return owner;
  }

  public void setOwner(ApplicationOwner owner) {
    this.owner = owner;
  }

  public List<LegacyDetails> getLegacyDetails() {
    return legacyDetails;
  }

  public void setLegacyDetails(List<LegacyDetails> legacyDetails) {
    this.legacyDetails = legacyDetails;
  }

  public List<AuthorizationPolicy> getAuthorizationPolicies() {
    return authorizationPolicies;
  }

  public void setAuthorizationPolicies(List<AuthorizationPolicy> authorizationPolicies) {
    this.authorizationPolicies = authorizationPolicies;
  }

  public List<UserDataStore> getUserDataStores() {
    return userDataStores;
  }

  public void setUserDataStores(List<UserDataStore> userDataStores) {
    this.userDataStores = userDataStores;
  }

  public Agent getAgent() {
    return agent;
  }

  public void setAgent(Agent agent) {
    this.agent = agent;
  }

  public List<Response> getResponses() {
    return responses;
  }

  public void setResponses(List<Response> responses) {
    this.responses = responses;
  }

  public List<ApplicationAttributes> getAttributes() {
    return attributes;
  }

  public void setAttributes(List<ApplicationAttributes> attributes) {
    this.attributes = attributes;
  }

  public String getSourceRawData() {
    return sourceRawData;
  }

  public void setSourceRawData(String sourceRawData) {
    this.sourceRawData = sourceRawData;
  }

  public boolean isInactivePolicyData() {
    return inactivePolicyData;
  }

  public void setInactivePolicyData(boolean inactivePolicyData) {
    this.inactivePolicyData = inactivePolicyData;
  }

  public Provider getProvider() {
    return provider;
  }

  public void setProvider(Provider provider) {
    this.provider = provider;
  }

  @Override
  public DiffResult diff(Application obj) {
    return new DiffBuilder(this, obj, ToStringStyle.NO_CLASS_NAME_STYLE)
        .append("description", description, obj.description)
        .append("contextRoot", contextRoot, obj.contextRoot)
        .append("enabled", enabled, obj.enabled).append("external", external, obj.external)
        .append("requireHTTPS", requireHTTPS, obj.requireHTTPS)
        .append("appPortfolioId", appPortfolioId, obj.appPortfolioId)
        .append("identityMapping", identityMapping, obj.identityMapping)
        .append("hostConfigurations", hostConfigurations, obj.hostConfigurations)
        .append("owner", owner, obj.owner).build();
  }

  public AuthenticationPolicy getDefaultAuthenticationPolicy() {
    if (authenticationPolicies != null) {
      for (AuthenticationPolicy authPolicy : authenticationPolicies) {
        if (authPolicy.isDefaultEntity()) {
          return authPolicy;
        }
      }
    }
    return null;
  }

  public AuthenticationScheme getDefaultAuthScheme() {

    AuthenticationPolicy authPolicy = getDefaultAuthenticationPolicy();
    if (null != authPolicy)
      return authPolicy.getAuthenticationScheme();
    else
      return null;
  }

  public String getSourceAttributeValueByName(String sourceAttrName) {
    if (null == sourceAttrName)
      return null;

    String sourceAttrValue = null;
    for (ApplicationAttributes attribute : attributes) {
      if (sourceAttrName.equalsIgnoreCase(attribute.getSourceAttrName())) {
        sourceAttrValue = attribute.getSourceAttrValue();
        break;
      }
    }
    return sourceAttrValue;
  }

  public Map<String, String> getHeaderAndCookieResponseValue() {
    Map<String, String> responseMap = new HashMap<String, String>();
    if (responses != null && !responses.isEmpty()) {
      for (Response response : responses) {
        if (MapperConstants.RESPONSE_HEADER.equalsIgnoreCase(response.getType())
            || MapperConstants.RESPONSE_COOKIE.equalsIgnoreCase(response.getType())) {

          String responseValue = response.getValue();
          String key = "";
          String value = "";
          if (responseValue.contains("userattr")) {
            key = responseValue.substring(0, responseValue.indexOf("="));
            value =
                responseValue.substring(responseValue.indexOf("\"") + 1,
                    responseValue.lastIndexOf("\""));

          }
          else {
            if (responseValue.contains("=")) {
              String[] responseValues = responseValue.split("=");
              if (responseValues != null && responseValues.length > 2) {
                key = responseValues[0];
                value = responseValues[1];
              }
            }
            else {
              key = value = responseValue;
            }
          }
          responseMap.put(key, value);
        }
      }
    }
    return responseMap;
  }
}
