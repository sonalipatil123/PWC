package com.persistent.pmt.response.openam;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LDAPModuleResponse implements ModuleResponse {
  private String authenticationLevel;
  private String operationTimeout;
  private String[] userSearchStartDN;
  private String trustAllServerCertificates;
  private String minimumPasswordLength;
  private String userBindPassword;
  private Type _type;
  private String userBindDN;
  private String connectionHeartbeatTimeUnit;
  @JsonProperty(value = "openam-auth-ldap-connection-mode")
  private String openamAuthLdapConnectionMode;
  private String _id;
  private String[] primaryLdapServer;
  private String[] secondaryLdapServer;
  private String beheraPasswordPolicySupportEnabled;
  private String userProfileRetrievalAttribute;
  private String searchScope;
  private String connectionHeartbeatInterval;
  private String returnUserDN;
  private Object userSearchFilter;
  private String[] profileAttributeMappings;
  private String[] userSearchAttributes;

  public Object getUserSearchFilter() {
    return userSearchFilter;
  }

  public String getAuthenticationLevel() {
    return authenticationLevel;
  }

  public void setAuthenticationLevel(String authenticationLevel) {
    this.authenticationLevel = authenticationLevel;
  }

  public String getOperationTimeout() {
    return operationTimeout;
  }

  public void setOperationTimeout(String operationTimeout) {
    this.operationTimeout = operationTimeout;
  }

  public String[] getUserSearchStartDN() {
    return userSearchStartDN;
  }

  public void setUserSearchStartDN(String[] userSearchStartDN) {
    this.userSearchStartDN = userSearchStartDN;
  }

  public String getTrustAllServerCertificates() {
    return trustAllServerCertificates;
  }

  public void setTrustAllServerCertificates(String trustAllServerCertificates) {
    this.trustAllServerCertificates = trustAllServerCertificates;
  }

  public String getMinimumPasswordLength() {
    return minimumPasswordLength;
  }

  public void setMinimumPasswordLength(String minimumPasswordLength) {
    this.minimumPasswordLength = minimumPasswordLength;
  }

  public String getUserBindPassword() {
    return userBindPassword;
  }

  public void setUserBindPassword(String userBindPassword) {
    this.userBindPassword = userBindPassword;
  }

  public Type get_type() {
    return _type;
  }

  public void set_type(Type _type) {
    this._type = _type;
  }

  public String getUserBindDN() {
    return userBindDN;
  }

  public void setUserBindDN(String userBindDN) {
    this.userBindDN = userBindDN;
  }

  public String getConnectionHeartbeatTimeUnit() {
    return connectionHeartbeatTimeUnit;
  }

  public void setConnectionHeartbeatTimeUnit(String connectionHeartbeatTimeUnit) {
    this.connectionHeartbeatTimeUnit = connectionHeartbeatTimeUnit;
  }

  public String getOpenamAuthLdapConnectionMode() {
    return openamAuthLdapConnectionMode;
  }

  public void setOpenamAuthLdapConnectionMode(String openamAuthLdapConnectionMode) {
    this.openamAuthLdapConnectionMode = openamAuthLdapConnectionMode;
  }

  public void setUserSearchFilter(Object userSearchFilter) {
    this.userSearchFilter = userSearchFilter;
  }

  public String get_id() {
    return _id;
  }

  public void set_id(String _id) {
    this._id = _id;
  }

  public String[] getPrimaryLdapServer() {
    return primaryLdapServer;
  }

  public void setPrimaryLdapServer(String[] primaryLdapServer) {
    this.primaryLdapServer = primaryLdapServer;
  }

  public String[] getSecondaryLdapServer() {
    return secondaryLdapServer;
  }

  public void setSecondaryLdapServer(String[] secondaryLdapServer) {
    this.secondaryLdapServer = secondaryLdapServer;
  }

  public String getBeheraPasswordPolicySupportEnabled() {
    return beheraPasswordPolicySupportEnabled;
  }

  public void setBeheraPasswordPolicySupportEnabled(String beheraPasswordPolicySupportEnabled) {
    this.beheraPasswordPolicySupportEnabled = beheraPasswordPolicySupportEnabled;
  }

  public String getUserProfileRetrievalAttribute() {
    return userProfileRetrievalAttribute;
  }

  public void setUserProfileRetrievalAttribute(String userProfileRetrievalAttribute) {
    this.userProfileRetrievalAttribute = userProfileRetrievalAttribute;
  }

  public String getSearchScope() {
    return searchScope;
  }

  public void setSearchScope(String searchScope) {
    this.searchScope = searchScope;
  }

  public String getConnectionHeartbeatInterval() {
    return connectionHeartbeatInterval;
  }

  public void setConnectionHeartbeatInterval(String connectionHeartbeatInterval) {
    this.connectionHeartbeatInterval = connectionHeartbeatInterval;
  }

  public String getReturnUserDN() {
    return returnUserDN;
  }

  public void setReturnUserDN(String returnUserDN) {
    this.returnUserDN = returnUserDN;
  }

  public String[] getProfileAttributeMappings() {
    return profileAttributeMappings;
  }

  public void setProfileAttributeMappings(String[] profileAttributeMappings) {
    this.profileAttributeMappings = profileAttributeMappings;
  }

  public String[] getUserSearchAttributes() {
    return userSearchAttributes;
  }

  public void setUserSearchAttributes(String[] userSearchAttributes) {
    this.userSearchAttributes = userSearchAttributes;
  }

  @Override
  public String toString() {
    return "LDAPModuleResponse [authenticationLevel=" + authenticationLevel
        + ", operationTimeout=" + operationTimeout + ", userSearchStartDN="
        + Arrays.toString(userSearchStartDN) + ", trustAllServerCertificates="
        + trustAllServerCertificates + ", minimumPasswordLength=" + minimumPasswordLength
        + ", userBindPassword=" + userBindPassword + ", _type=" + _type + ", userBindDN="
        + userBindDN + ", connectionHeartbeatTimeUnit=" + connectionHeartbeatTimeUnit
        + ", openamAuthLdapConnectionMode=" + openamAuthLdapConnectionMode + ", _id=" + _id
        + ", primaryLdapServer=" + Arrays.toString(primaryLdapServer)
        + ", secondaryLdapServer=" + Arrays.toString(secondaryLdapServer)
        + ", beheraPasswordPolicySupportEnabled=" + beheraPasswordPolicySupportEnabled
        + ", userProfileRetrievalAttribute=" + userProfileRetrievalAttribute + ", searchScope="
        + searchScope + ", connectionHeartbeatInterval=" + connectionHeartbeatInterval
        + ", returnUserDN=" + returnUserDN + ", userSearchFilter=" + userSearchFilter
        + ", profileAttributeMappings=" + Arrays.toString(profileAttributeMappings)
        + ", userSearchAttributes=" + Arrays.toString(userSearchAttributes) + "]";
  }

}
