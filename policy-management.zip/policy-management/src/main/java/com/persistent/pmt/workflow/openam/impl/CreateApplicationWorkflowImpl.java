/**
 * 
 * CreateApplicationWorkflowImpl
 * 
 * Implementation for create application workflow
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.workflow.openam.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.WorkflowType;
import com.persistent.pmt.constant.casm.AuthenticationSchemeTypes;
import com.persistent.pmt.constant.casm.PolicyGrammarConstants;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.exception.WorkflowException;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.model.AuthenticationScheme;
import com.persistent.pmt.model.ChangeHistory;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.service.ChangeHistoryService;
import com.persistent.pmt.service.ServerConfigurationService;
import com.persistent.pmt.utils.AlertLevel;
import com.persistent.pmt.utils.AuditWriter;
import com.persistent.pmt.workflow.CreateWorkflow;
import com.persistent.pmt.workflow.action.CreateAction;

@Component("createWorkflow")
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class CreateApplicationWorkflowImpl extends AbstractWorkflowImpl implements
    CreateWorkflow {

  private static final Logger logger = Logger.getLogger(CreateApplicationWorkflowImpl.class);

  @Autowired
  @Qualifier("createWorkflowAgentBased")
  private List<CreateAction> createWorkflowAgentBased;

  @Autowired
  @Qualifier("createWorkflowFederationBased")
  private List<CreateAction> createWorkflowFederationBased;

  @Autowired
  @Qualifier("createWorkflowFedAndAgentBased")
  private List<CreateAction> createWorkflowFedAndAgentBased;

  @Autowired
  @Qualifier("createWorkflowOAuthBased")
  private List<CreateAction> createWorkflowOAuthBased;

  @Autowired
  ThreadLocal<PMTContext> pmtContextThreadLocal;

  @Autowired
  private ChangeHistoryService changeHistoryService;

  @Autowired
  AuditWriter auditWriter;

  @Autowired
  org.springframework.core.env.Environment environmentprop;

  @Autowired
  @Qualifier("serverConfigurationService")
  ServerConfigurationService serverConfigurationService;

  @Autowired
  @Qualifier("createAgentAction")
  CreateAction createAgentActionImpl;

  @Override
  public void start(Object object) throws GenericException {
    String workflowId = getNewWorkflowId();

    logger.log(AlertLevel.ALERT, "==============================================");
    logger.log(AlertLevel.ALERT, "Workflow to create application in target STARTS (id: "
        + workflowId + ")");
    Application application = (Application) object;

    PMTContext pmtContext = pmtContextThreadLocal.get();
		pmtContext.setProcessId(workflowId);

    List<WorkflowError> errors = new ArrayList<>();

    Environment environment = application.getEnvironment();
    String lifecycle = null;
    if (environment != null) {
      lifecycle = environment.getName();
    }

    List<CreateAction> actions = calculateActionWorkflow(application);

    WorkFlowContext context = null;

    int counter = 0;
    if (actions != null && !actions.isEmpty()) {
      // Audit log for artifact creation started

      auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS, environmentprop
          .getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_CREATION_STARTED), "",
          new Object[] { application.getName(), application.getId() });
      try {
        context = createWorkflowContext(lifecycle, errors);
        if (context != null) {
          context.setRealmName(serverConfigurationService
              .getPropertyValue(PolicyGrammarConstants.AGENT_POLICY_EVALUATION_REALM));

          for (CreateAction action : actions) {
            counter++;
            action.execute(application, errors, context);
          }
        }

        auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS, environmentprop
            .getProperty(AuditPropertyConstants.TARGET_ACTION_PROVSION_WORKFLOW_SUCCESS), "",
            new Object[] { application.getName(), application.getId() });
      }
      catch (Exception ex) {

        changeHistoryService.createChangeHistory(application.getId(),
            ChangeHistory.ACTIONS.PROVISION,
            "Failed to provision application. Rollback started.", PMTConstants.FAILURE);

        // Audit log for artifact creation failure rollback started

        auditWriter
            .write(
                ACTIONS.PROVISION,
                PMTConstants.FAILURE,
                environmentprop
                    .getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_CREATION_FAILURE_ROLLBACK_STARTED),
                "", new Object[] { application.getName(), application.getId() });

        logger.log(Level.ERROR, "Workflow execution failed", ex);
        logger.log(AlertLevel.ALERT, "Rollback of create application actions STARTS");
        for (int i = counter - 1; i >= 0; i--) {
          CreateAction action = actions.get(i);
          try {
            action.rollback(application, errors, context);
          }
          catch (Exception e) {
            changeHistoryService.createChangeHistory(application.getId(),
                ChangeHistory.ACTIONS.PROVISION,
                "Rollback of application artifact creation failed.", PMTConstants.FAILURE);

            auditWriter
                .write(
                    ACTIONS.PROVISION,
                    PMTConstants.FAILURE,
                    environmentprop
                        .getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_CREATION_FAILURE_ROLLBACK_FAILED),
                    "", new Object[] { application.getId(), application.getName() });
            logger.log(AlertLevel.ALERT, "Rollback of application actions Failed");
          }
        }
        auditWriter
            .write(
                ACTIONS.PROVISION,
                PMTConstants.FAILURE,
                environmentprop
                    .getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_CREATION_FAILURE_ROLLBACK_SUCCESS),
                "", new Object[] { application.getId(), application.getName() });
        logger.log(AlertLevel.ALERT, "Rollback of create application actions ENDS");
      }
    }
    else {
      // Audit log for artifact creation failure action list is empty

      auditWriter
          .write(
              ACTIONS.PROVISION,
              PMTConstants.NEED_REVIEW,
              environmentprop
                  .getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_CREATION_FAILURE_ACTIONLIST_EMPTY),
              "", new Object[] { application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0,
              "Failed to provision application: since action list is empty");
      errors.add(error);
    }
    logger
        .log(AlertLevel.ALERT, "Workflow to create application ENDS (id: " + workflowId + ")");
    logger.log(AlertLevel.ALERT, "==============================================");

    if (!errors.isEmpty()) {
      throw new WorkflowException("Failed to provision application with id: "
          + application.getId() + " and name: " + application.getName() + ".", errors);
    }
  }

  private List<CreateAction> calculateActionWorkflow(Application application)
      throws GenericException {
    List<CreateAction> actions = null;
    AuthenticationScheme authenticationScheme = application.getDefaultAuthScheme();
    if (PMTConstants.PEP_TYPE_AGENT.equalsIgnoreCase(application.getPepType())) {

      if (authenticationScheme != null) {

        if (AuthenticationSchemeTypes.AUTHN_SCHEME_SAML2.getValue().equalsIgnoreCase(
            authenticationScheme.getType())) {
          actions = createWorkflowFedAndAgentBased;

          // Audit log for artifact creation for Fed+Agent based
          // application

          auditWriter
              .write(
                  ACTIONS.PROVISION,
                  PMTConstants.SUCCESS,
                  environmentprop
                      .getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_CREATION_FOR_FED_AND_AGENTBASED),
                  "", new Object[] { application.getName(), application.getId(), "Provider",
                      "Module", "ModuleChain" });
        }
        else {
          actions = createWorkflowAgentBased;
          // Audit log for artifact creation for Agent based
          // application

          auditWriter
              .write(
                  ACTIONS.PROVISION,
                  PMTConstants.SUCCESS,
                  environmentprop
                      .getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_CREATION_FOR_AGENTBASED),
                  "", new Object[] { application.getName(), application.getId(), "PolicySet",
                      "Policy", "Agent", "Module", "ModuleChain" });
        }
      }
    }
    else if (PMTConstants.PEP_TYPE_FEDERATION.equalsIgnoreCase(application.getPepType())) {

      if (AuthenticationSchemeTypes.AUTHN_SCHEME_SAML2.getValue().equalsIgnoreCase(
          authenticationScheme.getType())
          || AuthenticationSchemeTypes.AUTHN_SCHEME_SAML.getValue().equalsIgnoreCase(
              authenticationScheme.getType())
          || AuthenticationSchemeTypes.AUTHN_SCHEME_WSFED.getValue().equalsIgnoreCase(
              authenticationScheme.getType())) {
        actions = createWorkflowFederationBased;
        // Audit log for artifact creation for Federation based
        // application

        auditWriter
            .write(
                ACTIONS.PROVISION,
                PMTConstants.SUCCESS,
                environmentprop
                    .getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_CREATION_FOR_FEDERATIONBASED),
                "",
                new Object[] { application.getName(), application.getId(), "SAML Provider" });

      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_OAUTH.getValue().equalsIgnoreCase(
          authenticationScheme.getType())) {

        String oauthAgentCreationRequired =
            serverConfigurationService
                .getPropertyValue(PolicyGrammarConstants.OAUTH_AGENT_CREATION_REQUIRED);

        actions = createWorkflowOAuthBased;

        if (!"true".equalsIgnoreCase(oauthAgentCreationRequired)) {
          createWorkflowOAuthBased.remove(createAgentActionImpl);
        }

        // Audit log for artifact creation for oauth based application
        auditWriter
            .write(
                ACTIONS.PROVISION,
                PMTConstants.SUCCESS,
                environmentprop
                    .getProperty(AuditPropertyConstants.TARGET_ACTION_ARTIFACT_CREATION_FOR_OAUTHBASED),
                "", new Object[] { application.getName(), application.getId(), "PolicySet",
                    "Policy", "Agent", "Provider", "Module", "ModuleChain" });
      }
    }
    return actions;
  }
}
