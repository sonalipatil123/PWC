package com.persistent.pmt.executor.openam;

import com.persistent.pmt.executor.ArtifactExecutor;

public interface ModuleExecutor extends ArtifactExecutor {

}
