package com.persistent.pmt.dao;

import java.util.List;
import java.util.Map;

import com.persistent.pmt.model.AuditRecord;
import com.persistent.pmt.model.AuditRecord.ACTIONS;

public interface AuditRecordDao {

  public AuditRecord logAuditRecord(AuditRecord auditRecord);

  public List<AuditRecord> getRecordsByActionAndStatus(int environment, List<ACTIONS> action,
      String status, Map<String, Integer> pagingDetails);

	public List<String> getProcessIdForAction(int environment, ACTIONS action);

  public Long getRecordCountByActionAndStatus(int environment, List<ACTIONS> actions,
      String status);
}
