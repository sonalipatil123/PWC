package com.persistent.pmt.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Resource
 * 
 * Entity model for Resource
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "resources")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Resource {

	@Id
//	@SequenceGenerator(name = "SEQ_RESOURCE", sequenceName = "SEQ_RESOURCE", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_RESOURCE")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "uri")
	private String uri;

	@Column(name = "enabled")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean enabled;

	@Column(name = "anonymous")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean anonymous;

	@ManyToOne
	@JoinColumn(name = "application_id")
	private Application application;

	@JsonIgnore
	@Transient
	private int targetId;

	@JsonIgnore
	@Transient
	private int ruleSetId;

	@Column(name = "success_criteria")
	private String successCriteria;

	@ManyToOne
	@JoinColumn(name = "authentication_policy_id", nullable=true)
	private AuthenticationPolicy authenticationPolicy;

	@Column(name = "root_resource")
	private int rootResource;

	@JsonIgnore
	@Column(name = "target_name")
	private String targetName;

	@JsonIgnore
	@Column(name = "rule_set_name")
	private String ruleSetName;

	@JsonIgnore
	@Column(name = "http_methods")
	private String httpMethodsData;

	@Transient
	private List<String> httpMethods;

	@ManyToOne
	@JoinColumn(name = "authorization_policy_id", nullable=true)
	private AuthorizationPolicy authorizationPolicy;

	@Column(name = "resource_type")
	private String resourceType;

	public Resource() {
		super();
	}

	public Resource(String uri, boolean enabled, boolean anonymous,
			String successCriteria) {
		super();
		this.uri = uri;
		this.enabled = enabled;
		this.anonymous = anonymous;
		this.successCriteria = successCriteria;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((uri == null) ? 0 : uri.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Resource other = (Resource) obj;
		if (uri == null) {
			if (other.uri != null)
				return false;
		} else if (!uri.equals(other.uri))
			return false;
		return true;
	}

	public void updateResourceValues(Resource resource) {
		this.anonymous = resource.isAnonymous();
		this.enabled = resource.isEnabled();
		this.successCriteria = resource.getSuccessCriteria();

		/*
		 * if (resource.getAuthenticationPolicy() != null) {
		 * this.authenticationPolicy = resource.getAuthenticationPolicy();
		 * this.authenticationPolicy.setResource(this); }
		 */

		/*
		 * if (resource.getAuthorizationPolicies() != null) {
		 * this.authorizationPolicies.clear();
		 * this.authorizationPolicies.addAll(resource.getAuthorizationPolicies()
		 * ); }
		 */
	}

	public List<String> getHttpMethods() {
		if (this.httpMethodsData == null
				|| this.httpMethodsData.trim().length() == 0) {
			this.httpMethods = new ArrayList<String>();
		} else {
			String[] data = this.httpMethodsData.split(",");
			this.httpMethods = Arrays.asList(data);
		}
		return httpMethods;
	}

	public void setHttpMethods(List<String> httpMethods) {
		if (httpMethods == null || httpMethods.isEmpty()) {
			this.httpMethodsData = "";
		} else {
			this.httpMethodsData = StringUtils.join(httpMethods, ",");
		}
		this.httpMethods = httpMethods;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isAnonymous() {
		return anonymous;
	}

	public void setAnonymous(boolean anonymous) {
		this.anonymous = anonymous;
	}

	public int getTargetId() {
		return targetId;
	}

	public void setTargetId(int targetId) {
		this.targetId = targetId;
	}

	public int getRuleSetId() {
		return ruleSetId;
	}

	public void setRuleSetId(int ruleSetId) {
		this.ruleSetId = ruleSetId;
	}

	public String getSuccessCriteria() {
		return successCriteria;
	}

	public void setSuccessCriteria(String successCriteria) {
		this.successCriteria = successCriteria;
	}

	public AuthenticationPolicy getAuthenticationPolicy() {
		return authenticationPolicy;
	}

	public void setAuthenticationPolicy(
			AuthenticationPolicy authenticationPolicy) {
		this.authenticationPolicy = authenticationPolicy;
	}

	public int getRootResource() {
		return rootResource;
	}

	public void setRootResource(int rootResource) {
		this.rootResource = rootResource;
	}

	public String getTargetName() {
		return targetName;
	}

	public void setTargetName(String targetName) {
		this.targetName = targetName;
	}

	public String getRuleSetName() {
		return ruleSetName;
	}

	public void setRuleSetName(String ruleSetName) {
		this.ruleSetName = ruleSetName;
	}

	public String getHttpMethodsData() {
		return httpMethodsData;
	}

	public void setHttpMethodsData(String httpMethodsData) {
		this.httpMethodsData = httpMethodsData;
	}

	public AuthorizationPolicy getAuthorizationPolicy() {
		return authorizationPolicy;
	}

	public void setAuthorizationPolicy(AuthorizationPolicy authorizationPolicy) {
		this.authorizationPolicy = authorizationPolicy;
	}

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("Resource [id=");
    builder.append(id);
    builder.append(", uri=");
    builder.append(uri);
    builder.append(", enabled=");
    builder.append(enabled);
    builder.append(", anonymous=");
    builder.append(anonymous);
    builder.append(", application=");
    builder.append(application);
    builder.append(", targetId=");
    builder.append(targetId);
    builder.append(", ruleSetId=");
    builder.append(ruleSetId);
    builder.append(", successCriteria=");
    builder.append(successCriteria);
    builder.append(", authenticationPolicy=");
    builder.append(authenticationPolicy);
    builder.append(", rootResource=");
    builder.append(rootResource);
    builder.append(", targetName=");
    builder.append(targetName);
    builder.append(", ruleSetName=");
    builder.append(ruleSetName);
    builder.append(", httpMethodsData=");
    builder.append(httpMethodsData);
    builder.append(", httpMethods=");
    builder.append(httpMethods);
    builder.append(", authorizationPolicy=");
    builder.append(authorizationPolicy);
    builder.append(", resourceType=");
    builder.append(resourceType);
    builder.append("]");
    return builder.toString();
  }
}
