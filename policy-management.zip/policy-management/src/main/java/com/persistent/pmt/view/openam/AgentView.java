package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.view.TargetView;

@JsonInclude(Include.NON_NULL)
public class AgentView implements TargetView {

  @JsonIgnore
  private String id;
  private String userpassword;
  private Attribute status;
  private Attribute repositoryLocation;
  private Attribute clientIpHeader;
  private Attribute clientHostnameHeader;
  private Attribute continuousSecurityCookies;
  private Attribute gotoParameterName;
  private Attribute agentConfigChangeNotificationsEnabled;
  private Attribute webSocketConnectionIntervalInMinutes;
  private Attribute jwtName;
  private Attribute amLogoutUrl;
  private Attribute cookieName;
  private Attribute secureCookies;
  private Attribute ignorePathInfoForNotEnforcedUrls;
  private Attribute encodeSpecialCharsInCookies;
  private Attribute notificationsEnabled;
  private Attribute agentNotificationUrl;
  private Attribute caseInsensitiveUrlComparison;
  private Attribute policyCachePollingInterval;
  private Attribute ssoCachePollingInterval;
  private Attribute userIdParameter;
  private Attribute userIdParameterType;
  private Attribute profileAttributeFetchMode;
  private Attribute profileAttributeMap;
  private Attribute sessionAttributeFetchMode;
  private Attribute sessionAttributeMap;
  private Attribute responseAttributeFetchMode;
  private Attribute responseAttributeMap;
  private Attribute loadBalanced;
  private Attribute ignoreServerCheck;
  private Attribute ignorePreferredNamingUrl;
  private Attribute amLoginUrl;
  private Attribute agentUriPrefix;
  private Attribute ssoOnlyMode;
  private Attribute accessDeniedUrl;
  private Attribute fqdnCheck;
  private Attribute fqdnDefault;
  private Attribute fqdnMapping;
  private Attribute cookieResetEnabled;
  private Attribute cookieResetList;
  private Attribute cdsso;
  private Attribute anonymousUserId;
  private Attribute anonymousUserEnabled;
  private Attribute notEnforcedUrls;
  private Attribute invertNotEnforcedUrls;
  private Attribute notEnforcedIps;
  private Attribute postDataPreservation;
  private Attribute postDataCachePeriod;
  private Attribute cdssoUrls;
  private Attribute cdssoRedirectUri;
  private Attribute cdssoCookieDomain;
  private Attribute clientIpValidation;
  private Attribute profileAttributesCookiePrefix;
  private Attribute profileAttributesCookieMaxAge;
  private Attribute applicationLogoutUrls;
  private Attribute logoutResetCookies;
  private Attribute fetchPoliciesFromRootResource;
  private Attribute retrieveClientHostname;
  private Attribute encodeProfileAttributes;
  private Attribute encodeUrlSpecialCharacters;
  private Attribute ignorePathInfo;
  private Attribute overrideRequestProtocol;
  private Attribute overrideRequestHost;
  private Attribute overrideRequestPort;
  private Attribute overrideNotificationUrl;
  private Attribute agentConnectionTimeout;
  private Attribute primaryServerPollingPeriod;
  private Attribute agentLocale;
  private Attribute overrideProxyHostAndPort;
  private Attribute configurationPollingInterval;
  private Attribute configurationCleanupInterval;
  private Attribute customProperties;
  private Attribute fetchAttributesForNotEnforcedUrls;
  private Attribute authenticationType;
  private Attribute replayPasswordKey;
  private Attribute filterPriority;
  private Attribute filterConfiguredWithOwa;
  private Attribute changeProtocolToHttps;
  private Attribute idleSessionTimeoutUrl;
  private Attribute checkUserInDomino;
  private Attribute useLtpaToken;
  private Attribute ltpaTokenCookieName;
  private Attribute ltpaTokenConfigurationname;
  private Attribute ltpaTokenOrganizationName;
  private Attribute policyClockSkew;
  private Attribute policyEvaluationRealm;
  private Attribute policyEvaluationApplication;
  private Attribute auditAccessType;
  private Attribute auditLogLocation;
  private Attribute remoteLogFilename;
  private Attribute remoteLogSendInterval;
  private Attribute localAuditLogRotation;
  private Attribute localAuditRotationSize;
  private Attribute agentDebugLevel;
  private Attribute debugLogRotation;
  private Attribute debugRotationSize;
  private Attribute attributeMultiValueSeparator;
  private Attribute logoutRedirectUrl;
  private Attribute cdssoRootUrl;
  private Attribute showPasswordInHeader;
  private Attribute logonAndImpersonation;

  public AgentView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public AgentView(String userPassword, Attribute status, Attribute repositoryLocation,
      Attribute clientIpHeader, Attribute clientHostnameHeader,
      Attribute continuousSecurityCookies, Attribute gotoParameterName,
      Attribute agentConfigChangeNotificationsEnabled,
      Attribute webSocketConnectionIntervalInMinutes, Attribute jwtName, Attribute amLogoutUrl,
      Attribute cookieName, Attribute secureCookies,
      Attribute ignorePathInfoForNotEnforcedUrls, Attribute encodeSpecialCharsInCookies,
      Attribute notificationsEnabled, Attribute agentNotificationUrl,
      Attribute caseInsensitiveUrlComparison, Attribute policyCachePollingInterval,
      Attribute ssoCachePollingInterval, Attribute userIdParameter,
      Attribute userIdParameterType, Attribute profileAttributeFetchMode,
      Attribute profileAttributeMap, Attribute sessionAttributeFetchMode,
      Attribute sessionAttributeMap, Attribute responseAttributeFetchMode,
      Attribute responseAttributeMap, Attribute loadBalanced, Attribute ignoreServerCheck,
      Attribute ignorePreferredNamingUrl, Attribute amLoginUrl, Attribute agentUriPrefix,
      Attribute ssoOnlyMode, Attribute accessDeniedUrl, Attribute fqdnCheck,
      Attribute fqdnDefault, Attribute fqdnMapping, Attribute cookieResetEnabled,
      Attribute cookieResetList, Attribute cdsso, Attribute anonymousUserId,
      Attribute anonymousUserEnabled, Attribute notEnforcedUrls,
      Attribute invertNotEnforcedUrls, Attribute notEnforcedIps,
      Attribute postDataPreservation, Attribute postDataCachePeriod, Attribute cdssoUrls,
      Attribute cdssoRedirectUri, Attribute cdssoCookieDomain, Attribute clientIpValidation,
      Attribute profileAttributesCookiePrefix, Attribute profileAttributesCookieMaxAge,
      Attribute applicationLogoutUrls, Attribute logoutResetCookies,
      Attribute fetchPoliciesFromRootResource, Attribute retrieveClientHostname,
      Attribute encodeProfileAttributes, Attribute encodeUrlSpecialCharacters,
      Attribute ignorePathInfo, Attribute overrideRequestProtocol,
      Attribute overrideRequestHost, Attribute overrideRequestPort,
      Attribute overrideNotificationUrl, Attribute agentConnectionTimeout,
      Attribute primaryServerPollingPeriod, Attribute agentLocale,
      Attribute overrideProxyHostAndPort, Attribute configurationPollingInterval,
      Attribute configurationCleanupInterval, Attribute customProperties,
      Attribute fetchAttributesForNotEnforcedUrls, Attribute authenticationType,
      Attribute replayPasswordKey, Attribute filterPriority, Attribute filterConfiguredWithOwa,
      Attribute changeProtocolToHttps, Attribute idleSessionTimeoutUrl,
      Attribute checkUserInDomino, Attribute useLtpaToken, Attribute ltpaTokenCookieName,
      Attribute ltpaTokenConfigurationname, Attribute ltpaTokenOrganizationName,
      Attribute policyClockSkew, Attribute policyEvaluationRealm,
      Attribute policyEvaluationApplication, Attribute auditAccessType,
      Attribute auditLogLocation, Attribute remoteLogFilename, Attribute remoteLogSendInterval,
      Attribute localAuditLogRotation, Attribute localAuditRotationSize,
      Attribute agentDebugLevel, Attribute debugLogRotation, Attribute debugRotationSize,
      Attribute attributeMultiValueSeparator, Attribute logoutRedirectUrl,
      Attribute cdssoRootUrl, Attribute showPasswordInHeader, Attribute logonAndImpersonation) {
    super();
    this.userpassword = userPassword;
    this.status = status;
    this.repositoryLocation = repositoryLocation;
    this.clientIpHeader = clientIpHeader;
    this.clientHostnameHeader = clientHostnameHeader;
    this.continuousSecurityCookies = continuousSecurityCookies;
    this.gotoParameterName = gotoParameterName;
    this.agentConfigChangeNotificationsEnabled = agentConfigChangeNotificationsEnabled;
    this.webSocketConnectionIntervalInMinutes = webSocketConnectionIntervalInMinutes;
    this.jwtName = jwtName;
    this.amLogoutUrl = amLogoutUrl;
    this.cookieName = cookieName;
    this.secureCookies = secureCookies;
    this.ignorePathInfoForNotEnforcedUrls = ignorePathInfoForNotEnforcedUrls;
    this.encodeSpecialCharsInCookies = encodeSpecialCharsInCookies;
    this.notificationsEnabled = notificationsEnabled;
    this.agentNotificationUrl = agentNotificationUrl;
    this.caseInsensitiveUrlComparison = caseInsensitiveUrlComparison;
    this.policyCachePollingInterval = policyCachePollingInterval;
    this.ssoCachePollingInterval = ssoCachePollingInterval;
    this.userIdParameter = userIdParameter;
    this.userIdParameterType = userIdParameterType;
    this.profileAttributeFetchMode = profileAttributeFetchMode;
    this.profileAttributeMap = profileAttributeMap;
    this.sessionAttributeFetchMode = sessionAttributeFetchMode;
    this.sessionAttributeMap = sessionAttributeMap;
    this.responseAttributeFetchMode = responseAttributeFetchMode;
    this.responseAttributeMap = responseAttributeMap;
    this.loadBalanced = loadBalanced;
    this.ignoreServerCheck = ignoreServerCheck;
    this.ignorePreferredNamingUrl = ignorePreferredNamingUrl;
    this.amLoginUrl = amLoginUrl;
    this.agentUriPrefix = agentUriPrefix;
    this.ssoOnlyMode = ssoOnlyMode;
    this.accessDeniedUrl = accessDeniedUrl;
    this.fqdnCheck = fqdnCheck;
    this.fqdnDefault = fqdnDefault;
    this.fqdnMapping = fqdnMapping;
    this.cookieResetEnabled = cookieResetEnabled;
    this.cookieResetList = cookieResetList;
    this.cdsso = cdsso;
    this.anonymousUserId = anonymousUserId;
    this.anonymousUserEnabled = anonymousUserEnabled;
    this.notEnforcedUrls = notEnforcedUrls;
    this.invertNotEnforcedUrls = invertNotEnforcedUrls;
    this.notEnforcedIps = notEnforcedIps;
    this.postDataPreservation = postDataPreservation;
    this.postDataCachePeriod = postDataCachePeriod;
    this.cdssoUrls = cdssoUrls;
    this.cdssoRedirectUri = cdssoRedirectUri;
    this.cdssoCookieDomain = cdssoCookieDomain;
    this.clientIpValidation = clientIpValidation;
    this.profileAttributesCookiePrefix = profileAttributesCookiePrefix;
    this.profileAttributesCookieMaxAge = profileAttributesCookieMaxAge;
    this.applicationLogoutUrls = applicationLogoutUrls;
    this.logoutResetCookies = logoutResetCookies;
    this.fetchPoliciesFromRootResource = fetchPoliciesFromRootResource;
    this.retrieveClientHostname = retrieveClientHostname;
    this.encodeProfileAttributes = encodeProfileAttributes;
    this.encodeUrlSpecialCharacters = encodeUrlSpecialCharacters;
    this.ignorePathInfo = ignorePathInfo;
    this.overrideRequestProtocol = overrideRequestProtocol;
    this.overrideRequestHost = overrideRequestHost;
    this.overrideRequestPort = overrideRequestPort;
    this.overrideNotificationUrl = overrideNotificationUrl;
    this.agentConnectionTimeout = agentConnectionTimeout;
    this.primaryServerPollingPeriod = primaryServerPollingPeriod;
    this.agentLocale = agentLocale;
    this.overrideProxyHostAndPort = overrideProxyHostAndPort;
    this.configurationPollingInterval = configurationPollingInterval;
    this.configurationCleanupInterval = configurationCleanupInterval;
    this.customProperties = customProperties;
    this.fetchAttributesForNotEnforcedUrls = fetchAttributesForNotEnforcedUrls;
    this.authenticationType = authenticationType;
    this.replayPasswordKey = replayPasswordKey;
    this.filterPriority = filterPriority;
    this.filterConfiguredWithOwa = filterConfiguredWithOwa;
    this.changeProtocolToHttps = changeProtocolToHttps;
    this.idleSessionTimeoutUrl = idleSessionTimeoutUrl;
    this.checkUserInDomino = checkUserInDomino;
    this.useLtpaToken = useLtpaToken;
    this.ltpaTokenCookieName = ltpaTokenCookieName;
    this.ltpaTokenConfigurationname = ltpaTokenConfigurationname;
    this.ltpaTokenOrganizationName = ltpaTokenOrganizationName;
    this.policyClockSkew = policyClockSkew;
    this.policyEvaluationRealm = policyEvaluationRealm;
    this.policyEvaluationApplication = policyEvaluationApplication;
    this.auditAccessType = auditAccessType;
    this.auditLogLocation = auditLogLocation;
    this.remoteLogFilename = remoteLogFilename;
    this.remoteLogSendInterval = remoteLogSendInterval;
    this.localAuditLogRotation = localAuditLogRotation;
    this.localAuditRotationSize = localAuditRotationSize;
    this.agentDebugLevel = agentDebugLevel;
    this.debugLogRotation = debugLogRotation;
    this.debugRotationSize = debugRotationSize;
    this.attributeMultiValueSeparator = attributeMultiValueSeparator;
    this.logoutRedirectUrl = logoutRedirectUrl;
    this.cdssoRootUrl = cdssoRootUrl;
    this.showPasswordInHeader = showPasswordInHeader;
    this.logonAndImpersonation = logonAndImpersonation;
  }

  public String getUserpassword() {
    return userpassword;
  }

  public void setUserpassword(String userpassword) {
    this.userpassword = userpassword;
  }

  public Attribute getStatus() {
    return status;
  }

  public void setStatus(Attribute status) {
    this.status = status;
  }

  public Attribute getRepositoryLocation() {
    return repositoryLocation;
  }

  public void setRepositoryLocation(Attribute repositoryLocation) {
    this.repositoryLocation = repositoryLocation;
  }

  public Attribute getClientIpHeader() {
    return clientIpHeader;
  }

  public void setClientIpHeader(Attribute clientIpHeader) {
    this.clientIpHeader = clientIpHeader;
  }

  public Attribute getClientHostnameHeader() {
    return clientHostnameHeader;
  }

  public void setClientHostnameHeader(Attribute clientHostnameHeader) {
    this.clientHostnameHeader = clientHostnameHeader;
  }

  public Attribute getContinuousSecurityCookies() {
    return continuousSecurityCookies;
  }

  public void setContinuousSecurityCookies(Attribute continuousSecurityCookies) {
    this.continuousSecurityCookies = continuousSecurityCookies;
  }

  public Attribute getGotoParameterName() {
    return gotoParameterName;
  }

  public void setGotoParameterName(Attribute gotoParameterName) {
    this.gotoParameterName = gotoParameterName;
  }

  public Attribute getAgentConfigChangeNotificationsEnabled() {
    return agentConfigChangeNotificationsEnabled;
  }

  public void setAgentConfigChangeNotificationsEnabled(
      Attribute agentConfigChangeNotificationsEnabled) {
    this.agentConfigChangeNotificationsEnabled = agentConfigChangeNotificationsEnabled;
  }

  public Attribute getWebSocketConnectionIntervalInMinutes() {
    return webSocketConnectionIntervalInMinutes;
  }

  public void setWebSocketConnectionIntervalInMinutes(
      Attribute webSocketConnectionIntervalInMinutes) {
    this.webSocketConnectionIntervalInMinutes = webSocketConnectionIntervalInMinutes;
  }

  public Attribute getJwtName() {
    return jwtName;
  }

  public void setJwtName(Attribute jwtName) {
    this.jwtName = jwtName;
  }

  public Attribute getAmLogoutUrl() {
    return amLogoutUrl;
  }

  public void setAmLogoutUrl(Attribute amLogoutUrl) {
    this.amLogoutUrl = amLogoutUrl;
  }

  public Attribute getCookieName() {
    return cookieName;
  }

  public void setCookieName(Attribute cookieName) {
    this.cookieName = cookieName;
  }

  public Attribute getSecureCookies() {
    return secureCookies;
  }

  public void setSecureCookies(Attribute secureCookies) {
    this.secureCookies = secureCookies;
  }

  public Attribute getIgnorePathInfoForNotEnforcedUrls() {
    return ignorePathInfoForNotEnforcedUrls;
  }

  public void setIgnorePathInfoForNotEnforcedUrls(Attribute ignorePathInfoForNotEnforcedUrls) {
    this.ignorePathInfoForNotEnforcedUrls = ignorePathInfoForNotEnforcedUrls;
  }

  public Attribute getEncodeSpecialCharsInCookies() {
    return encodeSpecialCharsInCookies;
  }

  public void setEncodeSpecialCharsInCookies(Attribute encodeSpecialCharsInCookies) {
    this.encodeSpecialCharsInCookies = encodeSpecialCharsInCookies;
  }

  public Attribute getNotificationsEnabled() {
    return notificationsEnabled;
  }

  public void setNotificationsEnabled(Attribute notificationsEnabled) {
    this.notificationsEnabled = notificationsEnabled;
  }

  public Attribute getAgentNotificationUrl() {
    return agentNotificationUrl;
  }

  public void setAgentNotificationUrl(Attribute agentNotificationUrl) {
    this.agentNotificationUrl = agentNotificationUrl;
  }

  public Attribute getCaseInsensitiveUrlComparison() {
    return caseInsensitiveUrlComparison;
  }

  public void setCaseInsensitiveUrlComparison(Attribute caseInsensitiveUrlComparison) {
    this.caseInsensitiveUrlComparison = caseInsensitiveUrlComparison;
  }

  public Attribute getPolicyCachePollingInterval() {
    return policyCachePollingInterval;
  }

  public void setPolicyCachePollingInterval(Attribute policyCachePollingInterval) {
    this.policyCachePollingInterval = policyCachePollingInterval;
  }

  public Attribute getSsoCachePollingInterval() {
    return ssoCachePollingInterval;
  }

  public void setSsoCachePollingInterval(Attribute ssoCachePollingInterval) {
    this.ssoCachePollingInterval = ssoCachePollingInterval;
  }

  public Attribute getUserIdParameter() {
    return userIdParameter;
  }

  public void setUserIdParameter(Attribute userIdParameter) {
    this.userIdParameter = userIdParameter;
  }

  public Attribute getUserIdParameterType() {
    return userIdParameterType;
  }

  public void setUserIdParameterType(Attribute userIdParameterType) {
    this.userIdParameterType = userIdParameterType;
  }

  public Attribute getProfileAttributeFetchMode() {
    return profileAttributeFetchMode;
  }

  public void setProfileAttributeFetchMode(Attribute profileAttributeFetchMode) {
    this.profileAttributeFetchMode = profileAttributeFetchMode;
  }

  public Attribute getProfileAttributeMap() {
    return profileAttributeMap;
  }

  public void setProfileAttributeMap(Attribute profileAttributeMap) {
    this.profileAttributeMap = profileAttributeMap;
  }

  public Attribute getSessionAttributeFetchMode() {
    return sessionAttributeFetchMode;
  }

  public void setSessionAttributeFetchMode(Attribute sessionAttributeFetchMode) {
    this.sessionAttributeFetchMode = sessionAttributeFetchMode;
  }

  public Attribute getSessionAttributeMap() {
    return sessionAttributeMap;
  }

  public void setSessionAttributeMap(Attribute sessionAttributeMap) {
    this.sessionAttributeMap = sessionAttributeMap;
  }

  public Attribute getResponseAttributeFetchMode() {
    return responseAttributeFetchMode;
  }

  public void setResponseAttributeFetchMode(Attribute responseAttributeFetchMode) {
    this.responseAttributeFetchMode = responseAttributeFetchMode;
  }

  public Attribute getResponseAttributeMap() {
    return responseAttributeMap;
  }

  public void setResponseAttributeMap(Attribute responseAttributeMap) {
    this.responseAttributeMap = responseAttributeMap;
  }

  public Attribute getLoadBalanced() {
    return loadBalanced;
  }

  public void setLoadBalanced(Attribute loadBalanced) {
    this.loadBalanced = loadBalanced;
  }

  public Attribute getIgnoreServerCheck() {
    return ignoreServerCheck;
  }

  public void setIgnoreServerCheck(Attribute ignoreServerCheck) {
    this.ignoreServerCheck = ignoreServerCheck;
  }

  public Attribute getIgnorePreferredNamingUrl() {
    return ignorePreferredNamingUrl;
  }

  public void setIgnorePreferredNamingUrl(Attribute ignorePreferredNamingUrl) {
    this.ignorePreferredNamingUrl = ignorePreferredNamingUrl;
  }

  public Attribute getAmLoginUrl() {
    return amLoginUrl;
  }

  public void setAmLoginUrl(Attribute amLoginUrl) {
    this.amLoginUrl = amLoginUrl;
  }

  public Attribute getAgentUriPrefix() {
    return agentUriPrefix;
  }

  public void setAgentUriPrefix(Attribute agentUriPrefix) {
    this.agentUriPrefix = agentUriPrefix;
  }

  public Attribute getSsoOnlyMode() {
    return ssoOnlyMode;
  }

  public void setSsoOnlyMode(Attribute ssoOnlyMode) {
    this.ssoOnlyMode = ssoOnlyMode;
  }

  public Attribute getAccessDeniedUrl() {
    return accessDeniedUrl;
  }

  public void setAccessDeniedUrl(Attribute accessDeniedUrl) {
    this.accessDeniedUrl = accessDeniedUrl;
  }

  public Attribute getFqdnCheck() {
    return fqdnCheck;
  }

  public void setFqdnCheck(Attribute fqdnCheck) {
    this.fqdnCheck = fqdnCheck;
  }

  public Attribute getFqdnDefault() {
    return fqdnDefault;
  }

  public void setFqdnDefault(Attribute fqdnDefault) {
    this.fqdnDefault = fqdnDefault;
  }

  public Attribute getFqdnMapping() {
    return fqdnMapping;
  }

  public void setFqdnMapping(Attribute fqdnMapping) {
    this.fqdnMapping = fqdnMapping;
  }

  public Attribute getCookieResetEnabled() {
    return cookieResetEnabled;
  }

  public void setCookieResetEnabled(Attribute cookieResetEnabled) {
    this.cookieResetEnabled = cookieResetEnabled;
  }

  public Attribute getCookieResetList() {
    return cookieResetList;
  }

  public void setCookieResetList(Attribute cookieResetList) {
    this.cookieResetList = cookieResetList;
  }

  public Attribute getCdsso() {
    return cdsso;
  }

  public void setCdsso(Attribute cdsso) {
    this.cdsso = cdsso;
  }

  public Attribute getAnonymousUserId() {
    return anonymousUserId;
  }

  public void setAnonymousUserId(Attribute anonymousUserId) {
    this.anonymousUserId = anonymousUserId;
  }

  public Attribute getAnonymousUserEnabled() {
    return anonymousUserEnabled;
  }

  public void setAnonymousUserEnabled(Attribute anonymousUserEnabled) {
    this.anonymousUserEnabled = anonymousUserEnabled;
  }

  public Attribute getNotEnforcedUrls() {
    return notEnforcedUrls;
  }

  public void setNotEnforcedUrls(Attribute notEnforcedUrls) {
    this.notEnforcedUrls = notEnforcedUrls;
  }

  public Attribute getInvertNotEnforcedUrls() {
    return invertNotEnforcedUrls;
  }

  public void setInvertNotEnforcedUrls(Attribute invertNotEnforcedUrls) {
    this.invertNotEnforcedUrls = invertNotEnforcedUrls;
  }

  public Attribute getNotEnforcedIps() {
    return notEnforcedIps;
  }

  public void setNotEnforcedIps(Attribute notEnforcedIps) {
    this.notEnforcedIps = notEnforcedIps;
  }

  public Attribute getPostDataPreservation() {
    return postDataPreservation;
  }

  public void setPostDataPreservation(Attribute postDataPreservation) {
    this.postDataPreservation = postDataPreservation;
  }

  public Attribute getPostDataCachePeriod() {
    return postDataCachePeriod;
  }

  public void setPostDataCachePeriod(Attribute postDataCachePeriod) {
    this.postDataCachePeriod = postDataCachePeriod;
  }

  public Attribute getCdssoUrls() {
    return cdssoUrls;
  }

  public void setCdssoUrls(Attribute cdssoUrls) {
    this.cdssoUrls = cdssoUrls;
  }

  public Attribute getCdssoRedirectUri() {
    return cdssoRedirectUri;
  }

  public void setCdssoRedirectUri(Attribute cdssoRedirectUri) {
    this.cdssoRedirectUri = cdssoRedirectUri;
  }

  public Attribute getCdssoCookieDomain() {
    return cdssoCookieDomain;
  }

  public void setCdssoCookieDomain(Attribute cdssoCookieDomain) {
    this.cdssoCookieDomain = cdssoCookieDomain;
  }

  public Attribute getClientIpValidation() {
    return clientIpValidation;
  }

  public void setClientIpValidation(Attribute clientIpValidation) {
    this.clientIpValidation = clientIpValidation;
  }

  public Attribute getProfileAttributesCookiePrefix() {
    return profileAttributesCookiePrefix;
  }

  public void setProfileAttributesCookiePrefix(Attribute profileAttributesCookiePrefix) {
    this.profileAttributesCookiePrefix = profileAttributesCookiePrefix;
  }

  public Attribute getProfileAttributesCookieMaxAge() {
    return profileAttributesCookieMaxAge;
  }

  public void setProfileAttributesCookieMaxAge(Attribute profileAttributesCookieMaxAge) {
    this.profileAttributesCookieMaxAge = profileAttributesCookieMaxAge;
  }

  public Attribute getApplicationLogoutUrls() {
    return applicationLogoutUrls;
  }

  public void setApplicationLogoutUrls(Attribute applicationLogoutUrls) {
    this.applicationLogoutUrls = applicationLogoutUrls;
  }

  public Attribute getLogoutResetCookies() {
    return logoutResetCookies;
  }

  public void setLogoutResetCookies(Attribute logoutResetCookies) {
    this.logoutResetCookies = logoutResetCookies;
  }

  public Attribute getFetchPoliciesFromRootResource() {
    return fetchPoliciesFromRootResource;
  }

  public void setFetchPoliciesFromRootResource(Attribute fetchPoliciesFromRootResource) {
    this.fetchPoliciesFromRootResource = fetchPoliciesFromRootResource;
  }

  public Attribute getRetrieveClientHostname() {
    return retrieveClientHostname;
  }

  public void setRetrieveClientHostname(Attribute retrieveClientHostname) {
    this.retrieveClientHostname = retrieveClientHostname;
  }

  public Attribute getEncodeProfileAttributes() {
    return encodeProfileAttributes;
  }

  public void setEncodeProfileAttributes(Attribute encodeProfileAttributes) {
    this.encodeProfileAttributes = encodeProfileAttributes;
  }

  public Attribute getEncodeUrlSpecialCharacters() {
    return encodeUrlSpecialCharacters;
  }

  public void setEncodeUrlSpecialCharacters(Attribute encodeUrlSpecialCharacters) {
    this.encodeUrlSpecialCharacters = encodeUrlSpecialCharacters;
  }

  public Attribute getIgnorePathInfo() {
    return ignorePathInfo;
  }

  public void setIgnorePathInfo(Attribute ignorePathInfo) {
    this.ignorePathInfo = ignorePathInfo;
  }

  public Attribute getOverrideRequestProtocol() {
    return overrideRequestProtocol;
  }

  public void setOverrideRequestProtocol(Attribute overrideRequestProtocol) {
    this.overrideRequestProtocol = overrideRequestProtocol;
  }

  public Attribute getOverrideRequestHost() {
    return overrideRequestHost;
  }

  public void setOverrideRequestHost(Attribute overrideRequestHost) {
    this.overrideRequestHost = overrideRequestHost;
  }

  public Attribute getOverrideRequestPort() {
    return overrideRequestPort;
  }

  public void setOverrideRequestPort(Attribute overrideRequestPort) {
    this.overrideRequestPort = overrideRequestPort;
  }

  public Attribute getOverrideNotificationUrl() {
    return overrideNotificationUrl;
  }

  public void setOverrideNotificationUrl(Attribute overrideNotificationUrl) {
    this.overrideNotificationUrl = overrideNotificationUrl;
  }

  public Attribute getAgentConnectionTimeout() {
    return agentConnectionTimeout;
  }

  public void setAgentConnectionTimeout(Attribute agentConnectionTimeout) {
    this.agentConnectionTimeout = agentConnectionTimeout;
  }

  public Attribute getPrimaryServerPollingPeriod() {
    return primaryServerPollingPeriod;
  }

  public void setPrimaryServerPollingPeriod(Attribute primaryServerPollingPeriod) {
    this.primaryServerPollingPeriod = primaryServerPollingPeriod;
  }

  public Attribute getAgentLocale() {
    return agentLocale;
  }

  public void setAgentLocale(Attribute agentLocale) {
    this.agentLocale = agentLocale;
  }

  public Attribute getOverrideProxyHostAndPort() {
    return overrideProxyHostAndPort;
  }

  public void setOverrideProxyHostAndPort(Attribute overrideProxyHostAndPort) {
    this.overrideProxyHostAndPort = overrideProxyHostAndPort;
  }

  public Attribute getConfigurationPollingInterval() {
    return configurationPollingInterval;
  }

  public void setConfigurationPollingInterval(Attribute configurationPollingInterval) {
    this.configurationPollingInterval = configurationPollingInterval;
  }

  public Attribute getConfigurationCleanupInterval() {
    return configurationCleanupInterval;
  }

  public void setConfigurationCleanupInterval(Attribute configurationCleanupInterval) {
    this.configurationCleanupInterval = configurationCleanupInterval;
  }

  public Attribute getCustomProperties() {
    return customProperties;
  }

  public void setCustomProperties(Attribute customProperties) {
    this.customProperties = customProperties;
  }

  public Attribute getFetchAttributesForNotEnforcedUrls() {
    return fetchAttributesForNotEnforcedUrls;
  }

  public void setFetchAttributesForNotEnforcedUrls(Attribute fetchAttributesForNotEnforcedUrls) {
    this.fetchAttributesForNotEnforcedUrls = fetchAttributesForNotEnforcedUrls;
  }

  public Attribute getAuthenticationType() {
    return authenticationType;
  }

  public void setAuthenticationType(Attribute authenticationType) {
    this.authenticationType = authenticationType;
  }

  public Attribute getReplayPasswordKey() {
    return replayPasswordKey;
  }

  public void setReplayPasswordKey(Attribute replayPasswordKey) {
    this.replayPasswordKey = replayPasswordKey;
  }

  public Attribute getFilterPriority() {
    return filterPriority;
  }

  public void setFilterPriority(Attribute filterPriority) {
    this.filterPriority = filterPriority;
  }

  public Attribute getFilterConfiguredWithOwa() {
    return filterConfiguredWithOwa;
  }

  public void setFilterConfiguredWithOwa(Attribute filterConfiguredWithOwa) {
    this.filterConfiguredWithOwa = filterConfiguredWithOwa;
  }

  public Attribute getChangeProtocolToHttps() {
    return changeProtocolToHttps;
  }

  public void setChangeProtocolToHttps(Attribute changeProtocolToHttps) {
    this.changeProtocolToHttps = changeProtocolToHttps;
  }

  public Attribute getIdleSessionTimeoutUrl() {
    return idleSessionTimeoutUrl;
  }

  public void setIdleSessionTimeoutUrl(Attribute idleSessionTimeoutUrl) {
    this.idleSessionTimeoutUrl = idleSessionTimeoutUrl;
  }

  public Attribute getCheckUserInDomino() {
    return checkUserInDomino;
  }

  public void setCheckUserInDomino(Attribute checkUserInDomino) {
    this.checkUserInDomino = checkUserInDomino;
  }

  public Attribute getUseLtpaToken() {
    return useLtpaToken;
  }

  public void setUseLtpaToken(Attribute useLtpaToken) {
    this.useLtpaToken = useLtpaToken;
  }

  public Attribute getLtpaTokenCookieName() {
    return ltpaTokenCookieName;
  }

  public void setLtpaTokenCookieName(Attribute ltpaTokenCookieName) {
    this.ltpaTokenCookieName = ltpaTokenCookieName;
  }

  public Attribute getLtpaTokenConfigurationname() {
    return ltpaTokenConfigurationname;
  }

  public void setLtpaTokenConfigurationname(Attribute ltpaTokenConfigurationname) {
    this.ltpaTokenConfigurationname = ltpaTokenConfigurationname;
  }

  public Attribute getLtpaTokenOrganizationName() {
    return ltpaTokenOrganizationName;
  }

  public void setLtpaTokenOrganizationName(Attribute ltpaTokenOrganizationName) {
    this.ltpaTokenOrganizationName = ltpaTokenOrganizationName;
  }

  public Attribute getPolicyClockSkew() {
    return policyClockSkew;
  }

  public void setPolicyClockSkew(Attribute policyClockSkew) {
    this.policyClockSkew = policyClockSkew;
  }

  public Attribute getPolicyEvaluationRealm() {
    return policyEvaluationRealm;
  }

  public void setPolicyEvaluationRealm(Attribute policyEvaluationRealm) {
    this.policyEvaluationRealm = policyEvaluationRealm;
  }

  public Attribute getPolicyEvaluationApplication() {
    return policyEvaluationApplication;
  }

  public void setPolicyEvaluationApplication(Attribute policyEvaluationApplication) {
    this.policyEvaluationApplication = policyEvaluationApplication;
  }

  public Attribute getAuditAccessType() {
    return auditAccessType;
  }

  public void setAuditAccessType(Attribute auditAccessType) {
    this.auditAccessType = auditAccessType;
  }

  public Attribute getAuditLogLocation() {
    return auditLogLocation;
  }

  public void setAuditLogLocation(Attribute auditLogLocation) {
    this.auditLogLocation = auditLogLocation;
  }

  public Attribute getRemoteLogFilename() {
    return remoteLogFilename;
  }

  public void setRemoteLogFilename(Attribute remoteLogFilename) {
    this.remoteLogFilename = remoteLogFilename;
  }

  public Attribute getRemoteLogSendInterval() {
    return remoteLogSendInterval;
  }

  public void setRemoteLogSendInterval(Attribute remoteLogSendInterval) {
    this.remoteLogSendInterval = remoteLogSendInterval;
  }

  public Attribute getLocalAuditLogRotation() {
    return localAuditLogRotation;
  }

  public void setLocalAuditLogRotation(Attribute localAuditLogRotation) {
    this.localAuditLogRotation = localAuditLogRotation;
  }

  public Attribute getLocalAuditRotationSize() {
    return localAuditRotationSize;
  }

  public void setLocalAuditRotationSize(Attribute localAuditRotationSize) {
    this.localAuditRotationSize = localAuditRotationSize;
  }

  public Attribute getAgentDebugLevel() {
    return agentDebugLevel;
  }

  public void setAgentDebugLevel(Attribute agentDebugLevel) {
    this.agentDebugLevel = agentDebugLevel;
  }

  public Attribute getDebugLogRotation() {
    return debugLogRotation;
  }

  public void setDebugLogRotation(Attribute debugLogRotation) {
    this.debugLogRotation = debugLogRotation;
  }

  public Attribute getDebugRotationSize() {
    return debugRotationSize;
  }

  public void setDebugRotationSize(Attribute debugRotationSize) {
    this.debugRotationSize = debugRotationSize;
  }

  public Attribute getAttributeMultiValueSeparator() {
    return attributeMultiValueSeparator;
  }

  public void setAttributeMultiValueSeparator(Attribute attributeMultiValueSeparator) {
    this.attributeMultiValueSeparator = attributeMultiValueSeparator;
  }

  public Attribute getLogoutRedirectUrl() {
    return logoutRedirectUrl;
  }

  public void setLogoutRedirectUrl(Attribute logoutRedirectUrl) {
    this.logoutRedirectUrl = logoutRedirectUrl;
  }

  public Attribute getCdssoRootUrl() {
    return cdssoRootUrl;
  }

  public void setCdssoRootUrl(Attribute cdssoRootUrl) {
    this.cdssoRootUrl = cdssoRootUrl;
  }

  public Attribute getShowPasswordInHeader() {
    return showPasswordInHeader;
  }

  public void setShowPasswordInHeader(Attribute showPasswordInHeader) {
    this.showPasswordInHeader = showPasswordInHeader;
  }

  public Attribute getLogonAndImpersonation() {
    return logonAndImpersonation;
  }

  public void setLogonAndImpersonation(Attribute logonAndImpersonation) {
    this.logonAndImpersonation = logonAndImpersonation;
  }

}
