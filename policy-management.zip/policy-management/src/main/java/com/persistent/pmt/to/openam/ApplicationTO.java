package com.persistent.pmt.to.openam;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.ApplicationOwner;
import com.persistent.pmt.model.ApplicationState;
import com.persistent.pmt.model.AuthenticationPolicy;
import com.persistent.pmt.model.AuthorizationPolicy;
import com.persistent.pmt.model.AuthorizationPolicyAttribute;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.model.Originator;
import com.persistent.pmt.model.Platform;
import com.persistent.pmt.model.Resource;
import com.persistent.pmt.model.Response;
import com.persistent.pmt.model.UserDataStore;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationTO {
  private Integer id;
  private String name;
  private String state;
  private String contextRoot;
  private String originator;
  private String environment;
  private boolean requireHTTPS;
  private boolean external;
  private boolean webService;
  private String appPortfolioId;
  private String platform;
  private Boolean enabled;
  private String agentType;
  private String agent;
  private String description;
  private List<String> userDirectories;
  private List<ResourceTO> resources;
  private List<AuthenticationPolicyTO> authenticationPolicies;
  private List<AuthorizationPolicyTO> authorizationPolicies;
  private ApplicationOwner owner;
  private String provider;

  public ApplicationTO() {
    super();
  }

  public ApplicationTO(Application application) {
    this.id = application.getId();
    this.name = application.getName();
    this.contextRoot = application.getContextRoot();
    this.requireHTTPS = application.isRequireHTTPS();
    this.enabled = application.isEnabled();
    this.agentType = application.getPepType();
    this.external = application.isExternal();
    this.description = application.getDescription();
    this.webService = application.isWebService();
    this.appPortfolioId = application.getAppPortfolioId();

    if (application.getProvider() != null) {
      this.provider = application.getProvider().getName();
    }

    if (application.getAgent() != null) {
      this.agent = application.getAgent().getName();
    }
    ApplicationState state = application.getApplicationState();
    if (state != null)
      this.state = state.getState();

    Platform platform = application.getPlatform();
    if (platform != null)
      this.platform = platform.getName();

    Originator originator = application.getOriginator();
    if (originator != null)
      this.originator = originator.getName();

    Environment environment = application.getEnvironment();
    if (environment != null)
      this.environment = environment.getName();

    this.owner = application.getOwner();

    getResources(application);
    getUserDirectoriesList(application);
    getAuthenticationPolicy(application);
    getAuthorizationPolicies(application);
  }

  private void getUserDirectoriesList(Application application) {
    List<UserDataStore> userDataStores = application.getUserDataStores();
    for (UserDataStore userDataStore : userDataStores) {
      if (this.userDirectories == null) {
        this.userDirectories = new ArrayList<>();
      }
      this.userDirectories.add(userDataStore.getName());
    }
  }

  private void getAuthenticationPolicy(Application application) {

    List<AuthenticationPolicy> authPolicies = application.getAuthenticationPolicies();
    if (authPolicies != null) {
      List<AuthenticationPolicyTO> authenPolicies = new ArrayList<>();
      for (AuthenticationPolicy authPolicy : authPolicies) {
        if (authPolicy != null && authPolicy.isDefaultEntity()) {
          AuthenticationPolicyTO authPolicyTO = new AuthenticationPolicyTO();
          authPolicyTO.setId(authPolicy.getId());
          authPolicyTO.setName(authPolicy.getName());
          if (authPolicy.getDescription() != null) {
            authPolicyTO.setDescription(authPolicy.getDescription());
          }
          else {
            authPolicyTO.setDescription("");
          }
          authPolicyTO.setEnabled(authPolicy.isEnabled());
          authPolicyTO.setIsPublic(authPolicy.isSystemSpecific());

          if (authPolicy.getAuthenticationScheme() != null) {
            authPolicyTO.setScheme(authPolicy.getAuthenticationScheme().getName());
            authPolicyTO.setSchemeType(authPolicy.getAuthenticationScheme().getType());
          }

          if (application.getResources() != null && !application.getResources().isEmpty()) {
            List<String> uniqueResources = new ArrayList<>();
            Set<String> actions = new HashSet<>();

            for (Resource resource : application.getResources()) {
              if (resource.getAuthenticationPolicy() != null
                  && resource.getAuthenticationPolicy().getId() == authPolicyTO.getId()) {
                uniqueResources.add(String.valueOf(resource.getId()));
                actions.addAll(resource.getHttpMethods());
              }
            }
            authPolicyTO.setResources(uniqueResources);
            authPolicyTO.setActions(actions);
          }

          if (application.getResponses() != null && !application.getResponses().isEmpty()) {
            List<ResponseTO> responseTOs = new ArrayList<>();

            for (Response response : application.getResponses()) {
              if (response.getAuthenticationPolicy() != null) {
                if (response.getAuthenticationPolicy().getId() == authPolicyTO.getId()) {
                  ResponseTO responseTO = new ResponseTO();
                  responseTO.setName(response.getName());
                  responseTO.setType(response.getType());
                  responseTO.setValue(response.getValue());

                  responseTOs.add(responseTO);
                }
              }
            }
            authPolicyTO.setResponses(responseTOs);
          }

          authenPolicies.add(authPolicyTO);
        }
      }
      this.authenticationPolicies = authenPolicies;
    }
  }

  private void getAuthorizationPolicies(Application application) {
    List<AuthorizationPolicy> authzPolicies = application.getAuthorizationPolicies();

    if (authzPolicies != null && !authzPolicies.isEmpty()) {

      List<AuthorizationPolicyTO> authzPolicyTOs = new ArrayList<AuthorizationPolicyTO>();
      for (AuthorizationPolicy authzPolicy : authzPolicies) {
        AuthorizationPolicyTO authzPolicyTO = new AuthorizationPolicyTO();
        authzPolicyTO.setId(authzPolicy.getId());
        authzPolicyTO.setName(authzPolicy.getName());
        authzPolicyTO.setDescription(authzPolicy.getDescription());
        authzPolicyTO.setAuthorizationRule(authzPolicy.getAuthorizationRule());
        authzPolicyTO.setEnabled(authzPolicy.isEnabled());

        if (application.getResources() != null && !application.getResources().isEmpty()) {
          List<Resource> resources = application.getResources();
          List<String> uniqueResources = new ArrayList<>();
          Set<String> actions = new HashSet<>();

          for (Resource resource : resources) {
            if (resource.getAuthorizationPolicy() != null
                && resource.getAuthorizationPolicy().getId() == authzPolicyTO.getId()) {
              uniqueResources.add(String.valueOf(resource.getId()));
              actions.addAll(resource.getHttpMethods());
            }
          }
          authzPolicyTO.setResources(uniqueResources);
          authzPolicyTO.setActions(actions);
        }

        if (application.getResponses() != null && !application.getResponses().isEmpty()) {
          List<ResponseTO> responseTOs = new ArrayList<>();
          for (Response response : application.getResponses()) {
            if (response.getAuthorizationPolicy() != null) {
              if (response.getAuthorizationPolicy().getId() == authzPolicyTO.getId()) {
                ResponseTO responseTO = new ResponseTO();
                responseTO.setName(response.getName());
                responseTO.setType(response.getType());
                responseTO.setValue(response.getValue());
                responseTOs.add(responseTO);
              }
            }
          }
          authzPolicyTO.setResponses(responseTOs);
        }

        List<AuthorizationPolicyAttribute> attributes = authzPolicy.getAttributes();
        if (attributes != null) {
          List<ConditionTO> conditionTOs = new ArrayList<>();
          for (AuthorizationPolicyAttribute attribute : attributes) {
            ConditionTO conditionTO = new ConditionTO();
            conditionTO.setName(attribute.getName());
            conditionTO.setNegate(attribute.isNegate());
            conditionTO.setType(attribute.getConditionType());
            conditionTO.setValue(attribute.getConditionValue());

            conditionTOs.add(conditionTO);
          }
          authzPolicyTO.setConditions(conditionTOs);
        }
        authzPolicyTOs.add(authzPolicyTO);
      }
      this.authorizationPolicies = authzPolicyTOs;
    }
  }

  private void getResources(Application application) {

    List<Resource> resources = application.getResources();

    if (resources != null && !resources.isEmpty()) {
      List<ResourceTO> resourceTOs = new ArrayList<>();

      for (Resource resource : resources) {
        ResourceTO resourceTO = new ResourceTO();
        resourceTO.setId(resource.getId());
        resourceTO.setUri(resource.getUri());
        resourceTO.setAnonymous(resource.isAnonymous());
        resourceTO.setEnabled(resource.isEnabled());
        resourceTO.setResourceType(resource.getResourceType());
        boolean isRootResource = (resource.getRootResource() == 0) ? false : true;
        resourceTO.setRootResource(isRootResource);
        resourceTO.setRuleSetId(resource.getRuleSetId());
        resourceTO.setRuleSetName(resource.getRuleSetName());
        resourceTO.setTargetId(resource.getTargetId());
        resourceTO.setTargetName(resource.getTargetName());
        resourceTO.setActions(new HashSet<>(resource.getHttpMethods()));
        resourceTO.setSuccessCriteria(resource.getSuccessCriteria());

        if (resource.getAuthenticationPolicy() != null) {
          resourceTO.setAuthenticationPolicy(String.valueOf(resource.getAuthenticationPolicy()
              .getId()));
        }

        if (resource.getAuthorizationPolicy() != null) {
          resourceTO.setAuthorizationPolicy(String.valueOf(resource.getAuthorizationPolicy()
              .getId()));
        }

        resourceTOs.add(resourceTO);
      }

      this.resources = resourceTOs;
    }
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getContextRoot() {
    return contextRoot;
  }

  public void setContextRoot(String contextRoot) {
    this.contextRoot = contextRoot;
  }

  public String getOriginator() {
    return originator;
  }

  public void setOriginator(String originator) {
    this.originator = originator;
  }

  public String getEnvironment() {
    return environment;
  }

  public void setEnvironment(String environment) {
    this.environment = environment;
  }

  public boolean isRequireHTTPS() {
    return requireHTTPS;
  }

  public void setRequireHTTPS(boolean requireHTTPS) {
    this.requireHTTPS = requireHTTPS;
  }

  public boolean isExternal() {
    return external;
  }

  public void setExternal(boolean external) {
    this.external = external;
  }

  public boolean isWebService() {
    return webService;
  }

  public void setWebService(boolean webService) {
    this.webService = webService;
  }

  public String getAppPortfolioId() {
    return appPortfolioId;
  }

  public void setAppPortfolioId(String appPortfolioId) {
    this.appPortfolioId = appPortfolioId;
  }

  public String getPlatform() {
    return platform;
  }

  public void setPlatform(String platform) {
    this.platform = platform;
  }

  public Boolean getEnabled() {
    return enabled;
  }

  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  public String getAgentType() {
    return agentType;
  }

  public void setAgentType(String agentType) {
    this.agentType = agentType;
  }

  public String getAgent() {
    return agent;
  }

  public void setAgent(String agent) {
    this.agent = agent;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public List<String> getUserDirectories() {
    return userDirectories;
  }

  public void setUserDirectories(List<String> userDirectories) {
    this.userDirectories = userDirectories;
  }

  public List<ResourceTO> getResources() {
    return resources;
  }

  public void setResources(List<ResourceTO> resources) {
    this.resources = resources;
  }

  public List<AuthenticationPolicyTO> getAuthenticationPolicies() {
    return authenticationPolicies;
  }

  public void setAuthenticationPolicy(List<AuthenticationPolicyTO> authenticationPolicies) {
    this.authenticationPolicies = authenticationPolicies;
  }

  public List<AuthorizationPolicyTO> getAuthorizationPolicies() {
    return authorizationPolicies;
  }

  public void setAuthorizationPolicies(List<AuthorizationPolicyTO> authorizationPolicies) {
    this.authorizationPolicies = authorizationPolicies;
  }

  public ApplicationOwner getOwner() {
    return owner;
  }

  public void setOwner(ApplicationOwner owner) {
    this.owner = owner;
  }

  public String getProvider() {
    return provider;
  }

  public void setProvider(String provider) {
    this.provider = provider;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("ApplicationTO [id=");
    builder.append(id);
    builder.append(", name=");
    builder.append(name);
    builder.append(", state=");
    builder.append(state);
    builder.append(", contextRoot=");
    builder.append(contextRoot);
    builder.append(", originator=");
    builder.append(originator);
    builder.append(", environment=");
    builder.append(environment);
    builder.append(", requireHTTPS=");
    builder.append(requireHTTPS);
    builder.append(", external=");
    builder.append(external);
    builder.append(", webService=");
    builder.append(webService);
    builder.append(", appPortfolioId=");
    builder.append(appPortfolioId);
    builder.append(", platform=");
    builder.append(platform);
    builder.append(", enabled=");
    builder.append(enabled);
    builder.append(", agentType=");
    builder.append(agentType);
    builder.append(", agent=");
    builder.append(agent);
    builder.append(", description=");
    builder.append(description);
    builder.append(", userDirectories=");
    builder.append(userDirectories);
    builder.append(", resources=");
    builder.append(resources);
    builder.append(", authenticationPolicies=");
    builder.append(authenticationPolicies);
    builder.append(", authorizationPolicies=");
    builder.append(authorizationPolicies);
    builder.append(", owner=");
    builder.append(owner);
    builder.append(",provider=");
    builder.append(provider);
    builder.append("]");
    return builder.toString();
  }

}
