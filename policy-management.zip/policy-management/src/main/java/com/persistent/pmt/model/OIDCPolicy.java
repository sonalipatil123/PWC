package com.persistent.pmt.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OIDCPolicy {

	private boolean grantAccessSessionRevocationApi;
	private boolean pingAccessLogoutCapable;

	public OIDCPolicy() {
		super();
	}

	public OIDCPolicy(boolean grantAccessSessionRevocationApi, boolean pingAccessLogoutCapable) {
		this.grantAccessSessionRevocationApi = grantAccessSessionRevocationApi;
		this.pingAccessLogoutCapable = pingAccessLogoutCapable;
	}

	public boolean isGrantAccessSessionRevocationApi() {
		return grantAccessSessionRevocationApi;
	}

	public void setGrantAccessSessionRevocationApi(boolean grantAccessSessionRevocationApi) {
		this.grantAccessSessionRevocationApi = grantAccessSessionRevocationApi;
	}

	public boolean isPingAccessLogoutCapable() {
		return pingAccessLogoutCapable;
	}

	public void setPingAccessLogoutCapable(boolean pingAccessLogoutCapable) {
		this.pingAccessLogoutCapable = pingAccessLogoutCapable;
	}

}
