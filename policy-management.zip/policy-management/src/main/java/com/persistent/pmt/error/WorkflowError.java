/**
 * WorkflowError
 * 
 * Error container for Workflow
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.error;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class WorkflowError {

	private String operation;
	private String type;
	private int id;
	private int targetId;
	private String message;
	private String targetName;

	public WorkflowError() {
		super();
	}

	public WorkflowError(String operation, String type, int id, int targetId,
			String message) {
		this.operation = operation;
		this.type = type;
		this.id = id;
		this.targetId = targetId;
		this.message = message;
	}

	public WorkflowError(String operation, String type, int id,
			String targetName, String message) {
		this.operation = operation;
		this.type = type;
		this.id = id;
		this.targetName = targetName;
		this.message = message;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTargetId() {
		return targetId;
	}

	public void setTargetId(int targetId) {
		this.targetId = targetId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Operation:");
		sb.append(operation == null ? " " : operation + ": ");
		sb.append(type);
		sb.append(" (");
		sb.append("id:");
		sb.append(id);
		sb.append(", ");
		// TODO append target Id
		// sb.append("target_id:");
		sb.append(targetId);
		sb.append(")");
		if ("ROLLBACK".equals(operation)) {
			sb.append(": ");
			sb.append("Action: Manual deletion in target required");
		}
		sb.append(": ");
		sb.append(message);

		return sb.toString();
	}

}
