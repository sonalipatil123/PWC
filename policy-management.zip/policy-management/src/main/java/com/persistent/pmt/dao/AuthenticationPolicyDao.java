/**
 * AuthenticationPolicyDao
 * 
 * DAO interface for authentication policy
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.dao;

import com.persistent.pmt.model.AuthenticationPolicy;


public interface AuthenticationPolicyDao {

	AuthenticationPolicy createAuthenticationPolicy(
			AuthenticationPolicy authenticationPolicy);


}
