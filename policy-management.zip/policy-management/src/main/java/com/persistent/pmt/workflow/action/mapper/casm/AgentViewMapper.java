package com.persistent.pmt.workflow.action.mapper.casm;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.casm.PolicyGrammarConstants;
import com.persistent.pmt.dao.AgentDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Agent;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.Resource;
import com.persistent.pmt.service.ServerConfigurationService;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.utils.MapperUtils;
import com.persistent.pmt.view.openam.AgentView;
import com.persistent.pmt.view.openam.Attribute;
import com.persistent.pmt.workflow.action.mapper.GenericMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class AgentViewMapper implements GenericMapper {

  @Autowired
  @Qualifier("serverConfigurationService")
  ServerConfigurationService serverConfigurationService;

  @Autowired
  Environment environment;

  @Autowired
  @Qualifier("agentDao")
  AgentDao agentDao;

  @Override
  public Object getMappedObject(Object object, WorkFlowContext workFlowContext)
      throws GenericException {
    return getAgentViews((Application) object, workFlowContext);
  }

  @Override
  public String getId(Object object) throws GenericException {
    return CommonUtils.formatString(((Agent) object).getName(),
        MapperUtils.getInvalidCharacters());
  }

  private Object getAgentViews(Application application, WorkFlowContext workFlowContext)
      throws GenericException {
    List<AgentView> agentViews = null;

    if (application != null) {
      agentViews = new ArrayList<AgentView>();
      Agent agent = application.getAgent();
      if (PolicyGrammarConstants.AGENT_TYPE_GROUP.equals(agent.getType())) {
        String groupAgents =
            agent
                .getSourceAttributeValueByName(PolicyGrammarConstants.AGENT_ATTRIBUE_GROUP_AGENTS);
        if (groupAgents != null && !groupAgents.isEmpty()) {
          String[] agentNames = groupAgents.split(",");
          List<Agent> agentList =
              agentDao.getAgentListByNames(new ArrayList<String>(Arrays.asList(agentNames)));
          for (Agent groupAgent : agentList) {
            AgentView agentView = getAgentView(application, groupAgent, workFlowContext);
            agentViews.add(agentView);
          }
        }
      }
      else {
        AgentView agentView = getAgentView(application, agent, workFlowContext);
        agentViews.add(agentView);
      }
    }
    return agentViews;
  }

  private AgentView getAgentView(Application application, Agent agent,  WorkFlowContext workFlowContext) throws GenericException {
    AgentView agentView = null;
    if (agent != null) {
      agentView = new AgentView();
      agentView.setId(getId(agent));
      agentView.setUserpassword(getId(agent));
      agentView.setStatus(new Attribute(false, PolicyGrammarConstants.ACTIVE));
      agentView.setPolicyEvaluationApplication(new Attribute(false, CommonUtils.formatString(
          application.getName(), MapperUtils.getInvalidCharacters())));
      List<Resource> resources = application.getResources();
      List<String> notEnforcedUrl = new ArrayList<String>();
      String agentUrl = null;
      String protocol = "http://";
      String fqdnValue;

      String serverUrl =
          serverConfigurationService.getPropertyValue(PolicyGrammarConstants.OPENAM_SERVER_URL);
      agentView.setCdssoUrls(new Attribute(false, new String[] { serverUrl + "cdcservlet" }));
      agentView.setAmLogoutUrl(new Attribute(false, new String[] { serverUrl + "UI/Logout" }));
      agentView.setAmLoginUrl(new Attribute(false, new String[] { serverUrl + "UI/Login" }));
      fqdnValue =
          agent.getSourceAttributeValueByName(PolicyGrammarConstants.AGENT_ATTRIBUE_FQDN);
      if (fqdnValue != null) {
        String[] fqdnValues = fqdnValue.split(",");
        String agentSslPortRegex =
            serverConfigurationService
                .getPropertyValue(PolicyGrammarConstants.AGENT_SSL_PORT_REGEX);
        if (isAgentSecure(fqdnValue, agentSslPortRegex)) {
          protocol = "https://";
        }
        for (Resource resource : resources) {
          if (resource.isAnonymous()) {
            for (String fqdn : fqdnValues) {
              if (PolicyGrammarConstants.DUMMY_FQDN_VALUE.equals(fqdn)) {
                continue;
              }
              notEnforcedUrl.add(protocol + fqdn + resource.getUri());
            }
          }
        }
        agentView.setNotEnforcedUrls(new Attribute(false, notEnforcedUrl));

        if (fqdnValues[0].startsWith("http")) {
          agentUrl = fqdnValues[0];
        }
        else {
          agentUrl = protocol + fqdnValues[0];
        }

        if (!agentUrl.matches("(.*):[0-9][0-9](.*)")) {
          if (agentUrl.endsWith("/")) {
            agentUrl = agentUrl.substring(0, agentUrl.lastIndexOf("/"));
          }
          if (agentUrl.startsWith("http://")) {
            agentUrl = agentUrl + ":80";
          }
          else if (agentUrl.startsWith("https://")) {
            agentUrl = agentUrl + ":443";
          }
        }

        Map<String, String> fqdnMapping = new HashMap<>();
        for (String fqdn : fqdnValues) {
          if (PolicyGrammarConstants.DUMMY_FQDN_VALUE.equals(fqdn)) {
            // Auditing for Dummy FQDN Value
            workFlowContext.getAgentAuditData().append(
                MessageFormat.format(environment
                    .getProperty(AuditPropertyConstants.TARGET_MAPPER_AGENTVIEW_DUMMYVAL),
                    new Object[] { agent.getName(), agent.getId() }));
          }
          fqdnMapping.put(fqdn, protocol + fqdn);
        }
        agentView.setFqdnMapping(new Attribute(false, fqdnMapping));
        String remotelogFile = "";
        if (agentUrl.startsWith("http://")) {
          remotelogFile = agentUrl.substring(7);
        }
        else if (agentUrl.startsWith("https://")) {
          remotelogFile = agentUrl.substring(8);
        }
        agentView.setRemoteLogFilename(new Attribute(false, "amAgent_"
            + remotelogFile.replaceAll("\\.|:", "_") + ".log"));

        if (!agentUrl.endsWith("/")) {
          agentUrl = agentUrl + "/";
        }
        agentView.setAgentUriPrefix(new Attribute(false, agentUrl + "amagent"));
        agentView.setCdssoRootUrl(new Attribute(false, "agentRootURL=" + agentUrl));
        agentView.setFqdnDefault(new Attribute(false, agentUrl));
        agentView.setAgentNotificationUrl(new Attribute(false, agentUrl
            + "UpdateAgentCacheServlet?shortcircuit=false"));
        String agentLogoffUrl =
            agent
                .getSourceAttributeValueByName(PolicyGrammarConstants.AGENT_ATTRIBUE_LOGOFF_URI);
        if (agentLogoffUrl != null) {
          if (agentLogoffUrl.startsWith("/")) {
            agentLogoffUrl = agentLogoffUrl.substring(1);
          }
          agentView.setApplicationLogoutUrls(new Attribute(false, new String[] { agentUrl
              + agentLogoffUrl }));
          agentView.setLogoutRedirectUrl(new Attribute(false, agentUrl));
        }
      }
      Map<String, String> responseAttrMapping = application.getHeaderAndCookieResponseValue();
      // Value of the property is in OpenAM format
      // HTTP_HEADER or HTTP_COOKIE are the openAM values for
      // this parameter.
      String responseAttrFetchMode =
          serverConfigurationService
              .getPropertyValue(PolicyGrammarConstants.RESPONSE_ATTR_FETCH_MODE);
      agentView.setResponseAttributeFetchMode(new Attribute(false, responseAttrFetchMode));
      agentView.setResponseAttributeMap(new Attribute(false, responseAttrMapping));
      agentView.setPolicyEvaluationRealm(new Attribute(false, "/"
          + serverConfigurationService
              .getPropertyValue(PolicyGrammarConstants.AGENT_POLICY_EVALUATION_REALM)));
    }
    return agentView;
  }

  private boolean isAgentSecure(String fqdnValue, String agentSslPortRegex) {
    return fqdnValue.matches(agentSslPortRegex);
  }
}
