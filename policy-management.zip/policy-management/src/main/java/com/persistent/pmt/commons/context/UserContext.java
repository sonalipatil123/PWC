package com.persistent.pmt.commons.context;

import java.util.HashMap;
import java.util.Map;

import com.persistent.pmt.model.User;

public class UserContext {

	public static final String USER = "user";
	private Map<String, User> userContextMap;

	public UserContext() {
		userContextMap = new HashMap<String, User>();
	}

	public void setUser(String userKey, User user) {
		this.userContextMap.put(userKey, user);
	}

	public User getUser(String userKey) {
		return this.userContextMap.get(userKey);
	}

}
