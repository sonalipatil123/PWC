package com.persistent.pmt.executor.openam.impl;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.executor.openam.ModuleExecutor;
import com.persistent.pmt.response.DeleteResponseView;
import com.persistent.pmt.response.TargetResponse;
import com.persistent.pmt.response.openam.AnonymousModuleResponse;
import com.persistent.pmt.response.openam.CertificateModuleResponse;
import com.persistent.pmt.response.openam.HttpBasicModuleResponse;
import com.persistent.pmt.response.openam.LDAPModuleResponse;
import com.persistent.pmt.response.openam.LegacyOAuth2OpenIDConnectModuleResponse;
import com.persistent.pmt.response.openam.OpenIDConnectIdTokenBearerModuleResponse;
import com.persistent.pmt.response.openam.SAML2ModuleResponse;
import com.persistent.pmt.response.openam.WindowsDesktopSsoResponse;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.utils.EndPointUtils;
import com.persistent.pmt.view.TargetView;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component("openAMModuleExecutor")
public class ModuleExecutorImpl implements ModuleExecutor {

  @Autowired
  RestTemplate restTemplate;

  @Override
  public TargetResponse get(Object object, Product product, Artifact artifact,
      HashMap<String, String> params, WorkFlowContext context) {
    TargetResponse targetResponse = null;
    if (params != null) {
      String url =
          EndPointUtils.getEndPoint(product, artifact, HttpMethod.GET, context, params);
      HttpHeaders headers = CommonUtils.getHeaders(context, product, HttpMethod.GET);
      HttpEntity<?> entity = new HttpEntity<>(headers);

      Class<?> responseClass = getResponseClass(artifact);
      ResponseEntity<?> response = null;
      try {
        response = restTemplate.exchange(url, HttpMethod.GET, entity, responseClass);
      }
      catch (HttpClientErrorException httpClientErrorException) {
        if (!httpClientErrorException.getStatusCode().equals(HttpStatus.NOT_FOUND)) {
          throw httpClientErrorException;
        }
      }
      if (response != null && response.getStatusCode().equals(HttpStatus.OK))
        targetResponse = (TargetResponse) response.getBody();
    }
    return targetResponse;
  }

  @Override
  public void create(Object object, TargetView targetView, Product product, Artifact artifact,
      HashMap<String, String> params, WorkFlowContext context) {
    if (targetView != null && params != null) {
      String url =
          EndPointUtils.getEndPoint(product, artifact, HttpMethod.PUT, context, params);

      HttpHeaders headers = CommonUtils.getHeaders(context, product, HttpMethod.PUT);
      HttpEntity<TargetView> entity = new HttpEntity<>(targetView, headers);

      Class<?> responseClass = getResponseClass(artifact);

      ResponseEntity<?> response =
          restTemplate.exchange(url, HttpMethod.PUT, entity, responseClass);

      if (response != null && response.getStatusCode().equals(HttpStatus.OK)) {
        // application.setTargetId(response.getBody().get_id());
      }
    }
  }

  @Override
  public TargetResponse update(Object object, TargetView targetView, Product product,
      Artifact artifact, HashMap<String, String> params, WorkFlowContext context) {
    return null;
  }

  @Override
  public void delete(Object object, Product product, Artifact artifact,
      HashMap<String, String> params, WorkFlowContext context) {

    if (params != null) {
      String url =
          EndPointUtils.getEndPoint(product, artifact, HttpMethod.DELETE, context, params);

      HttpHeaders headers = CommonUtils.getHeaders(context, product, HttpMethod.DELETE);
      HttpEntity<?> entity = new HttpEntity<>(headers);
      restTemplate.exchange(url, HttpMethod.DELETE, entity, DeleteResponseView.class);
    }

  }

  @SuppressWarnings("rawtypes")
  private Class getResponseClass(Artifact artifact) {

    Class responseClass = null;
    if (artifact.equals(Artifact.MODULE_ANONYMOUS)) {
      responseClass = AnonymousModuleResponse.class;
    }
    else if (artifact.equals(Artifact.MODULE_LDAP)) {
      responseClass = LDAPModuleResponse.class;
    }
    else if (artifact.equals(Artifact.MODULE_CERT)) {
      responseClass = CertificateModuleResponse.class;
    }
    else if (artifact.equals(Artifact.MODULE_SAML)) {
      responseClass = SAML2ModuleResponse.class;
    }
    else if (artifact.equals(Artifact.MODULE_OAUTH2)) {
      responseClass = LegacyOAuth2OpenIDConnectModuleResponse.class;
    }
    else if (artifact.equals(Artifact.MODULE_OPENID_CONNECT)) {
      responseClass = OpenIDConnectIdTokenBearerModuleResponse.class;
    }
    else if (artifact.equals(Artifact.MODULE_WIN_DESKTOP_SSO)) {
      responseClass = WindowsDesktopSsoResponse.class;
    }
    else if (artifact.equals(Artifact.MODULE_HTTP_BASIC)) {
      responseClass = HttpBasicModuleResponse.class;
    }
    return responseClass;
  }
}