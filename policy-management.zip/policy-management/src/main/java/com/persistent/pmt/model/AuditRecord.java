package com.persistent.pmt.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * AuditRecord
 * 
 * Entity model for Audit Record
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "AUDIT_RECORD")
public class AuditRecord {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "PROCESS_ID")
	private String processId;

	@Column(name = "VERSION")
	private Long version;

	@Enumerated(EnumType.STRING)
	@Column(name = "ACTION")
	private ACTIONS action;

	@Column(name = "DATA")
	private String data;

	@Column(name = "MANAGED_BY")
	private String managedBy;

	@Column(name = "MANAGED_ON")
	private Timestamp managedOn;

	@Column(name = "CONTEXT")
	private String context;

	@ManyToOne
	@JoinColumn(name = "ENVIRONMENT_ID")
	private Environment environment;

	@Column(name = "STATUS")
	private String status;

	public AuditRecord() {

	}

	public AuditRecord(long version, ACTIONS action, String changeHistoryMessage, String managedBy, Timestamp timestamp,
			String processId, Environment environment, String context, String status) {
		this.version = version;
		this.action = action;
		this.data = changeHistoryMessage;
		this.managedBy = managedBy;
		this.managedOn = timestamp;
		this.processId = processId;
		this.environment = environment;
		this.context = context;
		this.status = status;
	}

	public AuditRecord(ACTIONS action, String changeHistoryMessage, String managedBy, Timestamp timestamp,
			String processId, Environment environment, String context, String status) {
		this.action = action;
		this.data = changeHistoryMessage;
		this.managedBy = managedBy;
		this.managedOn = timestamp;
		this.processId = processId;
		this.environment = environment;
		this.context = context;
		this.status = status;
	}

	public enum ACTIONS {
		IMPORT, PROVISION, IMPORT_ALL, COMBINED
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public ACTIONS getAction() {
		return action;
	}

	public void setAction(ACTIONS action) {
		this.action = action;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getManagedBy() {
		return managedBy;
	}

	public void setManagedBy(String managedBy) {
		this.managedBy = managedBy;
	}

	public Timestamp getManagedOn() {
		return managedOn;
	}

	public void setManagedOn(Timestamp managedOn) {
		this.managedOn = managedOn;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setVersion(Long version) {
		this.version = version;
	}
}
