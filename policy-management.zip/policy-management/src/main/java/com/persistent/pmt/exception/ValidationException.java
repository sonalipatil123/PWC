/**
 * ValidationException
 * 
 * Exception class for data validations
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.exception;

import org.springframework.validation.BindingResult;

public class ValidationException extends Exception {

	private static final long serialVersionUID = 1L;

	private BindingResult result;

	public ValidationException() {
		super();
	}

	public ValidationException(BindingResult result) {
		this.result = result;
	}

	public BindingResult getResult() {
		return result;
	}

	public void setResult(BindingResult result) {
		this.result = result;
	}

}
