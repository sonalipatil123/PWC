package com.persistent.pmt.dao;

import java.util.List;

import com.persistent.pmt.model.Agent;

/**
 * AgentDao Interface
 * 
 * @author Persistent Systems
 */
public interface AgentDao {

  public Agent createAgent(Agent testAgent);
  
  public List<Agent> getAgentsByName(String name, String envName);
  
  public List<Agent> getAgentListByNames(List<String> agentNames);

}
