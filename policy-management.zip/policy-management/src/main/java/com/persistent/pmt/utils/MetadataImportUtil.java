package com.persistent.pmt.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;

import com.persistent.pmt.constant.MapperConstants;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.response.GenericResponse;

public class MetadataImportUtil {
  @Autowired
  Environment environment;


	public static String readProviderMetadata(String providerName) throws GenericException {
		String metadataString = null;
    MetadataImportUtil metadataImportUtil = new MetadataImportUtil();
    String basePath =
        metadataImportUtil.environment.getProperty(MapperConstants.PROPERTY_CASM_XML_BASE_PATH);
    String metadata = basePath + "metadata";
		File fileBasePath = new File(basePath);
		File fileMetadata = new File(metadata);

    if (fileBasePath.isDirectory()) {
      if (fileMetadata.exists()) {
        File xml = new File(metadata + "\\" + providerName + ".xml");
        if (xml.exists()) {
          try {
            metadataString = FileUtils.readFileToString(xml);
          }
          catch (IOException e) {
            throw new GenericException("Unable to read metadata file. ",
                HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
          }
        }
      }

    }
    if (null == metadataString) {
      throw new GenericException("Metadata file does not exist or is empty.",
          HttpStatus.NOT_FOUND.value(), GenericResponse.FAILURE);
    }
    return metadataString;
  }

}
