/**
 * 
 * @author akriti
 */

package com.persistent.pmt.executor;

import java.util.HashMap;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.response.TargetResponse;
import com.persistent.pmt.view.TargetView;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public interface ArtifactExecutor {

  public TargetResponse get(Object object, Product product, Artifact artifact,
      HashMap<String, String> params, WorkFlowContext context);

  public void create(Object object, TargetView targetView, Product product,
      Artifact artifact, HashMap<String, String> params, WorkFlowContext context);

  public TargetResponse update(Object object, TargetView targetView, Product product,
      Artifact artifact, HashMap<String, String> params, WorkFlowContext context);

  public void delete(Object object, Product product, Artifact artifact,
      HashMap<String, String> params, WorkFlowContext context);

}
