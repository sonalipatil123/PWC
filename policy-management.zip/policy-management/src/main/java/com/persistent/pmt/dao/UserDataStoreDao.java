package com.persistent.pmt.dao;

import com.persistent.pmt.model.UserDataStore;

/**
 * UserDataStoreDao Interface
 * 
 * @author Persistent Systems
 */
public interface UserDataStoreDao {

  public UserDataStore createUserDataStore(UserDataStore userDataStore);

}
