package com.persistent.pmt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * Environment
 * 
 * Entity model for Environment
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "environment")
public class Environment {

	@Id
//	@GenericGenerator(name = "environment_generator", strategy = "increment")
//	@GeneratedValue(generator = "environment_generator")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	public Environment() {
		super();
	}

	public Environment(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Environment [id=" + id + ", name=" + name + "]";
	}

}
