package com.persistent.pmt.constant.casm;

import java.util.HashMap;
import java.util.Map;

/**
 * There is an instance defined for each type which has numeric
 * BitMappings.
 */
public enum BitMappingEnum {

  ADMIN_RIGHTS(new int[] { 0, 1, 2, 4, 8, 16, 32, 47, 64 }, "none", "ManageAllDomains",
      "ManageObjects", "ManageUsers", "ManageSecurity", "CacheManager", "RegisterTrustedHosts",
      "ManageEverything", "AccessSharedDB"),

  DOMAIN_MODE(new int[] { 0, 1, 2, 4, 8 }, "Default", "Hidden", "GlobalPoliciesApply", "Global",
      "Administration"),

  LOCAL_AUTHENTICATION_TYPE(new int[] { 1, 2 }, "Basic", "Form"),

  SIGNATURE_ALGO(new int[] { 1, 2 }, "RSAwithSHA1", "RSAwithSHA256"),

  STATUS(new int[] { 1, 2, 3, 4 }, "Incomplete", "Defined", "Active", "Inactive"),

  ARTIFACT_SIGNING_OPTION(new int[] { 0, 1, 2, 3 }, "SignAssertion", "SignResponse", "SignBoth",
      "SignNeither"),

  POST_SIGNING_OPTION(new int[] { 0, 1, 2 }, "SignAssertion", "SignResponse", "SignBoth"),

  DELEGATED_AUTH_TYPE(new int[] { 1, 2, 3, 4 }, "Cookie", "Query", "OpenCookie", "Cloud"),

  SLO_SOAP_SIGN_OPTION(new int[] { 0, 1, 2, 3 }, "SignLogoutRequest", "SignLogoutResponse",
      "SignBoth", "SignNeither"),

  // Defined in OpenAM. Ignoring
  // AUTHENTICATION_LEVEL(new int[] {}, ""),

  SESSION_NOT_ON_OR_AFTER_TYPE(new int[] { 0, 1, 2, 3 }, "AssertionValidity", "Omit",
      "IDPTimeout", "Custom"),

  AUTHN_CONTEXT_TYPE(new int[] { 1, 2 }, "Static", "Automatic"),

  ALLOW_TRANSACTION_TYPE(new int[] { 1, 2, 3 }, "AllowIDP", "AllowSP", "AllowBoth"),

  AUTHENTICATION_TYPE(new int[] { 1, 2 }, "Local", "Delegated"),

  USERDIRECTORY_SEARCHSCOPE(new int[] { 0, 1, 2 }, "Base", "OneLevel", "SubTree"),

  AUTHSCHEME_TYPE(new int[] { 1, 4, 9, 13, 14, 15, 16, 19, 20, 29, 30 }, "Basic", "HTMLForm",
      "X509Cert", "Anonymous", "NTLM", "Custom", "HTMLFormACE", "X509CertOrForm",
      "X509CertAndForm", "SAML2", "WSFED"),

  AGENTTYPE_VENDORTYPE(new int[] { 0, 1 }, "RADIUS", "WebAgent"),

  USERPOLICY_RESOLUTIONTYPE(new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 }, "Unknown",
      "SUBJECT_USER", "SUBJECT_GROUP", "ENVIRONMENT_LDAP_FILTER", "UserRole",
      "ENVIRONMENT_LDAP_FILTER", "Query", "SUBJECT_ALL",
      "GroupProp", "SUBJECT_GROUP", "DnProp", "IMSUserPolicy", "IMS", "IPAddress"),

  USERPOLICY_NAME(new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 }, "Unknown",
      "User", "Group", "LdapFilter", "UserRole",
      "LdapFilter", "Query", "All", "GroupProp", "Group", "DnProp",
      "IMSUserPolicy", "IMS"),

  USERPOLICY_POLICYFLAGS(new int[] { 0, 1, 2, 4 }, "Default", "Exclude", "Recursive", "AND");

  private Map<Integer, String> map = new HashMap<>();

  private BitMappingEnum(int[] keys, String... values) {

    int i = 0;
    for (String value : values) {
      map.put(keys[i], value);
      i++;
    }
  }

  /**
   * @param key
   * @return mapped String value to bit number
   */
  public String getBitMapValue(Integer key) {
    return map.get(key);
  }

}
