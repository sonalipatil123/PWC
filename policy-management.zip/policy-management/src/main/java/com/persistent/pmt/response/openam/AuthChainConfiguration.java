package com.persistent.pmt.response.openam;

import com.persistent.pmt.response.TargetResponse;

public class AuthChainConfiguration implements TargetResponse {

	private String module;
	private String criteria;
	private String options;

	public AuthChainConfiguration() {
		super();
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

}
