package com.persistent.pmt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * AuthorizationPolicyAttribute
 * 
 * Entity model for AuthorizationPolicyAttribute
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "authorization_policy_attribute")
public class AuthorizationPolicyAttribute {


	@JsonIgnore
	@Id
//	@SequenceGenerator(name = "SEQ_AUTHZ_POLICY_ATTR", sequenceName = "SEQ_AUTHZ_POLICY_ATTR", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_AUTHZ_POLICY_ATTR")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "condition_type")
	private String conditionType;

	@Column(name = "condition_value")
	private String conditionValue;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "auth_policy_id")
	private AuthorizationPolicy authorizationPolicy;

	@Column(name = "negate")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean negate;

  @Transient
  private String policyFlag;

	public AuthorizationPolicyAttribute() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getConditionType() {
		return conditionType;
	}

	public void setConditionType(String conditionType) {
		this.conditionType = conditionType;
	}

	public String getConditionValue() {
		return conditionValue;
	}

	public void setConditionValue(String conditionValue) {
		this.conditionValue = conditionValue;
	}

	public AuthorizationPolicy getAuthorizationPolicy() {
		return authorizationPolicy;
	}

	public void setAuthorizationPolicy(AuthorizationPolicy authorizationPolicy) {
		this.authorizationPolicy = authorizationPolicy;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isNegate() {
		return negate;
	}

	public void setNegate(boolean negate) {
		this.negate = negate;
	}

  public String getPolicyFlag() {
    return policyFlag;
  }

  public void setPolicyFlag(String policyFlag) {
    this.policyFlag = policyFlag;
  }

}
