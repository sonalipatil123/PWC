package com.persistent.pmt.model;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * ClientAuth
 * 
 * Entity model for ClientAuth
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientAuth {

	private String type;
	private String secret;
	private String encryptedSecret;

	public ClientAuth() {
		super();
	}

	public ClientAuth(String type, String secret) {
		this.type = type;
		this.secret = secret;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}

	public String getEncryptedSecret() {
		return encryptedSecret;
	}

	public void setEncryptedSecret(String encryptedSecret) {
		this.encryptedSecret = encryptedSecret;
	}

}
