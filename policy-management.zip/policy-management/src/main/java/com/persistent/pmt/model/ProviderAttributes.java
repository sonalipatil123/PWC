package com.persistent.pmt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * ProviderAttributes
 * 
 * Entity model for ProviderAttributes
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "provider_attributes")
public class ProviderAttributes {

  @JsonIgnore
  @Id
//  @SequenceGenerator(name = "SEQ_PROVIDER_ATTRIBUTE", sequenceName = "SEQ_PROVIDER_ATTRIBUTE", allocationSize = 1)
//  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_PROVIDER_ATTRIBUTE")
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "id")
  private int id;

  @Column(name = "source_attr_name")
  private String sourceAttrName;

  @Lob
  @Column(name = "source_attr_value", columnDefinition = "CLOB")
  private String sourceAttrValue;

  @Column(name = "target_attr_name")
  private String targetAttrName;

  @Column(name = "target_attr_value")
  private String targetAttrValue;

  //@JsonIgnore
  @ManyToOne
  @JoinColumn(name = "provider_id")
  private Provider provider;

  public ProviderAttributes() {
    super();
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getSourceAttrName() {
    return sourceAttrName;
  }

  public void setSourceAttrName(String sourceAttrName) {
    this.sourceAttrName = sourceAttrName;
  }

  public String getSourceAttrValue() {
    return sourceAttrValue;
  }

  public void setSourceAttrValue(String sourceAttrValue) {
    this.sourceAttrValue = sourceAttrValue;
  }

  public String getTargetAttrName() {
    return targetAttrName;
  }

  public void setTargetAttrName(String targetAttrName) {
    this.targetAttrName = targetAttrName;
  }

  public String getTargetAttrValue() {
    return targetAttrValue;
  }

  public void setTargetAttrValue(String targetAttrValue) {
    this.targetAttrValue = targetAttrValue;
  }
  
  public Provider fetchProvider() {
	  return provider;
  }

}
