package com.persistent.pmt.response;

import java.util.Iterator;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.ResourceSupport;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

public class PageResource<T> extends ResourceSupport implements Page<T> {

	private final Page<T> page;
	private String message;
	private String status;
	private int statusCode;

	public PageResource(Page<T> page, String pageParam, String sizeParam,
			String message, String status, int statusCode) {
		super();
		this.page = page;
		this.message = message;
		this.status = status;
		this.statusCode = statusCode;
		addPreviousLink(page, pageParam, sizeParam);
		addNextLink(page, pageParam, sizeParam);
		addFirstLink(page, pageParam, sizeParam);
		addLastLink(page, pageParam, sizeParam);
	}

	private void addPreviousLink(Page<T> page, String pageParam,
			String sizeParam) {
		if (page.hasPrevious()) {
			Link link = buildPageLink(pageParam, page.getNumber() - 1,
					sizeParam, page.getSize(), Link.REL_PREVIOUS);
			add(link);
		}
	}

	private void addNextLink(Page<T> page, String pageParam, String sizeParam) {
		if (page.hasNext()) {
			Link link = buildPageLink(pageParam, page.getNumber() + 1,
					sizeParam, page.getSize(), Link.REL_NEXT);
			add(link);
		}
	}

	private void addFirstLink(Page<T> page, String pageParam, String sizeParam) {
		if (!page.isFirst()) {
			Link link = buildPageLink(pageParam, 1, sizeParam, page.getSize(),
					Link.REL_FIRST);
			add(link);
		}
	}

	private void addLastLink(Page<T> page, String pageParam, String sizeParam) {
		if (!page.isLast()) {
			int pageNumber = (page.getTotalPages() > 0) ? page.getTotalPages()
					: 0;
			Link link = buildPageLink(pageParam, pageNumber, sizeParam,
					page.getSize(), Link.REL_LAST);
			add(link);
		}
	}

	private Link buildPageLink(String pageParam, int page, String sizeParam,
			int size, String rel) {
		String path = createBuilder().replaceQueryParam(pageParam, page)
				.replaceQueryParam(sizeParam, size).build().toUriString();
		return new Link(path, rel);
	}

	private ServletUriComponentsBuilder createBuilder() {
		return ServletUriComponentsBuilder.fromCurrentRequest();
	}

	@Override
	public List<T> getContent() {
		return page.getContent();
	}

	@Override
	public int getNumber() {
		return page.getNumber();
	}

	@Override
	public int getNumberOfElements() {
		return page.getNumberOfElements();
	}

	@Override
	public int getSize() {
		return page.getSize();
	}

	@Override
	public Sort getSort() {
		return page.getSort();
	}

	@Override
	public boolean hasContent() {
		return page.hasContent();
	}

	@Override
	public boolean hasNext() {
		return page.hasNext();
	}

	@Override
	public boolean hasPrevious() {
		return page.hasPrevious();
	}

	@Override
	public boolean isFirst() {
		return page.isFirst();
	}

	@Override
	public boolean isLast() {
		return page.isLast();
	}

	@Override
	public Pageable nextPageable() {
		return page.nextPageable();
	}

	@Override
	public Pageable previousPageable() {
		return page.previousPageable();
	}

	@Override
	public Iterator<T> iterator() {
		return page.iterator();
	}

	@Override
	public long getTotalElements() {
		return page.getTotalElements();
	}

	@Override
	public int getTotalPages() {
		return page.getTotalPages();
	}

	@Override
	public <S> Page<S> map(Converter<? super T, ? extends S> arg0) {
		return page.map(arg0);
	}

	public String getMessage() {
		return message;
	}

	public String getStatus() {
		return status;
	}

	public int getStatusCode() {
		return statusCode;
	}
}
