package com.persistent.pmt.constant;

public enum ApplicationFilter {

	NAME("name"), STATE("state"), PLATFORM("platform"), ENVIRONMENT("environment"), ENABLED("enabled"), EXTERNAL("external");
	
	private final String value;

	private ApplicationFilter(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
