package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.view.TargetView;

@JsonInclude(Include.NON_NULL)
public class OAuth2ClientView implements TargetView {

  @JsonIgnore
  private String id;
  private CoreOAuth2ClientConfig coreOAuth2ClientConfig;
  private AdvancedOAuth2ClientConfig advancedOAuth2ClientConfig;
  private CoreOpenIDClientConfig coreOpenIDClientConfig;
  private CoreUmaClientConfig coreUmaClientConfig;
  private SignEncOAuth2ClientConfig signEncOAuth2ClientConfig;

  public OAuth2ClientView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public CoreOAuth2ClientConfig getCoreOAuth2ClientConfig() {
    return this.coreOAuth2ClientConfig;
  }

  public void setCoreOAuth2ClientConfig(CoreOAuth2ClientConfig coreOAuth2ClientConfig) {
    this.coreOAuth2ClientConfig = coreOAuth2ClientConfig;
  }

  public AdvancedOAuth2ClientConfig getAdvancedOAuth2ClientConfig() {
    return this.advancedOAuth2ClientConfig;
  }

  public void setAdvancedOAuth2ClientConfig(
      AdvancedOAuth2ClientConfig advancedOAuth2ClientConfig) {
    this.advancedOAuth2ClientConfig = advancedOAuth2ClientConfig;
  }

  public CoreOpenIDClientConfig getCoreOpenIDClientConfig() {
    return this.coreOpenIDClientConfig;
  }

  public void setCoreOpenIDClientConfig(CoreOpenIDClientConfig coreOpenIDClientConfig) {
    this.coreOpenIDClientConfig = coreOpenIDClientConfig;
  }

  public SignEncOAuth2ClientConfig getSignEncOAuth2ClientConfig() {
    return this.signEncOAuth2ClientConfig;
  }

  public void setSignEncOAuth2ClientConfig(SignEncOAuth2ClientConfig signEncOAuth2ClientConfig) {
    this.signEncOAuth2ClientConfig = signEncOAuth2ClientConfig;
  }

  public CoreUmaClientConfig getCoreUmaClientConfig() {
    return this.coreUmaClientConfig;
  }

  public void setCoreUmaClientConfig(CoreUmaClientConfig coreUmaClientConfig) {
    this.coreUmaClientConfig = coreUmaClientConfig;
  }

  @Override
  public String toString() {
    return "OAuth2ClientView [id=" + id + ", coreOAuth2ClientConfig=" + coreOAuth2ClientConfig
        + ", advancedOAuth2ClientConfig=" + advancedOAuth2ClientConfig
        + ", coreOpenIDClientConfig=" + coreOpenIDClientConfig + ", coreUmaClientConfig="
        + coreUmaClientConfig + ", signEncOAuth2ClientConfig=" + signEncOAuth2ClientConfig
        + "]";
  }

}