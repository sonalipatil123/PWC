package com.persistent.pmt.to.openam;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationSummaryTO {

	private List<Map<String, String>> applications;

	public ApplicationSummaryTO() {
		super();
	}

	@JsonProperty("applications")
	public List<Map<String, String>> getApplications() {
		return applications;
	}

	public void setApplications(List<Map<String, String>> applications) {
		this.applications = applications;
	}

}
