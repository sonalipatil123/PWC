package com.persistent.pmt.response.openam;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude
public class CertificateModuleResponse implements ModuleResponse {

	private String authenticationLevel;
	private String otherCertificateAttributeToProfileMapping;
	private String crlMatchingCertificateAttribute;
	private String ldapCertificateAttribute;
	private String[] certificateLdapServers;
	private String crlHttpParameters;
	private String clientCertificateHttpHeaderName;
	private String cacheCRLsInMemory;
	private String[] trustedRemoteHosts;
	private String matchCertificateToCRL;
	private String updateCRLsFromDistributionPoint;
	private String userBindPassword;
	private String matchCACertificateToCRL;
	private String sslEnabled;
	private String ocspValidationEnabled;
	private String certificateAttributeToProfileMapping;
	private String userBindDN;
	@JsonProperty("iplanet-am-auth-cert-gw-cert-preferred")
	private String iplanetAmAuthCertGwCertPreferred;
	private String certificateAttributeProfileMappingExtension;
	private String matchCertificateInLdap;
	private String[] ldapSearchStartDN;
	private String _rev;
	private Type _type;
	private String _id;

	public CertificateModuleResponse() {
		super();
	}

	public String getAuthenticationLevel() {
		return authenticationLevel;
	}

	public void setAuthenticationLevel(String authenticationLevel) {
		this.authenticationLevel = authenticationLevel;
	}

	public String getOtherCertificateAttributeToProfileMapping() {
		return otherCertificateAttributeToProfileMapping;
	}

	public void setOtherCertificateAttributeToProfileMapping(
			String otherCertificateAttributeToProfileMapping) {
		this.otherCertificateAttributeToProfileMapping = otherCertificateAttributeToProfileMapping;
	}

	public String getCrlMatchingCertificateAttribute() {
		return crlMatchingCertificateAttribute;
	}

	public void setCrlMatchingCertificateAttribute(
			String crlMatchingCertificateAttribute) {
		this.crlMatchingCertificateAttribute = crlMatchingCertificateAttribute;
	}

	public String getLdapCertificateAttribute() {
		return ldapCertificateAttribute;
	}

	public void setLdapCertificateAttribute(String ldapCertificateAttribute) {
		this.ldapCertificateAttribute = ldapCertificateAttribute;
	}

	public String[] getCertificateLdapServers() {
		return certificateLdapServers;
	}

	public void setCertificateLdapServers(String[] certificateLdapServers) {
		this.certificateLdapServers = certificateLdapServers;
	}

	public String getCrlHttpParameters() {
		return crlHttpParameters;
	}

	public void setCrlHttpParameters(String crlHttpParameters) {
		this.crlHttpParameters = crlHttpParameters;
	}

	public String getClientCertificateHttpHeaderName() {
		return clientCertificateHttpHeaderName;
	}

	public void setClientCertificateHttpHeaderName(
			String clientCertificateHttpHeaderName) {
		this.clientCertificateHttpHeaderName = clientCertificateHttpHeaderName;
	}

	public String getCacheCRLsInMemory() {
		return cacheCRLsInMemory;
	}

	public void setCacheCRLsInMemory(String cacheCRLsInMemory) {
		this.cacheCRLsInMemory = cacheCRLsInMemory;
	}

	public String[] getTrustedRemoteHosts() {
		return trustedRemoteHosts;
	}

	public void setTrustedRemoteHosts(String[] trustedRemoteHosts) {
		this.trustedRemoteHosts = trustedRemoteHosts;
	}

	public String getMatchCertificateToCRL() {
		return matchCertificateToCRL;
	}

	public void setMatchCertificateToCRL(String matchCertificateToCRL) {
		this.matchCertificateToCRL = matchCertificateToCRL;
	}

	public String getUpdateCRLsFromDistributionPoint() {
		return updateCRLsFromDistributionPoint;
	}

	public void setUpdateCRLsFromDistributionPoint(
			String updateCRLsFromDistributionPoint) {
		this.updateCRLsFromDistributionPoint = updateCRLsFromDistributionPoint;
	}

	public String getUserBindPassword() {
		return userBindPassword;
	}

	public void setUserBindPassword(String userBindPassword) {
		this.userBindPassword = userBindPassword;
	}

	public String getMatchCACertificateToCRL() {
		return matchCACertificateToCRL;
	}

	public void setMatchCACertificateToCRL(String matchCACertificateToCRL) {
		this.matchCACertificateToCRL = matchCACertificateToCRL;
	}

	public String getSslEnabled() {
		return sslEnabled;
	}

	public void setSslEnabled(String sslEnabled) {
		this.sslEnabled = sslEnabled;
	}

	public String getOcspValidationEnabled() {
		return ocspValidationEnabled;
	}

	public void setOcspValidationEnabled(String ocspValidationEnabled) {
		this.ocspValidationEnabled = ocspValidationEnabled;
	}

	public String getCertificateAttributeToProfileMapping() {
		return certificateAttributeToProfileMapping;
	}

	public void setCertificateAttributeToProfileMapping(
			String certificateAttributeToProfileMapping) {
		this.certificateAttributeToProfileMapping = certificateAttributeToProfileMapping;
	}

	public String getUserBindDN() {
		return userBindDN;
	}

	public void setUserBindDN(String userBindDN) {
		this.userBindDN = userBindDN;
	}

	public String getIplanetAmAuthCertGwCertPreferred() {
		return iplanetAmAuthCertGwCertPreferred;
	}

	public void setIplanetAmAuthCertGwCertPreferred(
			String iplanetAmAuthCertGwCertPreferred) {
		this.iplanetAmAuthCertGwCertPreferred = iplanetAmAuthCertGwCertPreferred;
	}

	public String getCertificateAttributeProfileMappingExtension() {
		return certificateAttributeProfileMappingExtension;
	}

	public void setCertificateAttributeProfileMappingExtension(
			String certificateAttributeProfileMappingExtension) {
		this.certificateAttributeProfileMappingExtension = certificateAttributeProfileMappingExtension;
	}

	public String getMatchCertificateInLdap() {
		return matchCertificateInLdap;
	}

	public void setMatchCertificateInLdap(String matchCertificateInLdap) {
		this.matchCertificateInLdap = matchCertificateInLdap;
	}

	public String[] getLdapSearchStartDN() {
		return ldapSearchStartDN;
	}

	public void setLdapSearchStartDN(String[] ldapSearchStartDN) {
		this.ldapSearchStartDN = ldapSearchStartDN;
	}

	public String get_rev() {
		return _rev;
	}

	public void set_rev(String _rev) {
		this._rev = _rev;
	}

	public Type get_type() {
		return _type;
	}

	public void set_type(Type _type) {
		this._type = _type;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

}
