package com.persistent.pmt.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.dao.ServerConfigurationDao;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.model.PropertyStore;

/**
 * ServerConfigurationDaoImpl
 * 
 * @author Persistent Systems
 */
@PropertySource(value = { "classpath:application.properties" })
@Repository("serverConfigurationDao")
@Transactional
public class ServerConfigurationDaoImpl extends BaseDaoImpl implements ServerConfigurationDao {
	public static final String IMPORT_STATUS_IMPORTING = "IMPORTING";

  @SuppressWarnings("unchecked")
  @Override
  public List<PropertyStore> getProperties(int environment) {

    Criteria criteria = createCriteria(PropertyStore.class);
    criteria.add(Restrictions.eq("environment", environment));
    criteria.addOrder(Order.desc("key"));

    return (List<PropertyStore>) criteria.list();

  }

  @SuppressWarnings("unchecked")
  @Override
  public List<PropertyStore> getProperties() {
    Criteria criteria = createCriteria(PropertyStore.class);
    criteria.addOrder(Order.desc("key"));

    return (List<PropertyStore>) criteria.list();
  }

  @Override
  public PropertyStore getPropertyValue(String propertyName, int environment) {

    Criteria criteria = createCriteria(PropertyStore.class);
    criteria.add(Restrictions.eq("environment", environment));
    criteria.add(Restrictions.eq("key", propertyName));

    return (PropertyStore) criteria.uniqueResult();
  }

  @Override
  public void createProperty(PropertyStore property) {

    getSession().save(property);
    
  }
  
  @Override
  public void updateProperty(PropertyStore property) {

    getSession().saveOrUpdate(property);
   
  }

  @SuppressWarnings("unchecked")
  @Override
  public List<String> getLifeCycle() {

    Criteria criteria = createCriteria(Environment.class);
    criteria.setProjection(Projections.property("name"));
    return criteria.list();
  }

	@SuppressWarnings("unchecked")
	@Override
	public List<PropertyStore> checkOtherImportInProgress(String propertyName) {
		Criteria criteria = createCriteria(PropertyStore.class);
		criteria.add(Restrictions.eq("key", propertyName))
				.add(Restrictions.eq("value", IMPORT_STATUS_IMPORTING));
		return criteria.list();

	}

}
