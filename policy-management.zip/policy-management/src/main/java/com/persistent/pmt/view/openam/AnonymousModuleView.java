package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class AnonymousModuleView implements ModuleView {

  @JsonIgnore
  private String id;
	private int authenticationLevel;
	private String defaultAnonymousUsername;
	private String[] validAnonymousUsers;
	private boolean caseSensitiveUsernameMatchingEnabled;

	public AnonymousModuleView() {
		super();
	}

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

	public int getAuthenticationLevel() {
		return authenticationLevel;
	}

	public void setAuthenticationLevel(int authenticationLevel) {
		this.authenticationLevel = authenticationLevel;
	}

	public String getDefaultAnonymousUsername() {
		return defaultAnonymousUsername;
	}

	public void setDefaultAnonymousUsername(String defaultAnonymousUsername) {
		this.defaultAnonymousUsername = defaultAnonymousUsername;
	}

	public String[] getValidAnonymousUsers() {
		return validAnonymousUsers;
	}

	public void setValidAnonymousUsers(String[] validAnonymousUsers) {
		this.validAnonymousUsers = validAnonymousUsers;
	}

	public boolean getCaseSensitiveUsernameMatchingEnabled() {
		return caseSensitiveUsernameMatchingEnabled;
	}

	public void setCaseSensitiveUsernameMatchingEnabled(
			boolean caseSensitiveUsernameMatchingEnabled) {
		this.caseSensitiveUsernameMatchingEnabled = caseSensitiveUsernameMatchingEnabled;
	}

}
