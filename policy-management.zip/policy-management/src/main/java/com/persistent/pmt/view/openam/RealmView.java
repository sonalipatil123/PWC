package com.persistent.pmt.view.openam;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.view.TargetView;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RealmView implements TargetView {

  @JsonIgnore
  private String id;
  private String name;
  private String parentPath;
  private boolean active;
  private String[] aliases;

  public RealmView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String[] getAliases() {
    return aliases;
  }

  public void setAliases(String[] aliases) {
    this.aliases = aliases;
  }

  public String getParentPath() {
    return parentPath;
  }

  public void setParentPath(String parentPath) {
    this.parentPath = parentPath;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  @Override
  public String toString() {
    return "RealmView [realmName=" + name + ", parentPath=" + parentPath + ", active=" + active
        + ", aliases=" + Arrays.toString(aliases) + "]";
  }

}
