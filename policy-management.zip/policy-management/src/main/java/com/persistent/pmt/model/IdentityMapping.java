package com.persistent.pmt.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * IdentityMapping
 * 
 * Entity model for IdentityMapping
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "identity_mapping")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IdentityMapping {

	@JsonIgnore
	@Id
//	@SequenceGenerator(name = "SEQ_IDENTITY_MAPPING", sequenceName = "SEQ_IDENTITY_MAPPING", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_IDENTITY_MAPPING")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@JsonIgnore
	@Transient
	private int targetId;

	@Column(name = "name")
	private String name;

	@Column(name = "system_specific")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean systemSpecific;

	@Column(name = "life_cycle")
	private String lifeCycle;

	@Transient
	private boolean defaultEntity;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "identity_mapping_id")
	private List<ResponseHeader> responseHeaders;

	@JsonIgnore
	@Column(name = "target_name")
	private String targetName;

	public IdentityMapping() {
		super();
	}

	public IdentityMapping(int id, String name, boolean systemSpecific) {
		this.id = id;
		this.name = name;
		this.systemSpecific = systemSpecific;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTargetId() {
		return targetId;
	}

	public void setTargetId(int targetId) {
		this.targetId = targetId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isSystemSpecific() {
		return systemSpecific;
	}

	public void setSystemSpecific(boolean systemSpecific) {
		this.systemSpecific = systemSpecific;
	}

	public String getLifeCycle() {
		return lifeCycle;
	}

	public void setLifeCycle(String lifeCycle) {
		this.lifeCycle = lifeCycle;
	}

	public boolean isDefaultEntity() {
		return defaultEntity;
	}

	public void setDefaultEntity(boolean defaultEntity) {
		this.defaultEntity = defaultEntity;
	}

	public List<ResponseHeader> getResponseHeaders() {
		return responseHeaders;
	}

	public void setResponseHeaders(List<ResponseHeader> responseHeaders) {
		this.responseHeaders = responseHeaders;
	}

	public String getTargetName() {
		return targetName;
	}

	public void setTargetName(String targetName) {
		this.targetName = targetName;
	}

	public void updateIdentityMappingValues(IdentityMapping identityMapping) {
		this.name = identityMapping.getName();
		this.targetId = identityMapping.getTargetId();
		this.responseHeaders.clear();
		if (identityMapping.getResponseHeaders() != null
				&& !identityMapping.getResponseHeaders().isEmpty()) {
			this.responseHeaders.addAll(identityMapping.getResponseHeaders());
		}
	}

}
