/**
 * ApplicationHostOperationResponse
 * 
 * Base response for add/delete host configurations to existing application
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.error.WorkflowError;

@JsonInclude(Include.NON_NULL)
public class ApplicationHostOperationResponse {

	private String status;
	private String message;

	@JsonInclude(Include.NON_EMPTY)
	private List<WorkflowError> errors;

	public ApplicationHostOperationResponse() {
		super();
	}

	public ApplicationHostOperationResponse(String status, String message) {
		this.status = status;
		this.message = message;
	}

	public ApplicationHostOperationResponse(String status, String message, List<WorkflowError> errors) {
		this.status = status;
		this.message = message;
		this.errors = errors;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<WorkflowError> getErrors() {
		return errors;
	}

	public void setErrors(List<WorkflowError> errors) {
		this.errors = errors;
	}

}
