package com.persistent.pmt.constant;

public class AuditPropertyConstants {
	public static final String READER_GLOBAL_DOMAIN_FOUND = "source.reader.globaldomain.found";
	public static final String READER_READAGENT_CONFIG = "source.reader.readagent.config";
	public static final String READER_PREPAREAGENT_CONFIG = "source.reader.prepareagent.config";
  public static final String READER_PREPAREAGENT_CONFIG_DUMMY_FQDN =
      "source.reader.prepareagent.config.dummy.fqdn";

	public static final String SOURCE_IMPORT_FAILURE = "source.import.fail";
	public static final String SOURCE_MAPPER_AUTH_POLICIES = "source.mapper.domainentitymapper.authorization";

	public static final String SOURCE_MAPPER_DOMAIN = "source.mapper.domain";
	public static final String SOURCE_MAPPER_USER_DIRECTORIES = "source.mapper.userdirectories";
	public static final String SOURCE_MAPPER_RESPONSES = "source.mapper.mapper.responses";
	public static final String SOURCE_MAPPER_REALMS = "source.mapper.realms";
	public static final String SOURCE_MAPPER_POLICIES = "source.mapper.policies";
	public static final String SOURCE_MAPPER_RULE_GROUP = "source.mapper.rulegroup";
  public static final String SOURCE_MAPPER_AGENT_NOT_HAVING_AGENT_CONFIG =
      "source.mapper.agent.not.having.entity.config";
  public static final String SOURCE_MAPPER_DOMAIN_ENTITY_DISABLED_POLICY =
      "source.mapper.domain.entity.disabled.policy";
  public static final String SOURCE_MAPPER_DOMAIN_ENTITY_GLOBAL_RESPONSE =
      "source.mapper.domain.entity.global.response";
  public static final String SOURCE_MAPPER_DOMAIN_ENTITY_OBSOLETE_REALM =
      "source.mapper.domain.entity.obsolete.realm";
  public static final String SOURCE_MAPPER_DOMAIN_ENTITY_RULES_CONSOLIDATED =
      "source.mapper.domain.entity.rules.consolidated";
  public static final String SOURCE_MAPPER_DOMAIN_ENTITY_RESOURCE_CONSOLIDATED =
      "source.mapper.domain.entity.resource.consolidated";
  public static final String AGENT_NOT_HAVING_FQDN = "agent.not.having.fqdn";

	public static final String SOURCE_WRITER_AGENT_GROUP = "source.writer.agentgroup";
	public static final String SOURCE_WRITER_AGENT = "source.writer.agent";
	public static final String SOURCE_WRITER_AUTHSCHEME = "source.writer.authscheme";
	public static final String SOURCE_WRITER_DOMAIN = "source.writer.domain";
	public static final String SOURCE_WRITER_FEDERATION = "source.writer.federation";
	public static final String SOURCE_WRITER_USER_DIRECTORIES = "source.writer.userdirectory";

	public static final String TARGET_MAPPER_AGENTVIEW_DUMMYVAL = "target.mapper.agentview.dummyvalue";
	public static final String TARGET_MAPPER_MODULEVIEW_USERSTORE = "target.mapper.moduleview.userstore";
	public static final String TARGET_MAPPER_MODULEVIEW_CUSTOMSCHEME = "target.mapper.moduleview.customscheme";
	public static final String TARGET_MAPPER_MODULEVIEW_AUTHSCHEME_NTLM = "target.mapper.moduleview.authscheme.ntlm";

  public static final String TARGET_ARTIFACT_ACTION_SUCCESS = "target.artifact.action.success";
	public static final String TARGET_ACTION_SUCCESS = "target.action.success";
	public static final String TARGET_ARTIFACT_ACTION_DETAILS_SUCCESS = "target.artifact.action.details.success";
	public static final String TARGET_ACTION_FAILURE = "target.action.failure";
	public static final String TARGET_ACTION_ROLLBACK_SUCCESS = "target.action.rollback.success";
	public static final String TARGET_ACTION_ROLLBACK_FAILURE = "target.action.rollback.failure";
	public static final String TARGET_ACTION_EXISTS = "target.action.exists";
	public static final String TARGET_ACTION_DATA_NOT_VALID = "target.action.invalid.data";
	public static final String TARGET_ACTION_POLICY_RESOURCE_INVALID = "target.action.policy.resource.invalid";
	public static final String TARGET_ACTION_POLICY_RESOURCE_NOT_HAVING_AUTHORIZATIONPOLICY_ATTACHED = "target.action.policy.resource.not.having.authorizationpolicy.attached";

	public static final String TARGET_ACTION_POLICY_RESPONSE_DUPLICATE = "target.action.policy.resource.duplicate";
	public static final String TARGET_ACTION_POLICY_RESOURCE_ANONYMOUS = "target.action.policy.resource.anonymous";
	public static final String TARGET_ACTION_PROVIDER_METADATA_NOT_FOUND = "target.action.provider.metadata.not.found";

	public static final String TARGET_ACTION_PROVIDER_OAUTHGROUP_NOT_AVAILABLE = "target.action.provider.oauthgroup.not.available";
	public static final String TARGET_ACTION_PROVIDER_OF_TYPE_OUTH_SUCCESS = "target.action.provider.of.type.oauth.success";
	public static final String TARGET_ACTION_PROVIDER_OAUTHGROUP_PROPERTIES_APPLIED_TO_OAUTHCLIENT = "target.action.provider.oauthgroup.properties.applied.to.oauthclient";
	public static final String TARGET_ACTION_ARTIFACT_READ_SUCCESS = "target.action.artifact.read.success";
	public static final String TARGET_ACTION_ARTIFACT_RESPONSE_EMPTY = "target.action.artifact.response.empty";
	public static final String TARGET_ACTION_ARTIFACT_READ_FAILURE = "target.action.artifact.read.failure";
	public static final String TARGET_ACTION_ARTIFACT_READ_FAILURE_ACTIONLIST_EMPTY = "target.action.artifact.read.failure.since.action.list.empty";
	public static final String TARGET_ACTION_ARTIFACT_CREATION_STARTED = "target.action.artifact.creation.started";
	public static final String TARGET_ACTION_ARTIFACT_CREATION_FAILURE_ROLLBACK_STARTED = "target.action.artifact.creation.failure.rollback.started";
  public static final String TARGET_ACTION_ARTIFACT_CREATION_FAILURE_ROLLBACK_SUCCESS =
      "target.action.artifact.creation.failure.rollback.success";
  public static final String TARGET_ACTION_ARTIFACT_CREATION_FAILURE_ROLLBACK_FAILED =
      "target.action.artifact.creation.failure.rollback.failed";
	public static final String TARGET_ACTION_ARTIFACT_CREATION_FAILURE_ACTIONLIST_EMPTY = "target.action.artifact.creation.failure.since.action.list.empty";
	public static final String TARGET_ACTION_ARTIFACT_CREATION_FOR_AGENTBASED = "target.action.artifact.creation.for.agentbased.application";
	public static final String TARGET_ACTION_ARTIFACT_CREATION_FOR_FED_AND_AGENTBASED = "target.action.artifact.creation.for.fedandagentbased.application";
  public static final String TARGET_ACTION_ARTIFACT_CREATION_FOR_FEDERATIONBASED =
      "target.action.artifact.creation.for.federationbased.application";
	public static final String TARGET_ACTION_ARTIFACT_CREATION_FOR_OAUTHBASED = "target.action.artifact.creation.for.oauthbased.application";
	public static final String TARGET_ACTION_ARTIFACT_CREATION_FOR_COMBINED_APPLICATION_SUCCESS = "target.action.artifact.creation.for.combined.application.success";
  public static final String TARGET_ACTION_PROVSION_WORKFLOW_SUCCESS =
      "target.action.provision.workflow.success";
}
