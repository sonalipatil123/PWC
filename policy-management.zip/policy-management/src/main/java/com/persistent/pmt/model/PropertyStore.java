package com.persistent.pmt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * PropertyStore
 * 
 * Entity model for PropertyStore
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "property")
public class PropertyStore {

  @Id
//  @GenericGenerator(name = "property_generator", strategy = "increment")
//  @GeneratedValue(generator = "property_generator")
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "id")
  private int id;

  @Column(name = "keys")
  private String key;

  @Column(name = "value")
  private String value;

  @Column(name = "environment")
  private int environment;

  @Column(name = "alias")
  private String alias;

  @Column(name = "type")
  private String type;

  public PropertyStore() {
    super();
  }

  public PropertyStore(String propertyKey, String propertyValue, int environment, String alias,
      String type) {
    super();
    this.key = propertyKey;
    this.value = propertyValue;
    this.environment = environment;
    this.alias = alias;
    this.type = type;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getEnvironment() {
    return environment;
  }

  public void setEnvironment(int environment) {
    this.environment = environment;
  }

  public String getKey() {
    return key;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public String getAlias() {
    return alias;
  }

  public void setAlias(String alias) {
    this.alias = alias;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("PropertyStore [id=");
    builder.append(id);
    builder.append(", key=");
    builder.append(key);
    builder.append(", value=");
    builder.append(value);
    builder.append(", environment=");
    builder.append(environment);
    builder.append(", alias=");
    builder.append(alias);
    builder.append("]");
    return builder.toString();
  }

}
