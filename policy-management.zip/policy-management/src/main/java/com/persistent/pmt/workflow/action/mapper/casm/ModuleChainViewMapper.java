package com.persistent.pmt.workflow.action.mapper.casm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.MapperConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.casm.AuthenticationSchemeTypes;
import com.persistent.pmt.constant.casm.Criteria;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.AuthenticationPolicy;
import com.persistent.pmt.model.AuthenticationScheme;
import com.persistent.pmt.model.Response;
import com.persistent.pmt.service.ServerConfigurationService;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.utils.MapperUtils;
import com.persistent.pmt.view.openam.AnonymousModuleView;
import com.persistent.pmt.view.openam.AuthChainConfiguration;
import com.persistent.pmt.view.openam.CertificateModuleView;
import com.persistent.pmt.view.openam.HttpBasicModuleView;
import com.persistent.pmt.view.openam.LDAPModuleView;
import com.persistent.pmt.view.openam.LegacyOAuth2OpenIdConnectModuleView;
import com.persistent.pmt.view.openam.ModuleChainView;
import com.persistent.pmt.view.openam.ModuleView;
import com.persistent.pmt.view.openam.SAML2ModuleView;
import com.persistent.pmt.view.openam.WindowsDesktopModuleView;
import com.persistent.pmt.workflow.action.mapper.GenericMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component
public class ModuleChainViewMapper implements GenericMapper {

  @Autowired
  ServerConfigurationService serverConfigurationService;

  @SuppressWarnings("unchecked")
  @Override
  public Object getMappedObject(Object object, WorkFlowContext workFlowContext)
      throws GenericException {

    Map<String, Object> params = (HashMap<String, Object>) object;
    Application application = (Application) params.get("application");
    List<ModuleView> moduleViews = (List<ModuleView>) params.get("moduleViews");

    ModuleChainView chainView = new ModuleChainView();

    AuthenticationPolicy defaultAuthenticationPolicy = null;
    if (application != null) {
      defaultAuthenticationPolicy = application.getDefaultAuthenticationPolicy();
    }

    // Get success and failure Urls
    StringBuilder loginSuccessUrls = new StringBuilder();
    StringBuilder loginFailureUrls = new StringBuilder();

    if (application.getResponses() != null) {
      for (Response response : application.getResponses()) {
        if (response != null
            && response.getAuthenticationPolicy() != null
            && defaultAuthenticationPolicy.getId() == response.getAuthenticationPolicy()
                .getId()) {
          if (MapperConstants.RESPONSE_REDIRECT_ON_ACCEPT.equalsIgnoreCase(response.getType())) {
            if (loginSuccessUrls != null && loginSuccessUrls.length() > 0) {
              loginSuccessUrls.append(MapperConstants.SEPARATOR_COMMA);
            }
            loginSuccessUrls.append(response.getValue());
          }
          else if (MapperConstants.RESPONSE_REDIRECT_ON_REJECT.equalsIgnoreCase(response
              .getType())) {
            if (loginFailureUrls != null && loginFailureUrls.length() > 0) {
              loginFailureUrls.append(MapperConstants.SEPARATOR_COMMA);
            }
            loginFailureUrls.append(response.getValue());
          }
        }
      }
    }
    if (loginSuccessUrls != null && loginSuccessUrls.length() > 0) {
      chainView.setLoginSuccessUrl(new String[] { loginSuccessUrls.toString() });
    }
    if (loginFailureUrls != null && loginFailureUrls.length() > 0) {
      chainView.setLoginFailureUrl(new String[] { loginFailureUrls.toString() });
    }

    AuthenticationScheme authenticationScheme =
        defaultAuthenticationPolicy.getAuthenticationScheme();
    String authenticationType = authenticationScheme.getType();

    List<AuthChainConfiguration> authChainConfigurations =
        new ArrayList<AuthChainConfiguration>();

    if (moduleViews != null && !moduleViews.isEmpty()) {

      if (AuthenticationSchemeTypes.AUTHN_SCHEME_HTML_FORM.getValue().equalsIgnoreCase(
          authenticationType)
          || AuthenticationSchemeTypes.AUTHN_SCHEME_HTMLFORMACE.getValue().equalsIgnoreCase(
              authenticationType)) {
        for (ModuleView moduleView : moduleViews) {
          AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
          authChainConfiguration.setCriteria(Criteria.SUFFICIENT.toString());
          authChainConfiguration.setModule(((LDAPModuleView) moduleView).getId());
          authChainConfigurations.add(authChainConfiguration);
        }
      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_ANONYMOUS.getValue().equalsIgnoreCase(
          authenticationType)) {
        for (ModuleView moduleView : moduleViews) {
          AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
          authChainConfiguration.setCriteria(Criteria.SUFFICIENT.toString());
          authChainConfiguration.setModule(((AnonymousModuleView) moduleView).getId());
          authChainConfigurations.add(authChainConfiguration);
        }
      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_BASIC.getValue().equalsIgnoreCase(
          authenticationType)) {
        for (ModuleView moduleView : moduleViews) {
          if (moduleView instanceof HttpBasicModuleView) {
            AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
            authChainConfiguration.setCriteria(Criteria.SUFFICIENT.toString());
            authChainConfiguration.setModule(((HttpBasicModuleView) moduleView).getId());
            authChainConfigurations.add(authChainConfiguration);
          }
        }
      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_CUSTOM.getValue().equalsIgnoreCase(
          authenticationType)) {
        if (AuthenticationSchemeTypes.AUTHENTICATION_SCHEME_FORM.getValue().equalsIgnoreCase(
            serverConfigurationService.getPropertyValue(PMTConstants.CUSTOM_ALTERNATE_SCHEME))) {

          for (ModuleView moduleView : moduleViews) {
            AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
            authChainConfiguration.setCriteria(Criteria.SUFFICIENT.toString());
            authChainConfiguration.setModule(((LDAPModuleView) moduleView).getId());
            authChainConfigurations.add(authChainConfiguration);
          }
        }
      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_NTLM.getValue().equalsIgnoreCase(
          authenticationType)) {
        for (ModuleView moduleView : moduleViews) {
          if (moduleView instanceof WindowsDesktopModuleView) {
            AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
            authChainConfiguration.setCriteria(Criteria.SUFFICIENT.toString());
            authChainConfiguration.setModule(((WindowsDesktopModuleView) moduleView).getId());
            authChainConfigurations.add(authChainConfiguration);
          }
        }
      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_X509CERT.getValue().equalsIgnoreCase(
          authenticationType)) {
        for (ModuleView moduleView : moduleViews) {
          if (moduleView instanceof CertificateModuleView) {
            AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
            authChainConfiguration.setCriteria(Criteria.SUFFICIENT.toString());
            authChainConfiguration.setModule(((CertificateModuleView) moduleView).getId());
            authChainConfigurations.add(authChainConfiguration);
          }
        }
        Collections.reverse(authChainConfigurations);
      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_X509CERTANDFORM.getValue()
          .equalsIgnoreCase(authenticationType)) {
        for (ModuleView moduleView : moduleViews) {
          if (moduleView instanceof LDAPModuleView) {
            AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
            authChainConfiguration.setCriteria(Criteria.SUFFICIENT.toString());
            authChainConfiguration.setModule(((LDAPModuleView) moduleView).getId());
            authChainConfigurations.add(authChainConfiguration);
          }
          else if (moduleView instanceof CertificateModuleView) {
            AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
            authChainConfiguration.setCriteria(Criteria.REQUISITE.toString());
            authChainConfiguration.setModule(((CertificateModuleView) moduleView).getId());
            authChainConfigurations.add(authChainConfiguration);
          }
        }
        Collections.reverse(authChainConfigurations);
      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_X509CERTORFORM.getValue()
          .equalsIgnoreCase(authenticationType)) {
        for (ModuleView moduleView : moduleViews) {
          if (moduleView instanceof CertificateModuleView) {
            AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
            authChainConfiguration.setCriteria(Criteria.SUFFICIENT.toString());
            authChainConfiguration.setModule(((CertificateModuleView) moduleView).getId());
            authChainConfigurations.add(authChainConfiguration);
          }
          else if (moduleView instanceof LDAPModuleView) {
            AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
            authChainConfiguration.setCriteria(Criteria.SUFFICIENT.toString());
            authChainConfiguration.setModule(((LDAPModuleView) moduleView).getId());
            authChainConfigurations.add(authChainConfiguration);
          }
        }
        Collections.reverse(authChainConfigurations);
      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_SAML2.getValue().equalsIgnoreCase(
          authenticationType)) {

        for (ModuleView moduleView : moduleViews) {
          if (moduleView instanceof SAML2ModuleView) {
            AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
            authChainConfiguration.setCriteria(Criteria.SUFFICIENT.toString());
            authChainConfiguration.setModule(((SAML2ModuleView) moduleView).getId());
            authChainConfigurations.add(authChainConfiguration);
          }
        }
      }
      else if (AuthenticationSchemeTypes.AUTHN_SCHEME_OAUTH.getValue().equalsIgnoreCase(
          authenticationType)) {
        for (ModuleView moduleView : moduleViews) {
          AuthChainConfiguration authChainConfiguration = new AuthChainConfiguration();
          authChainConfiguration.setCriteria(Criteria.SUFFICIENT.toString());
          authChainConfiguration.setModule(((LegacyOAuth2OpenIdConnectModuleView) moduleView)
              .getId());
          authChainConfigurations.add(authChainConfiguration);
        }
      }
    }
    chainView.setId(getId(application));
    chainView.setAuthChainConfiguration(authChainConfigurations
        .toArray(new AuthChainConfiguration[authChainConfigurations.size()]));

    return chainView;
  }

  @Override
  public String getId(Object object) throws GenericException {
    return CommonUtils.formatString(((Application) object).getName(),
        MapperUtils.getInvalidCharacters());
  }

}
