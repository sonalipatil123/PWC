/**
 * ApplicationState
 * 
 * Enum for various application states
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.constant;

import java.util.ArrayList;
import java.util.List;

public enum ApplicationState {

  DRAFTED, IMPORTED, READY_TO_PROVISION, PROVISIONED, DECOMMISSIONED, PROVISION_UPDATE, COMBINED;

  public static List<String> getProvisionAllowedStates() {
    List<String> states = new ArrayList<>();
    states.add(IMPORTED.toString());
    states.add(READY_TO_PROVISION.toString());
    states.add(PROVISION_UPDATE.toString());

    return states;
  }

  public static List<String> getApplicationSummaryStates() {
    List<String> states = new ArrayList<>();
    states.add(IMPORTED.toString());
    states.add(READY_TO_PROVISION.toString());
    states.add(PROVISIONED.toString());
    states.add(PROVISION_UPDATE.toString());
    states.add(DECOMMISSIONED.toString());

    return states;
  }

  public static List<String> getImportSummaryStates() {
    List<String> states = new ArrayList<>();
    states.add(DRAFTED.toString());
    return states;
  }

  public static List<String> getProvisionedStates() {
    List<String> states = new ArrayList<>();
    states.add(PROVISIONED.toString());
    return states;
  }

}
