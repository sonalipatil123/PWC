package com.persistent.pmt.workflow.action.mapper.casm;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.MapperConstants;
import com.persistent.pmt.constant.Resource.HTTPMethods;
import com.persistent.pmt.constant.casm.BitMappingEnum;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.AuthenticationPolicy;
import com.persistent.pmt.model.AuthorizationPolicy;
import com.persistent.pmt.model.AuthorizationPolicyAttribute;
import com.persistent.pmt.model.Resource;
import com.persistent.pmt.model.Response;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.utils.MapperUtils;
import com.persistent.pmt.view.openam.Condition;
import com.persistent.pmt.view.openam.PolicyView;
import com.persistent.pmt.view.openam.ResponseAttributes;
import com.persistent.pmt.view.openam.Subject;
import com.persistent.pmt.workflow.action.mapper.GenericMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class PolicyViewMapper implements GenericMapper {

  private static List<String> validActionValues = validActionValues();
  private static String RESPONSE_TYPE_SUBJECT = "User";
  private static String RESPONSE_TYPE_STATIC = "Static";
  private static String SUBJECT_TYPE_ALL_AUTHENTICATED_USERS = "AuthenticatedUsers";
  private static String SUBJECT_TYPE_IDENTITY = "Identity";
  private static String ENVIRONMENT_CONDITION_LDAP_FILTER = "LDAPFilter";
  private static String ENVIRONMENT_CONDITION_IP_ADDRESS = "IPAddress";

  private static List<String> validActionValues() {
    List<String> validActionValues = new ArrayList<String>();
    validActionValues.add(HTTPMethods.GET.name());
    validActionValues.add(HTTPMethods.PUT.name());
    validActionValues.add(HTTPMethods.DELETE.name());
    validActionValues.add(HTTPMethods.POST.name());
    validActionValues.add(HTTPMethods.OPTIONS.name());
    validActionValues.add(HTTPMethods.HEAD.name());
    validActionValues.add(HTTPMethods.PATCH.name());
    return validActionValues;
  }

  @Autowired
  Environment environment;

  /**
   * Create Policy for application which includes resources, actions,
   * responses, subjects and conditions
   * 
   * @param application
   * @return List of policies
   * @throws GenericException
   */
  @Override
  public Object getMappedObject(Object object, WorkFlowContext workFlowContext)
      throws GenericException {

    Application application = (Application) object;
    List<PolicyView> policies = new ArrayList<PolicyView>();

    if (application != null && application.getAuthorizationPolicies() != null) {

      for (AuthorizationPolicy authzPolicy : application.getAuthorizationPolicies()) {
        PolicyView policyView = new PolicyView();
        policyView.setName(((AuthorizationPolicy) authzPolicy).getName());
        createResourcesAndActionValues(application, policyView, workFlowContext);
        if (policyView.getResources() != null && policyView.getResources().length >= 1) {
          policyView.setId(getId(authzPolicy));
          policyView.setApplicationName(CommonUtils.formatString(
              ((Application) object).getName(), MapperUtils.getInvalidCharacters()));
          policyView.setDescription(authzPolicy.getDescription());
          policyView.setActive(authzPolicy.isEnabled());

          createResponses(application, policyView, workFlowContext);
          createSubjectsAndConditions(authzPolicy, policyView);
          policyView.setName(getId(authzPolicy));

          policies.add(policyView);
        }
        else {
          // Audit log no valid resources within a policy.
          workFlowContext.getPolicyAuditData().append(
              MessageFormat.format(environment
                  .getProperty(AuditPropertyConstants.TARGET_ACTION_POLICY_RESOURCE_INVALID),
                  new Object[] { policyView.getName() }));
        }
      }
    }
    return policies;
  }

  /**
   * Create Responses for a policy
   * 
   * @param application
   * @param policyView
   * @throws GenericException
   */
  private void createResponses(Application application, PolicyView policyView,
      WorkFlowContext workFlowContext) throws GenericException {
    HashSet<ResponseAttributes> resourceAttributes = null;
    List<Response> responses = application.getResponses();
    if (responses != null) {
      resourceAttributes = new HashSet<ResponseAttributes>();
      List<String> responsePropertyNames = new ArrayList<String>();

      createResponseAttributesFromAuthzPolicy(policyView, resourceAttributes, responses,
          responsePropertyNames);

      // Check for responses from authentication Policy, However,
      // ignore if the response key is already present from thex
      // authorization responses set earlier
      createResponseAttributesFromAuthnPolicy(application, resourceAttributes, responses,
          responsePropertyNames, workFlowContext);
    }
    policyView.setResourceAttributes(resourceAttributes);
  }

  private void createResponseAttributesFromAuthnPolicy(Application application,
      HashSet<ResponseAttributes> resourceAttributes, List<Response> responses,
      List<String> responsePropertyNames, WorkFlowContext workFlowContext)
      throws GenericException {
    AuthenticationPolicy defaultAuthenticationPolicy = null;
    if (application.getAuthenticationPolicies() != null) {
      defaultAuthenticationPolicy = application.getDefaultAuthenticationPolicy();
    }
    for (Response response : responses) {

      AuthenticationPolicy responseAuthenticationPolicy = response.getAuthenticationPolicy();

      if (responseAuthenticationPolicy != null
          && responseAuthenticationPolicy.getName().equalsIgnoreCase(
              defaultAuthenticationPolicy.getName())) {

        ResponseAttributes responseAttributes = null;
        if (MapperConstants.RESPONSE_HEADER.equalsIgnoreCase(response.getType())
            || MapperConstants.RESPONSE_COOKIE.equalsIgnoreCase(response.getType())) {

          String responseValue = response.getValue();

          if (responseValue.contains("userattr")) {
            responseValue =
                responseValue.substring(responseValue.indexOf("\"") + 1,
                    responseValue.lastIndexOf("\""));
            if (!checkIfResponseAlreadyExists(responsePropertyNames, responseValue)) {
              responseAttributes = new ResponseAttributes();
              responseAttributes.setType(RESPONSE_TYPE_SUBJECT);
              responseAttributes.setPropertyName(responseValue);
            }
            else {
              // Audit log no valid response duplicate
              workFlowContext
                  .getPolicyAuditData()
                  .append(
                      MessageFormat.format(
                          environment
                              .getProperty(AuditPropertyConstants.TARGET_ACTION_POLICY_RESPONSE_DUPLICATE),
                          new Object[] { responseValue, responseAuthenticationPolicy.getName() }));
            }
          }
          else {
            if (responseValue.contains("=")) {
              String[] responseValues = responseValue.split("=");
              if (responseValues != null && responseValues.length > 1) {
                if (!checkIfResponseAlreadyExists(responsePropertyNames, responseValues[0])) {
                  responseAttributes = new ResponseAttributes();
                  responseAttributes.setPropertyName(responseValues[0]);
                  responseAttributes.setPropertyValues(new String[] { responseValues[1] });
                }
              }
            }
            else {
              if (!checkIfResponseAlreadyExists(responsePropertyNames, responseValue)) {
                responseAttributes = new ResponseAttributes();
                responseAttributes.setPropertyName(responseValue);
                responseAttributes.setPropertyValues(new String[] { responseValue });
              }
            }
            responseAttributes.setType(RESPONSE_TYPE_STATIC);
          }
          if (responseAttributes != null) {
            resourceAttributes.add(responseAttributes);
          }
        }
      }
    }
  }

  private void createResponseAttributesFromAuthzPolicy(PolicyView policyView,
      HashSet<ResponseAttributes> resourceAttributes, List<Response> responses,
      List<String> responsePropertyNames) {
    for (Response response : responses) {

      AuthorizationPolicy responseAuthzPolicy = response.getAuthorizationPolicy();

      if (responseAuthzPolicy != null
          && responseAuthzPolicy.getName().equalsIgnoreCase(policyView.getName())) {

        ResponseAttributes responseAttributes = null;
        if (MapperConstants.RESPONSE_HEADER.equalsIgnoreCase(response.getType())
            || MapperConstants.RESPONSE_COOKIE.equalsIgnoreCase(response.getType())) {

          String responseValue = response.getValue();

          if (responseValue.contains("userattr")) {
            responseValue =
                responseValue.substring(responseValue.indexOf("\"") + 1,
                    responseValue.lastIndexOf("\""));
            responseAttributes = new ResponseAttributes();
            responseAttributes.setType(RESPONSE_TYPE_SUBJECT);
            responseAttributes.setPropertyName(responseValue);
          }
          else {
            if (responseValue.contains("=")) {
              String[] responseValues = responseValue.split("=");
              if (responseValues != null && responseValues.length > 1) {
                responseAttributes = new ResponseAttributes();
                responseAttributes.setPropertyName(responseValues[0]);
                responseAttributes.setPropertyValues(new String[] { responseValues[1] });
              }
            }
            else {
              responseAttributes = new ResponseAttributes();
              responseAttributes.setPropertyName(responseValue);
              responseAttributes.setPropertyValues(new String[] { responseValue });
            }
            if (responseAttributes != null) {
              responseAttributes.setType(RESPONSE_TYPE_STATIC);
            }
          }
          if (responseAttributes != null) {
            resourceAttributes.add(responseAttributes);
          }
        }
        if (responseAttributes != null) {
          responsePropertyNames.add(responseAttributes.getPropertyName());
        }
      }
    }
  }

  private boolean checkIfResponseAlreadyExists(List<String> responsePropertyNames,
      String responseValue) {
    boolean status = false;
    if (responsePropertyNames.contains(responseValue)) {
      status = true;
    }
    return status;
  }

  /**
   * Create a map of actions and allow/deny status and list of
   * resources in an authorization policy
   * 
   * @param application
   * @param policyView
   * @throws GenericException
   */
  private void createResourcesAndActionValues(Application application, PolicyView policyView,
      WorkFlowContext workFlowContext) throws GenericException {

    Map<String, Boolean> actionValues = new HashMap<String, Boolean>();
    List<String> uris = new ArrayList<String>();

    List<Resource> resources = application.getResources();
    if (resources != null) {
      for (Resource resource : resources) {

        AuthorizationPolicy authzPolicy = resource.getAuthorizationPolicy();
        if (authzPolicy != null) {
          if (authzPolicy.getName().equalsIgnoreCase(policyView.getName())) {

            if (!resource.isAnonymous()) {
              // Get Resource Actions
              List<String> actions = resource.getHttpMethods();
              if (actions != null) {
                for (String action : actions) {
                  if (action.contains(MapperConstants.SEPARATOR_PIPE)) {
                    String[] actionAllowDeny =
                        action.split(Pattern.quote(MapperConstants.SEPARATOR_PIPE));
                    if (actionAllowDeny != null && actionAllowDeny.length == 2) {

                      if (validActionValues.contains(actionAllowDeny[0].toUpperCase())) {
                        actionValues.put(actionAllowDeny[0].toUpperCase(), (actionAllowDeny[1]
                            .equalsIgnoreCase(MapperConstants.ACTION_ALLOW)) ? true : false);
                      }
                    }
                  }
                  else if ("ALL".equals(action)) {
                    for (String actionValue : validActionValues) {
                      actionValues.put(actionValue, true);
                    }
                  }
                }
              }

              String uri = "";
              // Get Resource URI's
              if ("/".equals(resource.getUri().charAt(0))) {
                uri = MapperConstants.RESOURCE_PREFIX + resource.getUri();
              }
              else {
                uri = MapperConstants.RESOURCE_PREFIX + "/" + resource.getUri();
              }
              uris.add(uri);
            }
            else {
              // Audit log for anonymous resource
              workFlowContext
                  .getPolicyAuditData()
                  .append(
                      MessageFormat.format(
                          environment
                              .getProperty(AuditPropertyConstants.TARGET_ACTION_POLICY_RESOURCE_ANONYMOUS),
                          new Object[] { policyView.getName(), resource.getUri() }));
            }
          }
        }
        else {
          // Audit log for resource not having authorization policy
          // attached to it
          workFlowContext
              .getPolicyAuditData()
              .append(
                  MessageFormat.format(
                      environment
                          .getProperty(AuditPropertyConstants.TARGET_ACTION_POLICY_RESOURCE_NOT_HAVING_AUTHORIZATIONPOLICY_ATTACHED),
                      new Object[] { resource.getUri(), resource.getId() }));
        }
      }
      policyView.setResources(uris.toArray(new String[uris.size()]));
      policyView.setActionValues(actionValues);
    }
  }

  /**
   * Create Subjects & Conditions for the policy
   * 
   * @param application
   * @param policyView
   */
  private void createSubjectsAndConditions(AuthorizationPolicy authorizationPolicy,
      PolicyView policyView) {

    if (authorizationPolicy.getAttributes() != null) {

      if (checkIfAllAuthenticatedUsers(authorizationPolicy)) {
        createSubjectAndConditonsForAllAuthenticatedUsersWithLdapFilter(authorizationPolicy,
            policyView);
      }
      else {
        createSubjectAndConditionsSeparate(authorizationPolicy, policyView);
      }
    }
  }

  private void createSubjectAndConditonsForAllAuthenticatedUsersWithLdapFilter(
      AuthorizationPolicy authorizationPolicy, PolicyView policyView) {

    LinkedHashSet<HashMap<String, Object>> conditions =
        new LinkedHashSet<HashMap<String, Object>>();
    StringBuilder ldapFilter = new StringBuilder();
    StringBuilder ipConditionValue = new StringBuilder();
    int count = 0;

    for (AuthorizationPolicyAttribute attribute : authorizationPolicy.getAttributes()) {

      String conditionType = attribute.getConditionType();
      String conditionValue = attribute.getConditionValue();
      boolean negate = attribute.isNegate();

      if ((BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(1).equals(conditionType))) {

        if (negate) {
          ldapFilter.append("(!");
        }
        ldapFilter.append("("
            + getConditionValue(conditionValue, MapperConstants.SEPARATOR_COMMA) + ")");

        if (negate) {
          ldapFilter.append(")");
        }
        count++;
      }
      else if (BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(2).equals(conditionType)
          || BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(9).equals(conditionType)) {
        if (negate) {
          ldapFilter.append("(!");
        }
        ldapFilter.append("(isMemberOf=" + conditionValue + ")");

        if (negate) {
          ldapFilter.append(")");
        }
        count++;
      }
      else if (BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(3).equals(conditionType)
          || BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(5).equals(conditionType)) {

        createLdapFilterForEnvironmentCondition(ldapFilter, conditionValue, negate);
        count++;
      }
      else if (ENVIRONMENT_CONDITION_IP_ADDRESS.equals(conditionType)) {
        if (ipConditionValue.length() > 0) {
          ipConditionValue.append(MapperConstants.SEPARATOR_COMMA);
        }
        ipConditionValue.append(conditionValue);
      }
    }

    // Add IP Address to conditions
    if (ipConditionValue != null && ipConditionValue.length() > 0) {
      conditions.add(createIpAddressCondition(ipConditionValue.toString()));
    }

    if (ldapFilter != null && ldapFilter.length() > 0) {
      HashMap<String, Object> ldapCondition = createLDAPCondition(ldapFilter, count);
      conditions.add(ldapCondition);
    }

    // Set Environment Conditions
    if (conditions != null && !conditions.isEmpty()) {
      Condition policyViewCondition = new Condition();
      policyViewCondition.setType("AND");
      policyViewCondition.setConditions(conditions);
      policyView.setCondition(policyViewCondition);
    }

    // Set Subject to All Authenticated Users
    Subject subject = new Subject();
    subject.setType(SUBJECT_TYPE_ALL_AUTHENTICATED_USERS);
    policyView.setSubject(subject);
  }

  private void createSubjectAndConditionsSeparate(AuthorizationPolicy authorizationPolicy,
      PolicyView policyView) {

    LinkedHashSet<HashMap<String, Object>> conditions =
        new LinkedHashSet<HashMap<String, Object>>();
    LinkedHashSet<String> subjectUserValues = new LinkedHashSet<String>();
    LinkedHashSet<String> subjectGroupValues = new LinkedHashSet<String>();
    List<Object> subjects = new ArrayList<Object>();
    StringBuilder ipConditionValue = new StringBuilder();
    StringBuilder ldapFilter = new StringBuilder();
    int count = 0;

    for (AuthorizationPolicyAttribute attribute : authorizationPolicy.getAttributes()) {

      String conditionType = attribute.getConditionType();
      String conditionValue = attribute.getConditionValue();
      boolean negate = attribute.isNegate();

      if ((BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(1).equals(conditionType))) {

        if (("*").equals(conditionValue)) {
          continue;
        }
        if (negate) {
          subjects.add(createSubjectForNegate(conditionValue));
        }
        else {
          subjectUserValues.add(conditionValue);
        }
      }
      else if (BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(2).equals(conditionType)
          || BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(9).equals(conditionType)) {
        if (("*").equals(conditionValue)) {
          continue;
        }
        if (negate) {
          subjects.add(createSubjectForNegate(conditionValue));
        }
        else {
          subjectGroupValues.add(conditionValue);
        }
      }
      else if (BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(3).equals(conditionType)
          || BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(5).equals(conditionType)) {

        createLdapFilterForEnvironmentCondition(ldapFilter, conditionValue, negate);
        count++;
      }
      else if (ENVIRONMENT_CONDITION_IP_ADDRESS.equals(conditionType)) {
        if (ipConditionValue.length() > 0) {
          ipConditionValue.append(MapperConstants.SEPARATOR_COMMA);
        }
        ipConditionValue.append(conditionValue);
      }
    }

    // Add IP Address to conditions
    if (ipConditionValue != null && ipConditionValue.length() > 0) {
      conditions.add(createIpAddressCondition(ipConditionValue.toString()));
    }

    if ((subjectUserValues != null && !subjectUserValues.isEmpty())
        || (subjectGroupValues != null && !subjectGroupValues.isEmpty())) {

      if (subjectUserValues != null && !subjectUserValues.isEmpty()) {
        HashMap<String, Object> subjectCondition = new HashMap<String, Object>();
        subjectCondition.put("type", SUBJECT_TYPE_IDENTITY);
        subjectCondition.put("subjectValues", subjectUserValues);
        subjects.add(subjectCondition);
      }

      if (subjectGroupValues != null && !subjectGroupValues.isEmpty()) {
        HashMap<String, Object> subjectCondition = new HashMap<String, Object>();
        subjectCondition.put("type", SUBJECT_TYPE_IDENTITY);
        subjectCondition.put("subjectValues", subjectGroupValues);
        subjects.add(subjectCondition);
      }
    }
    else {
      if (subjects == null || subjects.isEmpty()) {
        // Set Subject to All Authenticated Users
        Subject subject = new Subject();
        subject.setType(SUBJECT_TYPE_ALL_AUTHENTICATED_USERS);
        subjects.add(subject);
      }
    }

    // Set Subjects
    Subject subject = new Subject();
    subject.setType("OR");
    subject.setSubjects(subjects);
    policyView.setSubject(subject);

    if (ldapFilter != null && ldapFilter.length() > 0) {
      HashMap<String, Object> ldapCondition = createLDAPCondition(ldapFilter, count);
      conditions.add(ldapCondition);
    }

    // Set Environment Conditions
    if (conditions != null && !conditions.isEmpty()) {
      Condition condition = new Condition();
      condition.setType("AND");
      condition.setConditions(conditions);
      policyView.setCondition(condition);
    }
  }

  private HashMap<String, Object> createSubjectForNegate(String conditionValue) {
    LinkedHashSet<String> subjectValuesForNegate = new LinkedHashSet<String>();
    subjectValuesForNegate.add(conditionValue);
    HashMap<String, Object> subjectCondition = new HashMap<String, Object>();
    subjectCondition.put("type", SUBJECT_TYPE_IDENTITY);
    subjectCondition.put("subjectValues", subjectValuesForNegate);

    HashMap<String, Object> notSubjectCondition = new HashMap<String, Object>();
    notSubjectCondition.put("type", "NOT");
    notSubjectCondition.put("subject", subjectCondition);
    return notSubjectCondition;
  }

  private HashMap<String, Object> createLDAPCondition(StringBuilder ldapFilter, int count) {
    if (count > 1) {
      ldapFilter.insert(0, "(|");
      ldapFilter.insert(ldapFilter.length(), ")");
    }
    // Add LDAP filter to conditions
    HashMap<String, Object> ldapCondition = new HashMap<String, Object>();
    ldapCondition.put("type", ENVIRONMENT_CONDITION_LDAP_FILTER);
    ldapCondition.put("ldapFilter", ldapFilter);
    return ldapCondition;
  }

  private void createLdapFilterForEnvironmentCondition(StringBuilder ldapFilter,
      String conditionValue, boolean negate) {
    if (negate) {
      ldapFilter.append("(!");
    }

    if (conditionValue.contains("(") && conditionValue.contains(")")) {
      ldapFilter.append(conditionValue);
    }
    else {
      ldapFilter.append("("
          + getConditionValue(conditionValue, MapperConstants.SEPARATOR_COMMA) + ")");
    }

    if (negate) {
      ldapFilter.append(")");
    }
  }

  private String getConditionValue(String conditionValue, String separator) {
    String value = "";
    if (conditionValue.contains(separator)) {
      String[] splitConditionValue = conditionValue.split(separator);
      if (splitConditionValue != null && splitConditionValue.length > 0) {
        value = splitConditionValue[0];
      }
    }
    else {
      value = conditionValue;
    }
    return value;
  }

  private HashMap<String, Object> createIpAddressCondition(String conditionValue) {

    HashMap<String, Object> ipConditions = new HashMap<String, Object>();

    if (conditionValue.contains(MapperConstants.SEPARATOR_COMMA)) {
      String[] conditionValues = conditionValue.split(MapperConstants.SEPARATOR_COMMA);
      if (conditionValues != null && conditionValue.length() > 0) {
        LinkedHashSet<HashMap<String, Object>> conditions = null;
        conditions = new LinkedHashSet<HashMap<String, Object>>();
        for (String value : conditionValues) {
          if (!value.isEmpty()) {
            HashMap<String, Object> ipAddressCondition = createIpCondition(value);
            conditions.add(ipAddressCondition);
          }
        }
        ipConditions.put("type", "OR");
        ipConditions.put("conditions", conditions);
      }
    }
    else {
      ipConditions = createIpCondition(conditionValue);
    }
    return ipConditions;
  }

  public HashMap<String, Object> createIpCondition(String value) {
    HashMap<String, Object> ipAddressCondition = null;

    String startIp = "";
    String endIp = "";
    if (value.contains(":")) {
      String[] values = value.split(":");
      if (values != null && values.length > 1) {
        startIp = values[0];
        endIp = values[1];
      }
    }
    else {
      startIp = value;
      endIp = value;
    }
    ipAddressCondition = new HashMap<String, Object>();
    ipAddressCondition.put("type", "IPv4");
    ipAddressCondition.put("startIp", startIp);
    ipAddressCondition.put("endIp", endIp);
    return ipAddressCondition;
  }

  private boolean checkIfAllAuthenticatedUsers(AuthorizationPolicy authorizationPolicy) {
    boolean isAllAuthenticatedUsers = false;
    boolean isSubjectUsersStar = false;
    boolean isSubjectGroupsStar = false;
    boolean isSubjectConditionPresent = false;
    boolean isEnvironmentLdapConditionPresent = false;

    for (AuthorizationPolicyAttribute attribute : authorizationPolicy.getAttributes()) {

      String conditionType = attribute.getConditionType();

      if (BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(7).equals(conditionType)) {
        isAllAuthenticatedUsers = true;
        break;
      }
      else if (BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(1).equals(conditionType)) {
        if ("*".equals(attribute.getConditionValue())) {
          isSubjectUsersStar = true;
        }
        else {
          isSubjectUsersStar = false;
        }
        isSubjectConditionPresent = true;
      }
      else if (BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(2).equals(conditionType)
          || BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(9).equals(conditionType)) {
        if ("*".equals(attribute.getConditionValue())) {
          isSubjectGroupsStar = true;
        }
        else {
          isSubjectGroupsStar = false;
        }
        isSubjectConditionPresent = true;
      }
      else if (BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(3).equals(conditionType)
          || BitMappingEnum.USERPOLICY_RESOLUTIONTYPE.getBitMapValue(5).equals(conditionType)) {
        isEnvironmentLdapConditionPresent = true;
      }
    }

    if ((isSubjectConditionPresent && isEnvironmentLdapConditionPresent)
        || (isSubjectUsersStar && isSubjectGroupsStar)) {
      isAllAuthenticatedUsers = true;
    }

    return isAllAuthenticatedUsers;
  }

  @Override
  public String getId(Object object) throws GenericException {
    return CommonUtils.formatString(((AuthorizationPolicy) object).getName(),
        MapperUtils.getInvalidCharacters());
  }
}
