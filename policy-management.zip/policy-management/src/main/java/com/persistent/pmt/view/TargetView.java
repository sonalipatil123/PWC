package com.persistent.pmt.view;

public interface TargetView {

}
