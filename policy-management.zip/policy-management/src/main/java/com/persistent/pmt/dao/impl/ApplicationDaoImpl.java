package com.persistent.pmt.dao.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.dao.AgentDao;
import com.persistent.pmt.dao.ApplicationDao;
import com.persistent.pmt.model.Agent;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.ApplicationAttributes;
import com.persistent.pmt.model.ApplicationSummary;
import com.persistent.pmt.model.Provider;
import com.persistent.pmt.to.openam.ApplicatonStatsByStateTO;

/**
 * ApplicationDaoImpl
 * 
 * @author Persistent Systems
 */
@PropertySource(value = { "classpath:application.properties" })
@Repository("applicationDao")
@Transactional
public class ApplicationDaoImpl extends BaseDaoImpl implements ApplicationDao {

	@Autowired
	AgentDao agentDao;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@SuppressWarnings("unchecked")
	@Override
	public List<ApplicationSummary> getApplicationsSummary(int env, List<String> states,
			Map<String, Integer> pagingDetails) {

		Criteria criteria = createCriteria(ApplicationSummary.class);
		criteria.add(Restrictions.eq("environment.id", env));
		criteria.createAlias("applicationState", "s").add(Restrictions.in("s.state", states));
		prepareCriteriaForPaging(criteria, pagingDetails);
		criteria.addOrder(Order.desc("id"));

		return (List<ApplicationSummary>) criteria.list();
	}

	@Override
	public Application getApplicationById(int id) {

		Criteria criteria = createCriteria(Application.class);
		criteria.add(Restrictions.eq("id", id));
		return (Application) criteria.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ApplicationSummary> getApplicationsByStateEnvAndIdList(int env, List<Integer> appIdList, List<String> states,
			Map<String, Integer> pagingDetails) {

		Criteria criteria = createCriteria(ApplicationSummary.class);
		criteria.add(Restrictions.in("id", appIdList));
		criteria.add(Restrictions.eq("environment.id", env));
		criteria.createAlias("applicationState", "s").add(Restrictions.in("s.state", states));
		prepareCriteriaForPaging(criteria, pagingDetails);
		criteria.addOrder(Order.desc("id"));

		return (List<ApplicationSummary>) criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ApplicationSummary> getApplicationByName(int env, String name, List<String> states,
			Map<String, Integer> pagingDetails) {

		Criteria criteria = createCriteria(ApplicationSummary.class);
		criteria.add(Restrictions.like("name", "%" + name + "%"));
		criteria.add(Restrictions.eq("environment.id", env));
		criteria.createAlias("applicationState", "s").add(Restrictions.in("s.state", states));
		prepareCriteriaForPaging(criteria, pagingDetails);
		criteria.addOrder(Order.desc("id"));
		
		return (List<ApplicationSummary>) criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ApplicationAttributes> getAppAttributesForDomainName(String domainName) {

		Criteria criteria = createCriteria(ApplicationAttributes.class);
		criteria.add(Restrictions.eq("sourceAttrName", PMTConstants.DOMAIN_NAME));
		criteria.add(Restrictions.like("sourceAttrValue", "%" + domainName + "%"));
		return (List<ApplicationAttributes>) criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ApplicationSummary> getApplicationsForAgentHierachy(int env, List<Agent> agentList, List<String> states,
			Map<String, Integer> pagingDetails) {

		Criteria criteria = createCriteria(ApplicationSummary.class);
		criteria.add(Restrictions.eq("environment.id", env));
		criteria.add(Restrictions.in("agent", agentList));
		criteria.createAlias("applicationState", "s").add(Restrictions.in("s.state", states));
		prepareCriteriaForPaging(criteria, pagingDetails);
		criteria.addOrder(Order.desc("id"));
		
		List<ApplicationSummary> appList = criteria.list();
		if (appList.isEmpty()) {
			// No application found for agent list
			// now we fetch applications from agent hierarchy
			for (Agent agent : agentList) {
				List<ApplicationSummary> appSummaryList = getApplicationByAgentHeirarchy(env, states, pagingDetails, agent);
				if (!appSummaryList.isEmpty())
					appList.addAll(appSummaryList);
			}
		}
		return appList;
	}

	// Direct link of application and agent Id not found
	// Method searches for any application link in Agent hierarchy
	private List<ApplicationSummary> getApplicationByAgentHeirarchy(int env, List<String> states,
			Map<String, Integer> pagingDetails, Agent agent) {

		List<String> agentNames = new ArrayList<>();
		String query = "select source_attr_value from agent_attributes where agent_id = ? "
				+ "and source_attr_name in ('Group_Child', 'Agent_Parent', 'Group_Agents') and source_attr_value is not null";
		List<Map<String, Object>> agentNameListMap = jdbcTemplate.queryForList(query, agent.getId());
		for (Map<String, Object> row : agentNameListMap) {
			String[] names = row.get("source_attr_value").toString().split(",");
			for (String name : names) {
				if (!"null".equals(name))
					agentNames.add(name);
			}
		}
		if (!agentNames.isEmpty()) {
			List<Agent> agentList = agentDao.getAgentListByNames(agentNames);
			return getApplicationsByAgentList(env, agentList, states, pagingDetails);
		} else {
			return Collections.emptyList();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ApplicationSummary> getApplicationsByAgentList(int env, List<Agent> agentList, List<String> states,
			Map<String, Integer> pagingDetails) {

		Criteria criteria = createCriteria(ApplicationSummary.class);
		criteria.add(Restrictions.in("agent", agentList));
		criteria.add(Restrictions.eq("environment.id", env));
		criteria.createAlias("applicationState", "s").add(Restrictions.in("s.state", states));
		prepareCriteriaForPaging(criteria, pagingDetails);
		criteria.addOrder(Order.desc("id"));
		
		return (List<ApplicationSummary>) criteria.list();
	}

	@Override
	public Application saveOrUpdateApplication(Application application) {
		getSession().save(application);
		return application;
	}

	private void prepareCriteriaForPaging(Criteria criteria, Map<String, Integer> pagingDetails) {
		if (pagingDetails != null && !pagingDetails.isEmpty()) {
			if (pagingDetails.containsKey("page")) {
				criteria.setFirstResult((pagingDetails.get("page")) * pagingDetails.get("numberPerPage"));
			}
			if (pagingDetails.containsKey("numberPerPage")) {
				criteria.setMaxResults(pagingDetails.get("numberPerPage"));
			}
		}
	}

	@Override
	public Long getApplicationCount(int environment, List<String> states) {
		Criteria criteria = createCriteria(Application.class);
		criteria.add(Restrictions.eq("environment.id", environment));
		if (states != null && !states.isEmpty()) {
			criteria.createAlias("applicationState", "s").add(Restrictions.in("s.state", states));
		}
		criteria.setProjection(Projections.rowCount());

		return ((Long) criteria.uniqueResult());
	}
	
	@Override
	public Long getApplicationSearchCountByName(int environment, List<String> states, String name) {
		Criteria criteria = createCriteria(Application.class);
		criteria.add(Restrictions.eq("environment.id", environment));
		criteria.add(Restrictions.like("name", "%" + name + "%"));
		if (states != null && !states.isEmpty()) {
			criteria.createAlias("applicationState", "s").add(Restrictions.in("s.state", states));
		}
		criteria.setProjection(Projections.rowCount());

		return ((Long) criteria.uniqueResult());
	}
	
	@Override
	public Long getApplicationSearchCountByIdList(int environment, List<String> states, List<Integer> appIdList) {
		Criteria criteria = createCriteria(Application.class);
		criteria.add(Restrictions.eq("environment.id", environment));
		criteria.add(Restrictions.in("id", appIdList));
		if (states != null && !states.isEmpty()) {
			criteria.createAlias("applicationState", "s").add(Restrictions.in("s.state", states));
		}
		criteria.setProjection(Projections.rowCount());

		return ((Long) criteria.uniqueResult());
	}
	
	@Override
	public Long getApplicationSearchCountByAgentName(int environment, List<String> states, List<Agent> agentList) {
		Criteria criteria = createCriteria(Application.class);
		criteria.add(Restrictions.eq("environment.id", environment));
		criteria.add(Restrictions.in("agent", agentList));
		if (states != null && !states.isEmpty()) {
			criteria.createAlias("applicationState", "s").add(Restrictions.in("s.state", states));
		}
		criteria.setProjection(Projections.rowCount());

		return ((Long) criteria.uniqueResult());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ApplicatonStatsByStateTO> getApplicationStatistics(int environment) {
		Criteria criteria = createCriteria(Application.class);
		criteria.add(Restrictions.eq("environment.id", environment));
		criteria.createAlias("applicationState", "s");
		ProjectionList proList = Projections.projectionList();
		proList.add(Projections.groupProperty("s.state"), "state");
		proList.add(Projections.rowCount(), "count");
		criteria.setProjection(proList);
		criteria.setResultTransformer(Transformers.aliasToBean(ApplicatonStatsByStateTO.class));

		return criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Provider> getProviders(String type) {

		Criteria criteria = createCriteria(Provider.class);
		criteria.add(Restrictions.eq("type", type));
		return criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ApplicationSummary> getApplicationByExactName(String name, int environment) {
		Criteria criteria = createCriteria(ApplicationSummary.class);
		criteria.add(Restrictions.eq("name", name));
		criteria.add(Restrictions.eq("environment.id", environment));
		return (List<ApplicationSummary>) criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Application> getApplicationsById(List<Integer> appIdList) {

		Criteria criteria = createCriteria(Application.class);
		criteria.add(Restrictions.in("id", appIdList));
		return (List<Application>) criteria.list();
	}

  @Override
  public List<Application> updateApplicationsStateById(List<Application> applications,
      com.persistent.pmt.model.ApplicationState state) {
    for (Application app : applications) {
      app.setApplicationState(state);
      app = saveOrUpdateApplication(app);
    }

    return applications;
  }
	
}
