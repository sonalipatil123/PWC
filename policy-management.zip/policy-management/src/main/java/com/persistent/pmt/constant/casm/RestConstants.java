/**
 * RestConstants
 * 
 * Constants class for Restful requests
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.constant.casm;

public interface RestConstants {

  public static final String REQUEST_PATH_REALM_NAME = "realmName";

  public static final String REQUEST_PATH_ID = "id";

  public static final String READ_MODULE_OAUTH2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/oauth2/{id}";

  public static final String READ_MODULE_LDAP_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/ldap/{id}";

  public static final String READ_MODULE_SAML2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/authSaml/{id}";

  public static final String READ_MODULE_CERTIFICAT_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/certificate/{id}";

  public static final String READ_MODULE_WINDOWSSSO_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/windowsdesktopsso/{id}";

  public static final String READ_MODULE_OPENIDCONNECT_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/openidconnect/{id}";

  public static final String READ_MODULE_ANONYMOUS_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/anonymous/{id}";

  public static final String READ_MODULE_HTTP_BASIC_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/httpbasic/{id}";

  public static final String READ_MODULE_CHAIN_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/chains/{id}";

  public static final String READ_REALM_ENDPOINT = "global-config/realms/{id}";

  public static final String READ_POLICY_SET_ENDPOINT = "{realmName}/applications/{id}";

  public static final String READ_RESOURCE_TYPE_ENDPOINT = "{realmName}/resourcetypes/{id}";

  public static final String READ_POLICY_ENDPOINT = "{realmName}/policies/{id}";

  public static final String READ_SESSION_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/services/session";

  public static final String READ_AGENT_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/agents/WebAgent/{id}";

  public static final String READ_SAML2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/federation/entityproviders/saml2/{id}";

  public static final String READ_WSFED_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/federation/entityproviders/ws/{id}";

  public static final String READ_OAUTH2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/agents/OAuth2Client/{id}";

  public static final String READ_OAUTH_GROUP_ENDPOINT =
      "realms/{realmName}/realm-config/agents/groups/OAuth2Client?_queryFilter=true";

  public static final String READ_SAML_PROVIDER_GROUP_ENDPOINT =
      "realms/{realmName}/realm-config/federation/entityproviders/saml2?_queryFilter=true";

  public static final String READ_CIRCLE_OF_TRUST_ENDPOINT =
      "realms/{realmName}/realm-config/federation/circlesoftrust?_fields=_id&_queryFilter=true";

  /* delete product Object Type FOR OPENAM */

  public static final String DELETE_MODULE_OAUTH2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/oauth2/{id}";

  public static final String DELETE_MODULE_LDAP_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/ldap/{id}";

  public static final String DELETE_MODULE_SAML2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/authSaml/{id}";

  public static final String DELETE_MODULE_CERTIFICAT_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/certificate/{id}";

  public static final String DELETE_MODULE_WINDOWSSSO_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/windowsdesktopsso/{id}";

  public static final String DELETE_MODULE_OPENIDCONNECT_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/openidconnect/{id}";

  public static final String DELETE_MODULE_ANONYMOUS_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/anonymous/{id}";

  public static final String DELETE_MODULE_HTTP_BASIC_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/httpbasic/{id}";

  public static final String DELETE_MODULE_CHAIN_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/chains/{id}";

  public static final String DELETE_REALM_ENDPOINT = "global-config/realms/{id}";

  public static final String DELETE_POLICY_SET_ENDPOINT = "{realmName}/applications/{id}";

  public static final String DELETE_RESOURCE_TYPE_ENDPOINT = "{realmName}/resourcetypes/{id}";

  public static final String DELETE_POLICY_ENDPOINT = "{realmName}/policies/{id}";

  public static final String DELETE_SESSION_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/services/session";

  public static final String DELETE_AGENT_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/agents/WebAgent/{id}";

  public static final String DELETE_SAML2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/federation/entityproviders/saml2/{id}";

  public static final String DELETE_WSFED_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/federation/entityproviders/ws/{id}";

  public static final String DELETE_OAUTH2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/agents/OAuth2Client/{id}";

  /* Create product Object Type FOR OPENAM */

  public static final String CREATE_MODULE_OAUTH2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/oauth2/{id}";

  public static final String CREATE_MODULE_LDAP_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/ldap/{id}";

  public static final String CREATE_MODULE_SAML2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/authSaml/{id}";

  public static final String CREATE_MODULE_CERTIFICAT_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/certificate/{id}";

  public static final String CREATE_MODULE_WINDOWSSSO_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/windowsdesktopsso/{id}";

  public static final String CREATE_MODULE_OPENIDCONNECT_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/openidconnect/{id}";

  public static final String CREATE_MODULE_ANONYMOUS_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/anonymous/{id}";

  public static final String CREATE_MODULE_HTTP_BASIC_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/modules/httpbasic/{id}";

  public static final String CREATE_MODULE_CHAIN_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/authentication/chains/{id}";

  public static final String CREATE_REALM_ENDPOINT = "global-config/realms?_action=create";

  public static final String CREATE_POST_POLICY_SET_ENDPOINT =
      "{realmName}/applications/?_action=create";

  public static final String CREATE_PUT_POLICY_SET_ENDPOINT = "{realmName}/applications/{id}";

  public static final String CREATE_PUT_RESOURCE_TYPE_ENDPOINT =
      "{realmName}/resourcetypes/{id}";

  public static final String CREATE_POST_RESOURCE_TYPE_ENDPOINT =
      "{realmName}/resourcetypes/?_action=create";

  public static final String CREATE_PUT_POLICY_ENDPOINT = "{realmName}/policies/{id}";

  public static final String CREATE_POST_POLICY_ENDPOINT =
      "{realmName}/policies/?_action=create";

  public static final String CREATE_SESSION_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/services/session";

  public static final String CREATE_AGENT_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/agents/WebAgent/{id}";

  public static final String CREATE_SAML2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/federation/entityproviders/saml2/{id}";

  public static final String CREATE_POST_SAML2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/federation/entityproviders/saml2?_action=create";

  public static final String CREATE_WSFED_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/federation/entityproviders/ws?_action=create";

  public static final String CREATE_OAUTH2_ENDPOINT =
      "realms/root/realms/{realmName}/realm-config/agents/OAuth2Client/{id}";

  // Authentication url to obtain sso token
  public static final String OPENAM_TOKEN_URL = "realms/{realmName}/authenticate";

}
