package com.persistent.pmt.view.openam;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_NULL)
public class LDAPModuleView implements ModuleView {

  @JsonIgnore
  private String id;
  private int authenticationLevel;
  private int operationTimeout;
  private String[] userSearchStartDN;
  private boolean trustAllServerCertificates;
  private String minimumPasswordLength;
  private String userBindPassword;
  private String connectionHeartbeatTimeUnit;
  private String userBindDN;
  @JsonProperty("openam-auth-ldap-connection-mode")
  private String openamAuthLdapConnectionMode;
  private String[] primaryLdapServer;
  private String[] secondaryLdapServer;
  private boolean beheraPasswordPolicySupportEnabled;
  private String userProfileRetrievalAttribute;
  private String searchScope;
  private int connectionHeartbeatInterval;
  private boolean returnUserDN;
  private String[] userSearchAttributes;
  private String userSearchFilter;
  private String[] profileAttributeMappings;

  public LDAPModuleView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public int getAuthenticationLevel() {
    return authenticationLevel;
  }

  public void setAuthenticationLevel(int authenticationLevel) {
    this.authenticationLevel = authenticationLevel;
  }

  public int getOperationTimeout() {
    return operationTimeout;
  }

  public void setOperationTimeout(int operationTimeout) {
    this.operationTimeout = operationTimeout;
  }

  public String[] getUserSearchStartDN() {
    return userSearchStartDN;
  }

  public void setUserSearchStartDN(String[] userSearchStartDN) {
    this.userSearchStartDN = userSearchStartDN;
  }

  public boolean getTrustAllServerCertificates() {
    return trustAllServerCertificates;
  }

  public void setTrustAllServerCertificates(boolean trustAllServerCertificates) {
    this.trustAllServerCertificates = trustAllServerCertificates;
  }

  public String getMinimumPasswordLength() {
    return minimumPasswordLength;
  }

  public void setMinimumPasswordLength(String minimumPasswordLength) {
    this.minimumPasswordLength = minimumPasswordLength;
  }

  public String getUserBindPassword() {
    return userBindPassword;
  }

  public void setUserBindPassword(String userBindPassword) {
    this.userBindPassword = userBindPassword;
  }

  public String getConnectionHeartbeatTimeUnit() {
    return connectionHeartbeatTimeUnit;
  }

  public void setConnectionHeartbeatTimeUnit(String connectionHeartbeatTimeUnit) {
    this.connectionHeartbeatTimeUnit = connectionHeartbeatTimeUnit;
  }

  public String getUserBindDN() {
    return userBindDN;
  }

  public void setUserBindDN(String userBindDN) {
    this.userBindDN = userBindDN;
  }

  public String getOpenamAuthLdapConnectionMode() {
    return openamAuthLdapConnectionMode;
  }

  public void setOpenamAuthLdapConnectionMode(String openamAuthLdapConnectionMode) {
    this.openamAuthLdapConnectionMode = openamAuthLdapConnectionMode;
  }

  public String[] getPrimaryLdapServer() {
    return primaryLdapServer;
  }

  public void setPrimaryLdapServer(String[] primaryLdapServer) {
    this.primaryLdapServer = primaryLdapServer;
  }

  public String[] getSecondaryLdapServer() {
    return secondaryLdapServer;
  }

  public void setSecondaryLdapServer(String[] secondaryLdapServer) {
    this.secondaryLdapServer = secondaryLdapServer;
  }

  public boolean getBeheraPasswordPolicySupportEnabled() {
    return beheraPasswordPolicySupportEnabled;
  }

  public void setBeheraPasswordPolicySupportEnabled(boolean beheraPasswordPolicySupportEnabled) {
    this.beheraPasswordPolicySupportEnabled = beheraPasswordPolicySupportEnabled;
  }

  public String getUserProfileRetrievalAttribute() {
    return userProfileRetrievalAttribute;
  }

  public void setUserProfileRetrievalAttribute(String userProfileRetrievalAttribute) {
    this.userProfileRetrievalAttribute = userProfileRetrievalAttribute;
  }

  public String getSearchScope() {
    return searchScope;
  }

  public void setSearchScope(String searchScope) {
    this.searchScope = searchScope;
  }

  public int getConnectionHeartbeatInterval() {
    return connectionHeartbeatInterval;
  }

  public void setConnectionHeartbeatInterval(int connectionHeartbeatInterval) {
    this.connectionHeartbeatInterval = connectionHeartbeatInterval;
  }

  public boolean getReturnUserDN() {
    return returnUserDN;
  }

  public void setReturnUserDN(boolean returnUserDN) {
    this.returnUserDN = returnUserDN;
  }

  public String[] getUserSearchAttributes() {
    return userSearchAttributes;
  }

  public void setUserSearchAttributes(String[] userSearchAttributes) {
    this.userSearchAttributes = userSearchAttributes;
  }

  public String getUserSearchFilter() {
    return userSearchFilter;
  }

  public void setUserSearchFilter(String userSearchFilter) {
    this.userSearchFilter = userSearchFilter;
  }

  public String[] getProfileAttributeMappings() {
    return profileAttributeMappings;
  }

  public void setProfileAttributeMappings(String[] profileAttributeMappings) {
    this.profileAttributeMappings = profileAttributeMappings;
  }

  @Override
  public String toString() {
    return "LDAPModuleView [authenticationLevel=" + authenticationLevel + ", operationTimeout="
        + operationTimeout + ", userSearchStartDN=" + Arrays.toString(userSearchStartDN)
        + ", trustAllServerCertificates=" + trustAllServerCertificates
        + ", minimumPasswordLength=" + minimumPasswordLength + ", userBindPassword="
        + userBindPassword + ", connectionHeartbeatTimeUnit=" + connectionHeartbeatTimeUnit
        + ", userBindDN=" + userBindDN + ", openamAuthLdapConnectionMode="
        + openamAuthLdapConnectionMode + ", primaryLdapServer="
        + Arrays.toString(primaryLdapServer) + ", secondaryLdapServer="
        + Arrays.toString(secondaryLdapServer) + ", beheraPasswordPolicySupportEnabled="
        + beheraPasswordPolicySupportEnabled + ", userProfileRetrievalAttribute="
        + userProfileRetrievalAttribute + ", searchScope=" + searchScope
        + ", connectionHeartbeatInterval=" + connectionHeartbeatInterval + ", returnUserDN="
        + returnUserDN + ", userSearchAttributes=" + Arrays.toString(userSearchAttributes)
        + ", userSearchFilter=" + userSearchFilter + ", profileAttributeMappings="
        + Arrays.toString(profileAttributeMappings) + "]";
  }

}
