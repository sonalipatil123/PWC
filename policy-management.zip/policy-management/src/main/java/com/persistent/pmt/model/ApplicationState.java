package com.persistent.pmt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * ApplicationState
 * 
 * Entity model for ApplicationState
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "application_state")
public class ApplicationState {

	@Id
//	@GenericGenerator(name = "app_state_generator", strategy = "increment")
//	@GeneratedValue(generator = "app_state_generator")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "state")
	private String state;

	public ApplicationState() {
		super();
	}

	public ApplicationState(int id, String state) {
		super();
		this.id = id;
		this.state = state;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "ApplicationState [id=" + id + ", state=" + state + "]";
	}

}
