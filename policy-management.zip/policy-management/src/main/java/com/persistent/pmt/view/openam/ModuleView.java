package com.persistent.pmt.view.openam;

import com.persistent.pmt.view.TargetView;

public interface ModuleView extends TargetView{

}
