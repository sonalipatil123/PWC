package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class SAML2ModuleView implements ModuleView {

  @JsonIgnore
  private String id;
  private int authenticationLevel;
  private String authComparison;
  private String forceAuthn;
  private String isPassive;
  private String authnContextDeclRef;
  private String authnContextClassRef;
  private String nameIdFormat;
  private String loginChain;
  private String sloEnabled;
  private String entityName;
  private String allowCreate;
  private String binding;
  private String reqBinding;
  private String metaAlias;
  private String sloRelay;

  public SAML2ModuleView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public int getAuthenticationLevel() {
    return authenticationLevel;
  }

  public void setAuthenticationLevel(int authenticationLevel) {
    this.authenticationLevel = authenticationLevel;
  }

  public String getAuthComparison() {
    return authComparison;
  }

  public void setAuthComparison(String authComparison) {
    this.authComparison = authComparison;
  }

  public String getForceAuthn() {
    return forceAuthn;
  }

  public void setForceAuthn(String forceAuthn) {
    this.forceAuthn = forceAuthn;
  }

  public String getIsPassive() {
    return isPassive;
  }

  public void setIsPassive(String isPassive) {
    this.isPassive = isPassive;
  }

  public String getAuthnContextDeclRef() {
    return authnContextDeclRef;
  }

  public void setAuthnContextDeclRef(String authnContextDeclRef) {
    this.authnContextDeclRef = authnContextDeclRef;
  }

  public String getAuthnContextClassRef() {
    return authnContextClassRef;
  }

  public void setAuthnContextClassRef(String authnContextClassRef) {
    this.authnContextClassRef = authnContextClassRef;
  }

  public String getNameIdFormat() {
    return nameIdFormat;
  }

  public void setNameIdFormat(String nameIdFormat) {
    this.nameIdFormat = nameIdFormat;
  }

  public String getLoginChain() {
    return loginChain;
  }

  public void setLoginChain(String loginChain) {
    this.loginChain = loginChain;
  }

  public String getSloEnabled() {
    return sloEnabled;
  }

  public void setSloEnabled(String sloEnabled) {
    this.sloEnabled = sloEnabled;
  }

  public String getEntityName() {
    return entityName;
  }

  public void setEntityName(String entityName) {
    this.entityName = entityName;
  }

  public String getAllowCreate() {
    return allowCreate;
  }

  public void setAllowCreate(String allowCreate) {
    this.allowCreate = allowCreate;
  }

  public String getBinding() {
    return binding;
  }

  public void setBinding(String binding) {
    this.binding = binding;
  }

  public String getReqBinding() {
    return reqBinding;
  }

  public void setReqBinding(String reqBinding) {
    this.reqBinding = reqBinding;
  }

  public String getMetaAlias() {
    return metaAlias;
  }

  public void setMetaAlias(String metaAlias) {
    this.metaAlias = metaAlias;
  }

  public String getSloRelay() {
    return sloRelay;
  }

  public void setSloRelay(String sloRelay) {
    this.sloRelay = sloRelay;
  }

}
