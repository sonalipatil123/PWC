package com.persistent.pmt.constant.casm;

public enum AuthenticationSchemeTypes {
	AUTHN_SCHEME_HTML_FORM("HTMLForm"), AUTHN_SCHEME_BASIC("Basic"), AUTHN_SCHEME_CUSTOM(
			"Custom"), AUTHN_SCHEME_ANONYMOUS("Anonymous"), AUTHN_SCHEME_NTLM("NTLM"), AUTHN_SCHEME_X509CERTORFORM(
					"X509CertOrForm"), AUTHN_SCHEME_X509CERTANDFORM("X509CertAndForm"), AUTHN_SCHEME_SAML2(
							"SAML2"), AUTHN_SCHEME_X509CERT("X509Cert"), AUTHN_SCHEME_HTMLFORMACE(
									"HTMLFormACE"), AUTHN_SCHEME_WSFED("WSFED"), AUTHN_SCHEME_SAML(
											"SAML"), AUTHN_SCHEME_OAUTH("OAUTH"), AUTHENTICATION_SCHEME_FORM("FORM");
	String authenticationScheme;

	private AuthenticationSchemeTypes(String authnScheme) {
		authenticationScheme = authnScheme;
	}

	public String getValue() {
		return authenticationScheme;
	}
}
