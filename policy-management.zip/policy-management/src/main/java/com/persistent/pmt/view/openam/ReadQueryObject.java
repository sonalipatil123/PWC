package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.constant.casm.Artifact;

@JsonInclude(Include.NON_NULL)
public class ReadQueryObject {
  String id;
  String name;
  Artifact objectType;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Artifact getObjectType() {
    return objectType;
  }

  public void setObjectType(Artifact objectType) {
    this.objectType = objectType;
  }
}
