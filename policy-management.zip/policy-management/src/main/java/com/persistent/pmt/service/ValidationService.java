package com.persistent.pmt.service;

import com.persistent.pmt.exception.GenericException;

public interface ValidationService {

  public void validateApplicationName(String application, int id) throws GenericException;

}
