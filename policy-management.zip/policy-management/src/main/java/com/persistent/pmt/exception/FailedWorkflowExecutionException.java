/**
 * FailedWorkflowExecutionException
 * 
 * Exception for failed workflow executions
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.exception;

import java.util.List;

import com.persistent.pmt.error.WorkflowError;

public class FailedWorkflowExecutionException extends WorkflowException {

	private static final long serialVersionUID = -4411391928171964045L;

	public FailedWorkflowExecutionException() {
		super();
	}

	public FailedWorkflowExecutionException(Throwable t) {
		super(t);
	}

	public FailedWorkflowExecutionException(List<WorkflowError> errors) {
		super(errors);
	}

	public FailedWorkflowExecutionException(String message, List<WorkflowError> errors) {
		super(message, errors);
	}

}
