package com.persistent.pmt.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.commons.context.TargetConnectionTemplate;
import com.persistent.pmt.constant.ApplicationFilter;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.PropertyConstants;
import com.persistent.pmt.constant.casm.PolicyGrammarConstants;
import com.persistent.pmt.dao.EnvironmentDao;
import com.persistent.pmt.dao.ServerConfigurationDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.model.PropertyStore;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.service.ServerConfigurationService;
import com.persistent.pmt.to.openam.EnvironmentPropertiesTO;
import com.persistent.pmt.to.openam.PropsTO;
import com.persistent.pmt.utils.StringUtils;

/**
 * ServerConfigurationServiceImpl
 * 
 * @author Persistent Systems
 */
@PropertySource(value = { "classpath:application.properties" })
@Service("serverConfigurationService")
@Transactional
public class ServerConfigurationServiceImpl implements ServerConfigurationService {

  @Autowired
  EnvironmentDao environmentDao;

  @Autowired
  ServerConfigurationDao serverConfigurationDao;

  @Autowired
  org.springframework.core.env.Environment environment;

  @Autowired
  ServerConfigurationService serverConfigurationService;

  @Autowired
  ThreadLocal<PMTContext> pmtContextThreadLocal;

  @Override
  public GenericResponse<?> getProperties() throws GenericException {

    GenericResponse<Map<String, EnvironmentPropertiesTO>> response = new GenericResponse<>();

    List<PropertyStore> propertyStores = null;

    PMTContext pmtContext = pmtContextThreadLocal.get();

    if (pmtContext.getApplicationFilters() != null
        && !pmtContext.getApplicationFilters().isEmpty()
        && ((String) pmtContext.getApplicationFilters().get(
            ApplicationFilter.ENVIRONMENT.getValue()) != null)) {
      Environment env =
          environmentDao.getEnvironmentByName((String) pmtContext.getApplicationFilters().get(
              ApplicationFilter.ENVIRONMENT.getValue()));
      if (env != null) {
        propertyStores = serverConfigurationDao.getProperties(env.getId());
      }
      else {
        propertyStores = serverConfigurationDao.getProperties();
      }
    }
    else {
      propertyStores = serverConfigurationDao.getProperties();
    }

    if (propertyStores != null && !propertyStores.isEmpty()) {
      // Get map of all env id,name
      List<Environment> envs = environmentDao.getAllEnvironments();

      if (envs != null && !envs.isEmpty()) {

        HashMap<Integer, String> envsIdName = new HashMap<>();
        for (Environment env : envs) {
          envsIdName.put(env.getId(), env.getName());
        }
        // Create response TOs
        Map<String, EnvironmentPropertiesTO> environmentPropsTOs = new HashMap<>();
        for (PropertyStore propertyStore : propertyStores) {
          String envName = envsIdName.get(propertyStore.getEnvironment());

          EnvironmentPropertiesTO environmentPropsTO =
              generateEnvironmentPropertiesTO(environmentPropsTOs, propertyStore, envName);

          environmentPropsTOs.put(envName, environmentPropsTO);
        }

        response.setContent(environmentPropsTOs);
        response.setStatusCode(HttpStatus.OK.value());
        response.setMessage("Server configuraion data has been returned successfully.");
        response.setStatus(GenericResponse.SUCCESS);
      }
      else {
        throw new GenericException(
            "The server successfully processed the request but environments data not found.",
            HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException(
          "The server successfully processed the request but property data not found.",
          HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
    }
    return response;
  }

  private EnvironmentPropertiesTO generateEnvironmentPropertiesTO(
      Map<String, EnvironmentPropertiesTO> environmentPropsTOs, PropertyStore propertyStore,
      String envName) {

    EnvironmentPropertiesTO environmentPropsTO = null;

    if (envName != null && !envName.isEmpty()) {
      environmentPropsTO = environmentPropsTOs.get(envName);
    }

    if (environmentPropsTO == null) {
      environmentPropsTO = new EnvironmentPropertiesTO();
      environmentPropsTO.setEnvironmentId(propertyStore.getEnvironment());
      environmentPropsTO.setEnvironmentName(envName);

      boolean configurationStatus = checkConfigurationStatus(propertyStore.getEnvironment());
      environmentPropsTO.setConfigurationStatus(configurationStatus);
    }

    if (environmentPropsTO.getProperties() == null) {
      PropsTO propsTo = new PropsTO();
      propsTo.setSystem(new HashMap<String, String>());
      propsTo.setTarget(new HashMap<String, String>());
      environmentPropsTO.setProperties(propsTo);
    }

    if (propertyStore.getType().equalsIgnoreCase(PMTConstants.SERVER_CONFIG_SYSTEM)) {
      environmentPropsTO.getProperties().getSystem()
          .put(propertyStore.getKey(), propertyStore.getValue());
    }
    else if (propertyStore.getType().equalsIgnoreCase(PMTConstants.SERVER_CONFIG_TARGET)) {
      environmentPropsTO.getProperties().getTarget()
          .put(propertyStore.getKey(), propertyStore.getValue());
    }
    return environmentPropsTO;
  }

  /**
   * Checks if the system properties required for functioning of PMT
   * available in DB or not
   * 
   * @return
   */
  private boolean checkConfigurationStatus(int envId) {

    String systemProperties = environment.getProperty(PropertyConstants.SYSTEM_PROPERTY);
    Boolean isAvailable = false;

    if (systemProperties != null && !systemProperties.isEmpty()) {
      List<String> props =
          new ArrayList<>(Arrays.asList(systemProperties.split(PropertyConstants.COMMA)));

      List<PropertyStore> properties = serverConfigurationDao.getProperties(envId);

      for (PropertyStore property : properties) {
        if (props.contains(property.getKey()) && !StringUtils.isEmpty(property.getValue())) {
          props.remove(property.getKey());
        }
      }

      if (props.isEmpty()) {
        isAvailable = true;
      }
    }

    return isAvailable;
  }

  @Override
  public String getPropertyValue(String propertyName) throws GenericException {
    String property_Name = "";

    PMTContext pmtContext = pmtContextThreadLocal.get();

    if (pmtContext.getApplicationFilters() != null
        && !pmtContext.getApplicationFilters().isEmpty()
        && ((String) pmtContext.getApplicationFilters().get(
            ApplicationFilter.ENVIRONMENT.getValue()) != null)) {

      Environment environment =
          environmentDao.getEnvironmentByName((String) pmtContext.getApplicationFilters().get(
              ApplicationFilter.ENVIRONMENT.getValue()));

      if (environment != null) {
        PropertyStore property =
            serverConfigurationDao.getPropertyValue(propertyName, environment.getId());

        if (property != null) {
          property_Name = property.getValue();
        }
        else {
          property_Name = "";
        }
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }

    return property_Name;
  }

  @Override
  public GenericResponse<?> createOrUpdateEnvironmentProperties(
      EnvironmentPropertiesTO environmentPropsTO) throws GenericException {

    GenericResponse<Map<String, EnvironmentPropertiesTO>> response = new GenericResponse<>();
    List<PropertyStore> propertyList = new ArrayList<PropertyStore>();
    if (environmentPropsTO != null && environmentPropsTO.getProperties() != null) {
      int environmentId = environmentPropsTO.getEnvironmentId();
      String environmentName = environmentPropsTO.getEnvironmentName();
      Map<String, EnvironmentPropertiesTO> environmentPropsTOs = new HashMap<>();
      if (environmentPropsTO.getProperties().getSystem() != null
          && !environmentPropsTO.getProperties().getSystem().isEmpty()) {
        updateProperties(environmentPropsTO.getProperties().getSystem(), environmentId,
            PMTConstants.SERVER_CONFIG_SYSTEM, propertyList);
      }
      if (environmentPropsTO.getProperties().getTarget() != null
          && !environmentPropsTO.getProperties().getSystem().isEmpty()) {
        updateProperties(environmentPropsTO.getProperties().getTarget(), environmentId,
            PMTConstants.SERVER_CONFIG_TARGET, propertyList);
      }
      for (PropertyStore propertyStore : propertyList) {

        EnvironmentPropertiesTO environmentPropertyTO =
            generateEnvironmentPropertiesTO(environmentPropsTOs, propertyStore, environmentName);

        environmentPropsTOs.put(environmentName, environmentPropertyTO);
      }
      response.setContent(environmentPropsTOs);
      response.setStatusCode(HttpStatus.OK.value());
      response.setMessage("Properties have been created/updated successfully.");
      response.setStatus(GenericResponse.SUCCESS);
    }
    else {
      throw new GenericException("Properties to be created/updated are empty.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }

    return response;
  }

  private List<PropertyStore> updateProperties(Map<String, String> propeties,
      int environmentid, String type, List<PropertyStore> list) {

    for (Entry<String, String> property : propeties.entrySet()) {

      PropertyStore property1 =
          serverConfigurationDao.getPropertyValue(property.getKey(), environmentid);
      if (property1 == null) {
        property1 =
            new PropertyStore(property.getKey(), property.getValue(), environmentid, "", type);
      }
      else {
        property1.setKey(property.getKey());
        property1.setValue(property.getValue());
        property1.setEnvironment(environmentid);
        property1.setType(type);
        property1.setAlias("");
      }
      serverConfigurationDao.createProperty(property1);
      list.add(property1);
    }
    return list;
  }

  @Override
  public GenericResponse<?> getLifecycle() throws GenericException {

    GenericResponse<List<String>> response = new GenericResponse<>();

    List<String> lifecycle = serverConfigurationDao.getLifeCycle();

    response.setContent(lifecycle);
    response.setStatusCode(HttpStatus.OK.value());
    response.setMessage("Lifecycle returned successfully.");
    response.setStatus(GenericResponse.SUCCESS);

    return response;
  }

  @Override
  public TargetConnectionTemplate getTargetConnectionTemplate() throws GenericException {

    TargetConnectionTemplate targetConnectionTemplate = new TargetConnectionTemplate();

    String property_user =
        serverConfigurationService.getPropertyValue(PMTConstants.CONTEXT_ADMIN_USER);
    if (property_user != null) {
      targetConnectionTemplate.setAdminUser(property_user);
    }

    String property_pass =
        serverConfigurationService.getPropertyValue(PMTConstants.CONTEXT_ADMIN_PASSWORD);
    if (property_pass != null) {
      targetConnectionTemplate.setAdminPassword(property_pass);
    }

    String property_version =
        serverConfigurationService.getPropertyValue(PMTConstants.CONTEXT_API_VERSION);
    if (property_version != null) {
      targetConnectionTemplate.setApiVersion(property_version);
    }

    String property_apibaseurl =
        serverConfigurationService.getPropertyValue(PMTConstants.CONTEXT_API_BASE_URL);
    if (property_apibaseurl != null) {
      targetConnectionTemplate.setApiUrl(property_apibaseurl);
    }

    String property_realm =
        serverConfigurationService
            .getPropertyValue(PolicyGrammarConstants.AGENT_POLICY_EVALUATION_REALM);
    if (property_realm != null) {
      targetConnectionTemplate.setRealm(property_realm);
    }

    return targetConnectionTemplate;
  }
}
