package com.persistent.pmt.response.openam;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.response.TargetResponse;
import com.persistent.pmt.view.openam.AuthChainConfiguration;

@JsonInclude(Include.NON_NULL)
public class ModuleChainResponse implements TargetResponse {

	private String _rev;
	private Type _type;
	private String _id;
	private AuthChainConfiguration[] authChainConfiguration;
	private String[] loginSuccessUrl;
	private String[] loginFailureUrl;
	private String[] loginPostProcessClass;

	public ModuleChainResponse() {
		super();
	}

	public String get_rev() {
		return _rev;
	}

	public void set_rev(String _rev) {
		this._rev = _rev;
	}

	public Type get_type() {
		return _type;
	}

	public void set_type(Type _type) {
		this._type = _type;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public AuthChainConfiguration[] getAuthChainConfiguration() {
		return authChainConfiguration;
	}

	public void setAuthChainConfiguration(
			AuthChainConfiguration[] authChainConfiguration) {
		this.authChainConfiguration = authChainConfiguration;
	}

	public String[] getLoginSuccessUrl() {
		return loginSuccessUrl;
	}

	public void setLoginSuccessUrl(String[] loginSuccessUrl) {
		this.loginSuccessUrl = loginSuccessUrl;
	}

	public String[] getLoginFailureUrl() {
		return loginFailureUrl;
	}

	public void setLoginFailureUrl(String[] loginFailureUrl) {
		this.loginFailureUrl = loginFailureUrl;
	}

	public String[] getLoginPostProcessClass() {
		return loginPostProcessClass;
	}

	public void setLoginPostProcessClass(String[] loginPostProcessClass) {
		this.loginPostProcessClass = loginPostProcessClass;
	}

}
