package com.persistent.pmt.service;

import java.util.List;

import org.springframework.data.domain.PageImpl;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.ChangeHistory;
import com.persistent.pmt.model.ChangeHistory.ACTIONS;
import com.persistent.pmt.response.GenericResponse;

public interface ChangeHistoryService {

  public void createChangeHistory(int applicationId, ACTIONS action, String context,
      String status) throws GenericException;

  public List<ChangeHistory> getRecords(int appId, ACTIONS action);

  public GenericResponse<?> getChangeHistoryStatistics() throws GenericException;

  public GenericResponse<?> getProvisionStatistics() throws GenericException;

  public PageImpl<ChangeHistory> getReportData(List<ACTIONS> actions, String status)
      throws GenericException;

}
