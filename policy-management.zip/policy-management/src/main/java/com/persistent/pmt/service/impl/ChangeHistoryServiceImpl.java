package com.persistent.pmt.service.impl;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.commons.context.UserContext;
import com.persistent.pmt.constant.ApplicationFilter;
import com.persistent.pmt.constant.ApplicationState;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.dao.ChangeHistoryDao;
import com.persistent.pmt.dao.EnvironmentDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.ChangeHistory;
import com.persistent.pmt.model.ChangeHistory.ACTIONS;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.service.ApplicationService;
import com.persistent.pmt.service.ChangeHistoryService;
import com.persistent.pmt.utils.StringUtils;

/**
 * @author Persistent Systems
 *
 */
@Service("changeHistoryService")
@Transactional
public class ChangeHistoryServiceImpl implements ChangeHistoryService {

  @Autowired
  ChangeHistoryDao changeHistoryDao;

  @Autowired
  EnvironmentDao environmentDao;

  @Autowired
  ThreadLocal<PMTContext> pmtContextThreadLocal;

  @Autowired
  ApplicationService applicationService;

  @Override
  public void createChangeHistory(int applicationId, ACTIONS action, String context,
      String status) throws GenericException {

    long version = getMaxVersion(applicationId);
    String changeHistoryMessage = null;
    Environment environment = null;

    PMTContext pmtContext = pmtContextThreadLocal.get();
    String user = pmtContext.getUserContext().getUser(UserContext.USER).getUserName();
    if (pmtContext != null
        && pmtContext.getApplicationFilters() != null
        && !pmtContext.getApplicationFilters().isEmpty()
        && ((String) pmtContext.getApplicationFilters().get(
            ApplicationFilter.ENVIRONMENT.getValue()) != null)) {

      environment =
          environmentDao.getEnvironmentByName((String) pmtContext.getApplicationFilters().get(
              ApplicationFilter.ENVIRONMENT.getValue()));

      if (environment != null) {
        if (action.equals(ChangeHistory.ACTIONS.CREATE))
          changeHistoryMessage =
              MessageFormat.format("Created application in PMT with Id {0}.", applicationId);
        if (action.equals(ChangeHistory.ACTIONS.PROVISION))
          changeHistoryMessage =
              MessageFormat.format("Provisioned application in target system with Id {0}.",
                  applicationId);
        if (action.equals(ChangeHistory.ACTIONS.DELETE))
          changeHistoryMessage =
              MessageFormat.format("Deleted application from PMT with Id {0}", applicationId);
        if (action.equals(ChangeHistory.ACTIONS.UPDATE))
          changeHistoryMessage =
              MessageFormat.format("Updated application in PMT with Id {0}.", applicationId);
        if (action.equals(ChangeHistory.ACTIONS.DECOMMISSION))
          changeHistoryMessage =
              MessageFormat.format(
                  "Decommision/delete application from target system with Id {0}.",
                  applicationId);
        if (action.equals(ChangeHistory.ACTIONS.IMPORT_ALL))
          changeHistoryMessage =
              "Bulk Import of Policy Data for selected environment is completed successfully.";
        if (action.equals(ChangeHistory.ACTIONS.IMPORT))
          changeHistoryMessage =
              MessageFormat.format("Import operation completed for Id {0}.", applicationId);
        if (action.equals(ChangeHistory.ACTIONS.LOGIN))
          changeHistoryMessage = MessageFormat.format("User logged in Id {0}.", user);
        if (action.equals(ChangeHistory.ACTIONS.STATE_UPDATE))
          changeHistoryMessage =
              MessageFormat.format("Updated application state in PMT with Id {0}.",
                  applicationId);

        if (StringUtils.isEmpty(context)) {
          context = "";
        }
        changeHistoryDao.logChangeHistory(new ChangeHistory(version, action,
            changeHistoryMessage, user, new Timestamp(System.currentTimeMillis()),
            applicationId, environment, context, status));
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
  }

  @Override
  public List<ChangeHistory> getRecords(int appId, ACTIONS action) {
    List<ChangeHistory> changeHistory = changeHistoryDao.getRecords(appId, action);
    return changeHistory;
  }

  @Override
  public PageImpl<ChangeHistory> getReportData(List<ACTIONS> actions, String status)
      throws GenericException {
    PageRequest pageable = null;
    List<ChangeHistory> totalRecords = null;
    Long totalRecordsCount = null;
    PMTContext pmtContext = pmtContextThreadLocal.get();
    String envName = pmtContext.getEnvironmentValue();
    if (envName != null) {
      Environment env = environmentDao.getEnvironmentByName(envName);
      if (env != null) {

        totalRecords =
            changeHistoryDao.getRecordsByActionAndStatus(env.getId(), actions, status,
                pmtContext.getPagingDetails());
        if (totalRecords != null && !totalRecords.isEmpty()) {
          totalRecordsCount =
              (changeHistoryDao.getRecordCountByActionAndStatus(env.getId(), actions, status,
                  false)).longValue();

          pageable =
              new PageRequest(pmtContext.getPagingDetails().get("page"), pmtContext
                  .getPagingDetails().get("numberPerPage"));
        }
        else {
          throw new GenericException(
              "The server successfully processed the request but report data not found.",
              HttpStatus.NO_CONTENT.value(), GenericResponse.FAILURE);
        }
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
    return new PageImpl<>(totalRecords, pageable, totalRecordsCount);
  }

  @Override
  public GenericResponse<?> getProvisionStatistics() throws GenericException {
    GenericResponse<Object> response = new GenericResponse<>();

    PMTContext pmtContext = pmtContextThreadLocal.get();
    String envName = pmtContext.getEnvironmentValue();
    if (envName != null) {
      Environment environment = environmentDao.getEnvironmentByName(envName);
      if (environment != null) {
        Map<Object, Object> responseMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> statistics = new LinkedHashMap<Object, Object>();
        Map<String, Long> stateCounts = new LinkedHashMap<String, Long>();

        LinkedHashMap<String, Long> applicationStatesMap =
            applicationService.fetchAppStatistics(environment);

        if (applicationStatesMap != null) {
          Long totalReadyToProvisionCount = null;
          Long readyToProvisionCount =
              applicationStatesMap.get(ApplicationState.READY_TO_PROVISION.name());
          Long importedCount = applicationStatesMap.get(ApplicationState.IMPORTED.name());

          if (readyToProvisionCount != null && importedCount != null) {
            totalReadyToProvisionCount = readyToProvisionCount + importedCount;
          }
          else if (readyToProvisionCount != null) {
            totalReadyToProvisionCount = readyToProvisionCount;
          }
          else if (importedCount != null) {
            totalReadyToProvisionCount = importedCount;
          }
          stateCounts.put(PMTConstants.TOTAL,
              applicationStatesMap.get(PMTConstants.TOTAL_FILTERED_COUNT));
          stateCounts.put(PMTConstants.READY_TO_PROVISION,

          totalReadyToProvisionCount);
          stateCounts.put(PMTConstants.SUCCESSFUL,
              applicationStatesMap.get(ApplicationState.PROVISIONED.name()));
        }
        ArrayList<ACTIONS> states = new ArrayList<ACTIONS>();
        states.add(ChangeHistory.ACTIONS.PROVISION);
        stateCounts.put(PMTConstants.FAILED, changeHistoryDao.getRecordCountByActionAndStatus(
            environment.getId(), states, PMTConstants.FAILURE, true));

        statistics.put(PMTConstants.REPORT_PROVISION, stateCounts);

        responseMap.put(PMTConstants.ENVIRONMENT_ID, environment.getId());
        responseMap.put(PMTConstants.ENVIRONMENT_NAME, environment.getName());
        responseMap.put(PMTConstants.STATISTICS, statistics);
        response.setContent(responseMap);
        response.setStatusCode(HttpStatus.OK.value());
        response.setMessage("Report data returned successfully.");
        response.setStatus(GenericResponse.SUCCESS);
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }

    return response;
  }

  @Override
  public GenericResponse<?> getChangeHistoryStatistics() throws GenericException {
    GenericResponse<Object> response = new GenericResponse<>();
    Long totalApplicationCount = null;
    Long totalModifiedCount = null;
    Long provisionedCount = null;
    PMTContext pmtContext = pmtContextThreadLocal.get();
    String envName = pmtContext.getEnvironmentValue();
    if (envName != null) {
      Environment environment = environmentDao.getEnvironmentByName(envName);
      if (environment != null) {
        Map<Object, Object> responseMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> changeHistoryMap = new LinkedHashMap<Object, Object>();
        Map<String, Long> stateCounts = new LinkedHashMap<String, Long>();

        LinkedHashMap<String, Long> applicationStatesMap =
            applicationService.fetchAppStatistics(environment);

        if (applicationStatesMap != null) {
          totalApplicationCount = applicationStatesMap.get(PMTConstants.TOTAL_FILTERED_COUNT);
          provisionedCount = applicationStatesMap.get(ApplicationState.PROVISIONED.name());
        }

        ArrayList<ACTIONS> states = new ArrayList<ACTIONS>();
        states.add(ChangeHistory.ACTIONS.UPDATE);
        totalModifiedCount =
            changeHistoryDao.getRecordCountByActionAndStatus(environment.getId(), states,
                PMTConstants.SUCCESS, true);
        stateCounts.put(PMTConstants.CHANGE_TOTAL, totalApplicationCount);
        stateCounts.put(PMTConstants.CHANGE_MODIFIED, totalModifiedCount);
        stateCounts.put(PMTConstants.CHANGE_PROVISIONED, provisionedCount);

        changeHistoryMap.put(PMTConstants.CHANGE_HISTORY, stateCounts);

        responseMap.put(PMTConstants.ENVIRONMENT_ID, environment.getId());
        responseMap.put(PMTConstants.ENVIRONMENT_NAME, environment.getName());
        responseMap.put(PMTConstants.STATISTICS, changeHistoryMap);

        response.setContent(responseMap);
        response.setStatusCode(HttpStatus.OK.value());
        response.setMessage("Report data returned successfully.");
        response.setStatus(GenericResponse.SUCCESS);
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
    return response;
  }

  private long getMaxVersion(int appId) {
    long version = 0;
    List<Long> versionList = changeHistoryDao.getVersion(appId);

    if (versionList != null && !versionList.isEmpty() && versionList.get(0) != null) {
      version = versionList.get(0);
      version++;
    }
    return version;
  }

}
