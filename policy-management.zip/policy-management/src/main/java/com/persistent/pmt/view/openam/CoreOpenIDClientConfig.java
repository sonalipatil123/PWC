package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CoreOpenIDClientConfig {

  private Attribute claims;
  private Attribute postLogoutRedirectUri;
  private Attribute clientSessionUri;
  private Attribute defaultMaxAge;
  private Attribute defaultMaxAgeEnabled;
  private Attribute jwtTokenLifetime;

  public CoreOpenIDClientConfig() {
    super();
  }

  public Attribute getClaims() {
    return claims;
  }

  public void setClaims(Attribute claims) {
    this.claims = claims;
  }

  public Attribute getPostLogoutRedirectUri() {
    return postLogoutRedirectUri;
  }

  public void setPostLogoutRedirectUri(Attribute postLogoutRedirectUri) {
    this.postLogoutRedirectUri = postLogoutRedirectUri;
  }

  public Attribute getClientSessionUri() {
    return clientSessionUri;
  }

  public void setClientSessionUri(Attribute clientSessionUri) {
    this.clientSessionUri = clientSessionUri;
  }

  public Attribute getDefaultMaxAge() {
    return defaultMaxAge;
  }

  public void setDefaultMaxAge(Attribute defaultMaxAge) {
    this.defaultMaxAge = defaultMaxAge;
  }

  public Attribute getDefaultMaxAgeEnabled() {
    return defaultMaxAgeEnabled;
  }

  public void setDefaultMaxAgeEnabled(Attribute defaultMaxAgeEnabled) {
    this.defaultMaxAgeEnabled = defaultMaxAgeEnabled;
  }

  public Attribute getJwtTokenLifetime() {
    return jwtTokenLifetime;
  }

  public void setJwtTokenLifetime(Attribute jwtTokenLifetime) {
    this.jwtTokenLifetime = jwtTokenLifetime;
  }

  @Override
  public String toString() {
    return "CoreOpenIDClientConfig [claims=" + claims + ", postLogoutRedirectUri="
        + postLogoutRedirectUri + ", clientSessionUri=" + clientSessionUri + ", defaultMaxAge="
        + defaultMaxAge + ", defaultMaxAgeEnabled=" + defaultMaxAgeEnabled
        + ", jwtTokenLifetime=" + jwtTokenLifetime + "]";
  }

}
