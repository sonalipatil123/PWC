/**
 * ApplicationStateDao
 * 
 * DAO interface for Application State
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.dao;

import com.persistent.pmt.model.ApplicationState;

public interface ApplicationStateDao {

  public ApplicationState getApplicationStateByName(String name);

}
