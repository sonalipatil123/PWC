package com.persistent.pmt.response.openam;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude
public class OpenIDConnectIdTokenBearerModuleResponse implements ModuleResponse {

	private String useSubClaimIfNoMatch;
	private String[] acceptedAuthorizedParties;
	private String cryptoContextValue;
	private String accountProviderClass;
	private String cryptoContextType;
	private String principalMapperClass;
	private String[] jwtToLdapAttributeMappings;
	private String idTokenIssuer;
	private String idTokenHeaderName;
	private String clientSecret;
	private String audienceName;
	private String _rev;
	private Type _type;
	private String _id;

	public OpenIDConnectIdTokenBearerModuleResponse() {
		super();
	}

	public String getUseSubClaimIfNoMatch() {
		return useSubClaimIfNoMatch;
	}

	public void setUseSubClaimIfNoMatch(String useSubClaimIfNoMatch) {
		this.useSubClaimIfNoMatch = useSubClaimIfNoMatch;
	}

	public String[] getAcceptedAuthorizedParties() {
		return acceptedAuthorizedParties;
	}

	public void setAcceptedAuthorizedParties(String[] acceptedAuthorizedParties) {
		this.acceptedAuthorizedParties = acceptedAuthorizedParties;
	}

	public String getCryptoContextValue() {
		return cryptoContextValue;
	}

	public void setCryptoContextValue(String cryptoContextValue) {
		this.cryptoContextValue = cryptoContextValue;
	}

	public String getAccountProviderClass() {
		return accountProviderClass;
	}

	public void setAccountProviderClass(String accountProviderClass) {
		this.accountProviderClass = accountProviderClass;
	}

	public String getCryptoContextType() {
		return cryptoContextType;
	}

	public void setCryptoContextType(String cryptoContextType) {
		this.cryptoContextType = cryptoContextType;
	}

	public String getPrincipalMapperClass() {
		return principalMapperClass;
	}

	public void setPrincipalMapperClass(String principalMapperClass) {
		this.principalMapperClass = principalMapperClass;
	}

	public String[] getJwtToLdapAttributeMappings() {
		return jwtToLdapAttributeMappings;
	}

	public void setJwtToLdapAttributeMappings(
			String[] jwtToLdapAttributeMappings) {
		this.jwtToLdapAttributeMappings = jwtToLdapAttributeMappings;
	}

	public String getIdTokenIssuer() {
		return idTokenIssuer;
	}

	public void setIdTokenIssuer(String idTokenIssuer) {
		this.idTokenIssuer = idTokenIssuer;
	}

	public String getIdTokenHeaderName() {
		return idTokenHeaderName;
	}

	public void setIdTokenHeaderName(String idTokenHeaderName) {
		this.idTokenHeaderName = idTokenHeaderName;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getAudienceName() {
		return audienceName;
	}

	public void setAudienceName(String audienceName) {
		this.audienceName = audienceName;
	}

	public String get_rev() {
		return _rev;
	}

	public void set_rev(String _rev) {
		this._rev = _rev;
	}

	public Type get_type() {
		return _type;
	}

	public void set_type(Type _type) {
		this._type = _type;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

}
