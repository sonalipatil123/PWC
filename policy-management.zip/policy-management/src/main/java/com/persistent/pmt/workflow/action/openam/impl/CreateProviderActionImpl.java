package com.persistent.pmt.workflow.action.openam.impl;

import java.text.MessageFormat;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.WorkflowType;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.constant.casm.AuthenticationSchemeTypes;
import com.persistent.pmt.constant.casm.PolicyGrammarConstants;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.exception.WorkflowException;
import com.persistent.pmt.executor.openam.OAuthExecutor;
import com.persistent.pmt.executor.openam.OAuthGroupExecutor;
import com.persistent.pmt.executor.openam.ProviderExecutor;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.model.Provider;
import com.persistent.pmt.response.openam.OAuthGroupResponse;
import com.persistent.pmt.response.openam.Result;
import com.persistent.pmt.service.ServerConfigurationService;
import com.persistent.pmt.utils.AuditWriter;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.view.openam.OAuth2ClientView;
import com.persistent.pmt.view.openam.ProviderView;
import com.persistent.pmt.view.openam.ReadQueryObject;
import com.persistent.pmt.workflow.action.CreateAction;
import com.persistent.pmt.workflow.action.mapper.casm.OAuth2ClientViewMapper;
import com.persistent.pmt.workflow.action.mapper.casm.ProviderViewMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component("createProviderAction")
@Order(value = 4)
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class CreateProviderActionImpl implements CreateAction {

  private static final Logger logger = Logger.getLogger(CreateProviderActionImpl.class);

  @Autowired
  @Qualifier("openAMSAMLProviderExecutor")
  ProviderExecutor samlProviderExecutor;

  @Autowired
  ProviderViewMapper providerViewMapper;

  @Autowired
  @Qualifier("openAMOAuth2ClientExecutor")
  OAuthExecutor oauthClientExecutor;

  @Autowired
  OAuth2ClientViewMapper oauth2ClientViewMapper;

  @Autowired
  @Qualifier("oAuthGroupExecutor")
  OAuthGroupExecutor oauthGroupExecutor;

  @Autowired
  @Qualifier("serverConfigurationService")
  ServerConfigurationService serverConfigurationService;

  @Autowired
  AuditWriter auditWriter;

  @Autowired
  Environment environment;

  @Override
  public Object execute(Object object, List<WorkflowError> errors,
      WorkFlowContext workFlowContext) throws Exception {

    logger.log(Level.INFO, "CreateProviderActionImpl execute START");
    Application application = (Application) object;
    String authenticationScheme = application.getDefaultAuthScheme().getType();
    Artifact artifact = null;
    try {
      if (authenticationScheme != null
          && (authenticationScheme.equals(AuthenticationSchemeTypes.AUTHN_SCHEME_SAML2
              .getValue())
              || authenticationScheme.equals(AuthenticationSchemeTypes.AUTHN_SCHEME_SAML
                  .getValue()) || authenticationScheme
                .equals(AuthenticationSchemeTypes.AUTHN_SCHEME_WSFED.getValue()))) {

				if (PMTConstants.PROVIDER_WSFEDSP.equals(application.getProvider().getType())) {
					artifact = Artifact.WSFED_PROVIDER;
				} else {
					artifact = Artifact.SAML_PROVIDER;
				}
        ProviderView providerView =
            (ProviderView) providerViewMapper.getMappedObject(application, workFlowContext);


        samlProviderExecutor.create(
            application,
            providerView,
            Product.OPENAM,
            artifact,
            CommonUtils.createOpenAMParamMap(providerView.get_id(),
                workFlowContext.getRealmName()), workFlowContext);
        workFlowContext.setProviderNameForRollbackOnFailure(providerView.get_id());

        // Audit log for success
        auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS, environment
            .getProperty(AuditPropertyConstants.TARGET_ARTIFACT_ACTION_DETAILS_SUCCESS),
            workFlowContext.getProviderAuditData().toString(), new Object[] { artifact.name(),
                providerView.get_id(), application.getName(), application.getId() });
      }
      else if (authenticationScheme != null
          && authenticationScheme.equals(AuthenticationSchemeTypes.AUTHN_SCHEME_OAUTH
              .getValue())) {
        artifact = Artifact.OAUTH_CLIENT;
        createOAuthClient(application, workFlowContext);

      }
    }
    catch (HttpClientErrorException ex) {
      // Audit Log for artifact creation failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE),
          workFlowContext.getProviderAuditData().toString(), new Object[] { artifact.name(),
              application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getResponseBodyAsString());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    catch (Exception ex) {
      // Audit Log for artifact creation failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE),
          workFlowContext.getProviderAuditData().toString(), new Object[] { artifact.name(),
              application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    logger.log(Level.INFO, "CreateProviderActionImpl execute END");
    return application;
  }

  @Override
  public Object rollback(Object object, List<WorkflowError> errors,
      WorkFlowContext workFlowContext) throws Exception {
    logger.log(Level.INFO, "CreateProviderActionImpl rollback START");
    Application application = (Application) object;

    Artifact artifact = null;
    if (application != null && application.getDefaultAuthScheme() != null) {
      String authenticationSchemeType = application.getDefaultAuthScheme().getType();

      if (authenticationSchemeType != null) {
        if (authenticationSchemeType.equals(AuthenticationSchemeTypes.AUTHN_SCHEME_SAML2
            .getValue())
            || authenticationSchemeType.equals(AuthenticationSchemeTypes.AUTHN_SCHEME_SAML
                .getValue())) {
          artifact = Artifact.SAML_PROVIDER;
        }
        else if (authenticationSchemeType.equals(AuthenticationSchemeTypes.AUTHN_SCHEME_WSFED
            .getValue())) {
          artifact = Artifact.WSFED_PROVIDER;
        }
        else if (authenticationSchemeType.equals(AuthenticationSchemeTypes.AUTHN_SCHEME_OAUTH
            .getValue())) {
          artifact = Artifact.OAUTH_CLIENT;
        }
      }
      try {
        if (workFlowContext.getProviderNameForRollbackOnFailure() != null
            && !workFlowContext.getProviderNameForRollbackOnFailure().isEmpty()) {
          logger.log(Level.INFO, "CreateProviderActionImpl rollback STARTED");
          samlProviderExecutor.delete(
              application,
              Product.OPENAM,
              artifact,
              CommonUtils.createOpenAMParamMap(
                  workFlowContext.getProviderNameForRollbackOnFailure(),
                  workFlowContext.getRealmName()), workFlowContext);

          // Audit log for rollback success
          auditWriter.write(
              ACTIONS.PROVISION,
              PMTConstants.SUCCESS,
              environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_SUCCESS),
              "",
              new Object[] { artifact.name(),
                  workFlowContext.getProviderNameForRollbackOnFailure(), application.getId(),
                  application.getName() });
        }
      }
      catch (HttpClientErrorException ex) {
        // Audit log for rollback failure
        auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
            environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
            new Object[] { artifact.name(), application.getName(), application.getId() });

        WorkflowError error =
            new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
                application.getId(), 0, "Failed to rollback Provider for application: "
                    + ex.getResponseBodyAsString());
        errors.add(error);
        logger.log(Level.ERROR, "Failed to rollback Provider for application with id: "
            + application.getId(), ex);
        throw new WorkflowException(ex);
      }
      catch (Exception ex) {
        // Audit log for rollback failure
        auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
            environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
            new Object[] { artifact.name(), application.getName(), application.getId() });

        WorkflowError error =
            new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
                application.getId(), 0, "Failed to rollback Provider for application: "
                    + ex.getLocalizedMessage());
        errors.add(error);
        logger.log(Level.ERROR, "Failed to rollback Provider for application  with id: "
            + application.getId(), ex);
        throw new WorkflowException(ex);
      }
    }
    logger.log(Level.INFO, "CreateProviderActionImpl rollback END");
    return application;
  }

  private void createOAuthClient(Application application, WorkFlowContext workFlowContext)
      throws GenericException, Exception {
    String clientGroup = null;
    Provider provider = application.getProvider();
    if (provider != null) {
      boolean oauthGroupEnabled =
          Boolean.parseBoolean((String) serverConfigurationService
              .getPropertyValue(PolicyGrammarConstants.OAUTH_GROUP_ENABLED));

      if (oauthGroupEnabled) {
        // checking if OAUTH GROUP is available in openAM or not
        clientGroup = provider.getSourceAttrValueByName(PolicyGrammarConstants.CLIENT_GROUP);
        ReadQueryObject readQueryObject = new ReadQueryObject();
        readQueryObject.setId(clientGroup);
        readQueryObject.setObjectType(Artifact.OAUTH_GROUP);
        if (clientGroup != null && !clientGroup.isEmpty()
            && !isOAuthClientGroupAvailable(readQueryObject, workFlowContext, clientGroup)) {

          // Audit log for OAuth group not available
          workFlowContext
              .getProviderAuditData()
              .append(
                  MessageFormat.format(
                      environment
                          .getProperty(AuditPropertyConstants.TARGET_ACTION_PROVIDER_OAUTHGROUP_NOT_AVAILABLE),
                      new Object[] { clientGroup }));

          throw new GenericException(
              "OAuthGroup with specified name is not available. Please check the configuration.");
        }
      }
      OAuth2ClientView oauth2ClientView =
          (OAuth2ClientView) oauth2ClientViewMapper.getMappedObject(application,
              workFlowContext);

      if (oauth2ClientView != null) {
        oauthClientExecutor.create(
            application,
            oauth2ClientView,
            Product.OPENAM,
            Artifact.OAUTH_CLIENT,
            CommonUtils.createOpenAMParamMap(oauth2ClientView.getId(),
                workFlowContext.getRealmName()), workFlowContext);

        workFlowContext.setProviderNameForRollbackOnFailure(oauth2ClientView.getId());

        boolean copyOAuthGroupProperty =
            Boolean.parseBoolean(serverConfigurationService
                .getPropertyValue(PolicyGrammarConstants.COPY_OAUTH_GROUP_PROPERTY));
        // if copyOAuthGroupProperty is true then make an update(same
        // PUT API call again) call for OAuthClient
        if (clientGroup != null && !clientGroup.isEmpty() && copyOAuthGroupProperty) {

          oauthClientExecutor.create(
              application,
              oauth2ClientView,
              Product.OPENAM,
              Artifact.OAUTH_CLIENT,
              CommonUtils.createOpenAMParamMap(oauth2ClientView.getId(),
                  workFlowContext.getRealmName()), workFlowContext);

          // Audit Log for OAuthGroup properties are
          // applied to OAuth Client

          workFlowContext
              .getProviderAuditData()
              .append(
                  MessageFormat.format(
                      environment
                          .getProperty(AuditPropertyConstants.TARGET_ACTION_PROVIDER_OAUTHGROUP_PROPERTIES_APPLIED_TO_OAUTHCLIENT),
                      new Object[] { clientGroup }));
        }

        // Audit log for successful creation of OAuth Client
        auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS, environment
            .getProperty(AuditPropertyConstants.TARGET_ACTION_PROVIDER_OF_TYPE_OUTH_SUCCESS),
            workFlowContext.getProviderAuditData().toString(),
            new Object[] { "OAuth2.0 Client", oauth2ClientView.getId(), application.getName(),
                application.getId() });

      }
      else {
        throw new Exception(
            "CreateProviderActionImpl | Provision Application Failed | OAuthClientView is empty");
      }
    }
    else {
      throw new Exception(
          "CreateProviderActionImpl | Provision Application Failed | Provider is empty");
    }
  }

  private boolean isOAuthClientGroupAvailable(Object object, WorkFlowContext context,
      String agentGroup) {
    boolean status = false;

    OAuthGroupResponse oauthGroupResponse =
        (OAuthGroupResponse) oauthGroupExecutor.get(object, Product.OPENAM,
            Artifact.OAUTH_GROUP,
            CommonUtils.createOpenAMParamMap(agentGroup, context.getRealmName()), context);
    if (oauthGroupResponse != null) {
      for (Result result : oauthGroupResponse.getResult()) {
        if (result.get_id().equalsIgnoreCase(agentGroup)) {
          status = true;
          return status;
        }
      }
    }
    return status;
  }
}
