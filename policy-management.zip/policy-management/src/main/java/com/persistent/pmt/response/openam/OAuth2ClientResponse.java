package com.persistent.pmt.response.openam;

import com.persistent.pmt.response.TargetResponse;
import com.persistent.pmt.view.openam.AdvancedOAuth2ClientConfig;
import com.persistent.pmt.view.openam.CoreOAuth2ClientConfig;
import com.persistent.pmt.view.openam.CoreOpenIDClientConfig;

public class OAuth2ClientResponse implements TargetResponse {

	private String _id;
	private CoreOpenIDClientConfig coreOpenIDClientConfig;
	private SignEncOAuth2ClientConfig signEncOAuth2ClientConfig;
	private CoreOAuth2ClientConfig coreOAuth2ClientConfig;
	private AdvancedOAuth2ClientConfig advancedOAuth2ClientConfig;

	public OAuth2ClientResponse() {
		super();
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public CoreOpenIDClientConfig getCoreOpenIDClientConfig() {
		return coreOpenIDClientConfig;
	}

	public void setCoreOpenIDClientConfig(
			CoreOpenIDClientConfig coreOpenIDClientConfig) {
		this.coreOpenIDClientConfig = coreOpenIDClientConfig;
	}

	public SignEncOAuth2ClientConfig getSignEncOAuth2ClientConfig() {
		return signEncOAuth2ClientConfig;
	}

	public void setSignEncOAuth2ClientConfig(
			SignEncOAuth2ClientConfig signEncOAuth2ClientConfig) {
		this.signEncOAuth2ClientConfig = signEncOAuth2ClientConfig;
	}

	public CoreOAuth2ClientConfig getCoreOAuth2ClientConfig() {
		return coreOAuth2ClientConfig;
	}

	public void setCoreOAuth2ClientConfig(
			CoreOAuth2ClientConfig coreOAuth2ClientConfig) {
		this.coreOAuth2ClientConfig = coreOAuth2ClientConfig;
	}

	public AdvancedOAuth2ClientConfig getAdvancedOAuth2ClientConfig() {
		return advancedOAuth2ClientConfig;
	}

	public void setAdvancedOAuth2ClientConfig(
			AdvancedOAuth2ClientConfig advancedOAuth2ClientConfig) {
		this.advancedOAuth2ClientConfig = advancedOAuth2ClientConfig;
	}

}