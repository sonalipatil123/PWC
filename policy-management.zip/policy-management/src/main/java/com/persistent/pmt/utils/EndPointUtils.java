package com.persistent.pmt.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.constant.casm.RestConstants;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component
public class EndPointUtils {

  public static String getEndPoint(Product product, Artifact artifact, HttpMethod operation,
      WorkFlowContext context, Map<String, String> params) {
    String endPoint = "";
    if (product.equals(Product.OPENAM)) {
      endPoint = getEndPointForOpenAMArtifacts(artifact, operation, context, params);
    }
    return endPoint;
  }

  private static String getEndPointForOpenAMArtifacts(Artifact artifact, HttpMethod operation,
      WorkFlowContext context, Map<String, String> params) {
    String url = "";

    if(Artifact.AUTHENTICATION.equals(artifact)){
    	url =
                context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                    + RestConstants.OPENAM_TOKEN_URL;
    }
    if (Artifact.REALM.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_REALM_ENDPOINT;
      }
      else if (HttpMethod.POST.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_REALM_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_REALM_ENDPOINT;
      }
    }
    else if (Artifact.RESOURCE_TYPE.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_RESOURCE_TYPE_ENDPOINT;
      }
      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_PUT_RESOURCE_TYPE_ENDPOINT;
      }
      else if (HttpMethod.POST.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_POST_RESOURCE_TYPE_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_RESOURCE_TYPE_ENDPOINT;
      }
    }
    else if (Artifact.POLICY.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_POLICY_ENDPOINT;
      }

      else if (HttpMethod.POST.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_POST_POLICY_ENDPOINT;
      }
      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_PUT_POLICY_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_POLICY_ENDPOINT;
      }
    }
    else if (Artifact.POLICY_SET.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_POLICY_SET_ENDPOINT;
      }

      else if (HttpMethod.POST.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_POST_POLICY_SET_ENDPOINT;
      }
      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_PUT_POLICY_SET_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_POLICY_SET_ENDPOINT;
      }
    }
    else if (Artifact.SESSION.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_SESSION_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_SESSION_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_SESSION_ENDPOINT;
      }

    }
    else if (Artifact.MODULE_ANONYMOUS.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_MODULE_ANONYMOUS_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_MODULE_ANONYMOUS_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_MODULE_ANONYMOUS_ENDPOINT;
      }

    }
    else if (Artifact.MODULE_LDAP.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_MODULE_LDAP_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_MODULE_LDAP_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_MODULE_LDAP_ENDPOINT;
      }

    }
    else if (Artifact.MODULE_SAML.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_MODULE_SAML2_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_MODULE_SAML2_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_MODULE_SAML2_ENDPOINT;
      }

    }
    else if (Artifact.MODULE_OAUTH2.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_MODULE_OAUTH2_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_MODULE_OAUTH2_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_MODULE_OAUTH2_ENDPOINT;
      }
    }
    else if (Artifact.MODULE_OPENID_CONNECT.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_MODULE_OPENIDCONNECT_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_MODULE_OPENIDCONNECT_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_MODULE_OPENIDCONNECT_ENDPOINT;
      }
    }
    else if (Artifact.MODULE_CERT.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_MODULE_CERTIFICAT_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_MODULE_CERTIFICAT_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_MODULE_CERTIFICAT_ENDPOINT;
      }
    }
    else if (Artifact.MODULE_WIN_DESKTOP_SSO.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_MODULE_WINDOWSSSO_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_MODULE_WINDOWSSSO_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_MODULE_WINDOWSSSO_ENDPOINT;
      }
    }
    else if (Artifact.MODULE_HTTP_BASIC.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_MODULE_HTTP_BASIC_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_MODULE_HTTP_BASIC_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_MODULE_HTTP_BASIC_ENDPOINT;
      }
    }

    else if (Artifact.MODULE_CHAIN.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_MODULE_CHAIN_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_MODULE_CHAIN_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_MODULE_CHAIN_ENDPOINT;
      }
    }
    else if (Artifact.AGENT.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_AGENT_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_AGENT_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_AGENT_ENDPOINT;
      }
    }
    else if (Artifact.OAUTH_CLIENT.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_OAUTH2_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_OAUTH2_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_OAUTH2_ENDPOINT;
      }
    }
    else if (Artifact.SAML_PROVIDER.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_SAML2_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_SAML2_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_SAML2_ENDPOINT;
      }
      else if (HttpMethod.POST.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_POST_SAML2_ENDPOINT;
      }
    }
    else if (Artifact.WSFED_PROVIDER.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_WSFED_ENDPOINT;
      }

      else if (HttpMethod.PUT.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_WSFED_ENDPOINT;
      }
      else if (HttpMethod.DELETE.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.DELETE_SAML2_ENDPOINT;
      }
      else if (HttpMethod.POST.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.CREATE_WSFED_ENDPOINT;
      }
    }
    else if (Artifact.OAUTH_GROUP.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_OAUTH_GROUP_ENDPOINT;
      }
    }
    else if (Artifact.SAML_PROVIDER_GROUP.equals(artifact)) {
      if (HttpMethod.GET.equals(operation)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_SAML_PROVIDER_GROUP_ENDPOINT;
      }
    }

    else if (Artifact.CIRCLE_OF_TRUST.equals(artifact)) {
      if (operation.equals(HttpMethod.GET)) {
        url =
            context.getToken(PMTConstants.CONTEXT_API_BASE_URL)
                + RestConstants.READ_CIRCLE_OF_TRUST_ENDPOINT;
      }
    }

    String finalURL = createFinalUrl(url, params);

    return finalURL;
  }

  private static String createFinalUrl(String url, Map<String, String> params) {
    StringBuilder updatedUrl = new StringBuilder();
    StringTokenizer tokenizedUrl = new StringTokenizer(url, "{}");
    List<String> buildURL = new ArrayList<String>();
    while (tokenizedUrl.hasMoreElements()) {
      buildURL.add(tokenizedUrl.nextElement().toString());
    }
    for (String str : buildURL) {
      if (null == params.get(str)) {
        updatedUrl = updatedUrl.append(str);
      }
      else {
        updatedUrl = updatedUrl.append(params.get(str));
      }
    }

    if (params.containsKey("name")) {
      updatedUrl =
          new StringBuilder((updatedUrl.toString()).substring(0, updatedUrl.lastIndexOf("/")));
      // updatedUrl.append("?_queryFilter=name%20eq%20'" +
      // params.get("name") + "'");
      updatedUrl.append("?_queryFilter=name eq '" + params.get("name") + "'");

    }
    return updatedUrl.toString();
  }
}
