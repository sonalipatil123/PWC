package com.persistent.pmt.metadata.generator.descriptors.sp;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.persistent.pmt.metadata.generator.XmlUtils.XmlSourceGenerator;
import com.persistent.pmt.metadata.generator.descriptors.core.Descriptor;

@Component
public class SpDescriptor implements Descriptor {

	@Autowired
	XmlSourceGenerator xmlSourceGenerator;

	private String template;

	@Override
	public String getXMLData(Map<String, String> tokenMap) {
		String xmlSource = xmlSourceGenerator.generateXmlSource(tokenMap, template);
		return xmlSource;
	}

	@Override
	public void setTemplatePath(String templatePath) {
		template = templatePath;
	}

	@Override
	public Map<String, String> getDescriptorData(Map<String, String> tokenMap) {
		return tokenMap;

	}

}
