package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.persistent.pmt.view.TargetView;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ModuleChainView implements TargetView {

  @JsonIgnore
  private String id;
  private AuthChainConfiguration[] authChainConfiguration;
  private String[] loginSuccessUrl;
  private String[] loginFailureUrl;
  private String[] loginPostProcessClass;

  public ModuleChainView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public AuthChainConfiguration[] getAuthChainConfiguration() {
    return authChainConfiguration;
  }

  public void setAuthChainConfiguration(AuthChainConfiguration[] authChainConfiguration) {
    this.authChainConfiguration = authChainConfiguration;
  }

  public String[] getLoginSuccessUrl() {
    return loginSuccessUrl;
  }

  public void setLoginSuccessUrl(String[] loginSuccessUrl) {
    this.loginSuccessUrl = loginSuccessUrl;
  }

  public String[] getLoginFailureUrl() {
    return loginFailureUrl;
  }

  public void setLoginFailureUrl(String[] loginFailureUrl) {
    this.loginFailureUrl = loginFailureUrl;
  }

  public String[] getLoginPostProcessClass() {
    return loginPostProcessClass;
  }

  public void setLoginPostProcessClass(String[] loginPostProcessClass) {
    this.loginPostProcessClass = loginPostProcessClass;
  }
}