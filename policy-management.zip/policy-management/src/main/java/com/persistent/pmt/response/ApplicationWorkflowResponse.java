/**
 * ApplicationWorkflowResponse
 * 
 * Workflow response for Application
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.model.Application;

@JsonInclude(Include.NON_NULL)
public class ApplicationWorkflowResponse extends ApplicationResponse {

	private String status;
	private List<WorkflowError> errors;

	public ApplicationWorkflowResponse() {
		super();
	}

	public ApplicationWorkflowResponse(Application application) {
		super(application);
	}

	public ApplicationWorkflowResponse(Application application, String status, List<WorkflowError> errors) {
		super(application);
		this.status = status;
		this.errors = errors;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<WorkflowError> getErrors() {
		return errors;
	}

	public void setErrors(List<WorkflowError> errors) {
		this.errors = errors;
	}

}
