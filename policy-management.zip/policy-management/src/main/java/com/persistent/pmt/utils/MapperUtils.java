package com.persistent.pmt.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.persistent.pmt.model.AgentAttributes;
import com.persistent.pmt.model.ApplicationAttributes;
import com.persistent.pmt.model.ApplicationSummary;

@Component
public class MapperUtils {

  private static Pattern pattern = Pattern.compile("(?i)[(\\[{]?null[)\\]}]?");
  private static final String invalidCharacters = "[,;<>=/+\" \\\\]";

  /**
   * Creates an ApplicationSummaryTO from ApplicationSummary Entity
   * object
   * 
   * @param applicationSummaryEntity
   * @return
   */
  public static Map<String, String> getApplicationSummaryTO(
      ApplicationSummary applicationSummaryEntity) {

    Map<String, String> applicationSummaryTO = null;
    if (applicationSummaryEntity != null) {
      applicationSummaryTO = new HashMap<String, String>();

      applicationSummaryTO.put("id", String.valueOf(applicationSummaryEntity.getId()));
      applicationSummaryTO.put("name", applicationSummaryEntity.getName());
      applicationSummaryTO.put("pepType", applicationSummaryEntity.getPepType());
      applicationSummaryTO.put("enabled", String.valueOf(applicationSummaryEntity.isEnabled()));
      applicationSummaryTO.put("description", applicationSummaryEntity.getDescription());
      if (applicationSummaryEntity.getApplicationState() != null) {
        applicationSummaryTO.put("state", applicationSummaryEntity.getApplicationState()
            .getState());
      }
      if (applicationSummaryEntity.getOriginator() != null) {
        applicationSummaryTO.put("originator", applicationSummaryEntity.getOriginator()
            .getName());
      }
      if (applicationSummaryEntity.getEnvironment() != null) {
        applicationSummaryTO.put("environment", applicationSummaryEntity.getEnvironment()
            .getName());
      }
      if (applicationSummaryEntity.getAgent() != null) {
        applicationSummaryTO.put("agentName", applicationSummaryEntity.getAgent().getName());
      }

      List<ApplicationAttributes> attributes = applicationSummaryEntity.getAttributes();
      if (attributes != null && attributes.size() > 0) {
        for (ApplicationAttributes attribute : attributes) {
          applicationSummaryTO.put(attribute.getSourceAttrName().toLowerCase(),
              attribute.getSourceAttrValue());
        }

      }
      List<AgentAttributes> agentAttributes =
          applicationSummaryEntity.getAgent().getAttributes();
      String updatedAttr = "";
      if (agentAttributes != null && agentAttributes.size() > 0) {

        StringBuilder value = new StringBuilder();
        for (AgentAttributes attribute : agentAttributes) {
					if ("Group_Agents".equalsIgnoreCase(attribute.getSourceAttrName())
							&& attribute.getSourceAttrValue() != null) {
            value = createValue(value);
            if (attribute.getSourceAttrValue() != null) {
              if (attribute.getSourceAttrValue().contains("null")) {
                updatedAttr = removeNullString(attribute.getSourceAttrValue());
                value.append("Group Agents:" + updatedAttr.replaceAll(",", "=>"));
              }
              else {
                value.append("Group Agents:"
                    + attribute.getSourceAttrValue().replace(",", "=>"));
              }
            }
          }
					else if ("Group_Parent".equalsIgnoreCase(attribute.getSourceAttrName())
							&& attribute.getSourceAttrValue() != null) {
            value = createValue(value);
            if (attribute.getSourceAttrValue() != null) {
              if (attribute.getSourceAttrValue().contains("null")) {
                updatedAttr = removeNullString(attribute.getSourceAttrValue());
                value.append("Group Parents:" + updatedAttr.replaceAll(",", "=>"));
              }
              else {
                value.append("Group Parents:"
                    + attribute.getSourceAttrValue().replaceAll(",", "=>"));
              }
            }
          }
					else if ("Group_Child".equalsIgnoreCase(attribute.getSourceAttrName())
							&& attribute.getSourceAttrValue() != null) {
            value = createValue(value);
            if (attribute.getSourceAttrValue() != null) {
              if (attribute.getSourceAttrValue().contains("null")) {
                updatedAttr = removeNullString(attribute.getSourceAttrValue());
                value.append("Group Children:" + updatedAttr.replaceAll(",", "=>"));
              }
              else {
                value.append("Group Children:"
                    + attribute.getSourceAttrValue().replaceAll(",", "=>"));
              }
            }
          }
					else if ("Agent_Parent".equalsIgnoreCase(attribute.getSourceAttrName())
							&& attribute.getSourceAttrValue() != null) {
            value = createValue(value);
            if (attribute.getSourceAttrValue() != null) {
              if (attribute.getSourceAttrValue().contains("null")) {
                updatedAttr = removeNullString(attribute.getSourceAttrValue());
                value.append("Agent Parents:" + updatedAttr.replaceAll(",", "=>"));
              }
              else {
                value.append("Agent Parents:"
                    + attribute.getSourceAttrValue().replaceAll(",", "=>"));
              }
            }
          }

          if (value != null && value.length() > 0) {
            applicationSummaryTO.put("agentHierarchy", value.toString());
          }
          else {
            applicationSummaryTO.put("agentHierarchy", "");
          }

        }
      }
    }
    return applicationSummaryTO;

  }

  private static StringBuilder createValue(StringBuilder value) {
    if (value.length() > 1 && !(value.toString().endsWith(","))) {
      value.append(",");
    }
    return value;
  }

  static String removeNullString(String value) {
    if (StringUtils.isEmpty(value)) {
      return org.apache.commons.lang3.StringUtils.EMPTY;
    }

    Matcher matcher = pattern.matcher(value);
    return matcher.replaceAll(org.apache.commons.lang3.StringUtils.EMPTY);
  }

  public static String getInvalidCharacters() {
    return invalidCharacters;
  }
}
