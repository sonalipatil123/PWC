package com.persistent.pmt.workflow.action.openam.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.WorkflowType;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.WorkflowException;
import com.persistent.pmt.executor.openam.ModuleChainExecutor;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.utils.AuditWriter;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.view.openam.ModuleChainView;
import com.persistent.pmt.view.openam.ModuleView;
import com.persistent.pmt.workflow.action.CreateAction;
import com.persistent.pmt.workflow.action.mapper.casm.ModuleChainViewMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component("createModuleChainAction")
@Order(value = 6)
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class CreateModuleChainActionImpl implements CreateAction {

  private static final Logger logger = Logger.getLogger(CreateModuleChainActionImpl.class);

  @Autowired
  @Qualifier("openAMModuleChainExecutor")
  ModuleChainExecutor moduleChainExecutor;

  @Autowired
  ModuleChainViewMapper moduleChainMapper;

  @Autowired
  AuditWriter auditWriter;

  @Autowired
  Environment environment;

  @Override
  public Object execute(Object object, List<WorkflowError> errors,
      WorkFlowContext workFlowContext) throws Exception {
    logger.log(Level.INFO, "CreateModuleChainActionImpl execute START");
    Application application = (Application) object;

    List<ModuleView> moduleViews = workFlowContext.getModuleViews();
    try {
      Map<String, Object> params = new HashMap<String, Object>();
      params.put("application", application);
      params.put("moduleViews", moduleViews);

      ModuleChainView moduleChainView =
          (ModuleChainView) moduleChainMapper.getMappedObject(params, workFlowContext);

      moduleChainExecutor.create(
          application,
          moduleChainView,
          Product.OPENAM,
          Artifact.MODULE_CHAIN,
          CommonUtils.createOpenAMParamMap(moduleChainView.getId(),
              workFlowContext.getRealmName()), workFlowContext);
      workFlowContext.setModuleChainRollbackOnFailure(true);

      // Audit log for success
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS, environment
          .getProperty(AuditPropertyConstants.TARGET_ARTIFACT_ACTION_DETAILS_SUCCESS),
          workFlowContext.getModuleChainAuditData().toString(), new Object[] { "ModuleChain",
              moduleChainView.getId(), application.getName(), application.getId() });
    }
    catch (HttpClientErrorException ex) {

      // Audit log for failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE),
          workFlowContext.getModuleChainAuditData().toString(), new Object[] { "ModuleChain",
              application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getResponseBodyAsString());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    catch (Exception ex) {
      // Audit log for failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE),
          workFlowContext.getModuleChainAuditData().toString(), new Object[] { "ModuleChain",
              application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);

    }

    logger.log(Level.INFO, "CreateModuleChainActionImpl execute END");
    return application;
  }

  @Override
  public Object rollback(Object object, List<WorkflowError> errors, WorkFlowContext context)
      throws Exception {
    logger.log(Level.INFO, "CreateModuleChainActionImpl rollback START");
    Application application = (Application) object;
    try {
      if (context.isModuleChainRollbackOnFailure()) {
        logger.log(Level.INFO, "CreateModuleChainActionImpl rollback STARTED");
        moduleChainExecutor.delete(
            application,
            Product.OPENAM,
            Artifact.MODULE_CHAIN,
            CommonUtils.createOpenAMParamMap(moduleChainMapper.getId(object),
                context.getRealmName()), context);
        // Audit log for rollback success
        auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS,
            environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_SUCCESS), "",
            new Object[] { "ModuleChain", moduleChainMapper.getId(object), application.getId(),
                application.getName() });
      }
      logger.log(Level.INFO, "CreateModuleChainActionImpl rollback END");
    }
    catch (HttpClientErrorException ex) {

      // Audit log for rollback failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
          new Object[] { "ModuleChain", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to rollback Module Chain for application: "
                  + ex.getResponseBodyAsString());
      errors.add(error);
      logger.log(Level.ERROR, "Failed to rollback Module Chain for application  with id: "
          + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    catch (Exception ex) {
      // Audit log for rollback failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
          new Object[] { "ModuleChain", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to rollback Module Chain for application: "
                  + ex.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR, "Failed to rollback Module Chain for application with id: "
          + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    return application;
  }
}
