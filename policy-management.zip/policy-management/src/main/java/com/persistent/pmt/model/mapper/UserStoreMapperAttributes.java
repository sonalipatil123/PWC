package com.persistent.pmt.model.mapper;

public class UserStoreMapperAttributes {

  private boolean userAndPassword;
  private boolean secureConnection;
  private String[] loginAttributes;
  private String[] primaryServers;
  private String[] searchRoots;
  private String searchScope;
  private String searchTimeOut;
  private String userLookupEnd;
  private String userLookupStart;
  private String binDN;
  private String password;
  private String name;

  public boolean isUserAndPassword() {
    return userAndPassword;
  }

  public void setUserAndPassword(boolean userAndPassword) {
    this.userAndPassword = userAndPassword;
  }

  public boolean isSecureConnection() {
    return secureConnection;
  }

  public void setSecureConnection(boolean secureConnection) {
    this.secureConnection = secureConnection;
  }

  public String[] getPrimaryServers() {
    return primaryServers;
  }

  public void setPrimaryServers(String[] primaryServers) {
    this.primaryServers = primaryServers;
  }

  public String[] getLoginAttributes() {
    return loginAttributes;
  }

  public void setLoginAttributes(String[] loginAttributes) {
    this.loginAttributes = loginAttributes;
  }

  public String[] getSearchRoots() {
    return searchRoots;
  }

  public void setSearchRoots(String[] searchRoots) {
    this.searchRoots = searchRoots;
  }

  public String getSearchScope() {
    return searchScope;
  }

  public void setSearchScope(String searchScope) {
    this.searchScope = searchScope;
  }

  public String getSearchTimeOut() {
    return searchTimeOut;
  }

  public void setSearchTimeOut(String searchTimeOut) {
    this.searchTimeOut = searchTimeOut;
  }

  public String getUserLookupEnd() {
    return userLookupEnd;
  }

  public void setUserLookupEnd(String userLookupEnd) {
    this.userLookupEnd = userLookupEnd;
  }

  public String getUserLookupStart() {
    return userLookupStart;
  }

  public void setUserLookupStart(String userLookupStart) {
    this.userLookupStart = userLookupStart;
  }

  public String getBinDN() {
    return binDN;
  }

  public void setBinDN(String binDN) {
    this.binDN = binDN;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
