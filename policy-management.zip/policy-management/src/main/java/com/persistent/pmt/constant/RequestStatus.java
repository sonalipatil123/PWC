/**
 * RequestStatus
 * 
 * Enum for status values of requests
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.constant;

public enum RequestStatus {

	SUCCESS("Success"), FAILED("Failed"), PARTIAL_SUCCESS("Partially Successful"), BAD_REQUEST("Bad Request");

	private final String value;

	private RequestStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
