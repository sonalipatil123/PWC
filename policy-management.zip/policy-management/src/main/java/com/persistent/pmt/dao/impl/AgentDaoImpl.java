package com.persistent.pmt.dao.impl;

import java.util.List;
import java.util.ListIterator;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.dao.AgentDao;
import com.persistent.pmt.model.Agent;

/**
 * AgentDaoImpl
 * 
 * Implementation of AgentDao
 * 
 * @author Persistent Systems
 */
@PropertySource(value = { "classpath:application.properties" })
@Repository("agentDao")
@Transactional
public class AgentDaoImpl extends BaseDaoImpl implements AgentDao {

  @Autowired
  ThreadLocal<PMTContext> pmtContextThreadLocal;

  /**
   * This method creates an agent into PMT database
   */
  @Override
  public Agent createAgent(Agent agent) {
    getSession().save(agent);
    return agent;
  }

  @SuppressWarnings("unchecked")
  @Override
  public List<Agent> getAgentsByName(String name, String envName) {

    Criteria criteria = createCriteria(Agent.class);
    criteria.add(Restrictions.like("name", "%" + name + "%"));
    criteria.add(Restrictions.like("id", "%" + envName));
    return criteria.list();

  }

  @SuppressWarnings("unchecked")
  @Override
  public List<Agent> getAgentListByNames(List<String> agentNames) {
    Criteria criteria = createCriteria(Agent.class);
    criteria.add(Restrictions.in("name", agentNames));
    List<Agent> agentList = criteria.list();
    ListIterator<Agent> agentListIterator = agentList.listIterator();
    String environment = pmtContextThreadLocal.get().getEnvironmentValue();
    while (agentListIterator.hasNext()) {
      Agent agent = agentListIterator.next();
      if (!agent.getId().contains(environment)) {
        agentListIterator.remove();
      }
    }
    return agentList;
  }
}