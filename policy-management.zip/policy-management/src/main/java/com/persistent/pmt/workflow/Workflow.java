/**
 * Workflow
 * 
 * Base interface for workflow
 * 
 *  @author Persistent Systems
 */

package com.persistent.pmt.workflow;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.exception.WorkflowException;

public interface Workflow {

  public void start(Object object) throws WorkflowException,GenericException;

}
