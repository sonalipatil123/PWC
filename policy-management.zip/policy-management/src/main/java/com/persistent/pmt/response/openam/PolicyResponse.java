package com.persistent.pmt.response.openam;

import java.util.HashSet;
import java.util.Map;

import com.persistent.pmt.response.TargetResponse;
import com.persistent.pmt.view.openam.Condition;
import com.persistent.pmt.view.openam.ResponseAttributes;
import com.persistent.pmt.view.openam.Subject;

public class PolicyResponse implements TargetResponse {

  private String _id;
  private String _rev;
  private boolean active;
  private String[] resources;
  private String description;
  private String applicationName;
  private String name;
  private Map<String, Boolean> actionValues;
  private String resourceTypeUuid;
  private String creationDate;
  private String createdBy;
  private String lastModifiedBy;
  private String lastModifiedDate;
  private Condition condition;
  private Subject subject;
  private HashSet<ResponseAttributes> resourceAttributes;

  public PolicyResponse() {
    super();
  }

  public PolicyResponse(String _id, String _rev, boolean active, String[] resources,
      String description, String applicationName, String name,
      Map<String, Boolean> actionValues, String resourceTypeUuid, String creationDate,
      String createdBy, String lastModifiedBy, String lastModifiedDate, Condition condition,
      Subject subject, HashSet<ResponseAttributes> resourceAttributes) {
    super();
    this._id = _id;
    this._rev = _rev;
    this.active = active;
    this.resources = resources;
    this.description = description;
    this.applicationName = applicationName;
    this.name = name;
    this.actionValues = actionValues;
    this.resourceTypeUuid = resourceTypeUuid;
    this.creationDate = creationDate;
    this.createdBy = createdBy;
    this.lastModifiedBy = lastModifiedBy;
    this.lastModifiedDate = lastModifiedDate;
    this.condition = condition;
    this.subject = subject;
    this.resourceAttributes = resourceAttributes;
  }

  public String get_id() {
    return _id;
  }

  public void set_id(String _id) {
    this._id = _id;
  }

  public String get_rev() {
    return _rev;
  }

  public void set_rev(String _rev) {
    this._rev = _rev;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  public String[] getResources() {
    return resources;
  }

  public void setResources(String[] resources) {
    this.resources = resources;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getApplicationName() {
    return applicationName;
  }

  public void setApplicationName(String applicationName) {
    this.applicationName = applicationName;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Map<String, Boolean> getActionValues() {
    return actionValues;
  }

  public void setActionValues(Map<String, Boolean> actionValues) {
    this.actionValues = actionValues;
  }

  public String getResourceTypeUuid() {
    return resourceTypeUuid;
  }

  public void setResourceTypeUuid(String resourceTypeUuid) {
    this.resourceTypeUuid = resourceTypeUuid;
  }

  public String getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(String creationDate) {
    this.creationDate = creationDate;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public String getLastModifiedBy() {
    return lastModifiedBy;
  }

  public void setLastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
  }

  public String getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(String lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  public Condition getCondition() {
    return condition;
  }

  public void setCondition(Condition condition) {
    this.condition = condition;
  }

  public Subject getSubject() {
    return subject;
  }

  public void setSubject(Subject subject) {
    this.subject = subject;
  }

  public HashSet<ResponseAttributes> getResourceAttributes() {
    return resourceAttributes;
  }

  public void setResourceAttributes(HashSet<ResponseAttributes> resourceAttributes) {
    this.resourceAttributes = resourceAttributes;
  }
}
