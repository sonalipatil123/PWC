package com.persistent.pmt.workflow.action;


public interface ReadAction extends Action {
}
