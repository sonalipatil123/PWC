package com.persistent.pmt.service;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.to.openam.ProviderTO;

public interface ProviderService {
	  public GenericResponse<?> getProviders(String type) throws GenericException;

	  public GenericResponse<?> createProviders(ProviderTO providerTO) throws GenericException;

}
