package com.persistent.pmt.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.dao.AuthenticationSchemeDao;
import com.persistent.pmt.model.AuthenticationScheme;

/**
 * AuthenticationSchemeDaoImpl
 * 
 * Implementation for AuthenticationSchemeDao
 * 
 * @author Persistent Systems
 */
@PropertySource(value = { "classpath:application.properties" })
@Repository("authenticationSchemeDao")
@Transactional
public class AuthenticationSchemeDaoImpl extends BaseDaoImpl implements AuthenticationSchemeDao {

  /**
   * This method creates an authentication scheme in PMT database
   */
  @Override
  public AuthenticationScheme createAuthenticationScheme(
      AuthenticationScheme authenticationScheme) {
    getSession().save(authenticationScheme);
    return authenticationScheme;
  }

  @Override
  public AuthenticationScheme getAuthenticationSchemeByName(String authenicationSchemeName) {
    Criteria criteria = createCriteria(AuthenticationScheme.class);
    criteria.add(Restrictions.eq("name", authenicationSchemeName));

    return (AuthenticationScheme) criteria.uniqueResult();
  }

  @Override
  public List<AuthenticationScheme> getAuthNSchemesByType(String authNSchemeType, String env) {
    Criteria criteria = createCriteria(AuthenticationScheme.class);
    criteria.add(Restrictions.eq("type", authNSchemeType));
    if(null!=env)
    	criteria.add(Restrictions.like("id", "%" + env));

    return (List<AuthenticationScheme>) criteria.list();
  }
  
}
