package com.persistent.pmt.dao;

import java.util.List;
import java.util.Map;

import com.persistent.pmt.model.Agent;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.ApplicationAttributes;
import com.persistent.pmt.model.ApplicationSummary;
import com.persistent.pmt.model.Provider;
import com.persistent.pmt.to.openam.ApplicatonStatsByStateTO;

/**
 * ApplicationDao
 * 
 * @author Persistent Systems
 */
public interface ApplicationDao {

	/**
	 * Get summary of all applications
	 * 
	 * @param environment
	 * @return
	 */
	public List<ApplicationSummary> getApplicationsSummary(int environment, List<String> states,
			Map<String, Integer> pagingDetails);

	/**
	 * Get the details of an application identified by id
	 * 
	 * @param id
	 * @return
	 */
	public Application getApplicationById(int id);

	/**
	 * Get the details of an application identified by name
	 * 
	 * @param name
	 * @return
	 */
	public List<ApplicationSummary> getApplicationByName(int environment, String name, List<String> states,
			Map<String, Integer> pagingDetails);

	/**
	 * Get the details of an application identified by agentId
	 * 
	 * @param agentId
	 * @return
	 */
	public List<ApplicationSummary> getApplicationsForAgentHierachy(int environment,List<Agent> agentList,List<String> states,
			Map<String, Integer> pagingDetails);

	/**
	 * Get the details of an applications identified by list of agentId
	 * 
	 * @param agentList
	 * @return
	 */
	public List<ApplicationSummary> getApplicationsByAgentList(int env, List<Agent> agentList, List<String> states,
			Map<String, Integer> pagingDetails);

	/**
	 * Update application state
	 * 
	 * @param application
	 * @return
	 */
	public Application saveOrUpdateApplication(Application application);

	/**
	 * Get application id by domain name
	 * 
	 * @param domainName
	 * @return
	 */
	public List<ApplicationAttributes> getAppAttributesForDomainName(String domainName);

	/**
	 * Get applications by appIdList
	 * 
	 * @param appIdList
	 * @return
	 */
	public List<ApplicationSummary> getApplicationsByStateEnvAndIdList(int environment, List<Integer> appIdList, List<String> states,
			Map<String, Integer> pagingDetails);

	/**
	 * Get count of all the applications
	 * 
	 * @param environment
	 * @param states
	 * @return
	 */
	public Long getApplicationCount(int environment, List<String> states);

	public List<ApplicatonStatsByStateTO> getApplicationStatistics(int environment);

	public List<Provider> getProviders(String string);

	/**
	 * This method returns application By its exact name
	 * 
	 * @param name
	 * @return
	 */
	public List<ApplicationSummary> getApplicationByExactName(String name,int environment);
	
	/**
	 * Get count of applications matching given name
	 * 
	 * @param environment
	 * @param states
	 * @return
	 */
	public Long getApplicationSearchCountByName(int environment, List<String> states, String name);
	
	/**
	 * Get count of applications by application Id's
	 * 
	 * @param environment
	 * @param states
	 * @return
	 */
	public Long getApplicationSearchCountByIdList(int environment, List<String> states, List<Integer> appIdList);
		
	/**
	 * Get count of applications by application Id's
	 * 
	 * @param environment
	 * @param states
	 * @return
	 */
	public Long getApplicationSearchCountByAgentName(int environment, List<String> states, List<Agent> agentList);
	
	/**
	 * Get applications by application Id's
	 * 
	 * @param application Id list
	 * @return List of application objects
	 */
  public List<Application> getApplicationsById(List<Integer> appIdList);


  public List<Application> updateApplicationsStateById(List<Application> res,
      com.persistent.pmt.model.ApplicationState state);

}
