package com.persistent.pmt.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * AuthenticationPolicy
 * 
 * Entity model for AuthenticationPolicy
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "authentication_policy")
public class AuthenticationPolicy {

  @Id
//  @SequenceGenerator(name = "SEQ_AUTHENTICATION_POLICY", sequenceName = "SEQ_AUTHENTICATION_POLICY", allocationSize = 1)
//  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_AUTHENTICATION_POLICY")
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "id")
  private int id;

  @Column(name = "name")
  private String name;

  @JsonIgnore
  @Transient
  private int targetId;

  @Column(name = "description")
  private String description;

  @Column(name = "system_specific")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean systemSpecific;

  @Column(name = "life_cycle")
  private String lifeCycle;

  @JsonIgnore
  @Column(name = "target_name")
  private String targetName;

  @Column(name = "authentication_level")
  private int authenticationLevel;

  @ManyToOne
  @JoinColumn(name = "authentication_scheme_id")
  private AuthenticationScheme authenticationScheme;

  @Column(name = "enabled")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean enabled;

  @Column(name = "default_policy")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean defaultEntity;

  @Transient
  private List<Resource> resources;

  @Transient
  private List<Response> responses;

  @ManyToOne
  @JoinColumn(name = "application_id")
  private Application application;

  public AuthenticationPolicy() {
    super();
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getTargetId() {
    return targetId;
  }

  public void setTargetId(int targetId) {
    this.targetId = targetId;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public boolean isSystemSpecific() {
    return systemSpecific;
  }

  public void setSystemSpecific(boolean systemSpecific) {
    this.systemSpecific = systemSpecific;
  }

  public String getLifeCycle() {
    return lifeCycle;
  }

  public void setLifeCycle(String lifeCycle) {
    this.lifeCycle = lifeCycle;
  }

  public boolean isDefaultEntity() {
    return defaultEntity;
  }

  public void setDefaultEntity(boolean defaultEntity) {
    this.defaultEntity = defaultEntity;
  }

  public String getTargetName() {
    return targetName;
  }

  public void setTargetName(String targetName) {
    this.targetName = targetName;
  }

  public AuthenticationScheme getAuthenticationScheme() {
    return authenticationScheme;
  }

  public void setAuthenticationScheme(AuthenticationScheme authenticationScheme) {
    this.authenticationScheme = authenticationScheme;
  }

  public boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }

  public int getAuthenticationLevel() {
    return authenticationLevel;
  }

  public void setAuthenticationLevel(int authenticationLevel) {
    this.authenticationLevel = authenticationLevel;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("AuthenticationPolicy [id=");
    builder.append(id);
    builder.append(", name=");
    builder.append(name);
    builder.append(", targetId=");
    builder.append(targetId);
    builder.append(", description=");
    builder.append(description);
    builder.append(", systemSpecific=");
    builder.append(systemSpecific);
    builder.append(", lifeCycle=");
    builder.append(lifeCycle);
    builder.append(", targetName=");
    builder.append(targetName);
    builder.append(", authenticationLevel=");
    builder.append(authenticationLevel);
    builder.append(", authenticationScheme=");
    builder.append(authenticationScheme);
    builder.append(", enabled=");
    builder.append(enabled);
    builder.append(", defaultEntity=");
    builder.append(defaultEntity);
    builder.append(", resources=");
    builder.append(resources);
    builder.append(", responses=");
    builder.append(responses);
    builder.append("]");
    return builder.toString();
  }

}
