package com.persistent.pmt.to.openam;

import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuthorizationPolicyTO {

  private int id;
  private String name;
  private String description;
  private Boolean enabled;
  private List<String> resources;
  private List<ConditionTO> conditions;
  private String authorizationRule;
  private List<ResponseTO> responses;
  private Set<String> actions;

  public AuthorizationPolicyTO() {
    super();
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Boolean getEnabled() {
    return enabled;
  }

  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  public List<String> getResources() {
    return resources;
  }

  public void setResources(List<String> resources) {
    this.resources = resources;
  }

  public List<ConditionTO> getConditions() {
    return conditions;
  }

  public void setConditions(List<ConditionTO> conditions) {
    this.conditions = conditions;
  }

  public String getAuthorizationRule() {
    return authorizationRule;
  }

  public void setAuthorizationRule(String authorizationRule) {
    this.authorizationRule = authorizationRule;
  }

  public List<ResponseTO> getResponses() {
    return responses;
  }

  public void setResponses(List<ResponseTO> responses) {
    this.responses = responses;
  }

  public Set<String> getActions() {
    return actions;
  }

  public void setActions(Set<String> actions) {
    this.actions = actions;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("AuthorizationPolicyTO [id=");
    builder.append(id);
    builder.append(", name=");
    builder.append(name);
    builder.append(", description=");
    builder.append(description);
    builder.append(", enabled=");
    builder.append(enabled);
    builder.append(", resources=");
    builder.append(resources);
    builder.append(", conditions=");
    builder.append(conditions);
    builder.append(", authorizationRule=");
    builder.append(authorizationRule);
    builder.append(", responses=");
    builder.append(responses);
    builder.append(", actions=");
    builder.append(actions);
    builder.append("]");
    return builder.toString();
  }

}
