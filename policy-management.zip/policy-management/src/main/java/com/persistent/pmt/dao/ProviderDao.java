package com.persistent.pmt.dao;

import java.util.List;

import com.persistent.pmt.model.Provider;
import com.persistent.pmt.model.ProviderAttributes;

/**
 * ProviderDao Interface
 * 
 * @author Persistent Systems
 */
public interface ProviderDao {

  public Provider createProvider(Provider provider);
  
  public Provider getProviderByName(String name);
  
  public void updateProvider(Provider provider);
  
  public Provider getProviderById(int providerId) ;
  
  public List<ProviderAttributes> getProviderAttributesBySourceAttr(String sourceAttrName, String sourceAttrValue);

}
