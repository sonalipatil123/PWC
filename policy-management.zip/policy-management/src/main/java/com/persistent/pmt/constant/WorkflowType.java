/**
 * WorkflowType
 * 
 * Enum for workflow execution types
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.constant;

public enum WorkflowType {

  PROVISION, ROLLBACK, DECOMMISSION, UPDATE, DELETE, REPROVISION, IMPORT, READ

}
