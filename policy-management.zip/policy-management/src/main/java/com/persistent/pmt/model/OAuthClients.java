package com.persistent.pmt.model;

import java.util.List;

public class OAuthClients {

	private List<OAuthClient> items;

	public OAuthClients() {
		super();
	}

	public List<OAuthClient> getItems() {
		return items;
	}

	public void setItems(List<OAuthClient> items) {
		this.items = items;
	}

}
