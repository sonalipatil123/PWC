package com.persistent.pmt.response.openam;

import com.persistent.pmt.response.TargetResponse;

public class ProviderResponse implements TargetResponse {
  private String _id;
  private String _rev;
  private String entityConfig;
  private String metadata;
  private Type _type;

  public String get_id() {
    return _id;
  }

  public void set_id(String _id) {
    this._id = _id;
  }

  public String get_rev() {
    return _rev;
  }

  public void set_rev(String _rev) {
    this._rev = _rev;
  }

  public String getEntityConfig() {
    return entityConfig;
  }

  public void setEntityConfig(String entityConfig) {
    this.entityConfig = entityConfig;
  }

  public String getMetadata() {
    return metadata;
  }

  public void setMetadata(String metadata) {
    this.metadata = metadata;
  }

  public Type get_type() {
    return _type;
  }

  public void set_type(Type _type) {
    this._type = _type;
  }

  @Override
  public String toString() {
    return "SAMLProviderResponse [_rev=" + _rev + ", _type=" + _type + ", entityConfig="
        + entityConfig + ", _id=" + _id + ", metadata=" + metadata + "]";
  }

}
