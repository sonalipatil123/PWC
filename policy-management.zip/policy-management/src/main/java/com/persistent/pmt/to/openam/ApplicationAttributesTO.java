package com.persistent.pmt.to.openam;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * ApplicationAttributes
 * 
 * Entity model for ApplicationAttributes
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationAttributesTO {

	private String sourceAttrName;
	private String sourceAttrValue;
	private String targetAttrName;
	private String targetAttrValue;

	public ApplicationAttributesTO() {
		super();
	}

  public String getSourceAttrName() {
    return sourceAttrName;
  }

  public void setSourceAttrName(String sourceAttrName) {
    this.sourceAttrName = sourceAttrName;
  }

  public String getSourceAttrValue() {
    return sourceAttrValue;
  }

  public void setSourceAttrValue(String sourceAttrValue) {
    this.sourceAttrValue = sourceAttrValue;
  }

  public String getTargetAttrName() {
    return targetAttrName;
  }

  public void setTargetAttrName(String targetAttrName) {
    this.targetAttrName = targetAttrName;
  }

  public String getTargetAttrValue() {
    return targetAttrValue;
  }

  public void setTargetAttrValue(String targetAttrValue) {
    this.targetAttrValue = targetAttrValue;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("ApplicationAttributesTO [sourceAttrName=");
    builder.append(sourceAttrName);
    builder.append(", sourceAttrValue=");
    builder.append(sourceAttrValue);
    builder.append(", targetAttrName=");
    builder.append(targetAttrName);
    builder.append(", targetAttrValue=");
    builder.append(targetAttrValue);
    builder.append("]");
    return builder.toString();
  }

}
