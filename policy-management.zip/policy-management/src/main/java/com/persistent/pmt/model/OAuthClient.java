package com.persistent.pmt.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * OAuthClient
 * 
 * Entity model for OAuthClient
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "oauth_client")
public class OAuthClient {

	@Id
//	@SequenceGenerator(name = "SEQ_OAUTH_CLIENT", sequenceName = "SEQ_OAUTH_CLIENT", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_OAUTH_CLIENT")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "name")
	private String name;

	@Column(name = "description")
	private String description;

	@Column(name = "bypass_approval_page")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean bypassApprovalPage;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "oauth_client_id")
	private List<RedirectURI> redirectUris;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "oauth_client_grant_type", joinColumns = {
			@JoinColumn(name = "oauth_client_id") }, inverseJoinColumns = { @JoinColumn(name = "grant_type_id") })
	private List<GrantType> grantTypes;

	@ManyToOne
	@JoinColumn(name = "environment_id")
	private Environment environment;

	@Column(name = "auth_type")
	private String authType;

	// @Column(name = "secret")
	@Transient
	private String secret;

	// @Column(name = "encrypted_secret")
	@Transient
	private String encryptedSecret;

	@JsonIgnore
	@Column(name = "scopes")
	private String scope;

	@Transient
	private String environmentName;

	@OneToOne(mappedBy = "oAuthClient", cascade = CascadeType.ALL, orphanRemoval = true)
	private OAuthOwner owner;
	
	@Transient
	private List<String> scopes;

	public OAuthClient() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isBypassApprovalPage() {
		return bypassApprovalPage;
	}

	public void setBypassApprovalPage(boolean bypassApprovalPage) {
		this.bypassApprovalPage = bypassApprovalPage;
	}

	public List<RedirectURI> getRedirectUris() {
		return redirectUris;
	}

	public void setRedirectUris(List<RedirectURI> redirectUris) {
		this.redirectUris = redirectUris;
	}

	public List<GrantType> getGrantTypes() {
		return grantTypes;
	}

	public void setGrantTypes(List<GrantType> grantTypes) {
		this.grantTypes = grantTypes;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	public String getAuthType() {
		return authType;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}

	public String getEncryptedSecret() {
		return encryptedSecret;
	}

	public void setEncryptedSecret(String encryptedSecret) {
		this.encryptedSecret = encryptedSecret;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getEnvironmentName() {
		return environmentName;
	}

	public void setEnvironmentName(String environmentName) {
		this.environmentName = environmentName;
	}

	public OAuthOwner getOwner() {
		return owner;
	}

	public void setOwner(OAuthOwner owner) {
		this.owner = owner;
	}
	
	public List<String> getScopes() {
		return scopes;
	}

	public void setScopes(String scope) {
		if(scope==null || scope.isEmpty()){
			this.scopes = new ArrayList<String>();
		}else{
			String[] data = this.scope.split(",");
			this.scopes = Arrays.asList(data);
		}
	}

	public void updateOAuthClientValues(OAuthClient newOAuthClient) {
		this.name = newOAuthClient.getName();
		this.description = newOAuthClient.getDescription();
		this.authType = newOAuthClient.getAuthType();
		this.bypassApprovalPage = newOAuthClient.isBypassApprovalPage();
		this.encryptedSecret = newOAuthClient.getEncryptedSecret();
		this.secret = newOAuthClient.getSecret();
		this.scope = newOAuthClient.getScope();
			
		//this.environment = null;
		
		this.grantTypes = null;
		this.grantTypes = newOAuthClient.getGrantTypes();

		for (RedirectURI uri : newOAuthClient.getRedirectUris()) {
			uri.setOauthClient(this);
		}
		this.getRedirectUris().clear();
		this.getRedirectUris().addAll(newOAuthClient.getRedirectUris());

		this.owner.setoAuthClient(null);
		newOAuthClient.getOwner().setoAuthClient(this);
		this.owner = newOAuthClient.getOwner();

	}

	@JsonIgnore
	public OAuthClient getDefensiveCopy() {
		OAuthClient client = new OAuthClient();
		client.setId(this.id);
		client.setClientId(this.clientId);
		client.setName(this.name);
		client.setDescription(this.description);
		client.setBypassApprovalPage(this.bypassApprovalPage);
		client.setEnvironmentName(this.environment.getName());
		client.setScope(this.scope);
		client.setAuthType(this.authType);
		client.setSecret(this.secret);
		client.setGrantTypes(this.grantTypes);
		client.setOwner(this.owner);
		client.setScopes(this.scope);
		List<RedirectURI> uris = this.redirectUris;
		List<RedirectURI> updatedUris = null;
		if (uris != null && !uris.isEmpty()) {
			updatedUris = new ArrayList<>();
			for (RedirectURI uri : uris) {
				updatedUris.add(new RedirectURI(uri.getId(), uri.getUri()));
			}
		}
		client.setRedirectUris(updatedUris);

		return client;
	}

	@Override
	public String toString() {
		return "OAuthClient [id=" + id + ", clientId=" + clientId + ", name=" + name + ", description=" + description
				+ ", bypassApprovalPage=" + bypassApprovalPage + ", redirectUris=" + redirectUris + ", grantTypes="
				+ grantTypes + ", environment=" + environment + ", authType=" + authType + ", secret=" + secret
				+ ", encryptedSecret=" + encryptedSecret + ", environmentName=" + environmentName + ", owner=" + owner
				+ "]";
	}

}
