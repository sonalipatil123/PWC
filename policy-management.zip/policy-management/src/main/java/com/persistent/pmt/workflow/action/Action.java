/**
 * Action
 * 
 * Base interface for Action
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.workflow.action;

import java.util.List;

import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public interface Action {

	public Object execute(Object object, List<WorkflowError> errors, WorkFlowContext context) throws Exception;

}
