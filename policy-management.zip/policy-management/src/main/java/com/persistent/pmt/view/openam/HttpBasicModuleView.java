package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class HttpBasicModuleView implements ModuleView {

  @JsonIgnore
  private String id;
  private int authenticationLevel;
  private String backendModuleName;

  public HttpBasicModuleView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public int getAuthenticationLevel() {
    return authenticationLevel;
  }

  public void setAuthenticationLevel(int authenticationLevel) {
    this.authenticationLevel = authenticationLevel;
  }

  public String getBackendModuleName() {
    return backendModuleName;
  }

  public void setBackendModuleName(String backendModuleName) {
    this.backendModuleName = backendModuleName;
  }
}
