package com.persistent.pmt.response.openam;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude
public class LegacyOAuth2OpenIDConnectModuleResponse implements ModuleResponse {

	private String authenticationEndpointUrl;
	private String userProfileServiceUrl;
	private String mailGatewayClass;
	private String scope;
	private String smtpUsername;
	private String openidConnectContextValue;
	private String accountProviderClass;
	private String[] accountMapperConfiguration;
	private String saveAttributesInSession;
	private String ssoProxyUrl;
	private String smtpPassword;
	private String[] attributeMapperConfiguration;
	private String accessTokenParameterName;
	private String authenticationLevel;
	private String[] attributeMappingClasses;
	private String smtpFromAddress;
	private String oauth2EmailAttribute;
	private String smtpHostPort;
	private String smtpHostName;
	private String accountMapperClass;
	private String logoutBehaviour;
	private String accessTokenEndpointUrl;
	private String promptForPassword;
	private String clientSecret;
	private String clientId;
	private String mixUpMitigation;
	private String mapToAnonymousUser;
	private String anonymousUserName;
	private String openidConnectContextType;
	private String openidConnectIssuer;
	private String smtpSslEnabled;
	private String createAccount;
	private String oauth2LogoutServiceUrl;
	private Type _type;
	private String _id;
	private String _rev;

	public LegacyOAuth2OpenIDConnectModuleResponse() {
		super();
	}

	public String getAuthenticationEndpointUrl() {
		return authenticationEndpointUrl;
	}

	public void setAuthenticationEndpointUrl(String authenticationEndpointUrl) {
		this.authenticationEndpointUrl = authenticationEndpointUrl;
	}

	public String getUserProfileServiceUrl() {
		return userProfileServiceUrl;
	}

	public void setUserProfileServiceUrl(String userProfileServiceUrl) {
		this.userProfileServiceUrl = userProfileServiceUrl;
	}

	public String getMailGatewayClass() {
		return mailGatewayClass;
	}

	public void setMailGatewayClass(String mailGatewayClass) {
		this.mailGatewayClass = mailGatewayClass;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getSmtpUsername() {
		return smtpUsername;
	}

	public void setSmtpUsername(String smtpUsername) {
		this.smtpUsername = smtpUsername;
	}

	public String getOpenidConnectContextValue() {
		return openidConnectContextValue;
	}

	public void setOpenidConnectContextValue(String openidConnectContextValue) {
		this.openidConnectContextValue = openidConnectContextValue;
	}

	public String getAccountProviderClass() {
		return accountProviderClass;
	}

	public void setAccountProviderClass(String accountProviderClass) {
		this.accountProviderClass = accountProviderClass;
	}

	public String[] getAccountMapperConfiguration() {
		return accountMapperConfiguration;
	}

	public void setAccountMapperConfiguration(
			String[] accountMapperConfiguration) {
		this.accountMapperConfiguration = accountMapperConfiguration;
	}

	public String getSaveAttributesInSession() {
		return saveAttributesInSession;
	}

	public void setSaveAttributesInSession(String saveAttributesInSession) {
		this.saveAttributesInSession = saveAttributesInSession;
	}

	public String getSsoProxyUrl() {
		return ssoProxyUrl;
	}

	public void setSsoProxyUrl(String ssoProxyUrl) {
		this.ssoProxyUrl = ssoProxyUrl;
	}

	public String getSmtpPassword() {
		return smtpPassword;
	}

	public void setSmtpPassword(String smtpPassword) {
		this.smtpPassword = smtpPassword;
	}

	public String[] getAttributeMapperConfiguration() {
		return attributeMapperConfiguration;
	}

	public void setAttributeMapperConfiguration(
			String[] attributeMapperConfiguration) {
		this.attributeMapperConfiguration = attributeMapperConfiguration;
	}

	public String getAccessTokenParameterName() {
		return accessTokenParameterName;
	}

	public void setAccessTokenParameterName(String accessTokenParameterName) {
		this.accessTokenParameterName = accessTokenParameterName;
	}

	public String getAuthenticationLevel() {
		return authenticationLevel;
	}

	public void setAuthenticationLevel(String authenticationLevel) {
		this.authenticationLevel = authenticationLevel;
	}

	public String[] getAttributeMappingClasses() {
		return attributeMappingClasses;
	}

	public void setAttributeMappingClasses(String[] attributeMappingClasses) {
		this.attributeMappingClasses = attributeMappingClasses;
	}

	public String getSmtpFromAddress() {
		return smtpFromAddress;
	}

	public void setSmtpFromAddress(String smtpFromAddress) {
		this.smtpFromAddress = smtpFromAddress;
	}

	public String getOauth2EmailAttribute() {
		return oauth2EmailAttribute;
	}

	public void setOauth2EmailAttribute(String oauth2EmailAttribute) {
		this.oauth2EmailAttribute = oauth2EmailAttribute;
	}

	public String getSmtpHostPort() {
		return smtpHostPort;
	}

	public void setSmtpHostPort(String smtpHostPort) {
		this.smtpHostPort = smtpHostPort;
	}

	public String getSmtpHostName() {
		return smtpHostName;
	}

	public void setSmtpHostName(String smtpHostName) {
		this.smtpHostName = smtpHostName;
	}

	public String getAccountMapperClass() {
		return accountMapperClass;
	}

	public void setAccountMapperClass(String accountMapperClass) {
		this.accountMapperClass = accountMapperClass;
	}

	public String getLogoutBehaviour() {
		return logoutBehaviour;
	}

	public void setLogoutBehaviour(String logoutBehaviour) {
		this.logoutBehaviour = logoutBehaviour;
	}

	public String getAccessTokenEndpointUrl() {
		return accessTokenEndpointUrl;
	}

	public void setAccessTokenEndpointUrl(String accessTokenEndpointUrl) {
		this.accessTokenEndpointUrl = accessTokenEndpointUrl;
	}

	public String getPromptForPassword() {
		return promptForPassword;
	}

	public void setPromptForPassword(String promptForPassword) {
		this.promptForPassword = promptForPassword;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getMixUpMitigation() {
		return mixUpMitigation;
	}

	public void setMixUpMitigation(String mixUpMitigation) {
		this.mixUpMitigation = mixUpMitigation;
	}

	public String getMapToAnonymousUser() {
		return mapToAnonymousUser;
	}

	public void setMapToAnonymousUser(String mapToAnonymousUser) {
		this.mapToAnonymousUser = mapToAnonymousUser;
	}

	public String getAnonymousUserName() {
		return anonymousUserName;
	}

	public void setAnonymousUserName(String anonymousUserName) {
		this.anonymousUserName = anonymousUserName;
	}

	public String getOpenidConnectContextType() {
		return openidConnectContextType;
	}

	public void setOpenidConnectContextType(String openidConnectContextType) {
		this.openidConnectContextType = openidConnectContextType;
	}

	public String getOpenidConnectIssuer() {
		return openidConnectIssuer;
	}

	public void setOpenidConnectIssuer(String openidConnectIssuer) {
		this.openidConnectIssuer = openidConnectIssuer;
	}

	public String getSmtpSslEnabled() {
		return smtpSslEnabled;
	}

	public void setSmtpSslEnabled(String smtpSslEnabled) {
		this.smtpSslEnabled = smtpSslEnabled;
	}

	public String getCreateAccount() {
		return createAccount;
	}

	public void setCreateAccount(String createAccount) {
		this.createAccount = createAccount;
	}

	public String getOauth2LogoutServiceUrl() {
		return oauth2LogoutServiceUrl;
	}

	public void setOauth2LogoutServiceUrl(String oauth2LogoutServiceUrl) {
		this.oauth2LogoutServiceUrl = oauth2LogoutServiceUrl;
	}

	public Type get_type() {
		return _type;
	}

	public void set_type(Type _type) {
		this._type = _type;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String get_rev() {
		return _rev;
	}

	public void set_rev(String _rev) {
		this._rev = _rev;
	}

}
