package com.persistent.pmt.response.openam;

import com.persistent.pmt.response.TargetResponse;

public interface ModuleResponse extends TargetResponse {
}
