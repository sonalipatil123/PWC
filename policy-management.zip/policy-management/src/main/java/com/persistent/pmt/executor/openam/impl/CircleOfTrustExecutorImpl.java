package com.persistent.pmt.executor.openam.impl;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.executor.openam.CircleOfTrustExecutor;
import com.persistent.pmt.response.TargetResponse;
import com.persistent.pmt.response.openam.CircleOfTrustResponse;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.utils.EndPointUtils;
import com.persistent.pmt.view.TargetView;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component("circleOfTrustExecutor")
public class CircleOfTrustExecutorImpl implements CircleOfTrustExecutor {

  @Autowired
  RestTemplate restTemplate;

  @Override
  public TargetResponse get(Object object, Product product, Artifact artifact,
      HashMap<String, String> params, WorkFlowContext context) {
    if (params != null) {
      String url =
          EndPointUtils.getEndPoint(product, artifact, HttpMethod.GET, context, params);
      HttpHeaders headers = CommonUtils.getHeaders(context, product, HttpMethod.GET);
      HttpEntity<?> entity = new HttpEntity<>(headers);
      ResponseEntity<CircleOfTrustResponse> response =
          restTemplate.exchange(url, HttpMethod.GET, entity, CircleOfTrustResponse.class);
      if (response != null)
        return response.getBody();
    }
    return null;
  }

  @Override
  public void create(Object object, TargetView targetView, Product product, Artifact artifact,
      HashMap<String, String> params, WorkFlowContext context) {
    // TODO Auto-generated method stub

  }

  @Override
  public TargetResponse update(Object object, TargetView targetView, Product product,
      Artifact artifact, HashMap<String, String> params, WorkFlowContext context) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public void delete(Object object, Product product, Artifact artifact,
      HashMap<String, String> params, WorkFlowContext context) {
    // TODO Auto-generated method stub

  }

}
