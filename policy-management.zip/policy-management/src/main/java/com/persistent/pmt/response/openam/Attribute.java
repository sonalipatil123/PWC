package com.persistent.pmt.response.openam;

public class Attribute {
	
	private boolean inherited;
	private Object value;

	public Attribute() {
		super();
	}

	public boolean isInherited() {
		return inherited;
	}

	public void setInherited(boolean inherited) {
		this.inherited = inherited;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

}
