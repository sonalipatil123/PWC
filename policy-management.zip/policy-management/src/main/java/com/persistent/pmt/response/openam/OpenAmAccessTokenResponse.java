package com.persistent.pmt.response.openam;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.response.TargetResponse;

@JsonInclude(Include.NON_NULL)
public class OpenAmAccessTokenResponse implements TargetResponse {
  String tokenId;
  String successUrl;
  String realm;

  public OpenAmAccessTokenResponse() {
    super();
  }

  public OpenAmAccessTokenResponse(String tokenId, String successUrl, String realm) {
    super();
    this.tokenId = tokenId;
    this.successUrl = successUrl;
    this.realm = realm;
  }

  public String getTokenId() {
    return tokenId;
  }

  public void setTokenId(String tokenId) {
    this.tokenId = tokenId;
  }

  public String getSuccessUrl() {
    return successUrl;
  }

  public void setSuccessUrl(String successUrl) {
    this.successUrl = successUrl;
  }

  public String getRealm() {
    return realm;
  }

  public void setRealm(String realm) {
    this.realm = realm;
  }

}
