package com.persistent.pmt.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * UserDataStore
 * 
 * Entity model for UserDataStore
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "user_data_store")
public class UserDataStore {

	@Id
	@Column(name = "id")
	private String id;

	@Column(name = "name")
	private String name;

	@Column(name = "description")
	private String description;

	@Column(name = "namespace")
	private String namespace;

	@Column(name = "server")
	private String server;

	@Column(name = "search_root")
	private String searchRoot;

	@Column(name = "search_scope")
	private String searchscope;

	@Column(name = "username")
	private String username;

	@Column(name = "password")
	private String password;

	@Column(name = "login_attribute")
	private String loginAttribute;

	@Column(name = "user_object_class")
	private String userObjectClass;

	@Column(name = "store_type")
	private String storeType;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "user_store_id")
	private List<UserDataStoreAttributes> attributes;

	public UserDataStore() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getServer() {
		return server;
	}

	public void setServer(String server) {
		this.server = server;
	}

	public String getSearchRoot() {
		return searchRoot;
	}

	public void setSearchRoot(String searchRoot) {
		this.searchRoot = searchRoot;
	}

	public String getSearchscope() {
		return searchscope;
	}

	public void setSearchscope(String searchscope) {
		this.searchscope = searchscope;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLoginAttribute() {
		return loginAttribute;
	}

	public void setLoginAttribute(String loginAttribute) {
		this.loginAttribute = loginAttribute;
	}

	public String getUserObjectClass() {
		return userObjectClass;
	}

	public void setUserObjectClass(String userObjectClass) {
		this.userObjectClass = userObjectClass;
	}

	public String getStoreType() {
		return storeType;
	}

	public void setStoreType(String storeType) {
		this.storeType = storeType;
	}

	public List<UserDataStoreAttributes> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<UserDataStoreAttributes> attributes) {
		this.attributes = attributes;
	}
}
