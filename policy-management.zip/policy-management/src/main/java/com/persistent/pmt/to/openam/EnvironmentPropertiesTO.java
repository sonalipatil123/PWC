package com.persistent.pmt.to.openam;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class EnvironmentPropertiesTO {

  private Integer environmentId;
  private String environmentName;
  private Boolean configurationStatus;
  private PropsTO properties;

  public PropsTO getProperties() {
    return properties;
  }

  public void setProperties(PropsTO properties) {
    this.properties = properties;
  }

  public Integer getEnvironmentId() {
    return environmentId;
  }

  public void setEnvironmentId(Integer environmentId) {
    this.environmentId = environmentId;
  }

  public String getEnvironmentName() {
    return environmentName;
  }

  public void setEnvironmentName(String environmentName) {
    this.environmentName = environmentName;
  }

  public Boolean getConfigurationStatus() {
    return configurationStatus;
  }

  public void setConfigurationStatus(Boolean configurationStatus) {
    this.configurationStatus = configurationStatus;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("EnvironmentPropsTO [environmentId=");
    builder.append(environmentId);
    builder.append(", environmentName=");
    builder.append(environmentName);
    builder.append(", properties=");
    builder.append(properties);
    builder.append(", configurationStatus=");
    builder.append(configurationStatus);
    builder.append("]");
    return builder.toString();
  }

}
