package com.persistent.pmt.view.openam;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.persistent.pmt.view.TargetView;

@JsonInclude(Include.NON_NULL)
public class PolicySetView implements TargetView {

  @JsonIgnore
  private String id;
  private String[] attributeNames;
  private String entitlementCombiner;
  private String[] subjects;
  private String[] resourceTypeUuids;
  private String applicationType;
  private String editable;
  private String[] conditions;
  private String creationDate;
  private String createdBy;
  private String resourceComparator;
  private String description;
  private String name;
  private String lastModifiedBy;
  private String lastModifiedDate;
  private String searchIndex;
  private String saveIndex;
  private String displayName;

  public PolicySetView() {
    super();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String[] getAttributeNames() {
    return attributeNames;
  }

  public void setAttributeNames(String[] attributeNames) {
    this.attributeNames = attributeNames;
  }

  public String getEntitlementCombiner() {
    return entitlementCombiner;
  }

  public void setEntitlementCombiner(String entitlementCombiner) {
    this.entitlementCombiner = entitlementCombiner;
  }

  public String[] getSubjects() {
    return subjects;
  }

  public void setSubjects(String[] subjects) {
    this.subjects = subjects;
  }

  public String[] getResourceTypeUuids() {
    return resourceTypeUuids;
  }

  public void setResourceTypeUuids(String[] resourceTypeUuids) {
    this.resourceTypeUuids = resourceTypeUuids;
  }

  public String getApplicationType() {
    return applicationType;
  }

  public void setApplicationType(String applicationType) {
    this.applicationType = applicationType;
  }

  public String getEditable() {
    return editable;
  }

  public void setEditable(String editable) {
    this.editable = editable;
  }

  public String[] getConditions() {
    return conditions;
  }

  public void setConditions(String[] conditions) {
    this.conditions = conditions;
  }

  public String getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(String creationDate) {
    this.creationDate = creationDate;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public String getResourceComparator() {
    return resourceComparator;
  }

  public void setResourceComparator(String resourceComparator) {
    this.resourceComparator = resourceComparator;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLastModifiedBy() {
    return lastModifiedBy;
  }

  public void setLastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
  }

  public String getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(String lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  public String getSearchIndex() {
    return searchIndex;
  }

  public void setSearchIndex(String searchIndex) {
    this.searchIndex = searchIndex;
  }

  public String getSaveIndex() {
    return saveIndex;
  }

  public void setSaveIndex(String saveIndex) {
    this.saveIndex = saveIndex;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  @Override
  public String toString() {
    return "PolicySetView [id=" + id + ", attributeNames=" + Arrays.toString(attributeNames)
        + ", entitlementCombiner=" + entitlementCombiner + ", subjects="
        + Arrays.toString(subjects) + ", resourceTypeUuids="
        + Arrays.toString(resourceTypeUuids) + ", applicationType=" + applicationType
        + ", editable=" + editable + ", conditions=" + Arrays.toString(conditions)
        + ", creationDate=" + creationDate + ", createdBy=" + createdBy
        + ", resourceComparator=" + resourceComparator + ", description=" + description
        + ", name=" + name + ", lastModifiedBy=" + lastModifiedBy + ", lastModifiedDate="
        + lastModifiedDate + ", searchIndex=" + searchIndex + ", saveIndex=" + saveIndex
        + ", displayName=" + displayName + "]";
  }

}
