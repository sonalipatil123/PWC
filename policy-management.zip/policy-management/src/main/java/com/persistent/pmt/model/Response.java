package com.persistent.pmt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Response
 * 
 * Entity model for Response
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "response")
public class Response {

	@Id
//	@SequenceGenerator(name = "SEQ_RESPONSE", sequenceName = "SEQ_RESPONSE", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_RESPONSE")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "type")
	private String type;

	@Column(name = "value")
	private String value;

	@Column(name = "description")
	private String description;

	@Column(name = "value_type")
	private String valueType;

	@ManyToOne
	@JoinColumn(name = "authorization_policy_id", nullable=true)
	private AuthorizationPolicy authorizationPolicy;

	@ManyToOne
	@JoinColumn(name = "application_id")
	private Application application;

	@ManyToOne
	@JoinColumn(name = "authentication_policy_id", nullable=true)
	private AuthenticationPolicy authenticationPolicy;
	
	@Transient
	private boolean isAuthenticationType;
	
	@Transient
	private boolean isAuthorizationType;
	

	public Response() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValueType() {
		return valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public AuthorizationPolicy getAuthorizationPolicy() {
		return authorizationPolicy;
	}

	public void setAuthorizationPolicy(AuthorizationPolicy authorizationPolicy) {
		this.authorizationPolicy = authorizationPolicy;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public AuthenticationPolicy getAuthenticationPolicy() {
		return authenticationPolicy;
	}

	public void setAuthenticationPolicy(
			AuthenticationPolicy authenticationPolicy) {
		this.authenticationPolicy = authenticationPolicy;
	}

	public boolean isAuthenticationType() {
		return isAuthenticationType;
	}

	public void setAuthenticationType(boolean isAuthenticationType) {
		this.isAuthenticationType = isAuthenticationType;
	}

	public boolean isAuthorizationType() {
		return isAuthorizationType;
	}

	public void setAuthorizationType(boolean isAuthorizationType) {
		this.isAuthorizationType = isAuthorizationType;
	}

	
}
