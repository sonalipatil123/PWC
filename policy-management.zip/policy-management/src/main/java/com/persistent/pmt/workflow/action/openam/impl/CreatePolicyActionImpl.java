package com.persistent.pmt.workflow.action.openam.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.WorkflowType;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.WorkflowException;
import com.persistent.pmt.executor.openam.PolicyExecutor;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.utils.AuditWriter;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.view.openam.PolicyView;
import com.persistent.pmt.workflow.action.CreateAction;
import com.persistent.pmt.workflow.action.mapper.casm.PolicyViewMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component("createPolicyAction")
@Order(value = 2)
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class CreatePolicyActionImpl implements CreateAction {

  private static final Logger logger = Logger.getLogger(CreatePolicyActionImpl.class);

  @Autowired
  @Qualifier("openAMPolicyExecutor")
  PolicyExecutor policyExecutor;

  @Autowired
  PolicyViewMapper policyViewMapper;

  @Autowired
  AuditWriter auditWriter;

  @Autowired
  Environment environment;

  @SuppressWarnings("unchecked")
  @Override
  public Object execute(Object object, List<WorkflowError> errors,
      WorkFlowContext workFlowContext) throws Exception {

    logger.log(Level.INFO, "CreatePolicyActionImpl execute START");

    Application application = (Application) object;
    try {

      List<PolicyView> policyViews =
          (List<PolicyView>) policyViewMapper.getMappedObject(application, workFlowContext);

      if (policyViews != null && !policyViews.isEmpty()) {
        List<PolicyView> rollbackPolicyViewsOnFailure = new ArrayList<PolicyView>();
        workFlowContext.setRollbackPolicyViewsOnFailure(rollbackPolicyViewsOnFailure);
        for (PolicyView policyView : policyViews) {
          policyView.setResourceTypeUuid(workFlowContext.getResourceType());
          policyExecutor.create(
              application,
              policyView,
              Product.OPENAM,
              Artifact.POLICY,
              CommonUtils.createOpenAMParamMap(policyView.getId(),
                  workFlowContext.getRealmName()), workFlowContext);
          rollbackPolicyViewsOnFailure.add(policyView);

          // Audit log for successful creation of policies
          workFlowContext.getPolicyAuditData().append(
              MessageFormat.format(
                  environment.getProperty(AuditPropertyConstants.TARGET_ACTION_SUCCESS),
                  new Object[] { "Policy", policyView.getId() }));
        }
        // Audit log for success
        auditWriter.write(ACTIONS.PROVISION, PMTConstants.SUCCESS,
            environment.getProperty(AuditPropertyConstants.TARGET_ARTIFACT_ACTION_SUCCESS),
            workFlowContext.getPolicyAuditData().toString(), new Object[] { "Policy(s)",
                application.getName(), application.getId() });
      }
      else {

        // Audit log for not valid data
        workFlowContext.getPolicyAuditData().append(
            MessageFormat.format(
                environment.getProperty(AuditPropertyConstants.TARGET_ACTION_DATA_NOT_VALID),
                new Object[] { "Policy" }));
        logger.log(Level.ERROR, "CreatePolicyActionImpl execute | application with id: "
            + application.getId()
            + " has no valid resources. No policy will be created in the target system.");
      }
    }
    catch (HttpClientErrorException ex) {

      // Audit Log for artifact creation failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE),
          workFlowContext.getPolicyAuditData().toString(),
          new Object[] { "Policy", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getResponseBodyAsString());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    catch (Exception ex) {
      // Audit Log for artifact creation failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_FAILURE),
          workFlowContext.getPolicyAuditData().toString(),
          new Object[] { "Policy", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to provision application: "
                  + ex.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR,
          "Failed to provision application with id: " + application.getId(), ex);
      throw new WorkflowException(ex);
    }

    logger.log(Level.INFO, "CreatePolicyActionImpl execute END");
    return application;
  }

  @Override
  public Object rollback(Object object, List<WorkflowError> errors, WorkFlowContext context)
      throws Exception {
    logger.log(Level.INFO, "CreatePolicyActionImpl rollback START");
    Application application = (Application) object;
    List<PolicyView> rollbackPolicyViews = context.getRollbackPolicyViewsOnFailure();
    try {
      if (rollbackPolicyViews != null && !rollbackPolicyViews.isEmpty()) {
        logger.log(Level.INFO, "CreatePolicyActionImpl rollback STARTED");
        for (PolicyView policyView : rollbackPolicyViews) {
          policyExecutor.delete(application, Product.OPENAM, Artifact.POLICY,
              CommonUtils.createOpenAMParamMap(policyView.getId(), context.getRealmName()),
              context);

          // Audit log for rollback success
          auditWriter.write(
              ACTIONS.PROVISION,
              PMTConstants.SUCCESS,
              environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_SUCCESS),
              "",
              new Object[] { "Policy", policyView.getId(), application.getId(),
                  application.getName() });
        }
      }
      logger.log(Level.INFO, "CreatePolicyActionImpl rollback END");
    }
    catch (HttpClientErrorException ex) {
      // Audit log for rollback failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
          new Object[] { "Policy", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to rollback Policy: "
                  + ex.getResponseBodyAsString());
      errors.add(error);
      logger.log(Level.ERROR, "Failed to rollback Policy for application with id: "
          + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    catch (Exception ex) {

      // Audit log for rollback failure
      auditWriter.write(ACTIONS.PROVISION, PMTConstants.FAILURE,
          environment.getProperty(AuditPropertyConstants.TARGET_ACTION_ROLLBACK_FAILURE), "",
          new Object[] { "Policy", application.getName(), application.getId() });

      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(), "Application",
              application.getId(), 0, "Failed to rollback Policy for application: "
                  + ex.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR, "Failed to rollback Policy for application with id: "
          + application.getId(), ex);
      throw new WorkflowException(ex);
    }
    return application;
  }
}
