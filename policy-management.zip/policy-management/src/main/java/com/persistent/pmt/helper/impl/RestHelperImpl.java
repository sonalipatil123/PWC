/**
 * RestHelperImpl
 * 
 * Implementation for REST execution helper
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.helper.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.helper.RestHelper;

@Component
public class RestHelperImpl<T> implements RestHelper<T> {

	@Autowired
	RestTemplate restTemplate;

	@Override
	public ResponseEntity<T> execute(String url, HttpMethod method, HttpEntity<T> entity, Class<T> clazz) {
		return restTemplate.exchange(url, method, entity, clazz);
	}

}
