package com.persistent.pmt.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.service.AuditRecordService;

@Component
public class AuditWriter {

	@Autowired
	AuditRecordService auditRecordService;

	public void write(ACTIONS action, String status, String message,
			String context, Object... paramList) throws GenericException {
		
		auditRecordService.createAuditRecord(action, status, message, context,
				paramList);
	}

}
