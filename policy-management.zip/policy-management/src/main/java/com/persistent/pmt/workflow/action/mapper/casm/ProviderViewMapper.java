package com.persistent.pmt.workflow.action.mapper.casm;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.EntityConfigTemplates;
import com.persistent.pmt.constant.MapperConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.PropertyConstants;
import com.persistent.pmt.constant.casm.AuthenticationSchemeTypes;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.metadata.generator.MetadataGenerator;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.AuthenticationScheme;
import com.persistent.pmt.model.Provider;
import com.persistent.pmt.model.ProviderAttributes;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.service.ServerConfigurationService;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.utils.MapperUtils;
import com.persistent.pmt.view.openam.ProviderView;
import com.persistent.pmt.workflow.action.mapper.GenericMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component
@PropertySource(value = { "classpath:application.properties", "classpath:auditMessages.properties" })
public class ProviderViewMapper implements GenericMapper {

	@Autowired
	@Qualifier("serverConfigurationService")
	ServerConfigurationService serverConfigurationService;

	@Autowired
	Environment environment;

	@Autowired
	MetadataGenerator metadataGenerator;

	@Override
	public Object getMappedObject(Object object, WorkFlowContext workFlowContext) throws GenericException {

		Application application = (Application) object;
		Provider provider = application.getProvider();

		if (null != provider) {

			if (PMTConstants.PROVIDER_WSFEDSP.equals(provider.getType())) {
				return createWSFedProviderView(application, workFlowContext);
			} else {
				return createSamlProviderView(application, workFlowContext);
			}
		}
		return null;
	}

	@Override
	public String getId(Object object) throws GenericException {
		return CommonUtils.formatString(((Provider) object).getName(), MapperUtils.getInvalidCharacters());
	}

	private ProviderView createSamlProviderView(Application application, WorkFlowContext workFlowContext)
			throws GenericException {

		String entityConfigXml = null;
		String entityConfigId = "";
		String attributeMapping = "";
		Provider provider = application.getProvider();

		AuthenticationScheme defaultAuthScheme = application.getDefaultAuthScheme();

		ProviderView samlProviderView = new ProviderView();
		if (null != defaultAuthScheme) {
			if (PMTConstants.PEP_TYPE_FEDERATION.equals(application.getPepType())) {
				if (AuthenticationSchemeTypes.AUTHN_SCHEME_SAML2.getValue()
						.equalsIgnoreCase(defaultAuthScheme.getType())) {
					String attributeLinkValue = "";
					for (ProviderAttributes attributes : provider.getAttributes()) {
						if (PMTConstants.SPID.equals(attributes.getSourceAttrName())) {
							entityConfigId = attributes.getSourceAttrValue();
							continue;
						}
						if (PMTConstants.ATTRIBUTES_LINK.equals(attributes.getSourceAttrName())) {
							attributeLinkValue = attributes.getSourceAttrValue();
							continue;
						}
					}
					attributeMapping = createAttributesMapForResponses(attributeLinkValue);
					samlProviderView.setMetadata(readProviderMetadata(provider.getName().trim(), application,
							workFlowContext, MapperConstants.SP_DESCRIPTOR));
				} else if (AuthenticationSchemeTypes.AUTHN_SCHEME_SAML.getValue()
						.equalsIgnoreCase(defaultAuthScheme.getType())) {
					String metadata = null;
					for (ProviderAttributes attributes : provider.getAttributes()) {
						if ("metadata".equals(attributes.getSourceAttrName())) {
							metadata = attributes.getSourceAttrValue();
							entityConfigId = getEntityId(attributes.getSourceAttrValue());
							break;
						}
					}
					Map<String, String> responseMap = application.getHeaderAndCookieResponseValue();
					StringBuilder attrMapping = createAttributesMapForResponses(responseMap);
					if (attrMapping != null) {
						attributeMapping = attrMapping.toString();
					}
					samlProviderView.setMetadata(metadata);
				}

				String circleOfTrustIDP = serverConfigurationService
						.getPropertyValue(PropertyConstants.CIRCLE_OF_TRUST_IDP);

				entityConfigXml = EntityConfigTemplates.REMOTE_SP_CONFIG_XML
						.replace(PMTConstants.ENTITY_CONFIG_ID, entityConfigId)
						.replace(PMTConstants.ENTITY_CONFIG_COT, circleOfTrustIDP)
						.replace(PMTConstants.ATTRIBUTE_MAP, attributeMapping);
			} else if (PMTConstants.PEP_TYPE_AGENT.equals(application.getPepType()) && null != defaultAuthScheme
					&& AuthenticationSchemeTypes.AUTHN_SCHEME_SAML2.getValue()
							.equalsIgnoreCase(defaultAuthScheme.getType())) {

				for (ProviderAttributes attributes : provider.getAttributes()) {
					if (PMTConstants.IDPID.equals(attributes.getSourceAttrName())) {
						entityConfigId = attributes.getSourceAttrValue();
						break;
					}
				}

				String circleOfTrustSP = serverConfigurationService
						.getPropertyValue(PropertyConstants.CIRCLE_OF_TRUST_SP);
				entityConfigXml = EntityConfigTemplates.REMOTE_IDP_CONFIG_XML
						.replace(PMTConstants.ENTITY_CONFIG_ID, entityConfigId)
						.replace(PMTConstants.ENTITY_CONFIG_COT, circleOfTrustSP);

				samlProviderView.setMetadata(readProviderMetadata(provider.getName().trim(), application,
						workFlowContext, MapperConstants.IDP_DESCRIPTOR));
			}
		}
		samlProviderView.set_id(entityConfigId);
		samlProviderView.setEntityConfig(entityConfigXml);
		return samlProviderView;
	}

	private String getEntityId(String metadata) {
		String entityId = null;
		StringTokenizer tokenizedMetadat = new StringTokenizer(metadata, " ");
		while (tokenizedMetadat.hasMoreTokens()) {
			String token = tokenizedMetadat.nextToken();
			if (token.startsWith("entityID=")) {
				String quatedEntityID = token.split("=")[1];
				entityId = quatedEntityID.substring(1, quatedEntityID.length() - 1);
				break;
			}
		}
		return entityId;
	}

	private String readProviderMetadata(String providerName, Application application, WorkFlowContext workFlowContext,
			String descriptor) throws GenericException {
		String metadataString = null;
		String basePath = environment.getProperty(MapperConstants.PROPERTY_CASM_XML_BASE_PATH);
		String metadata = basePath + MapperConstants.METADATA_FOLDER;
		metadataString = readMeatadataFromFile(basePath, metadata, providerName);
		if (null == metadataString) {
			metadataString = createProviderMetadataFile(application.getProvider(), descriptor);
			if (null == metadataString) {
				// Audit log for Metadata file does not exist or is empty
				workFlowContext.getProviderAuditData()
						.append(MessageFormat.format(
								environment
										.getProperty(AuditPropertyConstants.TARGET_ACTION_PROVIDER_METADATA_NOT_FOUND),
								new Object[] { providerName }));
				throw new GenericException("Metadata file does not exist or is empty.", HttpStatus.NOT_FOUND.value(),
						GenericResponse.FAILURE);
			}
		}
		return metadataString;
	}

	private StringBuilder createAttributesMapForResponses(Map<String, String> responseMap) {
		StringBuilder responseAttr = null;
		if (responseMap != null) {
			responseAttr = new StringBuilder();
			for (Entry<String, String> response : responseMap.entrySet()) {
				responseAttr.append("<Value>" + response.getKey() + "=" + response.getValue() + "</Value>\n");
			}
		}
		return responseAttr;
	}

	private String createAttributesMapForResponses(String attributeLinkValue) {

		StringBuilder responseAttr = new StringBuilder();
		if (attributeLinkValue != null && !attributeLinkValue.isEmpty()) {
			for (String attrLinkValue : attributeLinkValue.split("\\|")) {
				String key = null;
				String value = null;
				for (String resolvedAttrVaues : attrLinkValue.split(",")) {
					String[] attrMap = resolvedAttrVaues.split("=");
					if ("SAML2Attribute_Name".equals(attrMap[0])) {
						key = attrMap[1];
					} else if ("AttributeSource_UserAttribute".equals(attrMap[0])) {
						value = attrMap[1];
					}
				}
				responseAttr.append("<Value>" + key + "=" + value + "</Value>\n");
			}
		}
		return responseAttr.toString();
	}

	private ProviderView createWSFedProviderView(Application application, WorkFlowContext workFlowContext)
			throws GenericException {

		ProviderView wsFedProviderView = null;
		String circleOfTrustIDP = serverConfigurationService.getPropertyValue(PropertyConstants.CIRCLE_OF_TRUST_IDP);

		Provider provider = application.getProvider();

		if (circleOfTrustIDP != null && !circleOfTrustIDP.isEmpty()) {
			String federationId = "";
			for (ProviderAttributes attributes : provider.getAttributes()) {
				if (PMTConstants.KEY_RPID.equals(attributes.getSourceAttrName())) {
					federationId = attributes.getSourceAttrValue();
					break;
				}
			}

			String entityConfigXml = EntityConfigTemplates.WSFED_HOSTED_SP_CONFIG_XML
					.replace(PMTConstants.ENTITY_CONFIG_ID, federationId)
					.replace(PMTConstants.PROVIDER_DISPLAY_NAME, federationId)
					.replace(PMTConstants.ENTITY_CONFIG_COT, circleOfTrustIDP);

			wsFedProviderView = new ProviderView();
			wsFedProviderView.set_id(federationId);
			wsFedProviderView.setEntityConfig(entityConfigXml);
			wsFedProviderView.setMetadata(readProviderMetadata(provider.getName().trim(), application, workFlowContext,
					MapperConstants.RELYING_PARTY_DESCRIPTOR));
		}
		return wsFedProviderView;
	}

	private String createProviderMetadataFile(Provider provider, String descriptor) throws GenericException {

		// initializing basepath , template folder path, and metadata file creation path
		String basePath = environment.getProperty(MapperConstants.PROPERTY_CASM_XML_BASE_PATH);
		String tempalatePath = basePath + MapperConstants.METADATA_TEMPLATE_FOLDER;
		String creationPath = basePath + MapperConstants.METADATA_CREATION_FOLDER;

		// templateEntities map stores the descriptor or template entities as key and
		// their respective files as a value
		Map<String, String> templateEntities = new HashMap<>();
		templateEntities.put(MapperConstants.ENTITY_TEMPLATE, "EntityDescriptor_Template.xml");
		if (MapperConstants.SP_DESCRIPTOR.equals(descriptor)) {
			templateEntities.put(MapperConstants.DESCRIPTOR_TEMPLATE, "SP_SSO_Descriptor_Template.xml");
		} else if (MapperConstants.IDP_DESCRIPTOR.equals(descriptor)) {
			templateEntities.put(MapperConstants.DESCRIPTOR_TEMPLATE, "IDP_SSO_Descriptor_Template.xml");
		} else if (MapperConstants.RELYING_PARTY_DESCRIPTOR.equals(descriptor)) {
			templateEntities.put(MapperConstants.DESCRIPTOR_TEMPLATE,
					"WS_Fed_RelyingPartyTrust_RoleDescriptor_Template.xml");
		}
		templateEntities.put(MapperConstants.CONTACTS_TEMPLATE, "EntityDescriptor_ContactPerson_Iterator_Template.xml");
		templateEntities.put(MapperConstants.IDP_ATTRIBUTE_TEMPLATE,
				"IDP_SSO_Descriptor_Attribute_Iterator_Template.xml");

		Map<String, String> providerAttributes = new HashMap<String, String>();
		String metadataString = "";
		if (provider != null) {
			providerAttributes.put("AttributeRequesterConfig_RequireSignedAssertion", "false");

			for (ProviderAttributes attributes : provider.getAttributes()) {
				providerAttributes.put(attributes.getSourceAttrName(), attributes.getSourceAttrValue());
				if (("AttributeRequesterConfigLink").equals(attributes.getSourceAttrName())) {
					String attributeValue = attributes.getSourceAttrValue();

					String[] assertionValues = getAttributeValue(attributeValue, MapperConstants.SEPARATOR_COMMA,
							"AttributeRequesterConfig_RequireSignedAssertion");

					providerAttributes.put(assertionValues[0], assertionValues[1]);

				} else if (("MetadataSLOSvcsLink").equals(attributes.getSourceAttrName())
						|| ("MetadataAssConSvcsLink").equals(attributes.getSourceAttrName())) {
					String attributeValue = attributes.getSourceAttrValue();

					String key = "";
					String value = "";

					String[] metadataLinkValues = getAttributeValue(attributeValue, MapperConstants.SEPARATOR_PIPE,
							null);
					for (String metadataLinkValue : metadataLinkValues) {
						String[] metadataAttributeValues = getAttributeValue(metadataLinkValue, ",", null);
						for (String metadataAttrVal : metadataAttributeValues) {
							if (metadataAttrVal.contains("HTTP-Redirect")) {
								key = attributes.getSourceAttrName() + "_HTTP-Redirect";
							} else if (metadataAttrVal.contains("HTTP-POST")) {
								key = attributes.getSourceAttrName() + "_HTTP-POST";
							} else if (metadataAttrVal.contains("HTTP-Artifact")) {
								key = attributes.getSourceAttrName() + "_HTTP-Artifact";
							} else if (metadataAttrVal.contains("PAOS")) {
								key = attributes.getSourceAttrName() + "_PAOS";
							} else if (metadataAttrVal.contains("SOAP")) {
								key = attributes.getSourceAttrName() + "_SOAP";
							} else if (metadataAttrVal.contains("Endpoint_Location")) {
								String[] attrValues = getAttributeValue(metadataAttrVal,
										MapperConstants.SEPARATOR_EQUAL_TO, null);
								value = attrValues[1];
							}
						}
						providerAttributes.put(key, value);
					}

				}
			}

			if (MapperConstants.SP_DESCRIPTOR.equals(descriptor)) {
				providerAttributes.put(PMTConstants.ENTITY_ID, providerAttributes.get(PMTConstants.SPID));
			} else if (MapperConstants.IDP_DESCRIPTOR.equals(descriptor)) {
				providerAttributes.put(PMTConstants.ENTITY_ID, providerAttributes.get(PMTConstants.IDPID));
			}
			metadataString = metadataGenerator.generateMetadata(providerAttributes, provider.getName(),
					tempalatePath, creationPath, templateEntities, descriptor);

		} else {
			throw new GenericException("Provider Not Found.", HttpStatus.NOT_FOUND.value(), GenericResponse.FAILURE);
		}

		return metadataString;
	}

	private String[] getAttributeValue(String attributeValue, String separator, String checkVal) {
		String[] tempValues = null;
		String[] resultValue = null;
		if (attributeValue != null) {
			if (attributeValue.contains(separator)) {
				if (MapperConstants.SEPARATOR_PIPE.equals(separator)) {
					separator = Pattern.quote(MapperConstants.SEPARATOR_PIPE);

				}
				tempValues = attributeValue.split(separator);
				if (checkVal != null) {
					for (String tempValue : tempValues) {
						if (tempValue != null)
							if (tempValue.contains(checkVal)) {
								resultValue = tempValue.split(MapperConstants.SEPARATOR_EQUAL_TO);
								break;
							}
					}

				}
				resultValue = tempValues;
			}
		} else {
			resultValue = tempValues;
		}

		return resultValue;
	}

	private String readMeatadataFromFile(String basePath, String metadata, String providerName)
			throws GenericException {

		File fileBasePath = new File(basePath);
		File fileMetadata = new File(metadata);
		String metadataString = null;
		if (fileBasePath.isDirectory()) {
			if (fileMetadata.exists()) {
				File xml = new File(metadata + "/" + providerName + ".xml");
				if (xml.exists()) {
					try {
						metadataString = FileUtils.readFileToString(xml);
					} catch (IOException e) {
						throw new GenericException("Unable to read metadata file. ", HttpStatus.BAD_REQUEST.value(),
								GenericResponse.FAILURE);
					}
				}
			}
		}
		return metadataString;

	}

}
