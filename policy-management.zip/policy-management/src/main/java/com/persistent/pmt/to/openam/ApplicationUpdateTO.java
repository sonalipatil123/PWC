package com.persistent.pmt.to.openam;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationUpdateTO {

  @JsonProperty
  ApplicationTO applicationTO;
  @JsonProperty
  List<String> attributes;

  public ApplicationUpdateTO() {
    super();
  }

  public ApplicationUpdateTO(ApplicationTO applicationTO, List<String> attributes) {
    super();
    this.applicationTO = applicationTO;
    this.attributes = attributes;
  }

  public ApplicationTO getApplicationTO() {
    return applicationTO;
  }

  public void setApplicationTO(ApplicationTO applicationTO) {
    this.applicationTO = applicationTO;
  }

  public List<String> getAttributes() {
    return attributes;
  }

  public void setAttributes(List<String> attributes) {
    this.attributes = attributes;
  }

}
