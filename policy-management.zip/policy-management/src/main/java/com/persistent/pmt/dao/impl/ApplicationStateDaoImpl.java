/**
 * ApplicationStateDaoImpl
 * 
 * DAO implementation for Application State
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.dao.ApplicationStateDao;
import com.persistent.pmt.model.ApplicationState;

@Repository("applicationStateDao")
@Transactional
public class ApplicationStateDaoImpl extends BaseDaoImpl implements ApplicationStateDao {

  /**
   * This method fetches the application state of specific name
   * 
   * @param String
   * @return ApplicationState
   */
  @Override
  public ApplicationState getApplicationStateByName(String name) {
    Criteria criteria = createCriteria(ApplicationState.class);
    criteria.add(Restrictions.eq("state", name).ignoreCase());

    return (ApplicationState) criteria.uniqueResult();
  }

}