package com.persistent.pmt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * LegacyDetails
 * 
 * Entity model for LegacyDetails
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "application_legacy_details")
public class LegacyDetails {

	@Id
//	@SequenceGenerator(name = "SEQ_APPLICATION_LEGACY_DETAILS", sequenceName = "SEQ_APPLICATION_LEGACY_DETAILS", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_APPLICATION_LEGACY_DETAILS")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "resource_id")
	private int resourceId;

	@ManyToOne
	@JoinColumn(name = "application_id")
	private Application application;

	// @Column(name = "authentication_rule_id")
	// private int authenticationPolicyTargetId;
	//
	// @Column(name = "authorization_rule_ids")
	// private String authorizationPolicyTargetIds;

	@Column(name = "authorization_rule_names")
	private String authorizationRuleTargetNames;

	@Column(name = "authentication_rule_name")
	private String authenticationRuleTargetName;

	public LegacyDetails() {
		super();
	}

	public LegacyDetails(Resource resource) {
		this.resourceId = resource.getId();
		AuthenticationPolicy policy = null;
				//resource.getAuthenticationPolicy();
		// this.authenticationPolicyTargetId = (policy != null &&
		// !policy.isSystemSpecific()) ? policy.getTargetId() : 0;
		// this.authorizationPolicyTargetIds =
		// CommonUtils.getAuthorizationPolicyTargetIds(resource);

		this.authenticationRuleTargetName = (policy != null && !policy.isSystemSpecific()) ? policy.getTargetName()
				: null;
		//this.authorizationRuleTargetNames = CommonUtils.getAuthorizationPolicyTargetNames(resource);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getResourceId() {
		return resourceId;
	}

	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	/*public int getAuthenticationPolicyTargetId() {
		return authenticationPolicyTargetId;
	}

	public void setAuthenticationPolicyTargetId(int authenticationPolicyTargetId) {
		this.authenticationPolicyTargetId = authenticationPolicyTargetId;
	}

	public String getAuthorizationPolicyTargetIds() {
		return authorizationPolicyTargetIds;
	}

	public void setAuthorizationPolicyTargetIds(String authorizationPolicyTargetIds) {
		this.authorizationPolicyTargetIds = authorizationPolicyTargetIds;
	}*/

	public String getAuthorizationRuleTargetNames() {
		return authorizationRuleTargetNames;
	}

	public void setAuthorizationRuleTargetNames(String authorizationRuleTargetNames) {
		this.authorizationRuleTargetNames = authorizationRuleTargetNames;
	}

	public String getAuthenticationRuleTargetName() {
		return authenticationRuleTargetName;
	}

	public void setAuthenticationRuleTargetName(String authenticationRuleTargetName) {
		this.authenticationRuleTargetName = authenticationRuleTargetName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + resourceId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LegacyDetails other = (LegacyDetails) obj;
		if (resourceId != other.resourceId)
			return false;
		return true;
	}

}
