package com.persistent.pmt.dao;

import java.util.List;

import com.persistent.pmt.model.AuthenticationScheme;

/**
 * AuthenticationSchemeDao Interface
 *
 * @author Persistent Systems
 */
public interface AuthenticationSchemeDao {

  public AuthenticationScheme createAuthenticationScheme(
      AuthenticationScheme authenticationScheme);

  public AuthenticationScheme getAuthenticationSchemeByName(String authenicationSchemeName);
  
  public List<AuthenticationScheme> getAuthNSchemesByType(String authNSchemeType, String env);
  
}
