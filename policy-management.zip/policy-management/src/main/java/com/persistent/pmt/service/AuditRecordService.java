package com.persistent.pmt.service;

import java.util.List;

import org.springframework.data.domain.PageImpl;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.AuditRecord;
import com.persistent.pmt.model.AuditRecord.ACTIONS;
import com.persistent.pmt.response.GenericResponse;

public interface AuditRecordService {

  public void createAuditRecord(ACTIONS action, String status, String message, String context,
      Object... paramList) throws GenericException;

  public PageImpl<AuditRecord> getReportData(List<ACTIONS> actions, String status)
      throws GenericException;

  public GenericResponse<?> getImportStatistics() throws GenericException;

  int getMaxProcessIdForImportAll(int environmentId);
}
