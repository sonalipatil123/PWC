package com.persistent.pmt.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Provider
 * 
 * Entity model for Provider
 * 
 * @author Persistent Systems
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "provider")
public class Provider {

  @JsonIgnore
  @Id
  // @SequenceGenerator(name = "SEQ_PROVIDER", sequenceName =
  // "SEQ_PROVIDER", allocationSize = 1)
  // @GeneratedValue(strategy = GenerationType.SEQUENCE, generator =
  // "SEQ_PROVIDER")
  // TODO: uncomment below before check-in and recreate table with
  // Identity
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "id")
  private int id;

  @Column(name = "name")
  private String name;

  @Column(name = "description")
  private String description;

  @Column(name = "type")
  private String type;

  @Column(name = "remote")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean remote;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "provider_id")
  private List<ProviderAttributes> attributes;

  public Provider() {
    super();
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public boolean isRemote() {
    return remote;
  }

  public void setRemote(boolean remote) {
    this.remote = remote;
  }

  public List<ProviderAttributes> getAttributes() {
    return attributes;
  }

  public void setAttributes(List<ProviderAttributes> attributes) {
    this.attributes = attributes;
  }

  public String getSourceAttrValueByName(String sourceAttrName) {

    String sourceAttrValue = null;
    if (null == sourceAttrName)
      return sourceAttrValue;

    for (ProviderAttributes attr : attributes) {
      if (sourceAttrName.equals(attr.getSourceAttrName())) {
        sourceAttrValue = attr.getSourceAttrValue();
        break;
      }
    }
    return sourceAttrValue;
  }

}
