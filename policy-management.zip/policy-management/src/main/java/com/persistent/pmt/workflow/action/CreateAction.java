/**
 * CreateAction
 * 
 * Interface for create action
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.workflow.action;

import java.util.List;

import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public interface CreateAction extends Action {

  public Object rollback(Object object, List<WorkflowError> errors, WorkFlowContext context)
      throws Exception;

}
