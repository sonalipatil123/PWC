package com.persistent.pmt.commons.context;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.ApplicationFilter;

@Component("pmtContext")
public class PMTContext {

	public static final String PMTCONTEXTCONTAINER = "pmtContextContainer";
	private UserContext userContext;
	private FilterContext filterContext;
	private Map<String, String[]> paramContext;
	private HashMap<String, Object> applicationFilters;
	Map<String, Integer> pagingDetails;
	private List<String> writerFilters;
	private String processId;
	private int totalAppCount;

	public int getTotalAppCount() {
		return totalAppCount;
	}

	public void setTotalAppCount(int totalAppCount) {
		this.totalAppCount = totalAppCount;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public FilterContext getFilterContext() {
		return filterContext;
	}

	public void setFilterContext(FilterContext filterContext) {
		this.filterContext = filterContext;
	}

	public UserContext getUserContext() {
		return userContext;
	}

	public void setUserContext(UserContext userContext) {
		this.userContext = userContext;
	}

	public Map<String, String[]> getParamContext() {
		return paramContext;
	}

	public void setParamContext(Map<String, String[]> paramContext) {
		this.paramContext = paramContext;
	}

	public HashMap<String, Object> getApplicationFilters() {
		return applicationFilters;
	}

	public void setApplicationFilters(HashMap<String, Object> applicationFilters) {
		this.applicationFilters = applicationFilters;
	}

	public Map<String, Integer> getPagingDetails() {
		return pagingDetails;
	}

	public void setPagingDetails(Map<String, Integer> pagingDetails) {
		this.pagingDetails = pagingDetails;
	}

	public List<String> getWriterFilters() {
		return writerFilters;
	}

	public void setWriterFilters(List<String> writerFilters) {
		this.writerFilters = writerFilters;
	}

	public String getEnvironmentValue() {

		if (getApplicationFilters() != null && !getApplicationFilters().isEmpty()
				&& ((String) getApplicationFilters().get(ApplicationFilter.ENVIRONMENT.getValue()) != null)) {
			return (String) getApplicationFilters().get(ApplicationFilter.ENVIRONMENT.getValue());

		}
		return null;
	}

}