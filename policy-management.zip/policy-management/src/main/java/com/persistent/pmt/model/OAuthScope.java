package com.persistent.pmt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * OAuthScope
 * 
 * Entity model for OAuthScope
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "oauth_scope")
public class OAuthScope {

	@Id
//	@GenericGenerator(name = "oauth_scope_generator", strategy = "increment")
//	@GeneratedValue(generator = "oauth_scope_generator")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "life_cycle")
	private String lifeCycle;

	public OAuthScope() {
		super();
	}

	public OAuthScope(String name, String lifeCycle) {
		this.name = name;
		this.lifeCycle = lifeCycle;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
