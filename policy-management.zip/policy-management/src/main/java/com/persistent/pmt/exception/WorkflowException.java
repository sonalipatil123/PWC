/**
 * WorkflowException
 * 
 * Exception container for workflow
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.exception;

import java.util.List;

import com.persistent.pmt.error.WorkflowError;

public class WorkflowException extends GenericException {

	private static final long serialVersionUID = -7352265452156459337L;

	private List<WorkflowError> errors;

	public WorkflowException() {
		super();
	}

	public WorkflowException(List<WorkflowError> errors) {
		super();
		this.errors = errors;
	}

	public WorkflowException(String message, List<WorkflowError> errors) {
		super(message);
		this.errors = errors;
	}

	public WorkflowException(Throwable t) {
		super(t);
	}

	public List<WorkflowError> getErrors() {
		return errors;
	}

	public void setErrors(List<WorkflowError> errors) {
		this.errors = errors;
	}

}
