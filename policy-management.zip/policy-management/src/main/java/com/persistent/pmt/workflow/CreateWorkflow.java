/**
 * CreateWorkflow
 * 
 * Interface for create workflow
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.workflow;

public interface CreateWorkflow extends Workflow {

}
