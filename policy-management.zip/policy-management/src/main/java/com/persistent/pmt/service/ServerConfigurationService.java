package com.persistent.pmt.service;

import com.persistent.pmt.commons.context.TargetConnectionTemplate;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.to.openam.EnvironmentPropertiesTO;

/**
 * 
 * @author Persistent Systems
 */
public interface ServerConfigurationService {

	/**
   * Get all system properties for the environment identified by id
   * 
   * @return
	 * @throws GenericException 
   */
  public GenericResponse<?> getProperties() throws GenericException;

  /**
   * Get the value of property identified by name for environment
   * identified by environment
   * 
   * @param name
   * @param id
   * @return
 * @throws GenericException 
   */
  public String getPropertyValue(String propertyName) throws GenericException;

  /**
   * Create properties in PROPERTY table
   * 
   * @param property
   * @return
   * @throws GenericException
   */
  public GenericResponse<?> createOrUpdateEnvironmentProperties(
      EnvironmentPropertiesTO environmentPropsTO)
      throws GenericException;

  public GenericResponse<?> getLifecycle() throws GenericException;
  

  public TargetConnectionTemplate getTargetConnectionTemplate() throws GenericException;
}
