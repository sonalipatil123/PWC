package com.persistent.pmt.model;

public class ScoreBoard {

	private String lae_virtual_url;
	private String lae_backend_url;
	private String sso_pmt_app_name;
	private String lae_life_category;
	private String lae_security_regime;
	private String sso_status;

	public ScoreBoard() {
		super();
	}

	public String getSso_status() {
		return sso_status;
	}

	public void setSso_status(String sso_status) {
		this.sso_status = sso_status;
	}

	public String getLae_virtual_url() {
		return lae_virtual_url;
	}

	public void setLae_virtual_url(String lae_virtual_url) {
		this.lae_virtual_url = lae_virtual_url;
	}

	public String getLae_security_regime() {
		return lae_security_regime;
	}

	public void setLae_security_regime(String lae_security_regime) {
		this.lae_security_regime = lae_security_regime;
	}


	public String getLae_life_category() {
		return lae_life_category;
	}

	public void setLae_life_category(String lae_life_category) {
		this.lae_life_category = lae_life_category;
	}

	public String getLae_backend_url() {
		return lae_backend_url;
	}

	public void setLae_backend_url(String lae_backend_url) {
		this.lae_backend_url = lae_backend_url;
	}

	public String getSso_pmt_app_name() {
		return sso_pmt_app_name;
	}

	public void setSso_pmt_app_name(String sso_pmt_app_name) {
		this.sso_pmt_app_name = sso_pmt_app_name;
	}

}
