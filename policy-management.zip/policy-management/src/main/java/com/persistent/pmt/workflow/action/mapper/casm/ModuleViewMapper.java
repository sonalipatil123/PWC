package com.persistent.pmt.workflow.action.mapper.casm;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.AuditPropertyConstants;
import com.persistent.pmt.constant.MapperConstants;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.casm.AuthenticationSchemeTypes;
import com.persistent.pmt.constant.casm.PolicyGrammarConstants;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.model.AuthenticationScheme;
import com.persistent.pmt.model.AuthenticationSchemeAttributes;
import com.persistent.pmt.model.Provider;
import com.persistent.pmt.model.UserDataStore;
import com.persistent.pmt.model.UserDataStoreAttributes;
import com.persistent.pmt.model.mapper.UserStoreMapperAttributes;
import com.persistent.pmt.service.ServerConfigurationService;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.utils.MapperUtils;
import com.persistent.pmt.view.openam.AnonymousModuleView;
import com.persistent.pmt.view.openam.CertificateModuleView;
import com.persistent.pmt.view.openam.HttpBasicModuleView;
import com.persistent.pmt.view.openam.LDAPModuleView;
import com.persistent.pmt.view.openam.LegacyOAuth2OpenIdConnectModuleView;
import com.persistent.pmt.view.openam.ModuleView;
import com.persistent.pmt.view.openam.SAML2ModuleView;
import com.persistent.pmt.view.openam.WindowsDesktopModuleView;
import com.persistent.pmt.workflow.action.mapper.GenericMapper;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component
@PropertySource(value = { "classpath:application.properties",
    "classpath:auditMessages.properties" })
public class ModuleViewMapper implements GenericMapper {

  @Autowired
  ServerConfigurationService serverConfigurationService;

  @Autowired
  Environment environment;

  @Override
  public Object getMappedObject(Object object, WorkFlowContext workFlowContext)
      throws GenericException {
    return getModuleViews((Application) object, workFlowContext);
  }

  @Override
  public String getId(Object object) throws GenericException {
    return CommonUtils.formatString((((Application) object).getName()),
        MapperUtils.getInvalidCharacters());
  }

  public List<ModuleView> getModuleViews(Application application,
      WorkFlowContext workFlowContext) throws GenericException {
    List<ModuleView> moduleViews = new ArrayList<ModuleView>();
    String authenticationType = null;
    if (application != null) {
      AuthenticationScheme authenticationScheme = application.getDefaultAuthScheme();

      if (authenticationScheme != null) {
        authenticationType = authenticationScheme.getType();
      }
      if (PMTConstants.PEP_TYPE_AGENT.equalsIgnoreCase(application.getPepType())) {

        if (AuthenticationSchemeTypes.AUTHN_SCHEME_HTML_FORM.getValue().equalsIgnoreCase(
            authenticationType)
            || AuthenticationSchemeTypes.AUTHN_SCHEME_HTMLFORMACE.getValue().equalsIgnoreCase(
                authenticationType)) {

          List<LDAPModuleView> ldapModuleViews =
              createLdapModuleViews(application, authenticationScheme, workFlowContext);
          moduleViews.addAll(ldapModuleViews);
        }
        else if (AuthenticationSchemeTypes.AUTHN_SCHEME_ANONYMOUS.getValue().equalsIgnoreCase(
            authenticationType)) {
          AnonymousModuleView anonymousModuleView = new AnonymousModuleView();
          anonymousModuleView.setId(getId(application));
          anonymousModuleView
              .setAuthenticationLevel(getAuthenticationLevel(authenticationScheme));

          moduleViews.add(anonymousModuleView);
        }
        else if (AuthenticationSchemeTypes.AUTHN_SCHEME_BASIC.getValue().equalsIgnoreCase(
            authenticationType)) {

          List<LDAPModuleView> ldapModuleViews =
              createLdapModuleViews(application, authenticationScheme, workFlowContext);

          List<HttpBasicModuleView> basicModuleViews = new ArrayList<HttpBasicModuleView>();

          for (LDAPModuleView ldapModuleView : ldapModuleViews) {
            HttpBasicModuleView basicModuleView = new HttpBasicModuleView();
            basicModuleView
                .setAuthenticationLevel(getAuthenticationLevel(authenticationScheme));
            basicModuleView.setBackendModuleName(ldapModuleView.getId());
            basicModuleView.setId(getId(application));
            basicModuleViews.add(basicModuleView);
          }

          moduleViews.addAll(ldapModuleViews);
          moduleViews.addAll(basicModuleViews);
        }
        else if (AuthenticationSchemeTypes.AUTHN_SCHEME_CUSTOM.getValue().equalsIgnoreCase(
            authenticationType)) {
          // Audit Log- custom scheme will be picked from Target
          // System configuration from PMT Database for Module
          // creation for application.
          workFlowContext.getModuleAuditData().append(
              environment
                  .getProperty(AuditPropertyConstants.TARGET_MAPPER_MODULEVIEW_CUSTOMSCHEME));

          if (AuthenticationSchemeTypes.AUTHENTICATION_SCHEME_FORM.getValue()
              .equalsIgnoreCase(
                  serverConfigurationService
                      .getPropertyValue(PMTConstants.CUSTOM_ALTERNATE_SCHEME))) {
            List<LDAPModuleView> ldapModuleViews =
                createLdapModuleViews(application, authenticationScheme, workFlowContext);
            moduleViews.addAll(ldapModuleViews);
          }
        }

        else if (AuthenticationSchemeTypes.AUTHN_SCHEME_NTLM.getValue().equalsIgnoreCase(
            authenticationType)) {

          WindowsDesktopModuleView moduleView = new WindowsDesktopModuleView();
          moduleView.setId(getId(application));
          moduleView.setAuthenticationLevel(getAuthenticationLevel(authenticationScheme));
          moduleViews.add(moduleView);

          // Audit Log- Windows Desktop module created for
          // application. Authentication level set from siteminder
          // data. Rest all information is set to default.
          workFlowContext
              .getModuleAuditData()
              .append(
                  MessageFormat.format(
                  environment
                      .getProperty(AuditPropertyConstants.TARGET_MAPPER_MODULEVIEW_AUTHSCHEME_NTLM),
                      new Object[] { moduleView.getId() }));
        }
        else if (AuthenticationSchemeTypes.AUTHN_SCHEME_X509CERT.getValue().equalsIgnoreCase(
            authenticationType)) {

          CertificateModuleView certificateModuleView =
              createCertificateModuleView(application, authenticationScheme);
          moduleViews.add(certificateModuleView);
          return moduleViews;
        }
        else if (AuthenticationSchemeTypes.AUTHN_SCHEME_X509CERTANDFORM.getValue()
            .equalsIgnoreCase(authenticationType)
            || AuthenticationSchemeTypes.AUTHN_SCHEME_X509CERTORFORM.getValue()
                .equalsIgnoreCase(authenticationType)) {

          if (application.getUserDataStores() != null) {
            for (UserDataStore userDataStore : application.getUserDataStores()) {
              LDAPModuleView ldapModuleView =
                  createLDAPModuleView(authenticationScheme, userDataStore, workFlowContext);
              moduleViews.add(ldapModuleView);
            }

            CertificateModuleView certificateModuleView =
                createCertificateModuleView(application, authenticationScheme);
            moduleViews.add(certificateModuleView);
          }
          return moduleViews;
        }

        else if (AuthenticationSchemeTypes.AUTHN_SCHEME_SAML2.getValue().equalsIgnoreCase(
            authenticationType)) {

          Provider provider = application.getProvider();
          if (null != provider) {

            SAML2ModuleView saml2ModuleView = new SAML2ModuleView();
            saml2ModuleView.setId(getId(application));
            saml2ModuleView.setAuthenticationLevel(Integer.parseInt(authenticationScheme
                .getLevel()));
            saml2ModuleView.setNameIdFormat(provider.getSourceAttrValueByName("NameIDFormat"));
            saml2ModuleView.setEntityName(provider.getSourceAttrValueByName("IdPID"));
            saml2ModuleView.setMetaAlias("/pwc/idp2");

            String serverUrl =
                serverConfigurationService
                    .getPropertyValue(PolicyGrammarConstants.OPENAM_SERVER_URL);
            saml2ModuleView.setSloRelay(serverUrl + "IDPSloPOST/metaAlias/pwc/idp2");

            saml2ModuleView.setAuthnContextClassRef(provider
                .getSourceAttrValueByName("AuthnContextClassRef"));

            String requestBinding = "";
            String ssoServiceLink = provider.getSourceAttrValueByName("SSOServiceLink");

            if (ssoServiceLink.contains("Endpoint_Binding")) {
              if (ssoServiceLink.contains(MapperConstants.SEPARATOR_COMMA)) {
                String[] ssoServiceLinks =
                    ssoServiceLink.split(MapperConstants.SEPARATOR_COMMA);
                if (ssoServiceLinks != null && ssoServiceLinks.length > 0)
                  for (String link : ssoServiceLinks) {
                    requestBinding = fetchBindingValue(link);
                    break;
                  }
              }
              else {
                requestBinding = fetchBindingValue(ssoServiceLink);
              }
            }

            saml2ModuleView.setReqBinding(requestBinding);
            saml2ModuleView.setBinding("urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST");
            saml2ModuleView.setSloEnabled(provider.getSourceAttrValueByName("EnableSLO"));

            moduleViews.add(saml2ModuleView);
          }
          return moduleViews;
        }
      }
      else if (PMTConstants.PEP_TYPE_FEDERATION.equalsIgnoreCase(application.getPepType())) {

        if (AuthenticationSchemeTypes.AUTHN_SCHEME_OAUTH.getValue().equalsIgnoreCase(
            authenticationType)) {
          LegacyOAuth2OpenIdConnectModuleView legacyOAuth2OpenIdConnectModuleView =
              createLegacyOAuth2OIdCModuleView(application);
          moduleViews.add(legacyOAuth2OpenIdConnectModuleView);
        }
      }
    }
    return moduleViews;
  }

  private String fetchBindingValue(String link) {
    String requestBinding = "";
    if (link.contains("Endpoint_Binding") && link.contains("=")) {
      String[] links = link.split("=");
      if (links != null && links.length > 1) {
        if ("Endpoint_Binding".equals(links[0].trim())) {
          requestBinding = links[1].trim();
        }
      }
    }
    return requestBinding;
  }

  private LegacyOAuth2OpenIdConnectModuleView createLegacyOAuth2OIdCModuleView(
      Application application) throws GenericException {

    LegacyOAuth2OpenIdConnectModuleView legacyOAuth2OpenIdConnectModuleView =
        new LegacyOAuth2OpenIdConnectModuleView();
    legacyOAuth2OpenIdConnectModuleView.setId(getId(application));
    Provider provider = application.getProvider();
    if (provider != null) {
      legacyOAuth2OpenIdConnectModuleView.setClientId(provider
          .getSourceAttrValueByName(PolicyGrammarConstants.CLIENT_ID));
      legacyOAuth2OpenIdConnectModuleView.setClientSecret(provider
          .getSourceAttrValueByName(PolicyGrammarConstants.CLIENT_SECRETE));
    }

    return legacyOAuth2OpenIdConnectModuleView;
  }

  private List<LDAPModuleView> createLdapModuleViews(Application application,
      AuthenticationScheme authenticationScheme, WorkFlowContext workFlowContext)
      throws GenericException {
    List<LDAPModuleView> ldapModuleViews = new ArrayList<LDAPModuleView>();

    if (application.getUserDataStores() != null) {

      for (UserDataStore userDataStore : application.getUserDataStores()) {

        LDAPModuleView ldapModuleView =
            createLDAPModuleView(authenticationScheme, userDataStore, workFlowContext);
        ldapModuleViews.add(ldapModuleView);
      }
    }
    return ldapModuleViews;
  }

  private CertificateModuleView createCertificateModuleView(Application application,
      AuthenticationScheme authenticationScheme) throws GenericException {
    CertificateModuleView certificateModuleView = new CertificateModuleView();
    certificateModuleView.setId(getId(application));
    certificateModuleView.setAuthenticationLevel(getAuthenticationLevel(authenticationScheme));
    return certificateModuleView;
  }

  private LDAPModuleView createLDAPModuleView(AuthenticationScheme authenticationScheme,
      UserDataStore userDataStore, WorkFlowContext workFlowContext) throws GenericException {
    LDAPModuleView ldapModuleView = new LDAPModuleView();

    ldapModuleView.setId(CommonUtils.formatString(userDataStore.getName(),
        MapperUtils.getInvalidCharacters()));

    UserStoreMapperAttributes userStoreMapperAttributes =
        getUserStoreAttributes(userDataStore, workFlowContext);

    if (userStoreMapperAttributes.isUserAndPassword()) {
      ldapModuleView.setUserBindDN(userStoreMapperAttributes.getBinDN());
      ldapModuleView.setUserBindPassword(userStoreMapperAttributes.getPassword());

    }

    if (userStoreMapperAttributes.getPrimaryServers() != null
        && userStoreMapperAttributes.getPrimaryServers().length > 0) {
      ldapModuleView.setPrimaryLdapServer(userStoreMapperAttributes.getPrimaryServers());
    }
    ldapModuleView.setAuthenticationLevel(getAuthenticationLevel(authenticationScheme));
    ldapModuleView.setUserSearchStartDN(userStoreMapperAttributes.getSearchRoots());
    ldapModuleView.setOperationTimeout(Integer.parseInt(userStoreMapperAttributes
        .getSearchTimeOut()));
    ldapModuleView.setSearchScope(userStoreMapperAttributes.getSearchScope());
    ldapModuleView.setUserProfileRetrievalAttribute(userStoreMapperAttributes
        .getLoginAttributes()[0]);
    ldapModuleView.setUserSearchAttributes(userStoreMapperAttributes.getLoginAttributes());
    ldapModuleView.setUserSearchFilter(userStoreMapperAttributes.getUserLookupStart()
        + userStoreMapperAttributes.getLoginAttributes()[0]
        + userStoreMapperAttributes.getUserLookupEnd());
    ldapModuleView.setReturnUserDN(true);
    ldapModuleView.setTrustAllServerCertificates(true);
    if (userStoreMapperAttributes.isSecureConnection()) {
      ldapModuleView.setOpenamAuthLdapConnectionMode("LDAPS");
    }
    else {
      ldapModuleView.setOpenamAuthLdapConnectionMode("LDAP");
    }
    return ldapModuleView;

  }

  private int getAuthenticationLevel(AuthenticationScheme authenticationScheme) {
    int authenticationLevel = 0;
    for (AuthenticationSchemeAttributes attributes : authenticationScheme.getAttributes()) {
      if ("Level".equalsIgnoreCase(attributes.getSourceAttrName())) {
        authenticationLevel = Integer.parseInt(attributes.getSourceAttrValue());
      }
    }
    return authenticationLevel;
  }

  private UserStoreMapperAttributes getUserStoreAttributes(UserDataStore userDataStore,
      WorkFlowContext workFlowContext) throws GenericException {
    UserStoreMapperAttributes userStoreMapperAttributes = null;
    if (userDataStore != null) {
      userStoreMapperAttributes = new UserStoreMapperAttributes();

      userStoreMapperAttributes.setName(userDataStore.getName());
      userStoreMapperAttributes.setBinDN(userDataStore.getUsername());
      userStoreMapperAttributes.setPassword(userDataStore.getPassword());

      if (userDataStore != null & userDataStore.getAttributes() != null) {
        for (UserDataStoreAttributes userDataAttribute : userDataStore.getAttributes()) {

          if ("RequireCredentials".equalsIgnoreCase(userDataAttribute.getSourceAttrName())) {
            if ("true".equalsIgnoreCase(userDataAttribute.getSourceAttrValue())) {
              userStoreMapperAttributes.setUserAndPassword(true);
            }
          }
          else if ("SecureConnection".equalsIgnoreCase(userDataAttribute.getSourceAttrName())) {
            if ("true".equalsIgnoreCase(userDataAttribute.getSourceAttrValue())) {
              userStoreMapperAttributes.setSecureConnection(true);
            }
          }
          else if ("Server".equalsIgnoreCase(userDataAttribute.getSourceAttrName())) {
            // Audit Record
            workFlowContext.getModuleAuditData().append(
                MessageFormat.format(environment
                    .getProperty(AuditPropertyConstants.TARGET_MAPPER_MODULEVIEW_USERSTORE),
                        new Object[] {
                            CommonUtils.formatString(userDataStore.getName(),
                                MapperUtils.getInvalidCharacters()), userDataStore.getName() }));
          }
          else if ("SearchRoot".equalsIgnoreCase(userDataAttribute.getSourceAttrName())) {
            userStoreMapperAttributes.setSearchRoots(new String[] { userDataAttribute
                .getSourceAttrValue() });
          }
          else if ("SearchScope".equalsIgnoreCase(userDataAttribute.getSourceAttrName())) {
            String searchScope = "";
            if ("0".equals(userDataAttribute.getSourceAttrValue())) {
              userStoreMapperAttributes.setSearchScope(searchScope);
              searchScope = "OBJECT";
            }
            else if ("1".equals(userDataAttribute.getSourceAttrValue())) {
              searchScope = "ONELEVEL";
            }
            else if ("2".equals(userDataAttribute.getSourceAttrValue())) {
              searchScope = "SUBTREE";
            }
            userStoreMapperAttributes.setSearchScope(searchScope);

          }
          else if ("UniversalIDAttribute".equalsIgnoreCase(userDataAttribute
              .getSourceAttrName())) {
            userStoreMapperAttributes.setLoginAttributes(new String[] { userDataAttribute
                .getSourceAttrValue() });
          }
          else if ("SearchTimeout".equalsIgnoreCase(userDataAttribute.getSourceAttrName())) {
            userStoreMapperAttributes.setSearchTimeOut(userDataAttribute.getSourceAttrValue());
          }
          if ("UserLookupEnd".equalsIgnoreCase(userDataAttribute.getSourceAttrName())) {
            userStoreMapperAttributes.setUserLookupEnd(userDataAttribute.getSourceAttrValue());
          }
          else if ("UserLookupStart".equalsIgnoreCase(userDataAttribute.getSourceAttrName())) {
            userStoreMapperAttributes
                .setUserLookupStart(userDataAttribute.getSourceAttrValue());
          }
        }
      }
    }
    return userStoreMapperAttributes;
  }

}
