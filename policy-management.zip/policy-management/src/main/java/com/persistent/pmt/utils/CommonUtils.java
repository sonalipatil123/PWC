/**
 * CommonUtils
 * 
 * Utility class for common operations across application
 * 
 * @author Persistent Systems
 */
package com.persistent.pmt.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.ApplicationFilter;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.Product;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component
public class CommonUtils {

	public static HttpHeaders getHeaders(String ssoToken, Product product, HttpMethod method) {
		HttpHeaders headers = new HttpHeaders();
		if (ssoToken != null && !ssoToken.isEmpty()) {
			headers.add(PMTConstants.HEADER_AUTHORIZATION, ssoToken);
		}

		if (Product.OPENAM.equals(product)) {
			if (!HttpMethod.GET.equals(method)) {
				headers.add(PMTConstants.HEADER_CONTENT_TYPE, PMTConstants.TYPE_JSON);
			}
			headers.add(PMTConstants.HEADER_ACCEPT, PMTConstants.TYPE_JSON);
		}
		return headers;
	}

	public static HttpHeaders getHeaders(WorkFlowContext context, Product product, HttpMethod method) {

		return getHeaders(context.getToken(PMTConstants.CONTEXT_AUTHTOKEN), product, method);
	}

	public static String getStringValue(Attribute attribute) throws NamingException {
		if (attribute == null) {
			return null;
		}
		Object obj = attribute.get();
		String val = null;
		if (obj != null) {
			val = (String) obj;
		}

		return val;
	}

	public static String getMultiValuedString(Attribute attribute) throws NamingException {
		if (attribute == null) {
			return null;
		}
		NamingEnumeration<?> vals = attribute.getAll();

		StringBuilder strBuilder = new StringBuilder();
		while ((vals != null) && (vals.hasMore())) {
			String val = (String) vals.next();
			if (val != null) {
				strBuilder.append(val);
				strBuilder.append(":");
			}
		}
		int index = strBuilder.lastIndexOf(":");
		if (index > 0) {
			strBuilder.deleteCharAt(index);
		}

		return strBuilder.toString();
	}

	public static String getMultiValuedString1(Attribute attribute) throws NamingException {
		if (attribute == null) {
			return null;
		}
		NamingEnumeration<?> vals = attribute.getAll();

		StringBuilder strBuilder = new StringBuilder();
		while ((vals != null) && (vals.hasMore())) {
			String val = (String) vals.next();
			if (val != null) {
				strBuilder.append(val);
				strBuilder.append("&");
			}
		}
		int index = strBuilder.lastIndexOf("&");
		if (index > 0) {
			strBuilder.deleteCharAt(index);
		}

		return strBuilder.toString();
	}

	public static void processFilterParams(Map<String, String[]> params, Map<String, Object> filters) {
		if (params != null && !params.isEmpty()) {
			List<ApplicationFilter> applicationFilters = Arrays.asList(ApplicationFilter.values());
			String filterName = null;
			String[] value = null;

			for (ApplicationFilter filter : applicationFilters) {
				filterName = filter.getValue();
				if (params.containsKey(filterName) && (value = params.get(filterName)) != null && value.length > 0) {
					filters.put(filterName, value[0]);
				} else {
					// throw new GenericException("Filter not supported", 400,
					// "bad request");
				}
			}
		}
		// processPlatformFilter(user, params, filters);
	}

	public static void processPagingParams(Map<String, String[]> params, Map<String, Integer> pagingDetails,
			int totalCount) {
		String[] value = null;
		totalCount = (totalCount == 0) ? 10 : totalCount;

		if (params.containsKey("page") && (value = params.get("page")) != null) {
			pagingDetails.put("page", (value.length > 0) ? Integer.valueOf(value[0]) : 0);
		} else {
			pagingDetails.put("page", 0);
		}

		if (params.containsKey("numberPerPage") && (value = params.get("numberPerPage")) != null) {
			pagingDetails.put("numberPerPage", (value.length > 0) ? Integer.valueOf(value[0]) : totalCount);
		} else {
			pagingDetails.put("numberPerPage", totalCount);
		}
	}

	// method which extracts writer names which needs to be ran, this is
	// an optional
	public static void processWriterFilterParams(Map<String, String[]> params, List<String> writerFilters) {

		if (params != null && !params.isEmpty()) {
			List<ApplicationFilter> applicationFilters = Arrays.asList(ApplicationFilter.values());
			String filterName = null;
			String[] value = null;

			for (ApplicationFilter filter : applicationFilters) {
				filterName = filter.getValue();
				if (params.containsKey(filterName) && (value = params.get(filterName)) != null && value.length > 0) {
					writerFilters.add(value[0]);
				} else {
					// throw new GenericException("Filter not supported", 400,
					// "bad request");
				}
			}
		}
	}

	public static HashMap<String, String> createOpenAMParamMap(String id, String realmName) {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put(PMTConstants.ID, id);
		params.put(PMTConstants.REALM_NAME, realmName);
		return params;
	}

	public static String formatString(String str, String replaceCharacters) {
		if (str != null && replaceCharacters != null) {
			str = str.replaceAll(replaceCharacters, "");
		}
		return str;
	}

	public static boolean isNotEmpty(String str) {
		if (str != null && !str.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	public static Object deepCopy(Object object) {
		try {
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			ObjectOutputStream outputStrm = new ObjectOutputStream(outputStream);
			outputStrm.writeObject(object);
			ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
			ObjectInputStream objInputStream = new ObjectInputStream(inputStream);
			return objInputStream.readObject();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/*
	 * public static String truncateString(String s, int maxBytes) { int b = 0; for
	 * (int i = 0; i < s.length(); i++) { char c = s.charAt(i);
	 * 
	 * // ranges from http://en.wikipedia.org/wiki/UTF-8 int skip = 0; int more; if
	 * (c <= 0x007f) { more = 1; } else if (c <= 0x07FF) { more = 2; } else if (c <=
	 * 0xd7ff) { more = 3; } else if (c <= 0xDFFF) { // surrogate area, consume next
	 * char as well more = 4; skip = 1; } else { more = 3; }
	 * 
	 * if (b + more > maxBytes) { return s.substring(0, i); } b += more; i += skip;
	 * } return s; }
	 */
	
}
