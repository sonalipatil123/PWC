package com.persistent.pmt.dao.impl;

import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.dao.UserDataStoreDao;
import com.persistent.pmt.model.UserDataStore;

/**
 * UserDataStoreDaoImpl
 * 
 * Implementation of UserDataStoreDao
 * 
 * @author Persistent Systems
 */
@PropertySource(value = { "classpath:application.properties" })
@Repository("userDataStoreDao")
@Transactional
public class UserDataStoreDaoImpl extends BaseDaoImpl implements UserDataStoreDao {

  /**
   * This method creates an userDataStore into PMT database
   */
  @Override
  public UserDataStore createUserDataStore(UserDataStore userDataStore) {
    getSession().save(userDataStore);
    return userDataStore;
  }
}
