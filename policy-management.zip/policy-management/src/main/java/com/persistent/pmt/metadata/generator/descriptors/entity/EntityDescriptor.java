package com.persistent.pmt.metadata.generator.descriptors.entity;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.persistent.pmt.metadata.generator.XmlUtils.XmlSourceGenerator;
import com.persistent.pmt.metadata.generator.descriptors.core.Descriptor;

@Component
public class EntityDescriptor implements Descriptor {

	@Autowired
	XmlSourceGenerator xmlSourceGenerator;

	String metadataID;
	String entityID;
	Descriptor descriptor;
	Contacts contact;
	String template;

	public EntityDescriptor() {
		super();
	}

	public EntityDescriptor(Descriptor descriptorObj, Contacts contactObj) {
		this.descriptor = descriptorObj;
		this.contact = contactObj;

	}
	public Descriptor getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(Descriptor descriptor) {
		this.descriptor = descriptor;
	}

	public Contacts getContact() {
		return contact;
	}

	public void setContact(Contacts contact) {
		this.contact = contact;
	}



	@Override
	public Map<String, String> getDescriptorData(Map<String, String> tokenMap) {
		tokenMap.put("descriptorData", descriptor.getXMLData(tokenMap));
		tokenMap.put("contactPersonData", contact.getXMLData(tokenMap));
		return tokenMap;
	}

	@Override
	public void setTemplatePath(String template) {

		this.template = template;
	}

	@Override
	public String getXMLData(Map<String, String> tokenMap) {
		String xmlSource = xmlSourceGenerator.generateXmlSource(tokenMap, template);
		return xmlSource;
	}

}
