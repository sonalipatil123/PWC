package com.persistent.pmt.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.persistent.pmt.dao.BaseDao;


public class BaseDaoImpl implements BaseDao {

	@Autowired
	SessionFactory sessionFactory;

	/**
	 * This method provides hibernate session
	 * 
	 * @return Session
	 */
	@Override
	public Session getSession() {
		return sessionFactory.getCurrentSession();
	}

	/**
	 * This method provides hibernate criteria
	 * 
	 * @return Criteria
	 */
	@Override
	public Criteria createCriteria(Class<?> c) {
		return getSession().createCriteria(c);
	}

}
