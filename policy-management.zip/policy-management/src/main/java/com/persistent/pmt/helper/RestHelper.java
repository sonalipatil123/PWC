/**
 * RestHelper
 * 
 * Base interface for REST execution
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.helper;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

public interface RestHelper<T> {

	public ResponseEntity<T> execute(String url, HttpMethod method, HttpEntity<T> entity, Class<T> clazz);

}
