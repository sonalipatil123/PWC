package com.persistent.pmt.metadata.generator.descriptors.entity;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.persistent.pmt.metadata.generator.XmlUtils.XmlSourceGenerator;

@Component
public class Contacts {

	@Autowired
	XmlSourceGenerator xmlSourceGenerator;

	private String template;

	public String getXMLData(Map<String, String> tokenMap) {

		String xmlSource = xmlSourceGenerator.generateXmlSource(getContactPersonTokenList(tokenMap), template);
		return xmlSource;
	}

	private ArrayList<Map<String, String>> getContactPersonTokenList(Map<String, String> tokenMap) {
		ArrayList<Map<String, String>> tokenList = new ArrayList<Map<String, String>>();
		tokenList.add(tokenMap);

		return tokenList;
	}

	public void setTemplatePath(String template) {
		this.template = template;

	}
}
