package com.persistent.pmt.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.response.TargetResponse;
import com.persistent.pmt.service.ReadOpenAmArtifactService;
import com.persistent.pmt.view.openam.ReadQueryObject;
import com.persistent.pmt.workflow.ReadOpenAmArtifactWorkflow;

@Service("readOpenAMArtifactService")
@Transactional
public class ReadOpenAmArtifactServiceImpl implements ReadOpenAmArtifactService {

  @Autowired
  @Qualifier("readOpenAmArtifactWorkflowImpl")
  ReadOpenAmArtifactWorkflow readOpenAmArtifactWorkflow;

  @Override
  public GenericResponse<?> read(ReadQueryObject readQueryObject) throws GenericException {
    GenericResponse<Object> response = new GenericResponse<Object>();

    TargetResponse targetResponse = readOpenAmArtifactWorkflow.read(readQueryObject);
    response.setContent(targetResponse);
    response.setStatusCode(HttpStatus.OK.value());
    response.setMessage("OpenAM artifacts have been read successfully.");
    response.setStatus(GenericResponse.SUCCESS);

    return response;
  }
}
