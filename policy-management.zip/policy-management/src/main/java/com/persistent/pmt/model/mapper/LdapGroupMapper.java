package com.persistent.pmt.model.mapper;

import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

import org.springframework.ldap.core.AttributesMapper;

import com.persistent.pmt.model.LdapGroup;
import com.persistent.pmt.utils.CommonUtils;

public class LdapGroupMapper implements AttributesMapper<LdapGroup> {

	Map<String,String> attributeName = new HashMap<>();
	
	public void setAttributeName(Map<String, String> attributeName) {
		this.attributeName = attributeName;
	}

	@Override
	public LdapGroup mapFromAttributes(Attributes attributes) throws NamingException {
		LdapGroup ldapGroup = new LdapGroup();
		ldapGroup.setName(CommonUtils.getStringValue(attributes.get("cn")));
		
		
		ldapGroup.setMember(CommonUtils.getMultiValuedString(attributes.get((attributeName != null && attributeName.get("member") != null) ? attributeName.get("member"): "uniquemember")));
		
		return ldapGroup;
	}

}
