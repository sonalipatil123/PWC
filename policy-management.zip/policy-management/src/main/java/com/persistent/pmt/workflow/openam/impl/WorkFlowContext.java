package com.persistent.pmt.workflow.openam.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.persistent.pmt.view.openam.AgentView;
import com.persistent.pmt.view.openam.ModuleView;
import com.persistent.pmt.view.openam.PolicyView;

public class WorkFlowContext {

  private Map<String, Object> contextMap;
  private List<PolicyView> rollbackPolicyViewsOnFailure;
  private List<ModuleView> rollbackModuleViewsOnFailure;
  private List<ModuleView> moduleViews;
  private String resourceType;
  private String providerNameForRollbackOnFailure;
  private boolean policySetRollbackOnFailure;
  private boolean moduleChainRollbackOnFailure;
  private List<AgentView> rollbackAgentViewsOnFailure;
  private String realmName;
  private StringBuilder policySetAuditData = new StringBuilder();
  private StringBuilder policyAuditData = new StringBuilder();
  private StringBuilder moduleAuditData = new StringBuilder();
  private StringBuilder moduleChainAuditData = new StringBuilder();
  private StringBuilder providerAuditData = new StringBuilder();
  private StringBuilder agentAuditData = new StringBuilder();

  public WorkFlowContext() {
    this.contextMap = new HashMap<String, Object>();
  }

  public void setToken(String tokenKey, String tokenValue) {
    contextMap.put(tokenKey, tokenValue);
  }

  public String getToken(String tokenKey) {
    return (String) contextMap.get(tokenKey);
  }

  public List<PolicyView> getRollbackPolicyViewsOnFailure() {
    return rollbackPolicyViewsOnFailure;
  }

  public void setRollbackPolicyViewsOnFailure(List<PolicyView> rollbackPolicyViewsOnFailure) {
    this.rollbackPolicyViewsOnFailure = rollbackPolicyViewsOnFailure;
  }

  public List<ModuleView> getRollbackModuleViewsOnFailure() {
    return rollbackModuleViewsOnFailure;
  }

  public void setRollbackModuleViewsOnFailure(List<ModuleView> rollbackModuleViewsOnFailure) {
    this.rollbackModuleViewsOnFailure = rollbackModuleViewsOnFailure;
  }

  public List<ModuleView> getModuleViews() {
    return moduleViews;
  }

  public void setModuleViews(List<ModuleView> moduleViews) {
    this.moduleViews = moduleViews;
  }

  public String getResourceType() {
    return resourceType;
  }

  public void setResourceType(String resourceType) {
    this.resourceType = resourceType;
  }

  public String getProviderNameForRollbackOnFailure() {
    return providerNameForRollbackOnFailure;
  }

  public void setProviderNameForRollbackOnFailure(String providerNameForRollbackOnFailure) {
    this.providerNameForRollbackOnFailure = providerNameForRollbackOnFailure;
  }

  public List<AgentView> getRollbackAgentViewsOnFailure() {
    return rollbackAgentViewsOnFailure;
  }

  public void setRollbackAgentViewsOnFailure(List<AgentView> rollbackAgentViewsOnFailure) {
    this.rollbackAgentViewsOnFailure = rollbackAgentViewsOnFailure;
  }

  public String getRealmName() {
    return realmName;
  }

  public void setRealmName(String realmName) {
    this.realmName = realmName;
  }

  public boolean isPolicySetRollbackOnFailure() {
    return policySetRollbackOnFailure;
  }

  public void setPolicySetRollbackOnFailure(boolean policySetRollbackOnFailure) {
    this.policySetRollbackOnFailure = policySetRollbackOnFailure;
  }

  public boolean isModuleChainRollbackOnFailure() {
    return moduleChainRollbackOnFailure;
  }

  public void setModuleChainRollbackOnFailure(boolean moduleChainRollbackOnFailure) {
    this.moduleChainRollbackOnFailure = moduleChainRollbackOnFailure;
  }

  public StringBuilder getPolicySetAuditData() {
    return policySetAuditData;
  }

  public void setPolicySetAuditData(StringBuilder policySetAuditData) {
    this.policySetAuditData = policySetAuditData;
  }

  public StringBuilder getPolicyAuditData() {
    return policyAuditData;
  }

  public void setPolicyAuditData(StringBuilder policyAuditData) {
    this.policyAuditData = policyAuditData;
  }

  public StringBuilder getModuleAuditData() {
    return moduleAuditData;
  }

  public void setModuleAuditData(StringBuilder moduleAuditData) {
    this.moduleAuditData = moduleAuditData;
  }

  public StringBuilder getModuleChainAuditData() {
    return moduleChainAuditData;
  }

  public void setModuleChainAuditData(StringBuilder moduleChainAuditData) {
    this.moduleChainAuditData = moduleChainAuditData;
  }

  public StringBuilder getProviderAuditData() {
    return providerAuditData;
  }

  public void setProviderAuditData(StringBuilder providerAuditData) {
    this.providerAuditData = providerAuditData;
  }

  public StringBuilder getAgentAuditData() {
    return agentAuditData;
  }

  public void setAgentAuditData(StringBuilder agentAuditData) {
    this.agentAuditData = agentAuditData;
  }
}
