package com.persistent.pmt.helper.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.commons.context.TargetConnectionTemplate;
import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.WorkflowType;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.error.WorkflowError;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.helper.SSOAuthTokenHelper;
import com.persistent.pmt.response.openam.OpenAmAccessTokenResponse;
import com.persistent.pmt.utils.EndPointUtils;
import com.persistent.pmt.utils.PasswordEncoder;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component("openAMApiTokenHelper")
@PropertySource(value = { "classpath:application.properties" })
public class OpenAMSSOTokenHelperImpl implements SSOAuthTokenHelper {

  private static final Logger logger = Logger.getLogger(OpenAMSSOTokenHelperImpl.class);

  @Autowired
  RestTemplate restTemplate;

  @Override
  public String getAPIToken(TargetConnectionTemplate targetConnectionTemplate,
      List<WorkflowError> errors) throws GenericException {

    String tokenId = null;
    PasswordEncoder encoder = new PasswordEncoder();
    WorkFlowContext context = new WorkFlowContext();
    context.setToken(PMTConstants.CONTEXT_API_BASE_URL, targetConnectionTemplate.getApiUrl());
    Map<String,String> params = new HashMap<>();
    params.put(PMTConstants.REALM_NAME, targetConnectionTemplate.getRealm());
    String url = EndPointUtils.getEndPoint(Product.OPENAM, Artifact.AUTHENTICATION, HttpMethod.POST, context, params);
    HttpHeaders headers = new HttpHeaders();
    headers.add(PMTConstants.HEADER_CONTENT_TYPE, PMTConstants.TYPE_JSON);
    headers.add(PMTConstants.HEADER_OPEN_AM_USERNAME, targetConnectionTemplate.getAdminUser());
    headers.add(PMTConstants.HEADER_OPEN_AM_PASSWORD,
        encoder.decode(targetConnectionTemplate.getAdminPassword()));
    headers.add(PMTConstants.HEADER_OPEN_AM_API_VERSION,
        targetConnectionTemplate.getApiVersion());
    HttpEntity<?> entity = new HttpEntity<>(headers);

    ResponseEntity<OpenAmAccessTokenResponse> response = null;
    try {
      response =
          restTemplate.exchange(url, HttpMethod.POST, entity, OpenAmAccessTokenResponse.class);
    }
    catch (Exception e) {
      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(),
              "OpenAM authentication failed. URL: " + url, 0, 0, e.getLocalizedMessage());
      errors.add(error);
      logger.log(Level.ERROR, "OpenAM authentication failed. URL: " + url, e);
      throw new GenericException(e);
    }

    if (response != null && response.getStatusCode().equals(HttpStatus.OK)) {
      OpenAmAccessTokenResponse accessTokenView = response.getBody();
      tokenId = accessTokenView.getTokenId();
      return tokenId;
    }
    else {
      WorkflowError error =
          new WorkflowError(WorkflowType.PROVISION.toString(),
              "OpenAM authentication failed. Unable to fetch token. URL: " + url, 0, 0,
              "OpenAM authentication failed. Unable to fetch token.");
      errors.add(error);
      logger.log(Level.ERROR, "OpenAM authentication failed. Unable to fetch token. URL: "
          + url);
      throw new GenericException("OpenAM authentication failed. Unable to fetch token. URL: "
          + url);
    }

  }
}
