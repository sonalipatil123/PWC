package com.persistent.pmt.view.openam;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CoreOAuth2ClientConfig {

	private String agentgroup;
	private Attribute status;
	private String userpassword;
	private Attribute clientType;
	private Attribute redirectionUris;
	private Attribute scopes;
	private Attribute defaultScopes;
	private Attribute clientName;
	private Attribute authorizationCodeLifetime;
	private Attribute refreshTokenLifetime;
	private Attribute accessTokenLifetime;

	public CoreOAuth2ClientConfig() {
		super();
	}

	public String getAgentgroup() {
		return agentgroup;
	}

	public void setAgentgroup(String agentgroup) {
		this.agentgroup = agentgroup;
	}

	public Attribute getStatus() {
		return status;
	}

	public void setStatus(Attribute status) {
		this.status = status;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public Attribute getClientType() {
		return clientType;
	}

	public void setClientType(Attribute clientType) {
		this.clientType = clientType;
	}

	public Attribute getRedirectionUris() {
		return redirectionUris;
	}

	public void setRedirectionUris(Attribute redirectionUris) {
		this.redirectionUris = redirectionUris;
	}

	public Attribute getScopes() {
		return scopes;
	}

	public void setScopes(Attribute scopes) {
		this.scopes = scopes;
	}

	public Attribute getDefaultScopes() {
		return defaultScopes;
	}

	public void setDefaultScopes(Attribute defaultScopes) {
		this.defaultScopes = defaultScopes;
	}

	public Attribute getClientName() {
		return clientName;
	}

	public void setClientName(Attribute clientName) {
		this.clientName = clientName;
	}

	public Attribute getAuthorizationCodeLifetime() {
		return authorizationCodeLifetime;
	}

	public void setAuthorizationCodeLifetime(Attribute authorizationCodeLifetime) {
		this.authorizationCodeLifetime = authorizationCodeLifetime;
	}

	public Attribute getRefreshTokenLifetime() {
		return refreshTokenLifetime;
	}

	public void setRefreshTokenLifetime(Attribute refreshTokenLifetime) {
		this.refreshTokenLifetime = refreshTokenLifetime;
	}

	public Attribute getAccessTokenLifetime() {
		return accessTokenLifetime;
	}

	public void setAccessTokenLifetime(Attribute accessTokenLifetime) {
		this.accessTokenLifetime = accessTokenLifetime;
	}

  @Override
  public String toString() {
    return "CoreOAuth2ClientConfig [agentgroup=" + agentgroup + ", status=" + status
        + ", userpassword=" + userpassword + ", clientType=" + clientType
        + ", redirectionUris=" + redirectionUris + ", scopes=" + scopes + ", defaultScopes="
        + defaultScopes + ", clientName=" + clientName + ", authorizationCodeLifetime="
        + authorizationCodeLifetime + ", refreshTokenLifetime=" + refreshTokenLifetime
        + ", accessTokenLifetime=" + accessTokenLifetime + "]";
  }

}
