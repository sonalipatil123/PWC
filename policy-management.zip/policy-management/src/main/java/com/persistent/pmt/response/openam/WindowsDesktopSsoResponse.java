package com.persistent.pmt.response.openam;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude
public class WindowsDesktopSsoResponse implements ModuleResponse {
	private String _id;
	private String _rev;
	private Type _type;
	private String lookupUserInRealm;
	private String authenticationLevel;
	private String keytabFileName;
	private String principalName;
	private String[] trustedKerberosRealms;
	private String kerberosServerName;
	private String kerberosRealm;
	private String returnPrincipalWithDomainName;

	public WindowsDesktopSsoResponse() {
		super();
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String get_rev() {
		return _rev;
	}

	public void set_rev(String _rev) {
		this._rev = _rev;
	}

	public Type get_type() {
		return _type;
	}

	public void set_type(Type _type) {
		this._type = _type;
	}

	public String getLookupUserInRealm() {
		return lookupUserInRealm;
	}

	public void setLookupUserInRealm(String lookupUserInRealm) {
		this.lookupUserInRealm = lookupUserInRealm;
	}

	public String getAuthenticationLevel() {
		return authenticationLevel;
	}

	public void setAuthenticationLevel(String authenticationLevel) {
		this.authenticationLevel = authenticationLevel;
	}

	public String getKeytabFileName() {
		return keytabFileName;
	}

	public void setKeytabFileName(String keytabFileName) {
		this.keytabFileName = keytabFileName;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String[] getTrustedKerberosRealms() {
		return trustedKerberosRealms;
	}

	public void setTrustedKerberosRealms(String[] trustedKerberosRealms) {
		this.trustedKerberosRealms = trustedKerberosRealms;
	}

	public String getKerberosServerName() {
		return kerberosServerName;
	}

	public void setKerberosServerName(String kerberosServerName) {
		this.kerberosServerName = kerberosServerName;
	}

	public String getKerberosRealm() {
		return kerberosRealm;
	}

	public void setKerberosRealm(String kerberosRealm) {
		this.kerberosRealm = kerberosRealm;
	}

	public String getReturnPrincipalWithDomainName() {
		return returnPrincipalWithDomainName;
	}

	public void setReturnPrincipalWithDomainName(
			String returnPrincipalWithDomainName) {
		this.returnPrincipalWithDomainName = returnPrincipalWithDomainName;
	}

}
