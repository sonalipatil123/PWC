package com.persistent.pmt.metadata.generator.descriptors.core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.persistent.pmt.constant.MapperConstants;
import com.persistent.pmt.metadata.generator.descriptors.claimsprovider.ClaimsProviderDescriptor;
import com.persistent.pmt.metadata.generator.descriptors.idp.IdpAttribute;
import com.persistent.pmt.metadata.generator.descriptors.idp.IdpDescriptor;
import com.persistent.pmt.metadata.generator.descriptors.relyingparty.RelyingPartyDescriptor;
import com.persistent.pmt.metadata.generator.descriptors.sp.SpDescriptor;

@Component
public class DescriptorFactory {

	@Autowired
	IdpDescriptor idpDescriptor;

	@Autowired
	SpDescriptor spDescriptor;

	@Autowired
	ClaimsProviderDescriptor claimsProviderDescriptor;

	@Autowired
	RelyingPartyDescriptor relyingPartyDescriptor;

	public Descriptor getDescriptor(String descriptor, Descriptor descriptorObj) {

		if (MapperConstants.IDP_DESCRIPTOR.equalsIgnoreCase(descriptor)) {
			idpDescriptor.setIdpAttributeObj((IdpAttribute) descriptorObj);
			return idpDescriptor;
		} else if (MapperConstants.SP_DESCRIPTOR.equalsIgnoreCase(descriptor)) {
			return spDescriptor;
		} else if (MapperConstants.CLAIMS_PROVIDER_DESCRIPTOR.equalsIgnoreCase(descriptor)) {
			return claimsProviderDescriptor;
		} else if (MapperConstants.RELYING_PARTY_DESCRIPTOR.equalsIgnoreCase(descriptor)) {
			return relyingPartyDescriptor;
		}
		return null;
	}

}
