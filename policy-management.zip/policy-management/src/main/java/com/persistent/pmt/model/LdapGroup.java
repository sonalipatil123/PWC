package com.persistent.pmt.model;

import java.util.List;

/**
 * LdapGroup
 * @author Persistent Systems
 */
public class LdapGroup {

	private String name;
	private String member;
	private List<String> memberUid;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMember() {
		return member;
	}

	public void setMember(String member) {
		this.member = member;
	}

	public List<String> getMemberUid() {
		return memberUid;
	}

	public void setMemberUid(List<String> memberUid) {
		this.memberUid = memberUid;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("LdapGroup [name=");
		builder.append(name);
		builder.append(", member=");
		builder.append(member);
		builder.append(", memberUid=");
		builder.append(memberUid);
		builder.append("]");
		return builder.toString();
	}

}
