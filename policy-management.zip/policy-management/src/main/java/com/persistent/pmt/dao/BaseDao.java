/**
 * BaseDao
 * 
 * DAO interface for base database operations
 * 
 * @author Persistent Systems
 */

package com.persistent.pmt.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;

public interface BaseDao {

	public Session getSession();

	public Criteria createCriteria(Class<?> c);
}
