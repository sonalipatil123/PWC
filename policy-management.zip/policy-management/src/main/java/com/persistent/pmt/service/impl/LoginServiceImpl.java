/**
 * LoginServiceImpl
 * 
 * Service implementation for Login/Logout operations
 * 
 * @author Persistent Systems
 */
package com.persistent.pmt.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
// import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.helper.UserStoreHelper;
import com.persistent.pmt.model.ChangeHistory;
import com.persistent.pmt.model.LdapUser;
import com.persistent.pmt.model.User;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.response.LoginResponse;
import com.persistent.pmt.service.ChangeHistoryService;
import com.persistent.pmt.service.LoginService;
import com.persistent.pmt.service.ServerConfigurationService;

@Service("loginService")
@Transactional
public class LoginServiceImpl implements LoginService {

  @Autowired
  UserStoreHelper userStoreHelper;

  @Autowired
  ServerConfigurationService serverConfigurationService;

  @Autowired
  ChangeHistoryService changeHistoryService;

  /**
   * This method is used to login the user
   * 
   * @throws GenericException
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public GenericResponse login(User user) throws GenericException {
    GenericResponse<LoginResponse> response = new GenericResponse<>();
    boolean authenticated =
        userStoreHelper.authenticate(user.getUserName(), user.getWhatyouknow());

    LoginResponse l = new LoginResponse();
    l.setAuthenticated(authenticated);
    response.setContent(l);
    String roles = "";
    if (authenticated) {
      Map<String, String> roleMapping = new HashMap<>();
      roleMapping.put(
          serverConfigurationService.getPropertyValue(PMTConstants.PROPERTY_ADMIN_GROUP_NAME),
          "admin");
      roleMapping
          .put(serverConfigurationService
              .getPropertyValue(PMTConstants.PROPERTY_MANAGER_GROUP_NAME), "manager");
      roleMapping
          .put(serverConfigurationService
              .getPropertyValue(PMTConstants.PROPERTY_AUDITOR_GROUP_NAME), "auditor");
      roles = getPMTRoles(user, roleMapping);
      l.setRoles(roles);
    }
    if (authenticated && !StringUtils.isEmpty(roles)) {
      changeHistoryService.createChangeHistory(0, ChangeHistory.ACTIONS.LOGIN,
          "Login successful for user '" + user.getUserName() + "'.", PMTConstants.SUCCESS);
      response.setStatus(GenericResponse.SUCCESS);
      response.setMessage("Login Successful.");
      response.setStatusCode(HttpStatus.OK.value());
    }
    else {
      changeHistoryService.createChangeHistory(0, ChangeHistory.ACTIONS.LOGIN,
          "Login failed for user '" + user.getUserName() + "'.", PMTConstants.FAILURE);
      throw new GenericException("Login failed.", HttpStatus.FORBIDDEN.value(),
          GenericResponse.FAILURE);
    }
    return response;
  }

  private String getPMTRoles(User user, Map<String, String> pmtRoleMapping) {

    StringBuilder roles = new StringBuilder("");
    LdapUser ldapUser = userStoreHelper.getLdapUser(user);
    if (ldapUser != null) {
      if (ldapUser.getMemberCN() != null && !(ldapUser.getMemberCN().isEmpty())) {
        List<String> memberCN = ldapUser.getMemberCN();
        for (String s : memberCN) {
          if (pmtRoleMapping.get(s) != null) {
            if (!roles.toString().isEmpty())
              roles.append(",");
            roles.append(pmtRoleMapping.get(s));
          }
        }

      }
    }
    return roles.toString();
  }
}
