package com.persistent.pmt.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * Platform
 * 
 * Entity model for Platform
 * 
 * @author Persistent Systems
 */
@Entity
@Table(name = "platform")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Platform {

	@Id
//	@GenericGenerator(name = "platform_generator", strategy = "increment")
//	@GeneratedValue(generator = "platform_generator")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "PEP_TYPE")
	private String pepType;

	@Column(name = "life_cycle")
	private String lifeCycle;

	@OneToOne(mappedBy = "platform", cascade = CascadeType.ALL, orphanRemoval = true)
	private PlatformOwner owner;

	public Platform() {
		super();
	}

	public Platform(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPepType() {
		return pepType;
	}

	public void setPepType(String pepType) {
		this.pepType = pepType;
	}

	public String getLifeCycle() {
		return lifeCycle;
	}

	public void setLifeCycle(String lifeCycle) {
		this.lifeCycle = lifeCycle;
	}

	public PlatformOwner getOwner() {
		return owner;
	}

	public void setOwner(PlatformOwner owner) {
		this.owner = owner;
	}

	@Override
	public String toString() {
		return "Platform [id=" + id + ", name=" + name + ", pepType=" + pepType + ", lifeCycle=" + lifeCycle
				+ ", owner=" + owner + "]";
	}

	public void updatePlatformValues(Platform platform) {
		if (this.owner != null)
			this.owner.setPlatform(null);
		if (platform.getOwner() != null) {
			platform.getOwner().setPlatform(this);
		}
		this.owner = platform.getOwner();
	}
}
