package com.persistent.pmt.executor.openam.impl;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.executor.openam.PolicyExecutor;
import com.persistent.pmt.response.DeleteResponseView;
import com.persistent.pmt.response.TargetResponse;
import com.persistent.pmt.response.openam.PolicyResponse;
import com.persistent.pmt.utils.CommonUtils;
import com.persistent.pmt.utils.EndPointUtils;
import com.persistent.pmt.view.TargetView;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

@Component("openAMPolicyExecutor")
public class PolicyExecutorImpl implements PolicyExecutor {

  @Autowired
  RestTemplate restTemplate;

  @Override
  public TargetResponse get(Object object, Product product, Artifact artifact,
      HashMap<String, String> params, WorkFlowContext context) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public void create(Object object, TargetView targetView, Product product, Artifact artifact,
      HashMap<String, String> params, WorkFlowContext context) {

    if (targetView != null && params != null) {
      String url =
          EndPointUtils.getEndPoint(product, artifact, HttpMethod.PUT, context, params);

      HttpHeaders headers = CommonUtils.getHeaders(context, product, HttpMethod.PUT);
      HttpEntity<TargetView> entity = new HttpEntity<>(targetView, headers);

      ResponseEntity<PolicyResponse> response =
          restTemplate.exchange(url, HttpMethod.PUT, entity, PolicyResponse.class);

      if (response != null && response.getStatusCode().equals(HttpStatus.OK)) {
        // application.setTargetId(response.getBody().getName());
      }
    }
  }

  @Override
  public TargetResponse update(Object object, TargetView targetView, Product product,
      Artifact artifact, HashMap<String, String> params, WorkFlowContext context) {
    return null;
    // TODO Auto-generated method stub

  }

  @Override
  public void delete(Object object, Product product, Artifact artifact,
      HashMap<String, String> params, WorkFlowContext context) {
    if (params != null) {
      String url =
          EndPointUtils.getEndPoint(product, artifact, HttpMethod.DELETE, context, params);
      HttpHeaders headers = CommonUtils.getHeaders(context, product, HttpMethod.DELETE);
      HttpEntity<?> entity = new HttpEntity<>(headers);
      restTemplate.exchange(url, HttpMethod.DELETE, entity, DeleteResponseView.class);
    }

  }
}