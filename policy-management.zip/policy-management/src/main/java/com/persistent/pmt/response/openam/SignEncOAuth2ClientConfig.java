package com.persistent.pmt.response.openam;

public class SignEncOAuth2ClientConfig {

	private Attribute tokenEndpointAuthSigningAlgorithm;
	private Attribute requestParameterEncryptedAlg;
	private Attribute userinfoEncryptedResponseEncryptionAlgorithm;
	private Attribute userinfoResponseFormat;
	private Attribute jwkStoreCacheMissCacheTime;
	private Attribute requestParameterEncryptedEncryptionAlgorithm;
	private Attribute userinfoSignedResponseAlg;
	private Attribute idTokenEncryptionEnabled;
	private Attribute idTokenPublicEncryptionKey;
	private Attribute jwkSet;
	private Attribute idTokenEncryptionAlgorithm;
	private Attribute jwksCacheTimeout;
	private Attribute publicKeyLocation;
	private Attribute idTokenEncryptionMethod;
	private Attribute idTokenSignedResponseAlg;
	private Attribute userinfoEncryptedResponseAlg;
	private Attribute jwksUri;
	private Attribute clientJwtPublicKey;
	private Attribute requestParameterSignedAlg;

	public SignEncOAuth2ClientConfig() {
		super();
	}

	public Attribute getTokenEndpointAuthSigningAlgorithm() {
		return tokenEndpointAuthSigningAlgorithm;
	}

	public void setTokenEndpointAuthSigningAlgorithm(
			Attribute tokenEndpointAuthSigningAlgorithm) {
		this.tokenEndpointAuthSigningAlgorithm = tokenEndpointAuthSigningAlgorithm;
	}

	public Attribute getRequestParameterEncryptedAlg() {
		return requestParameterEncryptedAlg;
	}

	public void setRequestParameterEncryptedAlg(
			Attribute requestParameterEncryptedAlg) {
		this.requestParameterEncryptedAlg = requestParameterEncryptedAlg;
	}

	public Attribute getUserinfoEncryptedResponseEncryptionAlgorithm() {
		return userinfoEncryptedResponseEncryptionAlgorithm;
	}

	public void setUserinfoEncryptedResponseEncryptionAlgorithm(
			Attribute userinfoEncryptedResponseEncryptionAlgorithm) {
		this.userinfoEncryptedResponseEncryptionAlgorithm = userinfoEncryptedResponseEncryptionAlgorithm;
	}

	public Attribute getUserinfoResponseFormat() {
		return userinfoResponseFormat;
	}

	public void setUserinfoResponseFormat(Attribute userinfoResponseFormat) {
		this.userinfoResponseFormat = userinfoResponseFormat;
	}

	public Attribute getJwkStoreCacheMissCacheTime() {
		return jwkStoreCacheMissCacheTime;
	}

	public void setJwkStoreCacheMissCacheTime(
			Attribute jwkStoreCacheMissCacheTime) {
		this.jwkStoreCacheMissCacheTime = jwkStoreCacheMissCacheTime;
	}

	public Attribute getRequestParameterEncryptedEncryptionAlgorithm() {
		return requestParameterEncryptedEncryptionAlgorithm;
	}

	public void setRequestParameterEncryptedEncryptionAlgorithm(
			Attribute requestParameterEncryptedEncryptionAlgorithm) {
		this.requestParameterEncryptedEncryptionAlgorithm = requestParameterEncryptedEncryptionAlgorithm;
	}

	public Attribute getUserinfoSignedResponseAlg() {
		return userinfoSignedResponseAlg;
	}

	public void setUserinfoSignedResponseAlg(Attribute userinfoSignedResponseAlg) {
		this.userinfoSignedResponseAlg = userinfoSignedResponseAlg;
	}

	public Attribute getIdTokenEncryptionEnabled() {
		return idTokenEncryptionEnabled;
	}

	public void setIdTokenEncryptionEnabled(Attribute idTokenEncryptionEnabled) {
		this.idTokenEncryptionEnabled = idTokenEncryptionEnabled;
	}

	public Attribute getIdTokenPublicEncryptionKey() {
		return idTokenPublicEncryptionKey;
	}

	public void setIdTokenPublicEncryptionKey(
			Attribute idTokenPublicEncryptionKey) {
		this.idTokenPublicEncryptionKey = idTokenPublicEncryptionKey;
	}

	public Attribute getJwkSet() {
		return jwkSet;
	}

	public void setJwkSet(Attribute jwkSet) {
		this.jwkSet = jwkSet;
	}

	public Attribute getIdTokenEncryptionAlgorithm() {
		return idTokenEncryptionAlgorithm;
	}

	public void setIdTokenEncryptionAlgorithm(
			Attribute idTokenEncryptionAlgorithm) {
		this.idTokenEncryptionAlgorithm = idTokenEncryptionAlgorithm;
	}

	public Attribute getJwksCacheTimeout() {
		return jwksCacheTimeout;
	}

	public void setJwksCacheTimeout(Attribute jwksCacheTimeout) {
		this.jwksCacheTimeout = jwksCacheTimeout;
	}

	public Attribute getPublicKeyLocation() {
		return publicKeyLocation;
	}

	public void setPublicKeyLocation(Attribute publicKeyLocation) {
		this.publicKeyLocation = publicKeyLocation;
	}

	public Attribute getIdTokenEncryptionMethod() {
		return idTokenEncryptionMethod;
	}

	public void setIdTokenEncryptionMethod(Attribute idTokenEncryptionMethod) {
		this.idTokenEncryptionMethod = idTokenEncryptionMethod;
	}

	public Attribute getIdTokenSignedResponseAlg() {
		return idTokenSignedResponseAlg;
	}

	public void setIdTokenSignedResponseAlg(Attribute idTokenSignedResponseAlg) {
		this.idTokenSignedResponseAlg = idTokenSignedResponseAlg;
	}

	public Attribute getUserinfoEncryptedResponseAlg() {
		return userinfoEncryptedResponseAlg;
	}

	public void setUserinfoEncryptedResponseAlg(
			Attribute userinfoEncryptedResponseAlg) {
		this.userinfoEncryptedResponseAlg = userinfoEncryptedResponseAlg;
	}

	public Attribute getJwksUri() {
		return jwksUri;
	}

	public void setJwksUri(Attribute jwksUri) {
		this.jwksUri = jwksUri;
	}

	public Attribute getClientJwtPublicKey() {
		return clientJwtPublicKey;
	}

	public void setClientJwtPublicKey(Attribute clientJwtPublicKey) {
		this.clientJwtPublicKey = clientJwtPublicKey;
	}

	public Attribute getRequestParameterSignedAlg() {
		return requestParameterSignedAlg;
	}

	public void setRequestParameterSignedAlg(Attribute requestParameterSignedAlg) {
		this.requestParameterSignedAlg = requestParameterSignedAlg;
	}

}
