package com.persistent.pmt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.persistent.pmt.commons.context.PMTContext;
import com.persistent.pmt.constant.ApplicationFilter;
import com.persistent.pmt.dao.ApplicationDao;
import com.persistent.pmt.dao.EnvironmentDao;
import com.persistent.pmt.exception.GenericException;
import com.persistent.pmt.model.ApplicationSummary;
import com.persistent.pmt.model.Environment;
import com.persistent.pmt.response.GenericResponse;
import com.persistent.pmt.service.ValidationService;

@Service
@Transactional
public class ValidationServiceImpl implements ValidationService {
	private static final String SPECIAL_CHARS = ".*[,;<>=/+\"\\\\]+.*";

	@Autowired
	ApplicationDao applicationDao;

	@Autowired
	ThreadLocal<PMTContext> pmtContextThreadLocal;

	@Autowired
	EnvironmentDao environmentDao;

	/**
	 * This method validates that application name does not contain special
	 * characters and application name is unique
	 */
	public void validateApplicationName(String applicationName, int id) throws GenericException {

		if (isApplicationNameValid(applicationName)) {
			throw new GenericException("Application name '" + applicationName
					+ "' contains special characters( ,;<>=/+\"\\) which are not allowed. Please correct the name.",
					HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
		}
		if (!isApplicationNameUnique(applicationName, id)) {
			throw new GenericException(
					"Application name '" + applicationName + "' already exists. Please choose a new name.",
					HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
		}

	}

	/**
	 * This method checks whether the application name contains special characters
	 * that are not allowed in openAM
	 * 
	 * @param applicationName
	 * @return
	 */
	private boolean isApplicationNameValid(String applicationName) {
		boolean status = false;
		if (applicationName.matches(SPECIAL_CHARS)) {
			status = true;
		}
		return status;
	}

	/**
   * This method fetches application with exact name from database and
   * checks if it is unique
   * 
   * @param applicationName
   * @return
   * @throws GenericException
   */
  private boolean isApplicationNameUnique(String applicationName, int id)
      throws GenericException {
    PMTContext pmtContext = pmtContextThreadLocal.get();
    if (pmtContext != null
        && pmtContext.getApplicationFilters() != null
        && !pmtContext.getApplicationFilters().isEmpty()
        && ((String) pmtContext.getApplicationFilters().get(
            ApplicationFilter.ENVIRONMENT.getValue()) != null)) {
      Environment environment =
          environmentDao.getEnvironmentByName((String) pmtContext.getApplicationFilters().get(
              ApplicationFilter.ENVIRONMENT.getValue()));

      if (environment != null) {
        List<ApplicationSummary> applicationSummary =
            applicationDao.getApplicationByExactName(applicationName, environment.getId());
        boolean status = true;
				// Id will not be 0 in case application name check is happening during provision
				// flow.
				if (id != 0) {
					if (applicationSummary.size() == 1) {
						if (applicationSummary.get(0).getId() == id) {
							status = true;
						} else {
							status = false;
						}
					} else if (applicationSummary.size() > 1) {
						status = false;
					}
				}
				// id will be 0, when new application is getting created. example: combined
				// application creation name
				// validation
				else {
					if (applicationSummary.size() >= 1) {
						status = false;
					}
				}
        return status;
      }
      else {
        throw new GenericException(
            "Environment specified is either invalid or data not found.",
            HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
      }
    }
    else {
      throw new GenericException("Environment is not specified.",
          HttpStatus.BAD_REQUEST.value(), GenericResponse.FAILURE);
    }
  }
}
