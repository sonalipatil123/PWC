package com.persistent.pmt.dao;

import java.util.List;
import java.util.Map;

import com.persistent.pmt.model.ChangeHistory;
import com.persistent.pmt.model.ChangeHistory.ACTIONS;

public interface ChangeHistoryDao {

  public ChangeHistory logChangeHistory(ChangeHistory changeHistory);

  public List<Long> getVersion(int applicationId);

  public List<ChangeHistory> getRecords(int appid, ACTIONS action);

  public Long getRecordCountByActionAndStatus(int environment, List<ACTIONS> actions,
      String status, boolean distinct);

  public List<ChangeHistory> getRecordsByActionAndStatus(int environment, List<ACTIONS> action,
      String status, Map<String, Integer> pagingDetails);
}
