package com.persistent.pmt.constant;

import java.util.ArrayList;
import java.util.List;

public class PropertyConstants {

  private static final String PMT_ADMIN_GROUP = "pmt_admin_group";

  private static final String LDAP_USER_STORE = "ldap.user.store";
  private static final String LDAP_USER_URL = "user.ldap.url";
  private static final String LDAP_USER_BASE = "user.ldap.base";
  private static final String LDAP_USER_USER = "user.ldap.user";
  private static final String LDAP_USER_PASSWORD = "user.ldap.password";

  public static final String IMPORT_STATUS = "import.status";
  public static final String SYSTEM_PROPERTY = "system.properties";
  public static final String COMMA = ",";
  public static final String COLON = ":";
  public static final String MODE = "mode";
  public static final String CHECK_ENVIRONMENT_PROPERTIES = "checkEnvProperties";

  public static final String DEV_OPENAM_ADMIN = "openam.admin";
  public static final String DEV_OPENAM_ADMIN_PASSWORD = "openam.password";
  public static final String DEV_OPENAM_URL = "openam.url";

  public static final String DEV_OPENAM_API_BASE_URL = "openam.api.base.url";
  public static final String DEV_OPENAM_API_VERSION = "openam.api.version";
  
  public static final String OBSOLETE_KEYWORDS = "obsolete.keywords";
  public static final String CIRCLE_OF_TRUST_IDP = "circle.of.trust.idp";
  public static final String CIRCLE_OF_TRUST_SP = "circle.of.trust.sp";
  public static final String VALID_RESOURCE_FILE_EXTENSIONS = "valid.resource.file.extensions";

  public static final String ENV_DEV = "dev";
  public static final String ENV_STAGE = "stage";
  public static final String ENV_PROD = "prod";
  
  public static final int AUDIT_CONTEXT_MAX_BYTES = 4000;

  public static List<String> getProperties() {
    List<String> properties = new ArrayList<>();
    properties.add(PMT_ADMIN_GROUP);
    properties.add(LDAP_USER_STORE);
    properties.add(LDAP_USER_URL);
    properties.add(LDAP_USER_BASE);
    properties.add(LDAP_USER_USER);
    properties.add(LDAP_USER_PASSWORD);

    return properties;
  }
}
