package com.persistent.pmt.executor.openam.impl;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.PMTConstants;
import com.persistent.pmt.response.openam.OpenAmAccessTokenResponse;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public class StubWorkflowContextUtils {
  private RestTemplate restTemplate;
  StubWorkflowContextUtils data;

  public StubWorkflowContextUtils() {

  }

  public WorkFlowContext getWorkflowContext(RestTemplate restTemplate) {
    this.restTemplate = restTemplate;
    WorkFlowContext context = new WorkFlowContext();
    context
        .setToken(
            "AuthToken",
            getAccessToken("http://PT-DGTORA14803.persistent.co.in:8080/openam/json/realms/root/authenticate"));

    context.setToken(PMTConstants.CONTEXT_API_BASE_URL,
        "http://pt-dgtora14803.persistent.co.in:8080/openam/json/");
    return context;
  }

  private String getAccessToken(String ssoTokenUrl) {
    HttpHeaders headers = new HttpHeaders();
    headers.add("Content-Type", "application/json");
    headers.add("X-OpenAM-Username", "amadmin");
    headers.add("X-OpenAM-Password", "Welcome1");
    headers.add("Accept-API-Version", "resource=2.0, protocol=1.0");
    HttpEntity<?> entity = new HttpEntity<>(headers);

    ResponseEntity<OpenAmAccessTokenResponse> response =
        restTemplate.exchange(ssoTokenUrl, HttpMethod.POST, entity,
            OpenAmAccessTokenResponse.class);

    if (response != null && response.getStatusCode().equals(HttpStatus.OK)) {
      OpenAmAccessTokenResponse accessTokenView = response.getBody();
      return accessTokenView.getTokenId();
    }
    return null;
  }
}