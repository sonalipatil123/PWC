package com.persistent.pmt.executor.openam.impl;

import java.util.HashMap;

import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.view.openam.AdvancedOAuth2ClientConfig;
import com.persistent.pmt.view.openam.Attribute;
import com.persistent.pmt.view.openam.CoreOAuth2ClientConfig;
import com.persistent.pmt.view.openam.CoreOpenIDClientConfig;
import com.persistent.pmt.view.openam.CoreUmaClientConfig;
import com.persistent.pmt.view.openam.OAuth2ClientView;
import com.persistent.pmt.view.openam.SignEncOAuth2ClientConfig;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public class OAuth2ClientExecutorImplTest {
  protected RestTemplate restTemplate;

  public static void main(String[] args) {
    StubWorkflowContextUtils data = new StubWorkflowContextUtils();
    RestUtil rt = new RestUtil();
    OAuth2ClientExecutorImplTest oauth2ClientExecutorImplTest =
        new OAuth2ClientExecutorImplTest();
    try {
      oauth2ClientExecutorImplTest.restTemplate = rt.getRestTemplate();
    }
    catch (Exception e) {
    }

    WorkFlowContext context =
        data.getWorkflowContext(oauth2ClientExecutorImplTest.restTemplate);

    oauth2ClientExecutorImplTest.testCreateOauth2Client(oauth2ClientExecutorImplTest, context);
    oauth2ClientExecutorImplTest.testDeleteOauth2Client(oauth2ClientExecutorImplTest, context);
  }

  private void testCreateOauth2Client(
      OAuth2ClientExecutorImplTest oauth2ClientExecutorImplTest, WorkFlowContext context) {
    OAuth2ClientExecutorImpl auuth2ClientExecutorImpl = new OAuth2ClientExecutorImpl();
    OAuth2ClientView oauth2ClientView = stubOAuth2ClientView();
    auuth2ClientExecutorImpl.restTemplate = oauth2ClientExecutorImplTest.restTemplate;
    Application application = new Application();
    HashMap<String, String> params = new HashMap<String, String>();
    // params.put("id", "MyOAuth");
    params.put("id", "morgan Stanley newUMA");
    params.put("realmName", "PWC");
    auuth2ClientExecutorImpl.create(application, oauth2ClientView, Product.OPENAM,
        Artifact.OAUTH_CLIENT, params, context);
  }

  private OAuth2ClientView stubOAuth2ClientView() {
    /*
     * OAuth2ClientView oauth2ClientView = new OAuth2ClientView();
     * CoreOAuth2ClientConfig coreOAuth2ClientConfig = new
     * CoreOAuth2ClientConfig();
     * coreOAuth2ClientConfig.setClientType(new Attribute(true,
     * "Confidential"));
     * coreOAuth2ClientConfig.setAuthorizationCodeLifetime(new
     * Attribute(true, 0));
     * coreOAuth2ClientConfig.setAccessTokenLifetime(new
     * Attribute(true, 0));
     * coreOAuth2ClientConfig.setAgentgroup("oAuthGroupOne");
     * coreOAuth2ClientConfig.setAccessTokenLifetime(new Attribute());
     * oauth2ClientView
     * .setCoreOAuth2ClientConfig(coreOAuth2ClientConfig);
     */

    OAuth2ClientView oauth2ClientView = null;
    // if (provider != null) {
    oauth2ClientView = new OAuth2ClientView();
    // oauth2ClientView.setId(provider.getName());

    oauth2ClientView.setId("morgan Stanley newUMA");

    CoreOAuth2ClientConfig coreOAuth2ClientConfig = new CoreOAuth2ClientConfig();
    /*
     * String agentGroup = null; for (ProviderAttributes
     * providerAttributes : provider.getAttributes()) { if
     * (providerAttributes
     * .getSourceAttrName().equalsIgnoreCase("agentgroup")) {
     * agentGroup = providerAttributes.getSourceAttrValue(); } }
     */
    coreOAuth2ClientConfig.setAgentgroup("oAuthGroupOne");
    coreOAuth2ClientConfig.setStatus(new Attribute(true, "Active"));
    coreOAuth2ClientConfig.setUserpassword("Welcome1");
    coreOAuth2ClientConfig.setClientType(new Attribute(true, "Confidential"));

    // coreOAuth2ClientConfig.setRedirectionUris(new Attribute(true,
    // new String[] {}));
    coreOAuth2ClientConfig.setRedirectionUris(new Attribute(true));
    // coreOAuth2ClientConfig.setScopes(new Attribute(true, new
    // String[] {}));
    coreOAuth2ClientConfig.setScopes(new Attribute(true));
    coreOAuth2ClientConfig.setDefaultScopes(new Attribute(true, new String[] {}));
    coreOAuth2ClientConfig.setClientName(new Attribute(true, new String[] {}));
    coreOAuth2ClientConfig.setAuthorizationCodeLifetime(new Attribute(true, 0));
    coreOAuth2ClientConfig.setRefreshTokenLifetime(new Attribute(true, 0));
    coreOAuth2ClientConfig.setAccessTokenLifetime(new Attribute(true, 0));

    oauth2ClientView.setCoreOAuth2ClientConfig(coreOAuth2ClientConfig);

    AdvancedOAuth2ClientConfig advancedOAuth2ClientConfig = new AdvancedOAuth2ClientConfig();
    advancedOAuth2ClientConfig.setName(new Attribute(true, new String[] {}));
    advancedOAuth2ClientConfig.setDescriptions(new Attribute(true, new String[] {}));
    advancedOAuth2ClientConfig.setRequestUris(new Attribute(true, new String[] {}));
    advancedOAuth2ClientConfig.setResponseTypes(new Attribute(true, new String[] {}));
    advancedOAuth2ClientConfig.setContacts(new Attribute(true, new String[] {}));
    advancedOAuth2ClientConfig.setTokenEndpointAuthMethod(new Attribute(true, ""));
    advancedOAuth2ClientConfig.setSectorIdentifierUri(new Attribute(true, ""));
    advancedOAuth2ClientConfig.setSubjectType(new Attribute(true, ""));
    advancedOAuth2ClientConfig.setUpdateAccessToken(new Attribute(true, ""));
    advancedOAuth2ClientConfig.setIsConsentImplied(new Attribute(true, true));
    advancedOAuth2ClientConfig.setMixUpMitigation(new Attribute(true, true));

    oauth2ClientView.setAdvancedOAuth2ClientConfig(advancedOAuth2ClientConfig);

    CoreOpenIDClientConfig coreOpenIDClientConfig = new CoreOpenIDClientConfig();
    coreOpenIDClientConfig.setClaims(new Attribute(true, new String[] {}));
    coreOpenIDClientConfig.setPostLogoutRedirectUri(new Attribute(true, new String[] {}));
    coreOpenIDClientConfig.setClientSessionUri(new Attribute(true, ""));
    coreOpenIDClientConfig.setDefaultMaxAge(new Attribute(true, 0));
    coreOpenIDClientConfig.setDefaultMaxAgeEnabled(new Attribute(true, true));
    coreOpenIDClientConfig.setJwtTokenLifetime(new Attribute(true, 0));

    oauth2ClientView.setCoreOpenIDClientConfig(coreOpenIDClientConfig);

    SignEncOAuth2ClientConfig signEncOAuth2ClientConfig = new SignEncOAuth2ClientConfig();
    signEncOAuth2ClientConfig.setJwksUri(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setJwksCacheTimeout(new Attribute(true, 0));
    signEncOAuth2ClientConfig.setJwkStoreCacheMissCacheTime(new Attribute(true, 0));
    signEncOAuth2ClientConfig.setTokenEndpointAuthSigningAlgorithm(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setJwkSet(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setIdTokenSignedResponseAlg(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setIdTokenEncryptionEnabled(new Attribute(true, true));
    signEncOAuth2ClientConfig.setIdTokenEncryptionAlgorithm(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setIdTokenEncryptionMethod(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setIdTokenPublicEncryptionKey(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setClientJwtPublicKey(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setPublicKeyLocation(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setUserinfoResponseFormat(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setUserinfoSignedResponseAlg(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setUserinfoEncryptedResponseAlg(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setUserinfoEncryptedResponseEncryptionAlgorithm(new Attribute(
        true, ""));
    signEncOAuth2ClientConfig.setRequestParameterSignedAlg(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setRequestParameterEncryptedAlg(new Attribute(true, ""));
    signEncOAuth2ClientConfig.setRequestParameterEncryptedEncryptionAlgorithm(new Attribute(
        true, ""));

    oauth2ClientView.setSignEncOAuth2ClientConfig(signEncOAuth2ClientConfig);

    CoreUmaClientConfig coreUmaClientConfig = new CoreUmaClientConfig();
    coreUmaClientConfig.setClaimsRedirectionUris(new Attribute(true));

    oauth2ClientView.setCoreUmaClientConfig(coreUmaClientConfig);

    // }
    return oauth2ClientView;
  }

  private void testDeleteOauth2Client(
      OAuth2ClientExecutorImplTest oauth2ClientExecutorImplTest, WorkFlowContext wfc) {
    Application application = new Application();
    OAuth2ClientExecutorImpl auuth2ClientExecutorImpl = new OAuth2ClientExecutorImpl();
    auuth2ClientExecutorImpl.restTemplate = oauth2ClientExecutorImplTest.restTemplate;
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("id", "MyOAuth");
    params.put("realmName", "PWC");
    auuth2ClientExecutorImpl.delete(application, Product.OPENAM, Artifact.OAUTH_CLIENT, params,
        wfc);
  }
}
