package com.persistent.pmt.executor.openam.impl;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

public class RestUtil {

  @Autowired
  Environment environment;

  /**
   * This method prepares and returns Rest Template for OpenAM APIs
   * 
   * @return RestTemplate
   * @throws Exception
   */
  @Bean(name = "restTemplate")
  public RestTemplate getRestTemplate() throws Exception {
    ClientHttpRequestFactory requestFactory =
        new HttpComponentsClientHttpRequestFactory(getHttpClient());
    RestTemplate restTemplate =
        new RestTemplate(new BufferingClientHttpRequestFactory(requestFactory));
    // restTemplate.getInterceptors().add(new UserAgentInterceptor());
    // restTemplate.getInterceptors().add(new
    // LoggingRequestInterceptor());

    return restTemplate;
  }

  /**
   * This method provides the Http Client
   * 
   * @return CloseableHttpClient
   * @throws Exception
   */
  private CloseableHttpClient getHttpClient() throws Exception {
    HttpClientBuilder builder = HttpClients.custom();
    builder.setSSLSocketFactory(getSocketFactory());

    /*
     * if (null == environment.getProperty("ping_api_sso_enabled")) {
     * builder
     * .setDefaultCredentialsProvider(getCredentialsProvider()); }
     */

    return builder.build();
  }

  /**
   * This method provides socket factory for SSL connections
   * 
   * @return SSLConnectionSocketFactory
   * @throws Exception
   */
  private SSLConnectionSocketFactory getSocketFactory() throws Exception {
    // return new SSLConnectionSocketFactory(getSSLContext(), new
    // String[] {
    // "TLSv1" }, null,
    // NoopHostnameVerifier.INSTANCE);
    // TLS version changed to debug PF calls issue
    return new SSLConnectionSocketFactory(getSSLContext(), new String[] { "TLSv1", "TLSv1.1",
        "TLSv1.2" }, null, NoopHostnameVerifier.INSTANCE);
  }

  /**
   * This method created SSL context using provided key store details
   * 
   * @return SSLContext
   * @throws Exception
   */
  /*
   * private SSLContext getSSLContext() throws Exception { String
   * keyStoreFile = environment.getRequiredProperty("keystore.file");
   * String keyStorePassword =
   * environment.getRequiredProperty("keystore.password");
   * 
   * KeyStore keyStore =
   * KeyStore.getInstance(KeyStore.getDefaultType());
   * keyStore.load(new FileInputStream(new File(keyStoreFile)),
   * keyStorePassword.toCharArray());
   * 
   * SSLContextBuilder builder = new SSLContextBuilder();
   * builder.loadTrustMaterial(keyStore, new
   * TrustSelfSignedStrategy());
   * 
   * return builder.build(); }
   */
  private SSLContext getSSLContext() throws Exception {

    SSLContextBuilder builder = new SSLContextBuilder();
    builder.loadTrustMaterial(null, new TrustStrategy() {
      @Override
      public boolean isTrusted(X509Certificate[] chain, String authType)
          throws CertificateException {
        return true;
      }
    });
    // builder.loadTrustMaterial(keyStore, new
    // TrustSelfSignedStrategy());

    return builder.build();
  }
}
