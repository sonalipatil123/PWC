package com.persistent.pmt.executor.openam.impl;

import java.util.HashMap;

import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.view.openam.AnonymousModuleView;
import com.persistent.pmt.view.openam.CertificateModuleView;
import com.persistent.pmt.view.openam.HttpBasicModuleView;
import com.persistent.pmt.view.openam.LDAPModuleView;
import com.persistent.pmt.view.openam.LegacyOAuth2OpenIdConnectModuleView;
import com.persistent.pmt.view.openam.ModuleView;
import com.persistent.pmt.view.openam.OpenIdConnectIdTokenBearerModuleView;
import com.persistent.pmt.view.openam.SAML2ModuleView;
import com.persistent.pmt.view.openam.WindowsDesktopModuleView;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public class ModuleExecutorImplTest {
  protected RestTemplate restTemplate;

  public static void main(String[] args) {
    RestUtil rt = new RestUtil();
    StubWorkflowContextUtils data = new StubWorkflowContextUtils();
    ModuleExecutorImplTest moduleExecutorImplTest = new ModuleExecutorImplTest();
    try {
      moduleExecutorImplTest.restTemplate = rt.getRestTemplate();
    }
    catch (Exception e) {
    }

    WorkFlowContext context = data.getWorkflowContext(moduleExecutorImplTest.restTemplate);
    moduleExecutorImplTest.testCreateModule(moduleExecutorImplTest, context);
    moduleExecutorImplTest.testDeleteModule(moduleExecutorImplTest, context);
    moduleExecutorImplTest.testReadModule(moduleExecutorImplTest, context);
  }

  private void testReadModule(ModuleExecutorImplTest moduleExecutorImplTest,
      WorkFlowContext context) {
    ModuleExecutorImpl moduleExecutorImpl = new ModuleExecutorImpl();
    moduleExecutorImpl.restTemplate = moduleExecutorImplTest.restTemplate;
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("id", "LDAP1/ 312312");
    params.put("realmName", "PWC");
    Application application = new Application();
    moduleExecutorImpl.get(application, Product.OPENAM, Artifact.MODULE_LDAP, params, context);

  }

  private void testDeleteModule(ModuleExecutorImplTest moduleExecutorImplTest,
      WorkFlowContext context) {
    ModuleExecutorImpl reamexec = new ModuleExecutorImpl();
    Application application = new Application();
    reamexec.restTemplate = moduleExecutorImplTest.restTemplate;
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("id", "newBasicModuleFromCode");
    params.put("realmName", "PWC");
    reamexec.delete(application, Product.OPENAM, Artifact.MODULE_HTTP_BASIC, params, context);
  }

  private void testCreateModule(ModuleExecutorImplTest moduleExecutorImplTest,
      WorkFlowContext context) {
    ModuleView moduleView = stubHttpBasicModuleView();
    Application application = new Application();
    ModuleExecutorImpl moduleExecutorImpl = new ModuleExecutorImpl();
    moduleExecutorImpl.restTemplate = moduleExecutorImplTest.restTemplate;
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("id", "newBasicModuleFromCode");
    params.put("realmName", "PWC");
    moduleExecutorImpl.create(application, moduleView, Product.OPENAM,
        Artifact.MODULE_HTTP_BASIC, params, context);
  }

  private ModuleView stubWindosDesktopSSOModuleView() {
    WindowsDesktopModuleView windowsDesktopModuleView = new WindowsDesktopModuleView();
    windowsDesktopModuleView.setTrustedKerberosRealms(new String[] {});
    windowsDesktopModuleView.setLookupUserInRealm(false);
    windowsDesktopModuleView.setAuthenticationLevel(0);
    windowsDesktopModuleView.setReturnPrincipalWithDomainName(false);

    return windowsDesktopModuleView;

  }

  private ModuleView stubOpenIdConnectTokenBearerModuleView() {
    OpenIdConnectIdTokenBearerModuleView openIdConnectIdTokenBearerModuleView =
        new OpenIdConnectIdTokenBearerModuleView();
    openIdConnectIdTokenBearerModuleView
        .setCryptoContextType("https://accounts.google.com/.well-known/openid-configuration");
    openIdConnectIdTokenBearerModuleView.setJwtToLdapAttributeMappings(new String[] {
        "sub=uid", "email=mail" });
    openIdConnectIdTokenBearerModuleView.setUseSubClaimIfNoMatch(false);
    openIdConnectIdTokenBearerModuleView
        .setPrincipalMapperClass("org.forgerock.openam.authentication.modules.oidc.JwtAttributeMapper");
    openIdConnectIdTokenBearerModuleView.setIdTokenHeaderName("oidc_id_token");
    openIdConnectIdTokenBearerModuleView.setAcceptedAuthorizedParties(new String[] {
        "http://www.example.com/authorized/party", "AuthorizedPartyExample" });
    openIdConnectIdTokenBearerModuleView.setIdTokenIssuer("accounts.google.com");
    openIdConnectIdTokenBearerModuleView
        .setAccountProviderClass("org.forgerock.openam.authentication.modules.common.mapping.DefaultAccountProvider");
    openIdConnectIdTokenBearerModuleView.setClientSecret(null);
    openIdConnectIdTokenBearerModuleView
        .setCryptoContextType(".well-known/openid-configuration_url");
    openIdConnectIdTokenBearerModuleView.setAudienceName("example");
    return openIdConnectIdTokenBearerModuleView;
  }

  private ModuleView stubAnonymousModuleView() {
    AnonymousModuleView anonymousModuleView = new AnonymousModuleView();
    anonymousModuleView.setValidAnonymousUsers(new String[] {});
    anonymousModuleView.setAuthenticationLevel(0);
    anonymousModuleView.setCaseSensitiveUsernameMatchingEnabled(false);
    anonymousModuleView.setDefaultAnonymousUsername("anonymous");
    return anonymousModuleView;
  }

  private ModuleView stubCertificateModuleView() {
    CertificateModuleView certificateModuleView = new CertificateModuleView();
    certificateModuleView.setMatchCertificateInLdap(false);
    certificateModuleView.setCertificateAttributeProfileMappingExtension("none");
    certificateModuleView.setMatchCertificateToCRL(false);
    certificateModuleView.setCrlMatchingCertificateAttribute("CN");
    certificateModuleView
        .setCertificateLdapServers(new String[] { "pt-dgtora14803.persistent.co.in:50389" });
    certificateModuleView.setLdapCertificateAttribute("CN");
    certificateModuleView.setOtherCertificateAttributeToProfileMapping(null);
    certificateModuleView.setUpdateCRLsFromDistributionPoint(true);
    certificateModuleView.setCacheCRLsInMemory(true);
    certificateModuleView.setCrlHttpParameters("");
    certificateModuleView.setAuthenticationLevel(0);
    certificateModuleView.setCertificateAttributeToProfileMapping("subject CN");
    certificateModuleView.setLdapSearchStartDN(new String[] {});
    certificateModuleView.setUserBindDN("cn=Directory Manager");
    certificateModuleView.setTrustedRemoteHosts(new String[] { "none" });
    certificateModuleView.setMatchCACertificateToCRL(false);
    certificateModuleView.setIplanetAmAuthCertGwCertPreferred(false);
    certificateModuleView.setOcspValidationEnabled(false);
    certificateModuleView.setSslEnabled(false);
    certificateModuleView.setUserBindPassword(null);
    certificateModuleView.setClientCertificateHttpHeaderName(" ");

    return certificateModuleView;
  }

  private ModuleView stuboAuth2ModuleView() {
    LegacyOAuth2OpenIdConnectModuleView legacyOauth2OpenIdConnectView =
        new LegacyOAuth2OpenIdConnectModuleView();
    legacyOauth2OpenIdConnectView.setMixUpMitigation(true);
    legacyOauth2OpenIdConnectView.setSsoProxyUrl("ssoProxyUrl");
    legacyOauth2OpenIdConnectView.setAuthenticationLevel(0);
    legacyOauth2OpenIdConnectView
        .setAccountMapperClass("org.forgerock.openam.authentication.modules.common.mapping.JsonAttributeMapper");
    legacyOauth2OpenIdConnectView.setAccountMapperConfiguration(new String[] {
        "id=facebook-id", "email=mail" });
    legacyOauth2OpenIdConnectView.setOauth2LogoutServiceUrl(" ");
    legacyOauth2OpenIdConnectView.setAnonymousUserName("anonymous");
    legacyOauth2OpenIdConnectView
        .setMailGatewayClass("org.forgerock.openam.authentication.modules.oauth2.DefaultEmailGatewayImpl");
    legacyOauth2OpenIdConnectView.setOauth2EmailAttribute("");
    legacyOauth2OpenIdConnectView.setSmtpHostName("localhost");
    legacyOauth2OpenIdConnectView.setSmtpSslEnabled(null);
    legacyOauth2OpenIdConnectView.setUserProfileServiceUrl("userProfileServiceUrl");
    legacyOauth2OpenIdConnectView.setOpenidConnectContextValue(null);
    legacyOauth2OpenIdConnectView.setPromptForPassword(true);
    legacyOauth2OpenIdConnectView.setSmtpFromAddress("info@forgerock.com");
    legacyOauth2OpenIdConnectView.setScope("scope");
    legacyOauth2OpenIdConnectView.setAccessTokenParameterName("accessTokenParameterName");
    legacyOauth2OpenIdConnectView.setSmtpHostPort("25");
    legacyOauth2OpenIdConnectView.setSaveAttributesInSession(true);
    legacyOauth2OpenIdConnectView.setOpenidConnectIssuer(null);
    legacyOauth2OpenIdConnectView.setAttributeMapperConfiguration(new String[] {
        "first_name=givenname", "id=facebook-id", "email=facebook-email",
        "last_name=facebook-lname", "first_name=facebook-fname", "last_name=sn", "name=cn",
        "email=mail" });
    legacyOauth2OpenIdConnectView.setClientId(null);
    legacyOauth2OpenIdConnectView.setSmtpUsername("");
    legacyOauth2OpenIdConnectView.setAuthenticationEndpointUrl("authenticationEndpointUrl");
    legacyOauth2OpenIdConnectView.setOpenidConnectContextType(null);
    legacyOauth2OpenIdConnectView.setAccessTokenEndpointUrl("accessTokenEndpointUrl");
    legacyOauth2OpenIdConnectView.setClientId("Newclient1");
    legacyOauth2OpenIdConnectView
        .setAccountProviderClass("org.forgerock.openam.authentication.modules.common.mapping.DefaultAccountProvider");
    legacyOauth2OpenIdConnectView.setSmtpPassword(null);
    legacyOauth2OpenIdConnectView
        .setAttributeMappingClasses(new String[] { "org.forgerock.openam.authentication.modules.common.mapping.JsonAttributeMapper" });
    legacyOauth2OpenIdConnectView.setCreateAccount(true);
    legacyOauth2OpenIdConnectView.setMapToAnonymousUser(false);
    legacyOauth2OpenIdConnectView.setLogoutBehaviour("prompt");
    return legacyOauth2OpenIdConnectView;
  }

  private ModuleView stubSAMLModuleView() {
    SAML2ModuleView saml2ModuleView = new SAML2ModuleView();
    saml2ModuleView.setAuthenticationLevel(0);
    saml2ModuleView.setMetaAlias("/sp");
    saml2ModuleView.setLoginChain(null);
    saml2ModuleView.setIsPassive("false");
    saml2ModuleView.setSloRelay("http://");
    saml2ModuleView.setForceAuthn("false");
    saml2ModuleView.setAuthnContextDeclRef(null);
    saml2ModuleView.setEntityName("http://");
    saml2ModuleView.setNameIdFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:persistent");
    saml2ModuleView.setAuthComparison("exact");
    saml2ModuleView.setReqBinding("urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect");
    saml2ModuleView.setSloEnabled("false");
    saml2ModuleView.setBinding("urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Artifact");
    saml2ModuleView.setAllowCreate("true");
    saml2ModuleView.setAuthnContextClassRef(null);

    return saml2ModuleView;
  }

  private ModuleView stubLdapModuleView() {
    LDAPModuleView moduleView = new LDAPModuleView();
    moduleView.setUserSearchFilter(null);
    moduleView.setAuthenticationLevel(0);
    moduleView.setSearchScope("SUBTREE");
    moduleView.setReturnUserDN(true);
    moduleView.setProfileAttributeMappings(new String[] {});
    moduleView.setUserBindDN("cn=Directory Manager");
    moduleView.setUserSearchAttributes(new String[] { "uid" });
    moduleView.setConnectionHeartbeatTimeUnit("SECONDS");
    moduleView.setBeheraPasswordPolicySupportEnabled(true);
    moduleView.setUserProfileRetrievalAttribute("uid");
    moduleView.setMinimumPasswordLength("8");
    moduleView.setPrimaryLdapServer(new String[] { "pt-dgtora14803.persistent.co.in:50389" });
    moduleView.setOpenamAuthLdapConnectionMode("LDAP");
    moduleView.setConnectionHeartbeatInterval(10);
    moduleView.setSecondaryLdapServer(new String[] {});
    moduleView.setUserSearchStartDN(new String[] { "dc=openam,dc=forgerock,dc=org" });
    moduleView.setTrustAllServerCertificates(false);
    moduleView.setOperationTimeout(0);

    return moduleView;
  }

  private ModuleView stubHttpBasicModuleView() {
    HttpBasicModuleView httpBasicModuleView = new HttpBasicModuleView();
    httpBasicModuleView.setAuthenticationLevel(0);
    httpBasicModuleView.setBackendModuleName("LDAP");
    return httpBasicModuleView;
  }
}
