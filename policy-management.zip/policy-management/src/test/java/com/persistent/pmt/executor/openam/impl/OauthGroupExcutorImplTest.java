package com.persistent.pmt.executor.openam.impl;

import java.util.HashMap;

import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.response.openam.OAuthGroupResponse;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public class OauthGroupExcutorImplTest {
  protected RestTemplate restTemplate;

  public static void main(String[] args) {
    StubWorkflowContextUtils data = new StubWorkflowContextUtils();
    RestUtil rt = new RestUtil();
    OauthGroupExcutorImplTest oauthGroupExcutorImplTest = new OauthGroupExcutorImplTest();
    try {
      oauthGroupExcutorImplTest.restTemplate = rt.getRestTemplate();
    }
    catch (Exception e) {
    }

    WorkFlowContext context = data.getWorkflowContext(oauthGroupExcutorImplTest.restTemplate);
    oauthGroupExcutorImplTest.testGetOAuthGroup(oauthGroupExcutorImplTest, context);
  }

  private void testGetOAuthGroup(OauthGroupExcutorImplTest oauthGroupExcutorImplTest,
      WorkFlowContext context) {
    OAuthGroupExecutorImpl oauthGroupExecutorImpl = new OAuthGroupExecutorImpl();
    oauthGroupExecutorImpl.restTemplate = oauthGroupExcutorImplTest.restTemplate;
    Application application = new Application();
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("id", "MyAgent");
    params.put("realmName", "PWC");
    OAuthGroupResponse oauthGroups =
        (OAuthGroupResponse) oauthGroupExecutorImpl.get(application, Product.OPENAM,
            Artifact.OAUTH_GROUP, params, context);
  }

}
