package com.persistent.pmt.executor.openam.impl;

import java.util.HashMap;

import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.view.openam.ProviderView;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public class ProviderExecutorImplTest {
  protected RestTemplate restTemplate;

  public static void main(String[] args) {
    StubWorkflowContextUtils data = new StubWorkflowContextUtils();
    RestUtil rt = new RestUtil();
    ProviderExecutorImplTest samlProviderExecutorImplTest = new ProviderExecutorImplTest();
    try {
      samlProviderExecutorImplTest.restTemplate = rt.getRestTemplate();
    }
    catch (Exception e) {
    }

    WorkFlowContext context =
        data.getWorkflowContext(samlProviderExecutorImplTest.restTemplate);

    samlProviderExecutorImplTest.testCreatePostProvider(samlProviderExecutorImplTest, context);
    samlProviderExecutorImplTest.testCreateProvider(samlProviderExecutorImplTest, context);
    samlProviderExecutorImplTest.testDeleteSamlProvider(samlProviderExecutorImplTest, context);
  }

  private void testCreatePostProvider(ProviderExecutorImplTest samlProviderExecutorImplTest,
      WorkFlowContext context) {

    ProviderView samlProviderView = stubSaml2View();
    Application application = new Application();
    ProviderExecutorImpl saml2ExecutorImpl = new ProviderExecutorImpl();
    saml2ExecutorImpl.restTemplate = samlProviderExecutorImplTest.restTemplate;
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("id", "SAMLTEst");
    params.put("realmName", "PWC");
    saml2ExecutorImpl.create(application, samlProviderView, Product.OPENAM,
        Artifact.SAML_PROVIDER, params, context);

  }

  private void testDeleteSamlProvider(ProviderExecutorImplTest samlProviderExecutorImplTest,
      WorkFlowContext context) {
    ProviderExecutorImpl saml2ExecutorImpl = new ProviderExecutorImpl();
    saml2ExecutorImpl.restTemplate = samlProviderExecutorImplTest.restTemplate;
    Application application = new Application();
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("id", "SAMLTEst");
    params.put("realmName", "PWC");
    saml2ExecutorImpl.delete(application, Product.OPENAM, Artifact.SAML_PROVIDER, params,
        context);
  }

  private void testCreateProvider(ProviderExecutorImplTest samlProviderExecutorImplTest,
      WorkFlowContext wfc) {
    ProviderView samlProviderView = stubSaml2View();
    Application application = new Application();
    ProviderExecutorImpl saml2ExecutorImpl = new ProviderExecutorImpl();
    saml2ExecutorImpl.restTemplate = samlProviderExecutorImplTest.restTemplate;
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("id", "SAMLTEst");
    params.put("realmName", "PWC");
    saml2ExecutorImpl.create(application, samlProviderView, Product.OPENAM,
        Artifact.SAML_PROVIDER, params, wfc);

  }

  private ProviderView stubSaml2View() {
    /*
     * ProviderView saml2View = new ProviderView();
     * saml2View.setMetadata("metadata");
     * saml2View.setEntityConfig("entityConfig"); return saml2View;
     */
    ProviderView saml2View = new ProviderView();
    saml2View.set_id("https://trialid.persistent.co.in:14101/oam/fed");
    saml2View
        .setMetadata("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<EntityDescriptor ID=\"id-rZxg3A6wOsp6w6x58NhogKrcfG09sqJdSPDB32iB\" cacheDuration=\"P30DT0H0M0S\" entityID=\"https://trialid.persistent.co.in:14101/oam/fed\" validUntil=\"2027-03-18T09:34:52Z\" xmlns=\"urn:oasis:names:tc:SAML:2.0:metadata\">\n    <SPSSODescriptor AuthnRequestsSigned=\"true\" WantAssertionsSigned=\"true\" protocolSupportEnumeration=\"urn:oasis:names:tc:SAML:2.0:protocol\">\n        <KeyDescriptor use=\"signing\">\n            <ds:KeyInfo xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">\n                <ds:X509Data>\n                    <ds:X509Certificate>MIICCjCCAXOgAwIBAgIBCjANBgkqhkiG9w0BAQQFADAqMSgwJgYDVQQDEx9jLXJoNi02NC1vYWFtMi5wZXJzaXN0ZW50LmNvLmluMB4XDTE3MDMyMDA5MzQ1MloXDTI3MDMxODA5MzQ1MlowKjEoMCYGA1UEAxMfYy1yaDYtNjQtb2FhbTIucGVyc2lzdGVudC5jby5pbjCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAltWx3Lx21Tm1w0tAFqFxbR/86YxVY6d6glDuS0lMxVGaKri0L61oF8TCrw38W6hjlc2Sht6WBPrBtC64E+O8KlhVs3gErAWsYRqQpYKY8w8nfDYrVF5JRhDzkUtAZrry0si2PhvIs8/noNaOniOOo7/Y4aUqvf6Fe2iXyJwqUNcCAwEAAaNAMD4wDAYDVR0TAQH/BAIwADAPBgNVHQ8BAf8EBQMDB9gAMB0GA1UdDgQWBBSKKagcwAVJ5HLUXRI3bX0ilol7xzANBgkqhkiG9w0BAQQFAAOBgQAHm4NJ1AQjvJTdZyIzKIURI4UwUBEhwFtcAc/XHORTdVy+ZZqC34fWX/fDPUOFN4l1R+dQve4MzY+it7S8K8x3nKvsaktTYMjtDpYoNQUWxoHZKzSFyEXbmGccJmBRcNuXAgqFDGES4b/7tO+1sl+bigeeyMgSfoOs9zXbJA6gvg==</ds:X509Certificate>\n                    <ds:X509IssuerSerial>\n                        <ds:X509IssuerName>CN=c-rh6-64-oaam2.persistent.co.in</ds:X509IssuerName>\n                        <ds:X509SerialNumber>10</ds:X509SerialNumber>\n                    </ds:X509IssuerSerial>\n                    <ds:X509SubjectName>CN=c-rh6-64-oaam2.persistent.co.in</ds:X509SubjectName>\n                </ds:X509Data>\n         </ds:KeyInfo>\n        </KeyDescriptor>\n        <KeyDescriptor use=\"encryption\">\n            <ds:KeyInfo xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">\n                <ds:X509Data>\n                    <ds:X509Certificate>MIICCjCCAXOgAwIBAgIBCjANBgkqhkiG9w0BAQQFADAqMSgwJgYDVQQDEx9jLXJoNi02NC1vYWFtMi5wZXJzaXN0ZW50LmNvLmluMB4XDTE3MDMyMDA5MzQ1MloXDTI3MDMxODA5MzQ1MlowKjEoMCYGA1UEAxMfYy1yaDYtNjQtb2FhbTIucGVyc2lzdGVudC5jby5pbjCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAltWx3Lx21Tm1w0tAFqFxbR/86YxVY6d6glDuS0lMxVGaKri0L61oF8TCrw38W6hjlc2Sht6WBPrBtC64E+O8KlhVs3gErAWsYRqQpYKY8w8nfDYrVF5JRhDzkUtAZrry0si2PhvIs8/noNaOniOOo7/Y4aUqvf6Fe2iXyJwqUNcCAwEAAaNAMD4wDAYDVR0TAQH/BAIwADAPBgNVHQ8BAf8EBQMDB9gAMB0GA1UdDgQWBBSKKagcwAVJ5HLUXRI3bX0ilol7xzANBgkqhkiG9w0BAQQFAAOBgQAHm4NJ1AQjvJTdZyIzKIURI4UwUBEhwFtcAc/XHORTdVy+ZZqC34fWX/fDPUOFN4l1R+dQve4MzY+it7S8K8x3nKvsaktTYMjtDpYoNQUWxoHZKzSFyEXbmGccJmBRcNuXAgqFDGES4b/7tO+1sl+bigeeyMgSfoOs9zXbJA6gvg==</ds:X509Certificate>\n                    <ds:X509IssuerSerial>\n                        <ds:X509IssuerName>CN=c-rh6-64-oaam2.persistent.co.in</ds:X509IssuerName>\n                        <ds:X509SerialNumber>10</ds:X509SerialNumber>\n                    </ds:X509IssuerSerial>\n                    <ds:X509SubjectName>CN=c-rh6-64-oaam2.persistent.co.in</ds:X509SubjectName>\n                </ds:X509Data>\n         </ds:KeyInfo>\n            <EncryptionMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#rsa-1_5\"/>\n            <EncryptionMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#aes128-cbc\"/>\n            <EncryptionMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#aes192-cbc\"/>\n            <EncryptionMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#aes256-cbc\"/>\n            <EncryptionMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#tripledes-cbc\"/>\n        </KeyDescriptor>\n        <SingleLogoutService Binding=\"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST\" Location=\"https://trialid.persistent.co.in:14101/oamfed/sp/samlv20\" ResponseLocation=\"https://trialid.persistent.co.in:14101/oamfed/sp/samlv20\"/>\n        <SingleLogoutService Binding=\"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect\" Location=\"https://trialid.persistent.co.in:14101/oamfed/sp/samlv20\" ResponseLocation=\"https://trialid.persistent.co.in:14101/oamfed/sp/samlv20\"/>\n        <AssertionConsumerService index=\"0\" isDefault=\"true\" Binding=\"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Artifact\" Location=\"https://trialid.persistent.co.in:14101/oam/server/fed/sp/sso\"/>\n        <AssertionConsumerService index=\"1\" Binding=\"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST\" Location=\"https://trialid.persistent.co.in:14101/oam/server/fed/sp/sso\"/>\n    </SPSSODescriptor>\n</EntityDescriptor>\n\n");
    saml2View
        .setEntityConfig("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<EntityConfig entityID=\"https://trialid.persistent.co.in:14101/oam/fed\" hosted=\"false\" xmlns=\"urn:sun:fm:SAML:2.0:entityconfig\">\n    <SPSSOConfig>\n        <Attribute name=\"wantLogoutResponseSigned\"/>\n        <Attribute name=\"wantAttributeEncrypted\"/>\n        <Attribute name=\"spAuthncontextMapper\"/>\n        <Attribute name=\"alwaysIdpProxy\"/>\n        <Attribute name=\"autofedAttribute\"/>\n        <Attribute name=\"spSessionSyncEnabled\"/>\n        <Attribute name=\"spAuthncontextComparisonType\"/>\n        <Attribute name=\"idpProxyList\"/>\n        <Attribute name=\"spDoNotWriteFederationInfo\"/>\n        <Attribute name=\"wantPOSTResponseSigned\"/>\n        <Attribute name=\"localAuthURL\"/>\n        <Attribute name=\"wantMNIRequestSigned\"/>\n        <Attribute name=\"spAdapterEnv\"/>\n        <Attribute name=\"basicAuthPassword\"/>\n        <Attribute name=\"transientUser\"/>\n        <Attribute name=\"cotlist\"/>\n        <Attribute name=\"spAttributeMapper\"/>\n        <Attribute name=\"saeSPUrl\"/>\n        <Attribute name=\"responseArtifactMessageEncoding\">\n            <Value>URI</Value>\n        </Attribute>\n        <Attribute name=\"useNameIDAsSPUserID\"/>\n        <Attribute name=\"wantAssertionEncrypted\"/>\n        <Attribute name=\"saml2AuthModuleName\"/>\n        <Attribute name=\"signingCertAlias\"/>\n        <Attribute name=\"relayStateUrlList\"/>\n        <Attribute name=\"appLogoutUrl\"/>\n        <Attribute name=\"useIntroductionForIDPProxy\"/>\n        <Attribute name=\"ECPRequestIDPListGetComplete\"/>\n        <Attribute name=\"attributeMap\">\n            <Value>uid=uid</Value>\n        </Attribute>\n        <Attribute name=\"spAuthncontextClassrefMapping\"/>\n        <Attribute name=\"wantMNIResponseSigned\"/>\n        <Attribute name=\"wantLogoutRequestSigned\"/>\n        <Attribute name=\"metaAlias\"/>\n        <Attribute name=\"ECPRequestIDPListFinderImpl\"/>\n        <Attribute name=\"spAccountMapper\"/>\n        <Attribute name=\"includeRequestedAuthnContext\"/>\n        <Attribute name=\"spAdapter\"/>\n        <Attribute name=\"ECPRequestIDPList\"/>\n        <Attribute name=\"saeAppSecretList\"/>\n        <Attribute name=\"idpProxyCount\"/>\n        <Attribute name=\"wantArtifactResponseSigned\"/>\n        <Attribute name=\"basicAuthOn\"/>\n        <Attribute name=\"wantNameIDEncrypted\"/>\n        <Attribute name=\"basicAuthUser\"/>\n        <Attribute name=\"saeSPLogoutUrl\"/>\n        <Attribute name=\"intermediateUrl\"/>\n        <Attribute name=\"useIDPFinder\"/>\n        <Attribute name=\"encryptionCertAlias\"/>\n        <Attribute name=\"defaultRelayState\"/>\n        <Attribute name=\"assertionTimeSkew\"/>\n        <Attribute name=\"autofedEnabled\"/>\n        <Attribute name=\"enableIDPProxy\"/>\n    </SPSSOConfig>\n</EntityConfig>\n\n");

    /*
     * Type type = new Type(); type.set_id("saml2");
     * type.setName("Entity Descriptor "); type.setCollection(true);
     * saml2View.setType(type);
     */

    return saml2View;

  }
}
