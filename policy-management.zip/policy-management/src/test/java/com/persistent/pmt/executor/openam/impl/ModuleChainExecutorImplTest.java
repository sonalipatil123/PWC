package com.persistent.pmt.executor.openam.impl;

import java.util.HashMap;

import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.constant.casm.Criteria;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.view.openam.AuthChainConfiguration;
import com.persistent.pmt.view.openam.ModuleChainView;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public class ModuleChainExecutorImplTest {

	protected RestTemplate restTemplate;

	public static void main(String[] args) {
		RestUtil rt = new RestUtil();
		StubWorkflowContextUtils data = new StubWorkflowContextUtils();
		ModuleChainExecutorImplTest moduleChainExecutorImplTest = new ModuleChainExecutorImplTest();
		try {
			moduleChainExecutorImplTest.restTemplate = rt.getRestTemplate();
		} catch (Exception e) {
		}

		WorkFlowContext context = data
				.getWorkflowContext(moduleChainExecutorImplTest.restTemplate);

		moduleChainExecutorImplTest.testCreateModuleChain(
				moduleChainExecutorImplTest, context);
		moduleChainExecutorImplTest.testDeleteModuleChain(
				moduleChainExecutorImplTest, context);
	}

	private void testCreateModuleChain(
			ModuleChainExecutorImplTest moduleChainExecutorImplTest,
			WorkFlowContext context) {
		ModuleChainView moduleChainView = stubModuleChainView();
		Application application = new Application();
		ModuleChainExecutorImpl moduleChainExecutorImpl = new ModuleChainExecutorImpl();
		moduleChainExecutorImpl.restTemplate = moduleChainExecutorImplTest.restTemplate;
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("id", "MyChain");
		params.put("realmName", "PWC");
		moduleChainExecutorImpl.create(application, moduleChainView,
				Product.OPENAM, Artifact.MODULE_CHAIN, params, context);
	}

	private ModuleChainView stubModuleChainView() {
		ModuleChainView moduleChainView = new ModuleChainView();
		AuthChainConfiguration one = new AuthChainConfiguration();
		one.setCriteria(Criteria.REQUIRED.toString());
		one.setModule("Amster");
    // one.setOptions("scope");
		AuthChainConfiguration two = new AuthChainConfiguration();
		two.setCriteria(Criteria.SUFFICIENT.toString());
		two.setModule("LDAPtoTestForAuthorization");
    // two.setOptions("options");
		AuthChainConfiguration[] authChainConfiguration = new AuthChainConfiguration[] {
				one, two };
		moduleChainView.setAuthChainConfiguration(authChainConfiguration);
		return moduleChainView;
	}

	private void testDeleteModuleChain(
			ModuleChainExecutorImplTest moduleChainExecutorImplTest,
			WorkFlowContext context) {
		ModuleChainExecutorImpl moduleChainExecutorImpl = new ModuleChainExecutorImpl();
		Application application = new Application();
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("id", "MyChain");
		params.put("realmName", "PWC");
		moduleChainExecutorImpl.restTemplate = moduleChainExecutorImplTest.restTemplate;
		moduleChainExecutorImpl.delete(application, Product.OPENAM,
				Artifact.MODULE_CHAIN, params, context);
	}

}
