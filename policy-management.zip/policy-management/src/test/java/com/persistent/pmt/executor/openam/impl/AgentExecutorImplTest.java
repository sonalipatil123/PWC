package com.persistent.pmt.executor.openam.impl;

import java.util.HashMap;

import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.view.openam.AgentView;
import com.persistent.pmt.view.openam.Attribute;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public class AgentExecutorImplTest {
	protected RestTemplate restTemplate;
	
	public static void main(String[] args) {
		StubWorkflowContextUtils data=new StubWorkflowContextUtils();
		RestUtil rt = new RestUtil();
		AgentExecutorImplTest agentExecutorImplTest = new AgentExecutorImplTest();
		try {
			agentExecutorImplTest.restTemplate = rt.getRestTemplate();
		} catch (Exception e) {
		}

		WorkFlowContext context =data.getWorkflowContext(agentExecutorImplTest.restTemplate);
    // agentExecutorImplTest.testCreateAgent(agentExecutorImplTest,
    // context);
    // agentExecutorImplTest.testDeleteAgent(agentExecutorImplTest,
    // context);
    agentExecutorImplTest.testGetAgent(agentExecutorImplTest, context);
	}

  private void testGetAgent(AgentExecutorImplTest agentExecutorImplTest, WorkFlowContext context) {
    AgentExecutorImpl agentExecutorImpl = new AgentExecutorImpl();
    agentExecutorImpl.restTemplate = agentExecutorImplTest.restTemplate;
    Application application = new Application();
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("id", "matlkmailnop013Copy");
    params.put("realmName", "PWC");
    agentExecutorImpl.get(application, Product.OPENAM, Artifact.AGENT, params, context);
  }

  private void testDeleteAgent(AgentExecutorImplTest agentExecutorImplTest,
			WorkFlowContext context) {
		AgentExecutorImpl agentExecutorImpl = new AgentExecutorImpl();
		agentExecutorImpl.restTemplate = agentExecutorImplTest.restTemplate;
		Application application = new Application();
		HashMap <String, String> params= new HashMap<String, String>();
    params.put("id", "search.pwcinternal.com1");
		params.put("realmName", "PWC");
		agentExecutorImpl.delete(application, Product.OPENAM, Artifact.AGENT, params, context);

	}

	private void testCreateAgent(AgentExecutorImplTest agentExecutorImplTest,
			WorkFlowContext wfc) {
		AgentView agentView = new AgentView();
    // agentView.setAccessDeniedUrl(new
    // Attribute(true,"accessDeniedUrl"));
    agentView.setStatus(new Attribute(false, "Active"));
		Application application = new Application();
		AgentExecutorImpl agentExecutorImpl = new AgentExecutorImpl();
		agentExecutorImpl.restTemplate = agentExecutorImplTest.restTemplate;
		HashMap <String, String> params= new HashMap<String, String>();
    params.put("id", "search.pwcinternal.com");
		params.put("realmName", "PWC");
		agentExecutorImpl.create(application, agentView, Product.OPENAM, Artifact.AGENT, params, wfc);

	}

	
}
