package com.persistent.pmt.executor.openam.impl;

import java.util.HashMap;

import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.view.openam.PolicySetView;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public class PolicySetExecutorImplTest {
	protected RestTemplate restTemplate;

	public static void main(String[] args) {
		StubWorkflowContextUtils data = new StubWorkflowContextUtils();
		RestUtil rt = new RestUtil();
		PolicySetExecutorImplTest policySetExecutorImplTest = new PolicySetExecutorImplTest();
		try {
			policySetExecutorImplTest.restTemplate = rt.getRestTemplate();
		} catch (Exception e) {
		}

		WorkFlowContext context = data
				.getWorkflowContext(policySetExecutorImplTest.restTemplate);

		policySetExecutorImplTest.testCreatePolicySet(
				policySetExecutorImplTest, context);
    // policySetExecutorImplTest.testDeletePolicySet(
    // policySetExecutorImplTest, context);

	}

	private void testDeletePolicySet(
			PolicySetExecutorImplTest policySetExecutorImplTest,
			WorkFlowContext context) {
		PolicySetExecutorImpl policySetExec = new PolicySetExecutorImpl();
		Application application = new Application();
		policySetExec.restTemplate = policySetExecutorImplTest.restTemplate;
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("id", "MyPolicySet");
		params.put("realmName", "PWC");
		policySetExec.delete(application, Product.OPENAM, Artifact.POLICY_SET,
				params, context);
	}

	private void testCreatePolicySet(
			PolicySetExecutorImplTest policySetExecutorImplTest,
			WorkFlowContext context) {
		PolicySetView policySetView = policySetExecutorImplTest
				.stubPolicySetView();
		Application application = new Application();
		PolicySetExecutorImpl policySetExec = new PolicySetExecutorImpl();
		policySetExec.restTemplate = policySetExecutorImplTest.restTemplate;
		HashMap<String, String> params = new HashMap<String, String>();
    // params.put("id", "MyPolicySet");
    params.put("id", "PWC BMS - unprotect - resources");
		params.put("realmName", "PWC");
		policySetExec.create(application, policySetView, Product.OPENAM,
				Artifact.POLICY_SET, params, context);
	}

	private PolicySetView stubPolicySetView() {
		PolicySetView policySetView = new PolicySetView();
    // policySetView.setName("MyPolicySet");
    // policySetView.setDisplayName("MyPolicySet");
    // String[] resourceTypeUuids = new String[] { "UrlResourceType"
    // };
    // policySetView.setResourceTypeUuids(resourceTypeUuids);
    // policySetView.setApplicationType("iPlanetAMWebAgentService");
		// policySetView.setRealm("/tryingToTestCopy");
    policySetView.setId(null);
    policySetView.setName("PWC BMS - unprotect - resources");
    policySetView.setDisplayName("PWC BMS - unprotect - /resources]");
    policySetView.setSubjects(new String[] { "SUBJECT_USER" });
    policySetView.setResourceTypeUuids(new String[] { "UrlResourceType" });
    policySetView.setApplicationType("iPlanetAMWebAgentService");// ("Agent");
    policySetView.setEditable("true");
    policySetView.setCreatedBy("admin");
    // policySetView.setCreationDate("2018/03/10 19:25:47");
		return policySetView;
	}

}
