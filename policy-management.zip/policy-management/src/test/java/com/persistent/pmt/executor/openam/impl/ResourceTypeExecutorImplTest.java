package com.persistent.pmt.executor.openam.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.response.openam.ResourceTypeResponse;
import com.persistent.pmt.response.openam.ResourceTypeResponseResult;
import com.persistent.pmt.view.openam.ResourceTypeView;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public class ResourceTypeExecutorImplTest {

  protected RestTemplate restTemplate;

  public static void main(String[] args) {

    StubWorkflowContextUtils data = new StubWorkflowContextUtils();
    RestUtil rt = new RestUtil();
    ResourceTypeExecutorImplTest resourceTypeExecutorImplTest =
        new ResourceTypeExecutorImplTest();
    try {
      resourceTypeExecutorImplTest.restTemplate = rt.getRestTemplate();
    }
    catch (Exception e) {
    }

    WorkFlowContext context =
        data.getWorkflowContext(resourceTypeExecutorImplTest.restTemplate);
    //resourceTypeExecutorImplTest.testCreateResourceType(resourceTypeExecutorImplTest, context);
    //resourceTypeExecutorImplTest.testDeleteResourceType(resourceTypeExecutorImplTest, context);
    resourceTypeExecutorImplTest.testGetResourceType(resourceTypeExecutorImplTest, context);
  }

  private void testGetResourceType(ResourceTypeExecutorImplTest resourceTypeExecutorImplTest,
      WorkFlowContext context) {
    ResourceTypeExecutorImpl resourceTypeExec = new ResourceTypeExecutorImpl();
    Application application = new Application();
    resourceTypeExec.restTemplate = resourceTypeExecutorImplTest.restTemplate;
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("name", "URL");
    params.put("realmName", "PWC");
    try {
    	ResourceTypeResponse object = (ResourceTypeResponse) resourceTypeExec
          .get(application, Product.OPENAM, Artifact.RESOURCE_TYPE, params, context);
    	System.out.println(object.getName());
    }
    catch (HttpClientErrorException ex) {
      System.out.println(ex.getResponseBodyAsString());
    }

  }

  private void testDeleteResourceType(
      ResourceTypeExecutorImplTest resourceTypeExecutorImplTest, WorkFlowContext context) {
    ResourceTypeExecutorImpl resourceTypeExec = new ResourceTypeExecutorImpl();
    Application application = new Application();
    resourceTypeExec.restTemplate = resourceTypeExecutorImplTest.restTemplate;
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("id", "MyResource");
    params.put("realmName", "PWC");
    resourceTypeExec.delete(application, Product.OPENAM, Artifact.RESOURCE_TYPE, params,
        context);
  }

  private void testCreateResourceType(
      ResourceTypeExecutorImplTest resourceTypeExecutorImplTest, WorkFlowContext wfc) {
    ResourceTypeView resourceTypeView = resourceTypeExecutorImplTest.stubResourceTypeView();
    Application application = new Application();
    ResourceTypeExecutorImpl resourceTypeExec = new ResourceTypeExecutorImpl();
    resourceTypeExec.restTemplate = resourceTypeExecutorImplTest.restTemplate;
    HashMap<String, String> params = new HashMap<String, String>();
    params.put("id", "MyResource");
    params.put("realmName", "PWC");
    resourceTypeExec.create(application, resourceTypeView, Product.OPENAM,
        Artifact.RESOURCE_TYPE, params, wfc);
  }

  private ResourceTypeView stubResourceTypeView() {
    ResourceTypeView resourceTypeView = new ResourceTypeView();
    Map<String, Boolean> actionMap = new HashMap<>();
    actionMap.put("read", true);
    resourceTypeView.setActions(actionMap);
    resourceTypeView.setName("ResourceTypeFromCode1");
    String[] pattern = new String[] { "/xyz" };
    resourceTypeView.setPatterns(pattern);
    return resourceTypeView;
  }

}
