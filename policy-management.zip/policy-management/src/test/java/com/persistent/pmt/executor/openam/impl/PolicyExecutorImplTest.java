package com.persistent.pmt.executor.openam.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.client.RestTemplate;

import com.persistent.pmt.constant.Product;
import com.persistent.pmt.constant.casm.Artifact;
import com.persistent.pmt.model.Application;
import com.persistent.pmt.view.openam.Condition;
import com.persistent.pmt.view.openam.PolicyView;
import com.persistent.pmt.workflow.openam.impl.WorkFlowContext;

public class PolicyExecutorImplTest {
	protected RestTemplate restTemplate;

	public static void main(String[] args) {
		StubWorkflowContextUtils data = new StubWorkflowContextUtils();
		RestUtil rt = new RestUtil();
		PolicyExecutorImplTest policyExecutorImplTest = new PolicyExecutorImplTest();
		try {
			policyExecutorImplTest.restTemplate = rt.getRestTemplate();
		} catch (Exception e) {
		}

		WorkFlowContext context = data
				.getWorkflowContext(policyExecutorImplTest.restTemplate);

		policyExecutorImplTest
				.testCreatePolicy(policyExecutorImplTest, context);
		policyExecutorImplTest
				.testDeletePolicy(policyExecutorImplTest, context);

	}

	private void testDeletePolicy(
			PolicyExecutorImplTest policyExecutorImplTest,
			WorkFlowContext context) {
		Application application = new Application();
		PolicyExecutorImpl policyExec = new PolicyExecutorImpl();
		policyExec.restTemplate = policyExecutorImplTest.restTemplate;
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("id", "MyNewPolicyInPWC");
		params.put("realmName", "PWC");
		policyExec.delete(application, Product.OPENAM, Artifact.POLICY, params,
				context);
	}

	private void testCreatePolicy(
			PolicyExecutorImplTest policyExecutorImplTest,
			WorkFlowContext context) {
		PolicyView policyView = stubPolicyView();
		Application application = new Application();
		PolicyExecutorImpl policyExec = new PolicyExecutorImpl();
		policyExec.restTemplate = policyExecutorImplTest.restTemplate;
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("id", "MyNewPolicyInPWC");
		params.put("realmName", "PWC");
		policyExec.create(application, policyView, Product.OPENAM,
				Artifact.POLICY, params, context);
	}

	private PolicyView stubPolicyView() {
		PolicyView policyView = new PolicyView();

		policyView.setName("MyNewPolicyInPWC");
		policyView.setApplicationName("TestPolicySet");
		policyView.setResourceTypeUuid("UrlResourceType");// 76656a38-5f8e-401b-83aa-4ccb74ce88d2
		policyView.setDescription("description");

		Map<String, Boolean> actionValues = new LinkedHashMap<String, Boolean>();
		actionValues.put("GET", true);
		actionValues.put("POST", true);

		policyView.setActionValues(actionValues);
		policyView.setResources(new String[] { "*://*:*/*" }); // "*://*:Admin.*","*://*:*/abc.html"

		List<Map<String, String>> l = new ArrayList<Map<String, String>>();
		Map<String, String> condAttribute1 = new HashMap<String, String>();
		condAttribute1.put("type", "LDAPFilter");
		condAttribute1.put("ldapFilter", "(uid=hello)");
    // l.add(condAttribute1);

		Map<String, String> condAttribute2 = new HashMap<String, String>();
		condAttribute2.put("type", "LDAPFilter");
		condAttribute2.put("ldapFilter", "(1=2)");
    // l.add(condAttribute2);

    // Condition condition2 = new Condition();
    // condition2.setType("OR");
    // condition2.setConditions(l);

    // Condition condtion3 = new Condition();
    // condtion3.setType("NOT");

    // List<Map<String, Object>> listCondition = new ArrayList<>();
		Map<String, Object> condAttribute3 = new HashMap<>();
		condAttribute3.put("type", "IPv4");
		condAttribute3.put("startIp", "10.80.33.207");
		condAttribute3.put("endIp", "10.80.33.207");
		condAttribute3.put("ipRange", new String[] {});
		condAttribute3.put("dnsName", new String[] {});
    // listCondition.add(condAttribute3);
    // condtion3.setConditions(listCondition);

		Condition condition = new Condition();

		condition.setType("AND");
		List conditionsTop = new ArrayList();
    // Map<String, Object> condAttribute4 = new HashMap<>();
    // condAttribute4.put("type", "Session");
    // condAttribute4.put("maxSessionTime", 20);
    // condAttribute4.put("terminateSession", false);
    // conditionsTop.add(condAttribute4);
		conditionsTop.add(condAttribute1);
		// conditionsTop.add(condition2);

		conditionsTop.add(condAttribute2);
		// conditionsTop.add(condtion3);
		conditionsTop.add(condAttribute3);
    // condition.setConditions(conditionsTop);
		policyView.setCondition(condition);

		Map<String, String> subject = new HashMap<String, String>();
		subject.put("type", "AuthenticatedUsers");
    // policyView.setSubject(subject);
		policyView.setActive(true);

		return policyView;
	}

}
