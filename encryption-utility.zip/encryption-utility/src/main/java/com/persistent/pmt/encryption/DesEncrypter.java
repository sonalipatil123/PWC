package com.persistent.pmt.encryption;


import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.commons.codec.binary.Base64;

/**
*/
public class DesEncrypter {
	/**
	 * 
	 */
	private static final String PBE_WITH_MD5_AND_DES = "PBEWithMD5AndDES";
	private Cipher ecipher;
	private Cipher dcipher;
	private static final byte[] SALT_MATRIX = { -82, -111, -55, 53, 84, 56, -27, 5 };

	/**
	 * Constructor for DesEncrypter.
	 * 
	 * @param paramString
	 *            String
	 */
	public DesEncrypter(String paramString) {
		try {
			PBEKeySpec localPBEKeySpec = new PBEKeySpec(paramString.toCharArray(), SALT_MATRIX, 19);
			SecretKey localSecretKey = SecretKeyFactory.getInstance(PBE_WITH_MD5_AND_DES).generateSecret(
					localPBEKeySpec);
			this.ecipher = Cipher.getInstance(PBE_WITH_MD5_AND_DES);
			this.dcipher = Cipher.getInstance(PBE_WITH_MD5_AND_DES);
			PBEParameterSpec localPBEParameterSpec = new PBEParameterSpec(SALT_MATRIX, 19);
			this.ecipher.init(1, localSecretKey, localPBEParameterSpec);
			this.dcipher.init(2, localSecretKey, localPBEParameterSpec);
		} catch (Exception e) {

			System.out.println("Error Occurred : " + e);
		}
	}

	/**
	 * Method encrypt.
	 * 
	 * @param paramString
	 *            String
	 * @return String
	 */
	public String encrypt(String paramString) {
		if (paramString == null) {
			return null;
		}
		try {
			byte[] arrayOfByte1 = paramString.getBytes("UTF8");
			byte[] arrayOfByte2 = this.ecipher.doFinal(arrayOfByte1);
			if (arrayOfByte2 != null) {
				byte[] arrayOfByte3 = Base64.encodeBase64(arrayOfByte2);
				return new String(arrayOfByte3);
			}

			System.out.println("Encrypted String is null");
		} catch (Exception localException) {

			System.out.println("Error occurred when encrypting input:" + paramString + " " + localException);
		}
		return null;
	}

	/**
	 * Method decrypt.
	 * 
	 * @param paramString
	 *            String
	 * @return String
	 */
	public String decrypt(String paramString) {
		if (paramString == null) {
			return null;
		}
		try {
			byte[] arrayOfByte1 = paramString.getBytes();
			if (arrayOfByte1 != null) {
				byte[] arrayOfByte2 = Base64.decodeBase64(paramString.getBytes());
				byte[] arrayOfByte3 = this.dcipher.doFinal(arrayOfByte2);
				return new String(arrayOfByte3, "UTF8");
			}

			System.out.println("Byte array of encrypted string is null");
		} catch (Exception localException) {

			System.out.println("Error occurred when decrypting input: " + localException);
		}
		return null;
	}
}
