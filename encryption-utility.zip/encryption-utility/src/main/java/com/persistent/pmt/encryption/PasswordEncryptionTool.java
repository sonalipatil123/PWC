package com.persistent.pmt.encryption;

public class PasswordEncryptionTool {
	private PasswordEncryptionTool() {
		// private
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Welcome to PMT Encryption Tool\n\n");
		//Scanner s = new Scanner(System.in);
		try {
			PasswordEncoder encode = PasswordEncoder.getInstance();
			System.out.print("Enter String to Encrypt: ");
			//String sData = s.nextLine();
			char[] sData = System.console().readPassword();
			// String sData = "Welcome1";
			if (sData != null) {
				String sEncrypted = encode.encode(new String (sData));
				if (sEncrypted != null) {
					System.out.println("Encrypted Value : " + sEncrypted);
					sEncrypted = sEncrypted.replaceAll(":", "\\\\:");
					sEncrypted = sEncrypted.replaceAll("=", "\\\\=");
					System.out.println("Properties Escaped Encrypted Value : " + sEncrypted);
				} else {
					System.err.println("Error Encrypting Data.");
				}
			}
		} catch (Exception e) {
			System.err.println("Exception occurred" + e);
		} finally {
			//s.close();
		}
	}

}
