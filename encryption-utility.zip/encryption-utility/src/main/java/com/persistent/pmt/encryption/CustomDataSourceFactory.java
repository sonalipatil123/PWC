package com.persistent.pmt.encryption;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Properties;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.naming.Context;
import javax.sql.DataSource;

import org.apache.tomcat.jdbc.pool.DataSourceFactory;
import org.apache.tomcat.jdbc.pool.PoolConfiguration;
import org.apache.tomcat.jdbc.pool.XADataSource;


public class CustomDataSourceFactory extends DataSourceFactory{
	
	PasswordEncoder decryptor= PasswordEncoder.getInstance();
	
	@Override
	public DataSource createDataSource(Properties properties, Context context,
			boolean XA) throws InvalidKeyException, IllegalBlockSizeException,
			BadPaddingException, SQLException, NoSuchAlgorithmException,
			NoSuchPaddingException {
		// Here we decrypt our password.
		PoolConfiguration poolProperties = CustomDataSourceFactory
.parsePoolProperties(properties);
		poolProperties.setPassword(decryptor.decode(poolProperties
				.getPassword()));

		// The rest of the code is copied from Tomcat's DataSourceFactory.
		if (poolProperties.getDataSourceJNDI() != null
				&& poolProperties.getDataSource() == null) {
			performJNDILookup(context, poolProperties);
		}
		org.apache.tomcat.jdbc.pool.DataSource dataSource = XA ? new XADataSource(
				poolProperties) : new org.apache.tomcat.jdbc.pool.DataSource(
				poolProperties);
		dataSource.createPool();

		return dataSource;
	}
}

