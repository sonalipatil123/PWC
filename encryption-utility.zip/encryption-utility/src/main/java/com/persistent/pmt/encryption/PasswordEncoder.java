package com.persistent.pmt.encryption;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;


public class PasswordEncoder {
	private static String sPassPhrase = "";
	private static final String ENCODING_HEADER = "{:enc::";
	private static final String ENCODING_FOOTER = "::}";
	private static PasswordEncoder mInstance = null;
	private static final String REGEX_ESCAPE = "\\\\";
	private static final String ESCAPE = "\\";

	public PasswordEncoder() {
		// empty Constructor
		try {
			sPassPhrase = new String(Hex.decodeHex("4954472050617373776f7264214023".toCharArray()));
		} catch (DecoderException e) {

			System.out.println("Error building pass phrase. Encryption maynot work." + e);
		}
	}

	/**
	 * Method decode.
	 * 
	 * @param paramString
	 *            String
	 * @return String
	 */
	public String decode(String paramString) {
		String str2 = paramString;
		if (str2 == null) {
			str2 = "";
		}
		str2 = str2.trim();
		if (str2.contains(ESCAPE)) {
			str2 = str2.replaceAll(REGEX_ESCAPE, "");
		}
		String str1;
		if (str2.startsWith(ENCODING_HEADER) && str2.endsWith(ENCODING_FOOTER)) {
			try {
				int i = str2.indexOf(ENCODING_HEADER) + ENCODING_HEADER.length();
				int j = str2.length() - ENCODING_FOOTER.length();
				str2 = str2.substring(i, j);
				DesEncrypter localDesEncrypter = new DesEncrypter(sPassPhrase);
				str1 = localDesEncrypter.decrypt(str2);
			} catch (Exception e) {

				System.out.println("Error decrypting, returning empty." + e);
				str1 = "";
			}
			if (str1 == null) {
				str1 = "";
			}
		} else {
			return str2;
		}
		return str1;
	}

	/**
	 * Method encode.
	 * 
	 * @param paramString
	 *            String
	 * @return String
	 */
	public String encode(String paramString) {
		DesEncrypter localDesEncrypter = new DesEncrypter(sPassPhrase);
		String str = localDesEncrypter.encrypt(paramString);
		if (str == null) {
			return paramString;
		}
		str = ENCODING_HEADER + str + ENCODING_FOOTER;
		return str;
	}

	/**
	 * Method getInstance.
	 * 
	 * @return PasswordEncoder
	 */
	public static PasswordEncoder getInstance() {
		if (mInstance == null) {
			mInstance = new PasswordEncoder();
		}
		return mInstance;
	}
}
