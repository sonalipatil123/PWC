USE [pmt_db_name]
--ENVIRONMENT TABLE INSERTS--
Insert into ENVIRONMENT (NAME) values ('US-DEV');
Insert into ENVIRONMENT (NAME) values ('US-STAGE');
Insert into ENVIRONMENT (NAME) values ('US-PROD');
Insert into ENVIRONMENT (NAME) values ('UK-DEV');
Insert into ENVIRONMENT (NAME) values ('UK-STAGE');
Insert into ENVIRONMENT (NAME) values ('UK-PROD');

--PROPERTY TABLE INSERTS--
--NOTE:: All the properties Listed below need to be configured for each environment present in ENVIRONMENT table::--

Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.version','resource=2.0, protocol=1.0',1,'OPENAM API Version Header. This will need to change only if OpenAm version changes.','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.version','resource=2.0, protocol=1.0',2,'OPENAM API Version Header. This will need to change only if OpenAm version changes.','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.version','resource=2.0, protocol=1.0',3,'OPENAM API Version Header. This will need to change only if OpenAm version changes.','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.version','resource=2.0, protocol=1.0',4,'OPENAM API Version Header. This will need to change only if OpenAm version changes.','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.version','resource=2.0, protocol=1.0',5,'OPENAM API Version Header. This will need to change only if OpenAm version changes.','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.version','resource=2.0, protocol=1.0',6,'OPENAM API Version Header. This will need to change only if OpenAm version changes.','TARGET');

Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.base.url','http://OpenAM_Host:OpenAM_Port/openam/json/',1,'OpenAM REST API Base url','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.base.url','http://OpenAM_Host:OpenAM_Port/openam/json/',2,'OpenAM REST API Base url','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.base.url','http://OpenAM_Host:OpenAM_Port/openam/json/',3,'OpenAM REST API Base url','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.base.url','http://OpenAM_Host:OpenAM_Port/openam/json/',4,'OpenAM REST API Base url','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.base.url','http://OpenAM_Host:OpenAM_Port/openam/json/',5,'OpenAM REST API Base url','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.api.base.url','http://OpenAM_Host:OpenAM_Port/openam/json/',6,'OpenAM REST API Base url','TARGET');

Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.admin','OpenAM_SERVICE_ACCOUNT',1,'OpenAM privileged user to invoke REST API','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.password','OpenAM_SERVICE_ACCOUNT_PASSWORD',1,'Password for OpenAM privileged user to invoke REST API','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.admin','OpenAM_SERVICE_ACCOUNT',2,'OpenAM privileged user to invoke REST API','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.password','OpenAM_SERVICE_ACCOUNT_PASSWORD',2,'Password for OpenAM privileged user to invoke REST API','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.admin','OpenAM_SERVICE_ACCOUNT',3,'OpenAM privileged user to invoke REST API','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.password','OpenAM_SERVICE_ACCOUNT_PASSWORD',3,'Password for OpenAM privileged user to invoke REST API','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.admin','OpenAM_SERVICE_ACCOUNT',4,'OpenAM privileged user to invoke REST API','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.password','OpenAM_SERVICE_ACCOUNT_PASSWORD',4,'Password for OpenAM privileged user to invoke REST API','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.admin','OpenAM_SERVICE_ACCOUNT',5,'OpenAM privileged user to invoke REST API','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.password','OpenAM_SERVICE_ACCOUNT_PASSWORD',5,'Password for OpenAM privileged user to invoke REST API','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.admin','OpenAM_SERVICE_ACCOUNT',6,'OpenAM privileged user to invoke REST API','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.password','OpenAM_SERVICE_ACCOUNT_PASSWORD',6,'Password for OpenAM privileged user to invoke REST API','TARGET');



Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.sp','OpenAM_COT_SP',1,'Circle of trust in OpenAM that hosted SP is member of.','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.idp','OpenAM_COT_IDP',1,'Circle of trust in OpenAM that hosted IdP is member of','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.sp','OpenAM_COT_SP',2,'Circle of trust in OpenAM that hosted SP is member of.','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.idp','OpenAM_COT_IDP',2,'Circle of trust in OpenAM that hosted IdP is member of','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.sp','OpenAM_COT_SP',3,'Circle of trust in OpenAM that hosted SP is member of.','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.idp','OpenAM_COT_IDP',3,'Circle of trust in OpenAM that hosted IdP is member of','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.sp','OpenAM_COT_SP',4,'Circle of trust in OpenAM that hosted SP is member of.','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.idp','OpenAM_COT_IDP',4,'Circle of trust in OpenAM that hosted IdP is member of','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.sp','OpenAM_COT_SP',5,'Circle of trust in OpenAM that hosted SP is member of.','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.idp','OpenAM_COT_IDP',5,'Circle of trust in OpenAM that hosted IdP is member of','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.sp','OpenAM_COT_SP',6,'Circle of trust in OpenAM that hosted SP is member of.','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('circle.of.trust.idp','OpenAM_COT_IDP',6,'Circle of trust in OpenAM that hosted IdP is member of','TARGET');


Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('custom.alternate.scheme','FORM',1,'Used as default authentication scheme','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('custom.alternate.scheme','FORM',2,'Used as default authentication scheme','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('custom.alternate.scheme','FORM',3,'Used as default authentication scheme','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('custom.alternate.scheme','FORM',4,'Used as default authentication scheme','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('custom.alternate.scheme','FORM',5,'Used as default authentication scheme','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('custom.alternate.scheme','FORM',6,'Used as default authentication scheme','TARGET');

Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('oauthGroupEnabled','true',1,'Decides if OAuth client group should be attaached to OAuth client','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('copyOAuthGroupProperty','true',1,'Decides if OAuth client group properties should be inherited by default','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('oauthGroupEnabled','true',2,'Decides if OAuth client group should be attaached to OAuth client','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('copyOAuthGroupProperty','true',2,'Decides if OAuth client group properties should be inherited by default','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('oauthGroupEnabled','true',3,'Decides if OAuth client group should be attaached to OAuth client','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('copyOAuthGroupProperty','true',3,'Decides if OAuth client group properties should be inherited by default','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('oauthGroupEnabled','true',4,'Decides if OAuth client group should be attaached to OAuth client','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('copyOAuthGroupProperty','true',4,'Decides if OAuth client group properties should be inherited by default','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('oauthGroupEnabled','true',5,'Decides if OAuth client group should be attaached to OAuth client','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('copyOAuthGroupProperty','true',5,'Decides if OAuth client group properties should be inherited by default','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('oauthGroupEnabled','true',6,'Decides if OAuth client group should be attaached to OAuth client','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('copyOAuthGroupProperty','true',6,'Decides if OAuth client group properties should be inherited by default','TARGET');


Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_admin_group','pmtadmin',1,'PMT Admin Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_manager_group','pmtmanager',1,'PMT Manager Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_auditor_group','pmtauditor',1,'PMT Auditor Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_admin_group','pmtadmin',2,'PMT Admin Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_manager_group','pmtmanager',2,'PMT Manager Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_auditor_group','pmtauditor',2,'PMT Auditor Group','SYSTEM');

Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_admin_group','pmtadmin',3,'PMT Admin Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_manager_group','pmtmanager',3,'PMT Manager Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_auditor_group','pmtauditor',3,'PMT Auditor Group','SYSTEM');

Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_admin_group','pmtadmin',4,'PMT Admin Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_manager_group','pmtmanager',4,'PMT Manager Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_auditor_group','pmtauditor',4,'PMT Auditor Group','SYSTEM');

Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_admin_group','pmtadmin',5,'PMT Admin Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_manager_group','pmtmanager',5,'PMT Manager Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_auditor_group','pmtauditor',5,'PMT Auditor Group','SYSTEM');

Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_admin_group','pmtadmin',6,'PMT Admin Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_manager_group','pmtmanager',6,'PMT Manager Group','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('pmt_auditor_group','pmtauditor',6,'PMT Auditor Group','SYSTEM');


Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('import_status','NOT_CONFIGURED',1,'Data Import Status','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('import_status','NOT_CONFIGURED',2,'Data Import Status','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('import_status','NOT_CONFIGURED',3,'Data Import Status','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('import_status','NOT_CONFIGURED',4,'Data Import Status','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('import_status','NOT_CONFIGURED',5,'Data Import Status','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('import_status','NOT_CONFIGURED',6,'Data Import Status','SYSTEM');

INSERT INTO PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) VALUES ('responseAttributeFetchMode','HTTP_HEADER','1','signifies responseAttributeFetchMode','SYSTEM');
INSERT INTO PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) VALUES ('responseAttributeFetchMode','HTTP_HEADER','2','signifies responseAttributeFetchMode','SYSTEM');
INSERT INTO PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) VALUES ('responseAttributeFetchMode','HTTP_HEADER','3','signifies responseAttributeFetchMode','SYSTEM');
INSERT INTO PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) VALUES ('responseAttributeFetchMode','HTTP_HEADER','4','signifies responseAttributeFetchMode','SYSTEM');
INSERT INTO PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) VALUES ('responseAttributeFetchMode','HTTP_HEADER','5','signifies responseAttributeFetchMode','SYSTEM');
INSERT INTO PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) VALUES ('responseAttributeFetchMode','HTTP_HEADER','6','signifies responseAttributeFetchMode','SYSTEM');

Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.ssl.port.regex','(.*):[1-9]*443(.*)',1,'Regex for Agent SSL','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.ssl.port.regex','(.*):[1-9]*443(.*)',2,'Regex for Agent SSL','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.ssl.port.regex','(.*):[1-9]*443(.*)',3,'Regex for Agent SSL','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.ssl.port.regex','(.*):[1-9]*443(.*)',4,'Regex for Agent SSL','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.ssl.port.regex','(.*):[1-9]*443(.*)',5,'Regex for Agent SSL','SYSTEM');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.ssl.port.regex','(.*):[1-9]*443(.*)',6,'Regex for Agent SSL','SYSTEM');

Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.server.url','http://OpenAM_Host:OpenAM_Port/openam/',1
,'OpenAM Server URL','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.server.url','http://OpenAM_Host:OpenAM_Port/openam/',2,'OpenAM Server URL','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.server.url','http://OpenAM_Host:OpenAM_Port/openam/',3,'OpenAM Server URL','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.server.url','http://OpenAM_Host:OpenAM_Port/openam/',4,'OpenAM Server URL','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.server.url','http://OpenAM_Host:OpenAM_Port/openam/',5,'OpenAM Server URL','TARGET');
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('openam.server.url','http://OpenAM_Host:OpenAM_Port/openam/',6,'OpenAM Server URL','TARGET');

Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.policy.evaluation.realm','pwc',1 ,'Policy evaluation realm of agent','TARGET'); 
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.policy.evaluation.realm','pwc',2 ,'Policy evaluation realm of agent','TARGET'); 
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.policy.evaluation.realm','pwc',3 ,'Policy evaluation realm of agent','TARGET'); 
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.policy.evaluation.realm','pwc',4 ,'Policy evaluation realm of agent','TARGET'); 
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.policy.evaluation.realm','pwc',5 ,'Policy evaluation realm of agent','TARGET'); 
Insert into PROPERTY (KEYS,VALUE,ENVIRONMENT,ALIAS,TYPE) values ('agent.policy.evaluation.realm','pwc',6 ,'Policy evaluation realm of agent','TARGET'); 


--APPLICATION_STATE TABLE INSERTS--
Insert into APPLICATION_STATE (STATE) values ('DRAFTED');
Insert into APPLICATION_STATE (STATE) values ('IMPORTED');
Insert into APPLICATION_STATE (STATE) values ('PROVISION_UPDATE');
Insert into APPLICATION_STATE (STATE) values ('READY_TO_PROVISION');
Insert into APPLICATION_STATE (STATE) values ('PROVISIONED');
Insert into APPLICATION_STATE (STATE) values ('DECOMMISSIONED');
Insert into APPLICATION_STATE (STATE) values ('COMBINED');


--Authentication Scheme--
Insert into AUTHENTICATION_SCHEME (ID,NAME,AUTHENTICATION_LEVEL,TYPE,DESCRIPTION) values ('SAML','SAML',5,'SAML','BootStrapped SAML Authentication Scheme');
Insert into AUTHENTICATION_SCHEME (ID,NAME,AUTHENTICATION_LEVEL,TYPE,DESCRIPTION) values ('OAUTH','OAUTH',4,'OAUTH','BootStrapped OAUTH Authentication Scheme');

