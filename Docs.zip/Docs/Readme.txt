Policy Migration tool README

==============================================================================================================================================================================
Build : - Milestone 4 Build (11th May, 2018)

What's included in this build?
==============================================================================================================================================================================
1. User interface features include
	1.1 Ability to view Reports & Statistics --> Import, Migration & Change History
	1.2 Ability to provision WSFED Provider in OpenAM.
2. Bug Fixes for Provision flows(Agent based, SAML Remote SP, SAML Remote IdP, OAuth)
3. Demo feedback items
	3.1 Incase FQDN is not present in an agent configuration, it is set to dummy.pwc.internal.com. The corresponding application will be provisioned as is. Audit entry will be created.
	3.2 Renaming of PMT Tabs/Screens
		3.2.1 "Import"  => "SiteMinder Policies"
		3.2.2 "Import Summary" to "SiteMinder Policy Summary"
		3.2.3 "Application details" to "SiteMinder Application Policy Details"
		3.2.4 "Application Summary" to "Policies Workbench"
	3.3 Alignment fix on Policy Comparision Screen. SiteMinder Data table moved to left.
	3.4 UI changes as suggested by Jonathan.
	
Note:
FQDN error if user tries to provision SAML SP/IDP application by converting to OAUTH. This is because all the agents of application type SAML SP/IDP do not have FQDN attribute itself. Workaround is to insert ‘fqdn’ attribute and its value manually in the AGENT_ATTRIBUTES table for the agent which belongs to that application and provision.

Known issues
==============================================================================================================================================================================
1) Rollback for Providers (/DELETE provider API) is not working as expected since Provider entityId of URL type does not work as pathId in OpenAM /DELETE API.
2) For audit record created for case “Agents not having AgentConfiguration object”, "Values for AgentName and DefaultAgentName are not present or are blank for AgentConfiguration objects with following names." and "More than one AgentConfiguration object found for Agents with following names.", some agent names are being truncated. This is because current size of context column of type varchar in table Audit_Record is 4000 bytes. A check is added to trim the context string if it’s size exceeds 4000 bytes.
3) IPAddress value similar to "AB9F3004/20" in SiteMinder Policy Data has not been processed.
==============================================================================================================================================================================
==============================================================================================================================================================================
Build : - Milestone 3 Build (16th April, 2018)

What's included in this build?
==============================================================================================================================================================================
1. Next build of the Policy Management Tool, which is composed of RESTful APIs, NodeJS & AngularJS based User Interface and utilities
2. User interface features include
	2.1 Ability to update application on 'Application Details' screen(opened from 'Application Summary' screen).
		2.1.1 Name, Description & Authentication Policy can be updated.
		2.1.2 On updating authentication policy to SAML, Provider information will be requested and on update, Provider will be created in PMT Database.
		2.1.3 On updating authentication policy to OAUTH, OAuth Client information will be requested and on update, Oauth Client will be created in PMT Database.
	2.2 Ability to compare application to be provisioned with application imported from Siteminder data.
	2.3 Ability to 'Provision' application to OpenAM.
	2.4 Ability to search application in 'Application Summary' and 'Import Summary' page based on Application Name, Domain Name or Agent Name
3. REST API to support all different features listed above
4. Support for TLS, Encrypted Passwords for LDAP and OpenAM connection

Known issues
==============================================================================================================================================================================
1) Getting error as CSRF Token Missing when user re-logins after keeping PMT application IDLE for 20-25 mins. Workaround is to close the browser and reopen.
2) Provision for WSFED Provider in OpenAM is not working. Persistent team is in discussion with PwC team.
3) Decryption of encrypted password for Tomcat JDBC connection is not working with Tomcat 8.5 onwards
4) Currently, user without any role is logged in and then logged out. However, user should not be logged in, in the first place.
5) Rollback for Providers (/DELETE provider API) is not working as expected since Provider entityId of URL type does not work as pathId in /DELETE API.

==============================================================================================================================================================================
==============================================================================================================================================================================

Build : - Milestone 2 incremental build

What's included in this build?
==============================================================================================================================================================================
1. First build of the Policy Management Tool, which is composed of RESTful APIs, NodeJS & AngularJS based User Interface and utilities
2. User interface features include
	2.1 Login and ability to select environment during login
	2.2 Ability to switch between environments
	2.3 Admin, Migration Manager and Auditor roles based access
	2.4 Ability to update OpenAm Target Server Configuration 
	2.5 Ability to initiate "Import" from SiteMinder data
	2.6 Ability to view details of imported application in SiteMinder format
	2.7 Ability to choose only required application to prepare for migration
	2.8 Ability to view application policy in generic grammar supported by PMT tool
	2.9 Ability to search application in "Application Summary" page based on Application Name, Domain Name or Agent Name
	3.0 Dashboard showing environment specific statistics of application policies
3. REST API to support all different features listed above
4. Support for MS SQL Server

Known issues
==============================================================================================================================================================================
1)	After importing policy data using policy XML data file. Some of the Applications are added into the APPLICATION table with Environment ID as NULL.
2)	Data issue. Resource of protected Realm marked as Anonymous. Domain name - Spanish Integrations.
3)	In case import from Policy XML data file fails then no message appears on the Import Summary screen. Though user can find out the status on Reports page
4)	Search is currently not integrated on Import Summary Page
5)	Environment drop down for switching between the environment is not working in IE (intermittent issue).
6)  This build does not contain support for TLS, Encrypted Passwords

	
