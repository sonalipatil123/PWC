#!/bin/bash

# This utility splits policy data xml into individual files for each object types

echo $#
if [ $# -ne 2 ] 
then
echo "----------------------------------------------------------------------------------------------------------------"
	echo "Usage: Run this script from the location where Policy Migration Tool package is extracted."
	echo "Make sure that policy data xml is placed in working location under sub folder with same name as that of environment."
	echo "Policy data xml file name must follow convention <environment name>_policydata.xml"
	echo "./splitPolicyDataXML.sh <Policy Data XML file path> <Environment Identifier. ex US-DEV>"
echo "----------------------------------------------------------------------------------------------------------------"
        exit 1
fi

objectTypesFile="SiteMinderObjectTypes.txt"

if [ ! -f $objectTypesFile ]; then
    echo "Run this script from the location where Policy Migration Tool package is extracted"
    exit 1
fi


if [ ! -f $1 ]; then
    echo "Path $1 either does not exist or not a file."
    exit 1
fi

cmd="sed -i 's/\" CreatedDateTime=/-$2\" CreatedDateTime=/g' $1" 
eval $cmd
cmd="sed -i 's/<\/XID>/-$2<\/XID>/g' $1"
eval $cmd
splitLocation=`dirname $1`
echo "Files will be created at location $splitLocation for each SiteMinder Object type"
while read p; do
 echo "Parsing all objets of type $p"
fName=`echo $p | cut -d':' -f 1,3 | tr ":" "_"|tr "." "_"` 
echo "<root>" >$splitLocation/$fName.xml
cmd=`echo "sed -n '/Object Class=\"$p\"/,/Object><!-- Xid=\"$p@/p' $1  >>$splitLocation/$fName.xml"`
eval $cmd
echo "</root>" >>$splitLocation/$fName.xml
done <SiteMinderObjectTypes.txt
sed -n '/<References>/,/<\/References>/p' $1 >$splitLocation/CA_SM_References.xml

cmd=` echo "cat $splitLocation/CA_SM_Domain.xml |grep -A 2 AgentTypeLink| grep XID | sort | uniq | cut -d'>' -f 2| cut -d'<' -f1 >/tmp/usedAgentTypes.txt"`
eval $cmd
while read p; do
cmd=`echo "cat $splitLocation/CA_SM_AgentType.xml | grep -A 40 $p | grep -A 2 \"CA.SM::AgentType.Name\" | grep \"<StringValue>\" | head -1"`
echo "AgentType for $p is"
eval $cmd
done </tmp/usedAgentTypes.txt
cmd=` echo "cat $splitLocation/CA_SM_Domain.xml |grep -A 2 AgentTypeAttrLink| grep XID | sort | uniq | cut -d'>' -f 2| cut -d'<' -f1 >/tmp/usedAgentTypeAttrs.txt"`
eval $cmd
while read p; do
cmd=`echo "cat $splitLocation/CA_SM_AgentTypeAttr.xml | grep -A 40 $p | grep -A 2 \"CA.SM::AgentTypeAttr.Name\" | grep \"<StringValue>\" | head -1 | grep "WebAgent""`
echo $p
eval $cmd
done </tmp/usedAgentTypeAttrs.txt

