package com.pwc.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.pwc.req.Property;



public class GenericObject extends AbstractTag{

	private List<Property> propertyList = new ArrayList<>();
	private List<GenericObject> subObjectList = new ArrayList<>();

	public List<Property> getPropertyList() {
		return propertyList;
	}

	public List<GenericObject> getSubObjectList() {
		return subObjectList;
	}

	@Override
	public String toString() {
		return "PolicyObject " + super.toString() + " [propertyList=" + propertyList
				+ ", subObjectList=" + subObjectList + "]";
	}

	
	
}
