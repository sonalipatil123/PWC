package com.pwc.model;

import java.util.HashMap;
import java.util.Map;

	public abstract class AbstractTag {

		private Map<String, String> attributes = new HashMap<String, String>();

		public Map<String, String> getAttributes() {
			return attributes;
		}
		
		@Override
		public String toString() {
			return "[attributes=" + attributes + "]";
		}
		
	}


