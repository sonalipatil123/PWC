package com.pwc.req;

import com.pwc.model.AbstractTag;

public class Property extends AbstractTag{
	
	private String Name;
    private String numberValue;
    private String stringValue;
    private String booleanValue;	
    private LinkValue linkValue;
    public String getName ()
    {
        return Name;
    }

    public String getStringValue() {
		return stringValue;
	}

	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}

	public String getBooleanValue() {
		return booleanValue;
	}

	public void setBooleanValue(String booleanValue) {
		this.booleanValue = booleanValue;
	}

	public void setName (String Name)
    {
        this.Name = Name;
    }

    public String getNumberValue ()
    {
        return numberValue;
    }

    public void setNumberValue (String NumberValue)
    {
        this.numberValue = NumberValue;
    }

	public LinkValue getLinkValue() {
		return linkValue;
	}

	public void setLinkValue(LinkValue linkValue) {
		this.linkValue = linkValue;
	}

	@Override
	public String toString() {
		return "Property [Name=" + Name + ", numberValue=" + numberValue + ", stringValue=" + stringValue
				+ ", booleanValue=" + booleanValue + ", linkValue=" + linkValue + "]";
	}

	

}
