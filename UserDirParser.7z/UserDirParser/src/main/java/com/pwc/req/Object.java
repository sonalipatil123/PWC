package com.pwc.req;

import java.util.ArrayList;
import java.util.List;

public class Object
{
    private String ExportType;

    private String ClassName;

    private String CreatedDateTime;

    private String ModifiedDateTime;

    private String UpdateMethod;

    private String UpdatedBy;

    private List<Property> propertylist=new ArrayList<Property>();


    public String getExportType ()
    {
        return ExportType;
    }

    public void setExportType (String ExportType)
    {
        this.ExportType = ExportType;
    }

  

    public String getCreatedDateTime ()
    {
        return CreatedDateTime;
    }

    public void setCreatedDateTime (String CreatedDateTime)
    {
        this.CreatedDateTime = CreatedDateTime;
    }

    public String getModifiedDateTime ()
    {
        return ModifiedDateTime;
    }

    public void setModifiedDateTime (String ModifiedDateTime)
    {
        this.ModifiedDateTime = ModifiedDateTime;
    }

    public String getUpdateMethod ()
    {
        return UpdateMethod;
    }

    public void setUpdateMethod (String UpdateMethod)
    {
        this.UpdateMethod = UpdateMethod;
    }

    public String getUpdatedBy ()
    {
        return UpdatedBy;
    }

    public void setUpdatedBy (String UpdatedBy)
    {
        this.UpdatedBy = UpdatedBy;
    }

    	  
    public List<Property> getPropertylist() {
		return propertylist;
	}

	public void setPropertylist(List<Property> propertylist) {
		this.propertylist = propertylist;
	}

	
	public String getClassName() {
		return ClassName;
	}

	public void setClassName(String className) {
		ClassName = className;
	}

	@Override
	public String toString() {
		return "Object [ExportType=" + ExportType + ", ClassName=" + ClassName + ", CreatedDateTime=" + CreatedDateTime
				+ ", ModifiedDateTime=" + ModifiedDateTime + ", UpdateMethod=" + UpdateMethod + ", UpdatedBy="
				+ UpdatedBy + ", propertylist=" + propertylist + "]";
	}
	
	
	
}
			
			