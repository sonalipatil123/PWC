package com.pwc.utils;

public class XmlTagConstants {

	//Constants for tag names in CA Siteminder
	public static final String POLICY_DATA = "PolicyData";
	public static final String REFERENCES = "References";
	public static final String REFERENCE_VALUE = "ReferenceValue";
    public static final String STRING_VALUE = "StringValue";
    public static final String OBJECT = "Object";
    public static final String PROPERTY = "Property";
    public static final String LINK_VALUE = "LinkValue";
    public static final String XID = "XID";
    public static final String XREF = "xref";
    public static final String NUMBER_VALUE = "NumberValue";
    public static final String BOOLEAN_VALUE = "BooleanValue";
    
}
