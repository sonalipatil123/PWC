package com.pwc.bean;

public class UserDirectory {
	

private Object[] Object;

public Object[] getObject ()
{
return Object;
}

public void setObject (Object[] Object)
{
this.Object = Object;
}

@Override
public String toString()
{
return "UserDirectory [Object = "+Object+"]";
}
}



