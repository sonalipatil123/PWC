package com.pwc.parser;

import java.util.List;

import com.pwc.model.AbstractTag;



public interface GenericXMLParser {

	public List<? extends AbstractTag> parse(String fileName);
}
