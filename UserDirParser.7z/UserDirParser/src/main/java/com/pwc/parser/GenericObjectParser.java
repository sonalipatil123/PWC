package com.pwc.parser;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import com.pwc.model.GenericObject;
import com.pwc.req.LinkValue;
import com.pwc.req.Property;
import com.pwc.utils.XmlTagConstants;



public class GenericObjectParser implements GenericXMLParser {

	@Override
	@SuppressWarnings("restriction")
	public List<GenericObject> parse(String fileName) {

   	   List<GenericObject> objectList = new ArrayList<GenericObject>();
   	   int counter = 0;
       GenericObject policyObject;
        
       try {
           // First, create a new XMLInputFactory
           XMLInputFactory inputFactory = XMLInputFactory.newInstance();
           // Setup a new eventReader
           InputStream in = new FileInputStream(fileName);
           XMLEventReader eventReader = inputFactory.createXMLEventReader(in);
           // read the XML document          
                   
           while (eventReader.hasNext()) {
           	
               XMLEvent event = eventReader.nextEvent();
               
               if (event.isStartElement()) {
                   StartElement startElement = event.asStartElement();
                   String tagName = startElement.getName().getLocalPart();
                                    
                   if (tagName.equals(XmlTagConstants.OBJECT)) {
                   	
                   	policyObject = parseObject(eventReader, event);
                   	objectList.add(policyObject);
                   	counter++;
                   }               
               }
               // If we reach the end of an item element, we add it to the list
               if (event.isEndElement()) {
                   EndElement endElement = event.asEndElement();
                   String tagName = endElement.getName().getLocalPart();
                   
                    if (tagName.equals(XmlTagConstants.OBJECT)) {                    	
                   	continue;
                   }               
               }
           }
       } catch (FileNotFoundException e) {
           e.printStackTrace();
       } catch (XMLStreamException e) {
           e.printStackTrace();
       } 
       System.out.println("Number of Objects: " + counter);
       return objectList;
   }
   
   
   @SuppressWarnings({"unchecked", "restriction"})
	private GenericObject parseObject(XMLEventReader eventReader, XMLEvent currectEvent) throws XMLStreamException {
   	
	   	GenericObject policyObject = new GenericObject();
	   	Property property = new Property();
	   	LinkValue linkValue = new LinkValue();
	   	StartElement firstElement = currectEvent.asStartElement();
   	
   		Iterator<Attribute> objectAttributes = firstElement.getAttributes();
        while (objectAttributes.hasNext()) {
            Attribute objectAttribute = objectAttributes.next();
            policyObject.getAttributes().put(objectAttribute.getName().toString(), objectAttribute.getValue());
        }  
   	
        while(eventReader.hasNext()) {
   		
   		XMLEvent event = eventReader.nextEvent();
   		if (event.isStartElement()) {
            StartElement startElement = event.asStartElement();
            String tagName = startElement.getName().getLocalPart();
            
            switch(tagName) {
            
            	case XmlTagConstants.PROPERTY: 
            		property = new Property();
	                Iterator<Attribute> attributes = startElement.getAttributes();
	                while (attributes.hasNext()) {
	                    Attribute attribute = attributes.next();
	                    property.getAttributes().put(attribute.getName().toString(), attribute.getValue());
	                } 
	                break;
	            
            	case XmlTagConstants.LINK_VALUE:
            		 linkValue = new LinkValue();   
            		 break;
            	
            	case XmlTagConstants.NUMBER_VALUE:
            		 event = eventReader.nextEvent();
	            	 property.setNumberValue(event.asCharacters().getData());
	            	 break;
	            	 
            	case XmlTagConstants.BOOLEAN_VALUE:
            		 event = eventReader.nextEvent();
	            	 property.setBooleanValue(event.asCharacters().getData());
	            	 break;
	            
            	/*case STRING_VALUE:
            		 event = eventReader.nextEvent();
	            	 property.setStringValue(event.asCharacters().getData());
	            	 break;*/
	            	 		 
            	case XmlTagConstants.XREF:
            		 event = eventReader.nextEvent();
            		 linkValue.setXREF(event.asCharacters().getData());
	            	 break;
	            	 
            	case XmlTagConstants.XID:
            		 event = eventReader.nextEvent();
            		 linkValue.setXID(event.asCharacters().getData());
	            	 break;
	            	 	            	           	 
            	case XmlTagConstants.OBJECT:
            		 GenericObject subObject = parseObject(eventReader, event);
	            	 policyObject.getSubObjectList().add(subObject);
	            	 break;

            	default: continue;	            		
            }	                            
    	} else if (event.isEndElement()) {
    		
            EndElement endElement = event.asEndElement();
            String tagName = endElement.getName().getLocalPart();
            
            if (tagName.equals(XmlTagConstants.PROPERTY)) {
            	policyObject.getPropertyList().add(property);                   	
            }
            else if (tagName.equals(XmlTagConstants.LINK_VALUE)) {
            	property.setLinkValue(linkValue);                   	
            }
            else if (tagName.equals(XmlTagConstants.OBJECT)) {
            	break;	            	
            }                
         }	
      }     	
      return policyObject;
   }

}